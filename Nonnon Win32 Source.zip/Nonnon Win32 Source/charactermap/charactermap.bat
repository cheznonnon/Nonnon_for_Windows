
@echo off

set compile=..\nonnon\project\compile.bat
set    name=charactermap
set  window=-mwindows

%compile%

