
@echo off

set compile=..\nonnon\project\compile.bat
set    name=combobox
set  window=-mwindows

%compile%

