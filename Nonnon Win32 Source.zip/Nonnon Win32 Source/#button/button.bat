
@echo off

set compile=..\nonnon\project\compile.bat
set    name=button
set  window=-mwindows

%compile%

