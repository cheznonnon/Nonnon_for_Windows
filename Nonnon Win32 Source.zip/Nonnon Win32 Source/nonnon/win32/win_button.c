// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_BUTTON
#define _H_NONNON_WIN32_WIN_BUTTON




#include "../neutral/bmp/fade.c"


#include "./gdi/doublebuffer_32bpp.c"
#include "./uxtheme.c"
#include "./win.c"




typedef struct {

	// [!] : internal

	HWND         hwnd;

	n_uxtheme    uxtheme;
	n_posix_bool is_classic;

	n_bmp_fade   fade;
	n_posix_bool fade_onoff;
	UINT         fade_timer_id;

	int          state;

	n_posix_bool active_onoff;
	n_posix_bool   sink_onoff;
	n_posix_bool    hot_onoff;
	n_posix_bool   hide_onoff;

	DWORD        init_timeout;

	n_posix_bool maclike_onoff;
	n_type_gfx   maclike_offset;


	// [!] : option : you can set these directly

	HICON        hicon;

	n_posix_bool select_onoff;
	n_posix_bool default_onoff;

	n_posix_bool keep_on_pressing;

	n_posix_bool bmp_backup_onoff;
	n_bmp        bmp;

} n_win_button;




static n_posix_bool n_win_button_printclient_onoff = n_posix_false;




#define n_win_button_zero( p ) n_memory_zero( p, sizeof( n_win_button ) )

void
n_win_button_debug_state( n_win_button *p, int pbs )
{

	n_posix_char *str = N_STRING_EMPTY;

	if ( pbs == PBS_NORMAL   ) { str = n_posix_literal( "PBS_NORMAL"   ); }
	if ( pbs == PBS_HOT      ) { str = n_posix_literal( "PBS_HOT"      ); }
	if ( pbs == PBS_DISABLED ) { str = n_posix_literal( "PBS_DISABLED" ); }
	if ( pbs == PBS_PRESSED  ) { str = n_posix_literal( "PBS_PRESSED"  ); }

	n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), " %s ", str );


	return;
}

void
n_win_button_box( HWND hwnd, HDC hdc, RECT *rect, COLORREF color )
{

	//n_win_box( hwnd, hdc, rect, color );

	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

	u32 argb = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color ) );

	n_bmp_box( bmp, x,y,sx,sy, argb );


	return;
}

n_posix_bool
n_win_button_is_enabled( n_win_button *p )
{
	return p->active_onoff;
}

void
n_win_button_fade_go( n_win_button *p )
{

	u32 color;
	if ( p->fade.color_fg == n_bmp_white )
	{
		color = n_bmp_black;
	} else {
		color = n_bmp_white;
	}

	p->fade.stop = n_posix_true;

	n_bmp_fade_go( &p->fade, color );

	n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );


	return;
}

void
n_win_button_move( n_win_button *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	if ( p->maclike_onoff )
	{
		n_type_gfx o = p->maclike_offset + 1;

		 x -= o;
		 y -= o;
		sx += o * 2;
		sy += o * 2;

		n_win_move( p->hwnd, x,y,sx,sy, redraw );
	} else {
		n_win_move( p->hwnd, x,y,sx,sy, redraw );
	}


	return;
}

void
n_win_button_move_toolband( n_win_button *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	if ( p->maclike_onoff )
	{
		n_type_gfx o = p->maclike_offset + 1;

		 x -= o;
		 y -= o;
		sx += o * 2;
		sy += o * 2;

		n_win_move       ( p->hwnd, x,y,sx,sy, redraw );
	} else {
		n_win_move_simple( p->hwnd, x,y,sx,sy, redraw );
	}


	return;
}

void
n_win_button_draw_background
(
	n_win_button *p,
	       n_bmp *bmp,
	  n_type_gfx  sx,
	  n_type_gfx  sy,
	  n_type_gfx  frame,
	  n_type_gfx  round,
	         u32  color_main,
	         u32  color_border,
	         int  state
)
{
//return;

	n_posix_bool patch_prev = n_bmp_roundrect_detect_coeff_patch_onoff;
	n_bmp_roundrect_detect_coeff_patch_onoff = n_posix_false;


	u32 color_bg = n_win_cornercolor_get( p->hwnd );
	u32 color_bd = color_border;


	n_bmp_flush( bmp, color_bg );
//return;

	n_type_gfx  ox = 0;
	n_type_gfx  oy = 0;
	n_type_gfx osx = sx;
	n_type_gfx osy = sy;


	n_type_gfx o = 0;

	if ( p->maclike_onoff )
	{

		o = p->maclike_offset;

		if (
			( state == PBS_HOT )
			||
			( ( state == PBS_PRESSED )&&( p->sink_onoff ) )
		)
		{

			color_bd = n_win_dwm_windowcolor_arranged();

			n_type_real step = ( 1.0 / o );

			n_type_real ratio;
			if ( n_win_darkmode_onoff )
			{
				ratio = 0.66;
			} else {
				ratio = 0.33;
			}

			n_type_gfx i = 0;
			n_posix_loop
			{
				n_type_gfx  xx = ox + i;
				n_type_gfx  yy = oy + i;
				n_type_gfx sxx = osx - ( i * 2 );
				n_type_gfx syy = osy - ( i * 2 );

				u32 clr = n_bmp_blend_pixel( color_bg, color_bd, (n_type_real) step * i * ratio );
				n_bmp_roundrect_pixel( bmp, xx,yy,sxx,syy, clr, round );

				i++;
				if ( i >= o ) { break; }
			}

		}

	} else {

		o = -1;

	}

	 ox += o;
	 oy += o;
	osx -= o * 2;
	osy -= o * 2;

	n_bmp_ui_roundframe( bmp, ox,oy,osx,osy, round, frame, color_border, color_main );
	//n_bmp_cornermask( bmp, round, 0, corner );


	n_bmp_roundrect_detect_coeff_patch_onoff = patch_prev;


	return;
}

COLORREF
n_win_button_draw_hot_color( n_win_button *p )
{

	u32 ret;


	u32 f = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE );

	u32 t;
	if ( n_win_darkmode_onoff )
	{
		t = n_win_darkmode_systemcolor_colorref2argb( COLOR_HIGHLIGHT );
	} else {
		t = n_win_dwm_windowcolor_arranged();
	}

	u32 c = n_bmp_blend_pixel( f, t, 0.33 );

	ret = n_bmp_argb2colorref( c );


	return ret;
}

COLORREF
n_win_button_draw_pressed_color( n_win_button *p )
{

	u32 ret;


	u32 f = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE    );
	u32 t = n_win_darkmode_systemcolor_colorref2argb( COLOR_3DDKSHADOW );

	u32 c = n_bmp_blend_pixel( f, t, 0.25 );

	ret = n_bmp_argb2colorref( c );


	return ret;
}

void
n_win_button_draw( n_win_button *p, HDC hdc_override, RECT *rect_arg )
{

	if ( p->hide_onoff ) { return; }


	if ( n_win_button_printclient_onoff == n_posix_false )
	{
		if ( n_posix_false == IsWindow       ( p->hwnd ) ) { return; }
		if ( n_posix_false == IsWindowVisible( p->hwnd ) ) { return; }
	}


	RECT  rect_null;
	RECT *rect;

	if ( rect_arg != NULL )
	{
		rect = rect_arg;
	} else {
		GetClientRect( p->hwnd, &rect_null );
		rect = &rect_null;
	}


	n_type_gfx sx,sy; n_win_rect_expand_size( rect, NULL, NULL, &sx, &sy );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d", sx, sy );


	// [x] : flicker prevention : n_gdi_doublebuffer_32bpp_simple_init() only

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx,sy );


	// [!] : Metrics

	n_type_gfx scale       = (n_type_gfx) trunc( n_win_scale( p->hwnd ) );
	n_type_gfx offset_sink = scale;

	int edge = EDGE_RAISED;
	int   bf = BF_RECT;
	int   bp = BP_PUSHBUTTON;
	int  pbs = p->state;

	DWORD style = n_win_style_get( p->hwnd );
	if ( style & BS_FLAT )
	{
		// [!] : BF_FLAT == WS_BORDER

		edge = EDGE_RAISED;
		bf   = bf | BF_MONO;
	}

	if ( p->select_onoff )
	{
		// [!] : Nonnon original behavior

		edge = EDGE_SUNKEN;
		bf   = bf & ~BF_MONO;

		if ( ( pbs != PBS_HOT )&&( pbs != PBS_PRESSED ) )
		{
			//pbs = PBS_PRESSED;
			offset_sink = 0;
		}

	}

	if ( p->state == PBS_PRESSED )
	{
		edge = EDGE_SUNKEN;
	}


	if ( p->active_onoff == n_posix_false )
	{
		pbs = PBS_DISABLED;
	}


	// Main

	n_posix_bool is_drawedge = n_posix_false;
/*
	if ( 1 )
	{
		// [!] : for debugging
	} else
*/
	if (
		( n_win_fluent_ui_onoff == n_posix_false )
		&&
		( n_win_darkmode_onoff )
	)
	{

		COLORREF base = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE   );
		COLORREF brdr = n_win_darkmode_systemcolor_ui( COLOR_BTNHIGHLIGHT );

		if ( pbs == PBS_HOT      ) { base = n_win_darkmode_systemcolor_ui( COLOR_BTNHIGHLIGHT ); }
		if ( pbs == PBS_DISABLED ) { base = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW    ); }
		if ( pbs == PBS_PRESSED  ) { base = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT    ); }

		if ( pbs == PBS_HOT      ) { brdr = n_win_color_blend( brdr, RGB( 255,255,255 ), 0.5 ); }

		n_type_gfx b = scale;
		RECT rect_inner = n_win_rect_set( NULL, b,b,sx-(b*2),sy-(b*2) );

		n_win_button_box( p->hwnd, hdc,  rect      , brdr );
		n_win_button_box( p->hwnd, hdc, &rect_inner, base );

	} else
	if (
//(1)
//
//(0)&&
		(
			( n_win_fluent_ui_onoff == n_posix_false )
			&&
			( p->uxtheme.onoff )
		)
		||
		(
			( n_win_fluent_ui_onoff != N_WIN_FLUENT_UI_OVERRIDE )
			&&
			( p->uxtheme.onoff )
			&&
			( n_posix_false == n_sysinfo_version_8_or_later() )
		)
//
	)
	{

/*
		if (
			( p->uxtheme.longhorn )
			&&
			( p->uxtheme.IsThemeBackgroundPartiallyTransparent( p->uxtheme.htheme, bp, pbs ) )
		)
*/		{

			n_posix_bool bg_onoff = n_win_property_get_literal( p->hwnd, "Background.OnOff" );

			if ( bg_onoff == n_posix_false )
			{
				p->uxtheme.DrawThemeParentBackground( p->hwnd, hdc, rect );
			} else {
				n_win_button_box( p->hwnd, hdc, rect, n_win_darkmode_systemcolor_ui( COLOR_BTNFACE ) );
			}

		}


		int state_f = n_win_property_get_literal( p->hwnd, "State" );

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, bp, state_f, rect, NULL );

		n_bmp bmp_f; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_f );


		int state_t = pbs;

		p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, bp, state_t, rect, NULL );

		n_bmp bmp_t; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_t );


		//n_bmp_alpha_visible( &bmp_f );
		//n_bmp_alpha_visible( &bmp_t );


		n_type_real ratio = (n_type_real) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_32bpp_instance.bmp );


		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );

	} else
	if (
//(0)&&
		( n_win_fluent_ui_onoff )
	)
	{

		// [!] : shared

		u32 corner = n_win_cornercolor_get( p->hwnd );

//n_win_debug_count( n_win_hwnd_toplevel( p->hwnd ) );

		n_type_gfx round = n_win_fluent_ui_round_param( p->hwnd );
		n_type_gfx frame = (n_type_gfx) trunc( n_win_scale( p->hwnd ) );


		int state_f = n_win_property_get_literal( p->hwnd, "State" );
		int state_t = pbs;

//n_win_button_debug_state( p, state_t );


		COLORREF color_f = 0;

		if ( state_f == PBS_NORMAL   ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE    ); }
		if ( state_f == PBS_HOT      ) { color_f = n_win_button_draw_hot_color( p ); }
		if ( state_f == PBS_DISABLED ) { color_f = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  ); }
		if ( state_f == PBS_PRESSED  ) { color_f = n_win_button_draw_pressed_color( p ); }


		COLORREF color_t = 0;

		if ( state_t == PBS_NORMAL   ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE    ); }
		if ( state_t == PBS_HOT      ) { color_t = n_win_button_draw_hot_color( p ); }
		if ( state_t == PBS_DISABLED ) { color_t = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  ); }
		if ( state_t == PBS_PRESSED  ) { color_t = n_win_button_draw_pressed_color( p ); }


		corner = n_bmp_alpha_visible_pixel( corner );

		if (
			( n_win_dwm_is_on() )
			&&
			( n_win_darkmode_onoff == n_posix_false )
		)
		{
			if ( n_win_property_get_literal( p->hwnd, "Toolband" ) )
			{
				corner = 0;
			}
		}


		u32 color_main_f = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_f ) );
		u32 color_main_t = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_t ) );


		u32 color_border_base;

		if ( n_win_darkmode_onoff )
		{
			color_border_base = n_bmp_white;
		} else {
			color_border_base = n_bmp_rgb( 1,1,1 );
		}

		u32 color_border_f;
		u32 color_border_t;

		if ( ( p->select_onoff )||( p->default_onoff ) )
		{
			color_border_f = n_win_dwm_windowcolor_arranged();
		} else {
			color_border_f = n_bmp_blend_pixel( color_main_f, color_border_base, 0.25 );
		}

		if ( ( p->select_onoff )||( p->default_onoff ) )
		{
			color_border_t = n_win_dwm_windowcolor_arranged();
		} else {
			color_border_t = n_bmp_blend_pixel( color_main_t, color_border_base, 0.25 );
		}


		// [!] : test

		//u32 border = n_win_color_blend( color_t, RGB( 0,0,0 ), 0.25 );
		//n_type_gfx s = scale / 2; 

		//n_win_fluent_ui_draw_roundrect( hdc_override, x  ,y  ,sx      ,sy      , round, border , 1.0 );
		//n_win_fluent_ui_draw_roundrect( hdc_override, x+s,y+s,sx-(s*2),sy-(s*2), round, color_t, 1.0 );


		// [!] : from

//if(round){}

		n_type_gfx frame_f = frame;
		if ( ( p->select_onoff )||( p->default_onoff ) ) { frame_f *= 2; }

		n_bmp bmp_f; n_bmp_zero( &bmp_f ); n_bmp_1st_fast( &bmp_f, sx,sy );

//n_bmp_flush( &bmp_f, color_f );

		n_win_button_draw_background
		(
			p,
			&bmp_f,
			sx,
			sy,
			frame_f,
			round,
			color_main_f,
			color_border_f,
			state_f
		);


		// [!] : To

		n_type_gfx frame_t = frame;
		if ( ( p->select_onoff )||( p->default_onoff ) ) { frame_t *= 2; }

		n_bmp *bmp_t = &n_gdi_doublebuffer_32bpp_instance.bmp;

//n_bmp_flush( bmp_t, color_t );

		n_win_button_draw_background
		(
			p,
			bmp_t,
			sx,
			sy,
			frame_t,
			round,
			color_main_t,
			color_border_t,
			state_t
		);


		// [!] : draw engine

		n_type_real ratio = (n_type_real) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, bmp_t, ratio );


		// [!] : cleaup

		n_bmp_free_fast( &bmp_f );

	} else {

		n_win_button_box( p->hwnd, hdc, rect, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );

		DrawEdge( hdc, rect, edge, bf );

		n_posix_bool is_toolband = n_win_property_get_literal( p->hwnd, "Toolband" );

		if ( is_toolband )
		{
			n_bmp_alpha_visible( &n_gdi_doublebuffer_32bpp_instance.bmp );
		}

		is_drawedge = n_posix_true;

	}


	{
		n_type_gfx c = 3;

		ExcludeClipRect( hdc,    0,   0,sx, c );
		ExcludeClipRect( hdc,    0,sy-c,sx,sy );
		ExcludeClipRect( hdc,    0,   0, c,sy );
		ExcludeClipRect( hdc, sx-c,   0,sx,sy );
	}


	// Text or Icon

/*
	if ( 1 )
	{
		// [!] : for checking performance
	} else
*/
	if ( p->hicon == NULL )
	{

		RECT r = { 0, 0, sx, sy };

		if ( p->sink_onoff )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			n_type_gfx o = offset_sink;

			if (
				( is_drawedge )
				||
				( p->uxtheme.onoff == n_posix_false )
			)
			{
				n_win_rect_move( &r, o, o );
			} else
			if ( p->uxtheme.longhorn )
			{
				n_win_rect_move( &r, 0, o );
			} else {
				n_win_rect_move( &r, o, o );
			}
		}


		int part, state;

		if ( p->uxtheme.onoff )
		{
			part  = bp;
			state = pbs;
		} else {
			part  = 0;
			state = p->state;
		}

		int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		n_uxtheme_draw_text( &p->uxtheme, p->hwnd, hdc, &r, part,state, dt, TMT_MSGBOXFONT, n_posix_false );
/*
		SetBkMode( hdc, TRANSPARENT );
		n_posix_char str[ 1024 ]; n_win_text_get( p->hwnd, str, 1024 );
		DrawText( hdc, str, -1, &r, dt );
*/
	} else {

		n_type_gfx ico_sx, ico_sy; n_win_stdsize_icon_large( &ico_sx, &ico_sy );


		n_type_gfx tx = ( sx - ico_sx ) / 2;
		n_type_gfx ty = ( sy - ico_sy ) / 2;

		if ( p->sink_onoff )
		{
			// [!] : Vista or later : Nonnon Original Behavior

			n_type_gfx o = offset_sink;

			if (
				( is_drawedge )
				||
				( p->uxtheme.onoff == n_posix_false )
			)
			{
				tx += o;
				ty += o;
			} else
			if ( p->uxtheme.longhorn )
			{
				ty += o;
			} else {
				tx += o;
				ty += o;
			}
		}


		// [Needed] : DWM : alpha value support

		int drawstate_onoff = n_win_property_get_literal( p->hwnd, "DrawState" );

		if ( ( p->uxtheme.onoff )&&( drawstate_onoff == n_posix_false ) )
		{

			HMODULE hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );

			FARPROC n_ImageList_Create      = (void*) GetProcAddress( hmod, "ImageList_Create"      );
			FARPROC n_ImageList_ReplaceIcon = (void*) GetProcAddress( hmod, "ImageList_ReplaceIcon" );
			FARPROC n_ImageList_Destroy     = (void*) GetProcAddress( hmod, "ImageList_Destroy"     );

			// [x] : Win10 : stretching is forced always
			int n_ILC_ORIGINALSIZE = 0x00010000;

			// [x] : WinXP : ILC_ORIGINALSIZE : handled as error
			if ( n_posix_false == n_sysinfo_version_vista_or_later() ) { n_ILC_ORIGINALSIZE = 0; }


			HIMAGELIST hil = (void*) n_ImageList_Create( ico_sx, ico_sy, ILC_COLOR32 | ILC_MASK | n_ILC_ORIGINALSIZE, 1, 0 );


			if ( pbs != PBS_DISABLED )
			{

				n_ImageList_ReplaceIcon( hil, -1, p->hicon );

			} else {

				HICON hicon_gray = n_win_icon_grayed( p->hicon, ico_sx, ico_sy );

				n_ImageList_ReplaceIcon( hil, -1, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}


			RECT r = n_win_rect_set( NULL, tx, ty, ico_sx, ico_sy );
			p->uxtheme.DrawThemeIcon( p->uxtheme.htheme, hdc, bp,pbs, &r, hil, 0 );

			n_ImageList_Destroy( hil );


			FreeLibrary( hmod );

		} else {

			if ( pbs != PBS_DISABLED )
			{

				HBRUSH hb = GetSysColorBrush( COLOR_BTNFACE );
				DrawState( hdc, hb, NULL, (LPARAM) p->hicon,0, tx,ty,0,0, DSS_NORMAL | DST_ICON );

			} else {

				HICON hicon_gray = n_win_icon_grayed( p->hicon, ico_sx, ico_sy );

				DrawIcon( hdc, tx,ty, hicon_gray );

				n_win_icon_exit( hicon_gray );

			}

		}

	}


//n_bmp_box( &n_gdi_doublebuffer_32bpp_instance.bmp, 0,0,10,10, 0 );

	if ( p->bmp_backup_onoff )
	{
		n_bmp_free( &p->bmp );
		n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &p->bmp );
	}


	if ( hdc_override == NULL )
	{
		n_gdi_doublebuffer_32bpp_simple_exit();
	} else {
		BitBlt( hdc_override, 0,0,sx,sy, hdc, 0,0, SRCCOPY );
		n_gdi_doublebuffer_32bpp_simple_cleanup();
	}


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_button_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_button_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_button *p = (void*) dwRefData;
#else  // #ifdef _WIN64
	n_win_button *p = (void*) n_win_property_get_literal( hwnd, "n_win_button" );
#endif // #ifdef _WIN64

	if ( p == NULL ) { return 0; }


	static HWND hwnd_pressed = NULL;


	switch( msg ) {


	case WM_PRINTCLIENT :

		if ( n_win_button_printclient_onoff )
		{
			n_win_button_draw( p, (HDC) wparam, NULL );
		}

	break;


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam != p->fade_timer_id ) { break; }

		n_bmp_fade_engine( &p->fade, p->fade_onoff );
		n_win_refresh( p->hwnd, n_posix_false );

		if ( p->fade.percent == 100 )
		{
			n_win_timer_exit( hwnd, p->fade_timer_id );
			n_win_property_set_literal( p->hwnd, "State", p->state );
		}

//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d", (int) p->fade.percent );
	break;


	case WM_MOUSEMOVE :

		// [!] : this code depends SetCapture()/ReleaseCapture()

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), " Button : WM_MOUSEHOVER " );
//break;
		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if ( p->keep_on_pressing ) { break; }

		if ( ( p->hot_onoff )&&( p->state != PBS_HOT ) )
		{
			p->state = PBS_HOT;
			n_win_button_fade_go( p );
		}

	break;

	case WM_MOUSELEAVE :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), " Button : WM_MOUSELEAVE " );
//break;
		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		if ( p->keep_on_pressing ) { break; }

		{
			if ( p->select_onoff )
			{
				p->state = PBS_PRESSED;
			} else {
				p->state = PBS_NORMAL;
			}

			p->sink_onoff = n_posix_false;
			p-> hot_onoff = n_posix_true;

			n_win_button_fade_go( p );
		}

	break;


	case WM_ERASEBKGND :

		//n_win_button_draw( p, NULL, NULL );

		return n_posix_true;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/

	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN   :

		if ( n_posix_false == IsWindowVisible( p->hwnd ) ) { break; }

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		hwnd_pressed = hwnd;

		SetCapture( hwnd );

	//case WM_LBUTTONDBLCLK :

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		p-> hot_onoff = n_posix_false;
		p->sink_onoff = n_posix_true;


		p->state = PBS_PRESSED;
		n_win_property_set_literal( p->hwnd, "State", PBS_HOT );

		n_win_button_fade_go( p );

	break;

	case WM_LBUTTONUP :
	{

		if ( n_posix_false == n_win_button_is_enabled( p ) ) { break; }

		ReleaseCapture();

		if ( hwnd_pressed != hwnd )
		{
			hwnd_pressed = NULL;

			p-> hot_onoff = n_posix_true;
			p->sink_onoff = n_posix_false;

			n_win_button_fade_go( p );

			break;
		}

		hwnd_pressed = NULL;

//n_win_debug_count( n_win_hwnd_toplevel( hwnd ) );

		//n_win_property_set_literal( p->hwnd, "State", p->state );

		extern void n_win_button_forced_internal( n_win_button *p, int state, n_posix_bool );
		n_win_button_forced_internal( p, p->state, n_posix_false );

		if ( p->init_timeout < n_posix_tickcount() )
		{
			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );
		}

		if ( p->keep_on_pressing )
		{
			//
		} else {
			p->sink_onoff = n_posix_false;
			p-> hot_onoff = n_posix_true;

			p->state = PBS_HOT;
			n_win_button_fade_go( p );
		}

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64

	// [Needed] : Win95 : crash

	WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "Subclass" );
	if ( pfunc == NULL ) { return 0; }

	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_button_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_button *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win_button_draw( p, di->hDC, &di->rcItem );

	}
	break;


	} // switch


	return;
}

void
n_win_button_on_settingchange( n_win_button *p )
{

	p->is_classic = n_win_style_is_classic();

	if ( p->is_classic ) { n_win_style_add( p->hwnd, BS_FLAT ); }


	n_win_stdfont_exit( &p->hwnd, 1 );
	n_win_stdfont_init( &p->hwnd, 1 );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"BUTTON" );


	p->fade_onoff = n_win_fade_is_on();
	n_bmp_fade_init( &p->fade, n_bmp_black );


	if ( n_win_fluent_ui_onoff )
	{
		p->maclike_onoff  = n_posix_true;
		p->maclike_offset = n_posix_max_n_type_gfx( 1, 4 * (n_type_gfx) floor( n_win_scale( p->hwnd ) ) );
	} else {
		p->maclike_onoff  = n_posix_false;
		p->maclike_offset = 0;
	}


	return;
}

#define n_win_button_init_literal( p, h, t, s ) n_win_button_init( p, h, n_posix_literal( t ), s )

#define n_win_button_init(     p, h, t, s ) n_win_button_init_internal( p, h, t, s, n_posix_false )
#define n_win_button_init_dwm( p, h, t, s ) n_win_button_init_internal( p, h, t, s, n_posix_true  )

// internal
void
n_win_button_init_internal( n_win_button *p, HWND hwnd_parent, n_posix_char *text, int state, n_posix_bool is_toolband )
{

	n_win_gui( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, text, &p->hwnd );
//n_win_style_add( p->hwnd, WS_BORDER );


	n_win_style_add( p->hwnd, BS_FLAT );


	p->state = state;
	n_win_property_set_literal( p->hwnd, "State", p->state );

	p->   hot_onoff = n_posix_true;
	p->active_onoff = ( p->state != PBS_DISABLED );


	p->fade_timer_id = n_win_timer_id_get();


	if ( is_toolband )
	{
		n_posix_bool onoff = n_posix_false;
		if ( n_win_dwm_is_on() )
		{
			onoff = n_posix_true;
		} else
		if ( n_posix_false == n_win_style_is_classic() )
		{
			onoff = n_posix_true;
		}
		n_win_property_init_literal( p->hwnd, "Toolband", onoff );
	}


	{

#ifdef _WIN64

		SetWindowSubclass( p->hwnd, n_win_button_subclass, 0, (DWORD_PTR) p );

#else  // #ifdef _WIN64

		WNDPROC pfunc = n_win_gui_subclass_set( p->hwnd, n_win_button_subclass );

		n_win_property_init_literal( p->hwnd, "n_win_button", (int) p     );
		n_win_property_init_literal( p->hwnd, "Subclass"    , (int) pfunc );

#endif // #ifdef _WIN64

	}


	n_win_button_on_settingchange( p );


	// [Needed] : faster environment like VirtualBox needs this trick

	p->init_timeout = n_posix_tickcount() + 200;


	return;
}

void
n_win_button_exit( n_win_button *p )
{

	n_win_property_exit_literal( p->hwnd, "State" );
	n_win_property_exit_literal( p->hwnd, "Background.OnOff" );
	n_win_property_exit_literal( p->hwnd, "Toolband" );
	n_win_property_exit_literal( p->hwnd, "DrawState" );


#ifdef _WIN64

	RemoveWindowSubclass( p->hwnd, n_win_button_subclass, 0 );

#else  // #ifdef _WIN64

	WNDPROC func = (WNDPROC) n_win_property_get_literal( p->hwnd, "Subclass" );
	n_win_gui_subclass_set( p->hwnd, func );

	n_win_property_exit_literal( p->hwnd, "n_win_button" );
	n_win_property_exit_literal( p->hwnd, "Subclass"     );

#endif // #ifdef _WIN64


	n_uxtheme_exit( &p->uxtheme, p->hwnd );


	n_bmp_free_fast( &p->bmp );


	n_win_icon_exit( p->hicon );

	n_win_stdfont_exit( &p->hwnd, 1 );


	DestroyWindow( p->hwnd );


	n_win_button_zero( p );


	return;
}

n_posix_bool
n_win_button_checklike( n_win_button *p, n_type_gfx index_off, n_type_gfx index_on, n_posix_bool onoff )
{

	// [!] : BS_AUTOCHECKBOX-like behavior


	n_posix_char *exe = n_win_exepath_new();

	if ( onoff )
	{
		onoff = n_posix_false;

		p->hicon = n_win_icon_init( exe, index_off, N_WIN_ICON_INIT_OPTION_RESOURCE );
	} else {
		onoff = n_posix_true;

		p->hicon = n_win_icon_init( exe, index_on , N_WIN_ICON_INIT_OPTION_RESOURCE );
	}

	p->select_onoff = onoff;

	n_string_path_free( exe );


	n_win_button_fade_go( p );


	return onoff;
}

#define n_win_button_forced( p, state ) n_win_button_forced_internal( p, state, n_posix_true )

// internal
void
n_win_button_forced_internal( n_win_button *p, int state, n_posix_bool fade_go_onoff )
{

	p->state = state;


	if ( fade_go_onoff )
	{
		n_win_button_fade_go( p );
	}


	RECT rect; GetClientRect( p->hwnd, &rect );

	n_posix_loop
	{
		n_bmp_fade_engine( &p->fade, p->fade_onoff );
		n_win_button_draw( p, NULL, &rect );

		if ( p->fade.percent == 100 ) { break; }

		n_posix_sleep( 0 );
	}


	n_win_property_set_literal( p->hwnd, "State", p->state );


	return;
}

#define n_win_button_grayed_onoff(       p, onoff ) n_win_button_grayed_onoff_main( p, onoff, n_posix_true  )
#define n_win_button_grayed_onoff_light( p, onoff ) n_win_button_grayed_onoff_main( p, onoff, n_posix_false )

// internal
void
n_win_button_grayed_onoff_main( n_win_button *p, n_posix_bool onoff, n_posix_bool fade_onoff )
{

	if ( onoff )
	{
		p->active_onoff = n_posix_false;

		n_win_property_set_literal( p->hwnd, "State", p->state );
		p->state = PBS_DISABLED;
	} else {
		p->active_onoff = n_posix_true;

		n_win_property_set_literal( p->hwnd, "State", p->state );
		p->state = PBS_NORMAL;
	}


	if ( fade_onoff ) { n_win_button_fade_go( p ); }


	return;
}

void
n_win_button_sync( n_win_button *p )
{

	n_win_message_send( p->hwnd, WM_MOUSELEAVE, 0, 0 );

	n_win_refresh( p->hwnd, n_posix_false );


	return;
}


#endif // _H_NONNON_WIN32_WIN_BUTTON


