// nlayer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_COLORPICKER
#define _H_NONNON_WIN32_WIN_COLORPICKER




#include "./win/_debug.c"
#include "./win/input.c"
#include "./win/message.c"
#include "./win/style.c"
#include "./win_scroller.c"





// [!] : for easy to read/replace

#define nwclr_refresh      n_win_colorpicker_refresh
#define nwclr_move         n_win_colorpicker_move
#define nwclr_enable       n_win_colorpicker_enable
#define nwclr_proc         n_win_colorpicker_proc




// [!] : internal

#define H_COLOR  c->hgui[ 0 ]
#define GUI_MAX           1


#define H_SCR_A  ( &c->hscr[ 0 ] )
#define H_SCR_R  ( &c->hscr[ 1 ] )
#define H_SCR_G  ( &c->hscr[ 2 ] )
#define H_SCR_B  ( &c->hscr[ 3 ] )
#define SCR_MAX              4



typedef struct {

	// [!] : for incompatibility between RGB() and n_bmp_rgb()

	u8              a,r,g,b;


	// internal

	HWND            hgui[ GUI_MAX ];
	n_win_scroller  hscr[ SCR_MAX ];

	n_posix_bool    grayscale_onoff;
	n_posix_bool    control_onoff;

	n_posix_bool    onoff;


	n_win_scroller *rich_scr;
	n_posix_bool    rich_all;

} n_win_colorpicker;




#define n_win_colorpicker_zero( p ) n_memory_zero( p, sizeof( n_win_colorpicker ) )

// internal
n_posix_bool
n_win_colorpicker_roundrect_moire_detect( n_type_gfx x, n_type_gfx y, n_type_gfx block_size, n_type_gfx block_twice )
{

	if ( block_size == 1 ) { return n_bmp_moire_detect( x, y, 1 ); }


	if ( ( x % block_twice ) < block_size )
	{
		if ( ( y % block_twice ) < block_size )         { return n_posix_true; }
	} else {
		if ( ( y % block_twice ) < block_size ) {} else { return n_posix_true; }
	}


	return n_posix_false;
}

// internal
void
n_win_colorpicker_roundrect_moire( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_type_gfx round, n_type_gfx block_size )
{

	n_type_gfx block_twice = block_size * 2;


	n_type_gfx fx = 0;
	n_type_gfx fy = 0;
	n_posix_loop
	{//break;

		n_type_real coeff = 0;
		n_bmp_roundrect_detect_coeff( fx,fy, sx,sy, round, &coeff );

		u32 c;

		n_bmp_ptr_get_fast( bmp, x + fx, y + fy, &c );

		if ( n_win_colorpicker_roundrect_moire_detect( fx, fy, block_size, block_twice ) )
		{
			c = n_bmp_blend_pixel( c, n_bmp_white, coeff * 0.5 );
		} else {
			c = n_bmp_blend_pixel( c, n_bmp_black, coeff * 0.5 );
		}

		n_bmp_ptr_set_fast( bmp, x + fx, y + fy,  c );


		fx++;
		if ( fx >= sx )
		{

			fx = 0;

			fy++;
			if ( fy >= sy ) { break; }
		}
	}


	return;
}

void
n_win_colorpicker_on_settingchange( n_win_colorpicker *c )
{

	n_win_scroller_on_settingchange( H_SCR_A );
	n_win_scroller_on_settingchange( H_SCR_R );
	n_win_scroller_on_settingchange( H_SCR_G );
	n_win_scroller_on_settingchange( H_SCR_B );

	return;
}

void
n_win_colorpicker_scroller_value_set( n_win_colorpicker *c, n_win_scroller *s, int v )
{

	n_win_hwndprintf_literal( s->value, "%3d", v );

	return;
}

void
n_win_colorpicker_scroller_refresh( n_win_colorpicker *c, n_win_scroller *s, int v )
{

	//n_win_message_send( GetParent( s->canvas ), WM_COMMAND, v, n_win_scroller_scroll_hwnd( s ) );

	n_win_colorpicker_scroller_value_set( c, s, v );

	s->scrollbar.unit_pos = v;

	n_win_scrollbar_draw_always( &s->scrollbar, n_posix_true );


	return;
}

void
n_win_colorpicker_shaft_color( n_win_colorpicker *c, n_win_scroller *s, u32 color, n_posix_bool gradient_onoff )
{

	if ( gradient_onoff )
	{
		s->scrollbar.color_sh_bg = n_bmp_black;
		s->scrollbar.color_sh_fg = color;
	} else {
		s->scrollbar.color_sh_fg = color;
		s->scrollbar.color_sh_bg = color;
	}

	n_bmp_free( &s->scrollbar.bmp_gr );

	n_win_scrollbar_draw_always( &s->scrollbar, n_posix_true );


	return;
}

void
n_win_colorpicker_refresh( n_win_colorpicker *c, int a, int r, int g, int b )
{

	if ( c == NULL ) { return; }


	if ( n_posix_false == IsWindowEnabled( H_COLOR ) ) { return; }


	c->a = a;
	c->r = r;
	c->g = g;
	c->b = b;

	n_win_colorpicker_scroller_refresh( c, H_SCR_A, a );
	n_win_colorpicker_scroller_refresh( c, H_SCR_R, r );
	n_win_colorpicker_scroller_refresh( c, H_SCR_G, g );
	n_win_colorpicker_scroller_refresh( c, H_SCR_B, b );

	c->grayscale_onoff = n_posix_false;

	n_win_refresh( H_COLOR, n_posix_true );


	return;
}

void
n_win_colorpicker_callback( void *data )
{
//n_posix_debug_literal( "" );

	n_win_colorpicker *c = data;

	//n_win_colorpicker_refresh( c, c->a, c->r, c->g, c->b );


	HDC  hdc = GetDC( H_COLOR );
	RECT r; GetClientRect( H_COLOR, &r );

	n_win_box( NULL, hdc, &r, RGB( c->r, c->g, c->b ) );

	if ( c->grayscale_onoff )
	{
		DrawEdge( hdc, &r, BDR_SUNKEN,      BF_RECT );
	} else {
		DrawEdge( hdc, &r, BDR_SUNKENOUTER, BF_RECT | BF_MONO );
	}

	ReleaseDC( H_COLOR, hdc );


	return;
}

void
n_win_colorpicker_init( n_win_colorpicker *c, HWND hwnd )
{

	if ( c == NULL ) { return; }


	n_win_scroller_zero( H_SCR_A );
	n_win_scroller_zero( H_SCR_R );
	n_win_scroller_zero( H_SCR_G );
	n_win_scroller_zero( H_SCR_B );


	// Window

	n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &H_COLOR );

	n_win_scroller_init_literal( H_SCR_A, hwnd, "A" );
	n_win_scroller_init_literal( H_SCR_R, hwnd, "R" );
	n_win_scroller_init_literal( H_SCR_G, hwnd, "G" );
	n_win_scroller_init_literal( H_SCR_B, hwnd, "B" );


	// Style

	n_win_style_add( H_COLOR, SS_NOTIFY );

	H_SCR_R->scrollbar.option |= N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
	H_SCR_G->scrollbar.option |= N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
	H_SCR_B->scrollbar.option |= N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;

	n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( 255,0,0 ), n_posix_true );
	n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,255,0 ), n_posix_true );
	n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,255 ), n_posix_true );


	H_SCR_A->scrollbar.menu.callback_data = (void*) c;
	H_SCR_R->scrollbar.menu.callback_data = (void*) c;
	H_SCR_G->scrollbar.menu.callback_data = (void*) c;
	H_SCR_B->scrollbar.menu.callback_data = (void*) c;
	H_SCR_A->scrollbar.menu.callback      = n_win_colorpicker_callback;
	H_SCR_R->scrollbar.menu.callback      = n_win_colorpicker_callback;
	H_SCR_G->scrollbar.menu.callback      = n_win_colorpicker_callback;
	H_SCR_B->scrollbar.menu.callback      = n_win_colorpicker_callback;


	// Scrollbars

	n_win_scroller_scroll_parameter( H_SCR_A, 1, 10, 255, c->a, n_posix_true );
	n_win_scroller_scroll_parameter( H_SCR_R, 1, 10, 255, c->r, n_posix_true );
	n_win_scroller_scroll_parameter( H_SCR_G, 1, 10, 255, c->g, n_posix_true );
	n_win_scroller_scroll_parameter( H_SCR_B, 1, 10, 255, c->b, n_posix_true );

	n_win_colorpicker_refresh( c, c->a, c->r, c->g, c->b );

	c->onoff = n_posix_true;


	return;
}

void
n_win_colorpicker_exit( n_win_colorpicker *c )
{

	if ( c == NULL ) { return; }


	// Window

	DestroyWindow( H_COLOR );

	n_win_scroller_exit( H_SCR_A );
	n_win_scroller_exit( H_SCR_R );
	n_win_scroller_exit( H_SCR_G );
	n_win_scroller_exit( H_SCR_B );


	return;
}

void
n_win_colorpicker_move( n_win_colorpicker *c, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	if ( c == NULL ) { return; }


	// Size

	n_type_gfx ty = sy / 4;

	nwscr_move( H_SCR_A, x,y+(ty*0),sx,ty, redraw );
	nwscr_move( H_SCR_R, x,y+(ty*1),sx,ty, redraw );
	nwscr_move( H_SCR_G, x,y+(ty*2),sx,ty, redraw );
	nwscr_move( H_SCR_B, x,y+(ty*3),sx,ty, redraw );


	// [!] : hack here

	n_type_gfx m; n_win_stdsize( NULL, NULL, NULL, &m );

	n_type_gfx unit = sx / 10;

	n_type_gfx clr_x  = x + ( m * 2 );
	n_type_gfx clr_y  = y + ( m * 1 );
	n_type_gfx clr_sx = ( unit * 1 ) - ( m * 2 );
	n_type_gfx clr_sy =   sy         - ( m * 2 );

	n_type_gfx a_y = H_SCR_A->text__y;
	n_type_gfx r_y = H_SCR_R->text__y;
	n_type_gfx g_y = H_SCR_G->text__y;
	n_type_gfx b_y = H_SCR_B->text__y;

	n_win_move_simple( H_SCR_A->label, x+unit+m+m,   a_y, clr_sx,H_SCR_A->text_sy, redraw );
	n_win_move_simple( H_SCR_R->label, x+unit+m+m,   r_y, clr_sx,H_SCR_R->text_sy, redraw );
	n_win_move_simple( H_SCR_G->label, x+unit+m+m,   g_y, clr_sx,H_SCR_G->text_sy, redraw );
	n_win_move_simple( H_SCR_B->label, x+unit+m+m,   b_y, clr_sx,H_SCR_B->text_sy, redraw );
	n_win_move_simple( H_COLOR       ,      clr_x, clr_y, clr_sx,          clr_sy, redraw );


	// [Needed]

	n_win_colorpicker_refresh( c, c->a, c->r, c->g, c->b );


	return;
}

void
n_win_colorpicker_enable( n_win_colorpicker *c, n_posix_bool enable )
{

	if ( ( c->onoff == n_posix_false )&&( enable == n_posix_false ) ) { return; }
	if ( ( c->onoff != n_posix_false )&&( enable != n_posix_false ) ) { return; }


	if ( enable )
	{
		H_SCR_R->scrollbar.option |=  N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
		H_SCR_G->scrollbar.option |=  N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
		H_SCR_B->scrollbar.option |=  N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
	} else {
		H_SCR_R->scrollbar.option &= ~N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
		H_SCR_G->scrollbar.option &= ~N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
		H_SCR_B->scrollbar.option &= ~N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR;
	}

	n_win_scrollbar_refresh_cache( &H_SCR_R->scrollbar );
	n_win_scrollbar_refresh_cache( &H_SCR_G->scrollbar );
	n_win_scrollbar_refresh_cache( &H_SCR_B->scrollbar );

	n_win_scrollbar_refresh_redraw_area( &H_SCR_R->scrollbar );
	n_win_scrollbar_refresh_redraw_area( &H_SCR_G->scrollbar );
	n_win_scrollbar_refresh_redraw_area( &H_SCR_B->scrollbar );

	n_win_scrollbar_draw_always( &H_SCR_R->scrollbar, n_posix_true );
	n_win_scrollbar_draw_always( &H_SCR_G->scrollbar, n_posix_true );
	n_win_scrollbar_draw_always( &H_SCR_B->scrollbar, n_posix_true );


	EnableWindow( H_COLOR, enable );
	nwscr_enable( H_SCR_A, enable );
	nwscr_enable( H_SCR_R, enable );
	nwscr_enable( H_SCR_G, enable );
	nwscr_enable( H_SCR_B, enable );


	c->onoff = enable;


	return;
}

void
n_win_colorpicker_rich_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_colorpicker *c )
{

	if ( c == NULL ) { return; }


	switch( msg ) {


	case WM_LBUTTONDOWN :
	{

		if ( H_SCR_R->scrollbar.pressed_shaft ) { break; }
		if ( H_SCR_G->scrollbar.pressed_shaft ) { break; }
		if ( H_SCR_B->scrollbar.pressed_shaft ) { break; }


		// [!] : this is insufficient : see WM_COMMAND at n_win_colorpicker_proc()

		if ( c->control_onoff )
		{
//n_posix_debug_literal( " %x ", n_win_hwnd_window( H_SCR_R->scrollbar.hwnd ) );

			c->rich_all = n_posix_true;
			c->rich_scr = H_SCR_R;

			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( c->r,0,0 ), n_posix_false );
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,c->g,0 ), n_posix_false );
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,c->b ), n_posix_false );

			break;
		}


		u32 r,g,b; r = g = b = 0;

		if ( H_SCR_R->scrollbar.pressed_thumb ) { c->rich_scr = H_SCR_R; r = c->r; } else
		if ( H_SCR_G->scrollbar.pressed_thumb ) { c->rich_scr = H_SCR_G; g = c->g; } else
		if ( H_SCR_B->scrollbar.pressed_thumb ) { c->rich_scr = H_SCR_B; b = c->b; } else { break; }

		n_win_colorpicker_shaft_color( c, c->rich_scr, n_bmp_rgb( r,g,b ), n_posix_false );

	}
	break;

	case WM_LBUTTONUP :

		if ( c->rich_scr == NULL ) { break; }

		if ( c->rich_all )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( 255,0,0 ), n_posix_true );
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,255,0 ), n_posix_true );
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,255 ), n_posix_true );
		} else
		if ( c->rich_scr == H_SCR_R )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( 255,0,0 ), n_posix_true );
		} else
		if ( c->rich_scr == H_SCR_G )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,255,0 ), n_posix_true );
		} else
		if ( c->rich_scr == H_SCR_B )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,255 ), n_posix_true );
		}

		c->rich_scr = NULL;
		c->rich_all = n_posix_false;

	break;

	case WM_MOUSEMOVE :

		if ( c->rich_scr == NULL ) { break; }

		if ( c->rich_all )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( c->r,0,0 ), n_posix_false );
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,c->g,0 ), n_posix_false );
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,c->b ), n_posix_false );
		} else
		if ( c->rich_scr == H_SCR_R )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( c->r,0,0 ), n_posix_false );
		} else
		if ( c->rich_scr == H_SCR_G )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,c->g,0 ), n_posix_false );
		} else
		if ( c->rich_scr == H_SCR_B )
		{
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,c->b ), n_posix_false );
		}

	break;


	} // switch


	return;
}

void
n_win_colorpicker_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_colorpicker *c )
{

	if ( c == NULL ) { return; }


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }
		if ( H_COLOR != di->hwndItem ) { break; }


		HDC  hdc = di->hDC;
		RECT r   = di->rcItem;


		if ( n_posix_false == IsWindowEnabled( H_COLOR ) ) { break; }

		if ( n_win_fluent_ui_onoff )
		{

			n_type_gfx x,y,sx,sy; n_win_rect_expand_size( &r, &x, &y, &sx, &sy );

			n_gdi_doublebuffer_32bpp_simple_init( H_COLOR, sx, sy );

			n_type_gfx round = n_win_fluent_ui_round_param( H_COLOR );
			n_type_gfx frame = (n_type_gfx) trunc( n_win_scale( H_COLOR ) );

			n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

			u32 corner = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE );

			u32 color_fg = n_bmp_rgb( c->r, c->g, c->b );
			if ( c->grayscale_onoff )
			{

				n_bmp_flush( bmp, corner );


				n_type_real scale_real = n_win_scale( H_COLOR );


				n_type_gfx block = (n_type_gfx) ceil( scale_real );
				n_win_colorpicker_roundrect_moire( bmp, x,y,sx,sy, round, block ); 


				n_type_gfx scale = (n_type_gfx) trunc( scale_real );

				scale *= 2;

				 x += scale;
				 y += scale;
				sx -= scale * 2;
				sy -= scale * 2;

				u32 color_bg = color_fg;
				n_bmp_roundrect_pixel( bmp, x,y,sx,sy, color_bg, round ); 


			} else {

				u32 color_bg = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );
				n_bmp_ui_roundframe( bmp, x,y,sx,sy, round, frame, color_bg, color_fg ); 
				n_bmp_cornermask( bmp, round, 0, corner );

			}

			n_gdi_doublebuffer_32bpp_simple_exit();

		} else {

			n_win_box( NULL, hdc, &r, RGB( c->r, c->g, c->b ) );

			if ( c->grayscale_onoff )
			{
				DrawEdge( hdc, &r, BDR_SUNKEN,      BF_RECT );
			} else {
				DrawEdge( hdc, &r, BDR_SUNKENOUTER, BF_RECT | BF_MONO );
			}

		}

	}
	break;


	case WM_COMMAND :
	{

		static n_posix_bool lock = n_posix_false;


		n_posix_bool sync = n_posix_false;


		c->control_onoff = n_posix_false;


		if ( (HWND) lparam == H_COLOR )
		{

			if ( STN_CLICKED == HIWORD( wparam ) )
			{

				if ( c->grayscale_onoff )
				{
					c->grayscale_onoff = n_posix_false;
				} else {
					c->grayscale_onoff = n_posix_true;
				}

				n_win_refresh( H_COLOR, n_posix_true );

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_A ) )
		{

			int prv = c->a;

			c->a = (int) wparam;

			if ( c->a != prv ) { sync = n_posix_true; }

			n_win_colorpicker_scroller_value_set( c, H_SCR_A, c->a );

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_R ) )
		{

			int prv = c->r;

			c->r = (int) wparam;

			if ( c->r != prv ) { sync = n_posix_true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_R, c->r );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				c->control_onoff = n_posix_true;

				lock = n_posix_true;

				c->g = c->b = c->r;

				n_win_colorpicker_scroller_refresh( c, H_SCR_G, c->r );
				n_win_colorpicker_scroller_refresh( c, H_SCR_B, c->r );

				sync = n_posix_true;

				lock = n_posix_false;

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_G ) )
		{

			int prv = c->g;

			c->g = (int) wparam;

			if ( c->g != prv ) { sync = n_posix_true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_G, c->g );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				c->control_onoff = n_posix_true;

				lock = n_posix_true;

				c->r = c->b = c->g;

				n_win_colorpicker_scroller_refresh( c, H_SCR_R, c->g );
				n_win_colorpicker_scroller_refresh( c, H_SCR_B, c->g );

				sync = n_posix_true;

				lock = n_posix_false;

			}

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_B ) )
		{

			int prv = c->b;

			c->b = (int) wparam;

			if ( c->b != prv ) { sync = n_posix_true; }


			n_win_colorpicker_scroller_value_set( c, H_SCR_B, c->b );


			if ( lock ) { break; }

			if ( ( c->grayscale_onoff )||( n_win_is_input( VK_CONTROL ) ) )
			{

				c->control_onoff = n_posix_true;

				lock = n_posix_true;

				c->r = c->g = c->b;

				n_win_colorpicker_scroller_refresh( c, H_SCR_R, c->b );
				n_win_colorpicker_scroller_refresh( c, H_SCR_G, c->b );

				sync = n_posix_true;

				lock = n_posix_false;

			}

		}

		if ( sync ) { n_win_refresh( H_COLOR, n_posix_true ); }


		// [!] : for mulitple instances

		if ( ( c->control_onoff == n_posix_false )&&( c->rich_all ) )
		{
//n_posix_debug_literal( " %x ", n_win_hwnd_window( H_SCR_R->scrollbar.hwnd ) );

			c->rich_all = n_posix_false;
			c->rich_scr = NULL;

			n_win_colorpicker_shaft_color( c, H_SCR_R, n_bmp_rgb( 255,0,0 ), n_posix_true );
			n_win_colorpicker_shaft_color( c, H_SCR_G, n_bmp_rgb( 0,255,0 ), n_posix_true );
			n_win_colorpicker_shaft_color( c, H_SCR_B, n_bmp_rgb( 0,0,255 ), n_posix_true );

			break;
		}


	}
	break;


	} // switch


	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_A );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_R );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_G );
	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_B );


	n_win_colorpicker_rich_proc( hwnd, msg, wparam, lparam, c );


	return;
}


#undef GUI_MAX
#undef H_COLOR

#undef SCR_MAX
#undef H_SCR_A
#undef H_SCR_R
#undef H_SCR_G
#undef H_SCR_B


#endif // _H_NONNON_WIN32_WIN_COLORPICKER


/*


#include "./win.c"


#include "../project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp;


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_colorpicker_zero( &cp );
		n_win_colorpicker_init( &cp, hwnd );

		n_win_colorpicker_refresh( &cp, 0, 0, 200, 255 );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

		n_win_colorpicker_move( &cp, 0,0,200,200, n_posix_true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_colorpicker_exit( &cp );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_colorpicker_proc( hwnd, msg, wparam, lparam, &cp );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/


