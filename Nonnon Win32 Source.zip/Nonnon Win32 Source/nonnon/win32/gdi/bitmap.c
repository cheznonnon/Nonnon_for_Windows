// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GDI_BITMAP
#define _H_NONNON_WIN32_GDI_BITMAP




#include "../../neutral/bmp.c"
#include "../../neutral/bmp/_error.c"




#define n_gdi_bitmap_draw( hwnd, bmp, fx,fy,fsx,fsy, tx,ty ) n_gdi_bitmap_draw_main( hwnd, NULL, bmp, fx,fy,fsx,fsy, tx,ty )

void
n_gdi_bitmap_draw_main
(
	       HWND  hwnd,
               HDC   hdc_override,
	const n_bmp *bmp,
	      n_type_gfx fx , n_type_gfx fy ,
	      n_type_gfx fsx, n_type_gfx fsy,
	      n_type_gfx tx , n_type_gfx ty
)
{

	if ( n_bmp_error( bmp ) ) { return; }


	HDC hdc = hdc_override;
	if ( hdc == NULL ) { hdc = GetDC( hwnd ); }


	BITMAPINFO bi = { N_BMP_INFOH( bmp ), { { 0,0,0,0 } } };


	n_type_gfx bmpsx = N_BMP_SX( bmp );
	n_type_gfx bmpsy = N_BMP_SY( bmp );

	fsx = n_posix_min_n_type_gfx( fsx, bmpsx );
	fsy = n_posix_min_n_type_gfx( fsy, bmpsy );


	// [!] : up-side-down

	//n_type_gfx dsx = bmpsx - fsx;
	n_type_gfx dsy = bmpsy - fsy;

	fy = dsy - fy;


	// [Mechanism]
	//
	//	 tx  ty : top-left    : destination position
	//	fsx fsy : top-left    : source size
	//	 fx  fy : bottom-left : source position
	//
	//	( ty + fsy ) will be bottom line of a source bitmap


	SetDIBitsToDevice
	(
		hdc, 
		tx,ty, fsx,fsy, fx,fy,
		0, N_BMP_SY( bmp ),
		N_BMP_PTR( bmp ),
		&bi,
		DIB_RGB_COLORS
	);


	if ( hdc_override == NULL ) { ReleaseDC( hwnd, hdc ); }


	// [!] : lock drawn area
	//
	//	maybe SetDIBitsToDevice()'s bug 
	//	*Blt() doesn't need this

	RECT r = { tx, ty, tx + fsx, ty + fsy };
	ValidateRect( hwnd, &r );


	return;
}


#endif // _H_NONNON_WIN32_GDI_BITMAP

