// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./26_proc_mouse_00_input_resizer.c"




void
n_win_txtbox_proc_mouse_aero_combo( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	switch( msg ) {


	case WM_MOUSEMOVE :

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX ) ) { break; }

		if ( p->aero_combo_onoff == n_posix_false ) { break; }

		if ( n_win_is_hovered( p->hwnd ) )
		{
			if ( p->aero_combo_fade_in == n_posix_false )
			{
//n_win_txtbox_hwndprintf_literal( p, " on " );

				p->aero_combo_init = n_posix_true;

				p->aero_combo_fade_in = n_posix_true;

				n_win_txtbox_fade_go( p, &p->aero_combo_fade );

				n_win_timer_init( p->hwnd, p->aero_combo_timer, 33 );
			}
		} else {
			if ( p->aero_combo_fade_in )
			{
//n_win_txtbox_hwndprintf_literal( p, " off " );

				p->aero_combo_init = n_posix_true;

				p->aero_combo_fade_in = n_posix_false;

				n_win_txtbox_fade_go( p, &p->aero_combo_fade );

				n_win_timer_init( p->hwnd, p->aero_combo_timer, 33 );
			}
		}

	break;


	} // switch


	return;
}

void
n_win_txtbox_grab_n_drag_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	switch( msg ) {


	case WM_MBUTTONDOWN :

		n_win_grab_n_drag_init( &p->grab_n_drag, hwnd );

		n_win_cursor_add( NULL, IDC_SIZEALL );


		p->grab_n_drag.inertia_onoff = n_posix_true;
		p->grab_n_drag.step_x        = 1;
		p->grab_n_drag.step_y        = 1;
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.unit_step, p->vscr.pixel_step );

		if ( p->vscr.pixel_step < 1 )
		{
			p->grab_n_drag.step_y = 33;
		}

	break;

	case WM_MOUSEMOVE :
	{

		if ( p->ime_composition_onoff ) { break; }


		int dx,dy;
		if ( n_win_grab_n_drag_loop( &p->grab_n_drag, &dx, &dy ) ) { break; }


		n_win_cursor_add( NULL, IDC_SIZEALL );


		n_type_int scr_x = p->scroll_pxl_tabbed_x;
		n_type_int scr_y = p->scroll_pxl_tabbed_y + dy;
//n_win_txtbox_hwndprintf_literal( p, " %lld %lld ", scr_x, scr_y );

		n_win_txtbox_scroll( p, scr_x, scr_y );


		n_win_txtbox_refresh( p, 0 );

	}
	break;

	case WM_MBUTTONUP :

		n_win_grab_n_drag_exit( &p->grab_n_drag );

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	case WM_TIMER :
	{

		int dx,dy;
		if ( n_win_grab_n_drag_inertia( &p->grab_n_drag, wparam, &dx, &dy ) ) { break; }

		n_type_int scr_x = p->scroll_pxl_tabbed_x;
		n_type_int scr_y = p->scroll_pxl_tabbed_y + dy;
//n_win_txtbox_hwndprintf_literal( p, " %d %lld ", dy, scr_y );

		n_win_txtbox_scroll( p, scr_x, scr_y );


		n_win_txtbox_refresh( p, 0 );

	}
	break;


	} // switch


	return;
}

n_posix_bool
n_win_txtbox_proc_mouse( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return n_posix_false; }


	if ( p->mouse_input_stop_onoff ) { return n_posix_false; }


	switch( msg ) {


	case WM_MOUSEWHEEL :
//break;

		if ( p->ime_composition_onoff ) { break; }


		{
			n_type_int page = (n_type_int) p->page_pxl_tabbed_sy / p->cell_pxl_sy;

			n_posix_bool onoff = ( page < p->txt.sy );
			if ( onoff == n_posix_false ) { break; }
		}


		// [!] : don't use n_win_txtbox_is_hovered() : scrollbars will be excluded

		if ( p->is_captured == n_posix_false )
		{
			if ( n_posix_false == n_win_is_hovered( p->hwnd ) ) { break; }
		}

		int delta = n_win_scrollbar_wheeldelta( wparam, 0, n_posix_true );
		if ( p->vscr.unit_step == 1 ) { delta *= p->cell_pxl_sy; }

		n_win_txtbox_line_scroll( p, p->scroll_pxl_tabbed_y + delta );
//break;


		n_win_scrollbar_scroll_pixel( &p->vscr, delta * p->vscr.pixel_step, N_WIN_SCROLLBAR_SCROLL_AUTO );

//n_win_txtbox_hwndprintf_literal( p, " %d : %g %g ", delta, p->vscr.unit_pos, p->vscr.pixel_pos );

//break;

		// [Needed] : prevent fast blink while wheeling

		{
			extern void n_win_txtbox_caret_on_timer( n_win_txtbox *p );
			n_win_txtbox_caret_on_timer( p );
		}

		if ( p->scroll_callback )
		{
			if ( p->scroll_callback( p->vscr.hwnd, WM_MOUSEWHEEL, 0,0 ) ) { break; }
		}

		n_win_scrollbar_draw_always( &p->vscr, n_posix_true );

		n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_MOUSEWHEEL );

	//break;
	case WM_MOUSEMOVE :

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{

			if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL )
			{

				if ( n_posix_false == n_win_txtbox_is_hovered( p ) ) { break; }

				if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
				{
					if ( p->vscr.pressed_thumb ) { break; }
				}

				n_posix_bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );
				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_MOUSEMOVE );

				if ( ( ret == n_posix_false )&&( p->select_cch_sy ) )
				{
					n_win_txtbox_message_redirect( p, hwnd, msg );
				}

			}

		} else {

			n_win_txtbox_message_redirect( p, hwnd, msg );

			if ( p->drag_phase == N_WIN_TXTBOX_DRAG_PHASE_CLICKED )
			{
				POINT pt; GetCursorPos( &pt );
				if ( ( pt.x != p->drag_pt.x )||( pt.y != p->drag_pt.y ) )
				{
					p->hscr.stop_onoff = n_posix_true;
					p->vscr.stop_onoff = n_posix_true;

					p->drag_phase   = N_WIN_TXTBOX_DRAG_PHASE_STARTED;
					p->drag_cch_min = p->select_cch_y;
					p->drag_cch_max = 1;

					p->prv_scr_x = p->scroll_pxl_tabbed_x;
					p->prv_scr_y = p->scroll_pxl_tabbed_y;

					p->drag_msec = 1;

					if ( p->drag_timer == 0 ) { p->drag_timer = n_win_timer_id_get(); }
					n_win_timer_init( hwnd, p->drag_timer, p->drag_msec );
				}
			}

		}

	break;


	case WM_LBUTTONDBLCLK :
	case WM_MBUTTONDBLCLK :
	case WM_RBUTTONDBLCLK :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
			n_win_simplemenu_hide( &p->menu_editbox );
		}


		if ( n_win_is_input( VK_SHIFT ) ) { break; }


		if ( ( msg == WM_LBUTTONDBLCLK )||( msg == WM_LBUTTONDOWN ) ) { p->vk_mouse = VK_LBUTTON; } else
		if ( ( msg == WM_RBUTTONDBLCLK )||( msg == WM_RBUTTONDOWN ) ) { p->vk_mouse = VK_MBUTTON; } else
		if ( ( msg == WM_MBUTTONDBLCLK )||( msg == WM_MBUTTONDOWN ) ) { p->vk_mouse = VK_RBUTTON; }


		if ( ( msg == WM_RBUTTONDOWN )&&( n_win_is_input( VK_LBUTTON ) ) ) { break; }


		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		static DWORD tripleclick_tmr  = 0;
		static UINT  tripleclick_pmsg = WM_NULL;
		static POINT tripleclick_pt   = { 0, 0 };


		if ( n_posix_false == n_win_txtbox_is_hovered( p ) ) { break; }
//n_win_hwndprintf_literal( hwnd, "%d %d", p->hover_cch_x, p->hover_cch_y );


		SetFocus( p->hwnd );


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( p->ime_composition_onoff )
			{

				break;

			} else
			if ( msg == WM_RBUTTONDOWN )
			{

				//

			} else
			if ( msg == WM_LBUTTONDBLCLK )
			{
//break;
				if ( p->is_hovered_linenum )
				{

					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{
						p->empty_line_selection = p->hover_cch_y;
					} else {
						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_drag_select2drag( p );
					}

					n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_LBUTTONDBLCLK );

					break;
				}


				// Triple-Click : Start

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = 0;
				} else {
					tripleclick_tmr = GetTickCount();
				}


				// [!] : for usability

				tripleclick_pmsg = WM_LBUTTONDBLCLK;

				GetCursorPos( &tripleclick_pt );


				if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
				{

					p->empty_line_selection = p->hover_cch_y;

					n_win_txtbox_draw_selection( p, N_WIN_TXTBOX_WM_LBUTTONDBLCLK );

				} else {

					n_type_int f,t;
					n_win_txtbox_select_word( p, p->hover_cch_x, p->hover_cch_y, &f, &t );
					n_win_txtbox_select( p, f, p->hover_cch_y, t - f, 1 );
					n_win_txtbox_drag_select2drag( p );

					n_win_txtbox_draw_selection( p, N_WIN_TXTBOX_WM_LBUTTONDBLCLK );

				}

			} else
			if ( msg == WM_LBUTTONDOWN )
			{
//n_win_txtbox_debug_count( p );
//break;
				if ( p->style_option & N_WIN_TXTBOX_OPTION_DELAYEDFOCUS_ON )
				{
					if ( p->select_cch_sx != 0 )
					{
						if ( p->delayed_focus == n_posix_false )
						{
							p->delayed_focus = n_posix_true;
							break;
						}
					}
				}


				n_posix_bool tripleclick_onoff = n_posix_true;


				// Triple-Click : End

				if ( ( GetTickCount() - tripleclick_tmr ) > GetDoubleClickTime() )
				{
					tripleclick_tmr = GetTickCount();
					tripleclick_onoff = n_posix_false;
				} else {
					tripleclick_tmr = 0;
				}


				// [!] : for usability

				if ( tripleclick_pmsg != WM_LBUTTONDBLCLK )
				{
					tripleclick_onoff = n_posix_false;
				} else {
					tripleclick_pmsg = WM_LBUTTONDOWN;
				}


				{

					n_type_gfx threshold_sx = 0;
					n_type_gfx threshold_sy = 0;
					n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

					POINT p;
					GetCursorPos( &p );

					if (
						( threshold_sx < abs( p.x - tripleclick_pt.x ) )
						||
						( threshold_sy < abs( p.y - tripleclick_pt.y ) )
					)
					{
						tripleclick_onoff = n_posix_false;
					}

				}

				if ( tripleclick_onoff )
				{
//break;
					if ( n_string_is_empty( n_txt_get( &p->txt, p->hover_cch_y ) ) )
					{
						p->empty_line_selection = p->hover_cch_y;
					} else {
						n_win_txtbox_line_select( p, p->hover_cch_y );
						n_win_txtbox_drag_select2drag( p );
						p->is_caret_tail = n_posix_true;
					}

					n_win_txtbox_draw_selection( p, N_WIN_TXTBOX_WM_LBUTTON_TRIPLE );

				} else {
//n_win_txtbox_hwndprintf_literal( p, " Single Click " );
//break;

					n_type_int prv_sel_y  = p->select_cch_y;
					n_type_int prv_sel_sy = p->select_cch_sy;


					p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;

					p->is_dragging = n_posix_false;


					n_win_txtbox_message_redirect( p, hwnd, msg );


					n_type_int prv_sel_sx = p->select_cch_sx;

					{
//n_win_txtbox_hwndprintf_literal( p, " Dragging Start : %d : %d ", p->shift_dragging, p->prv_drag );

						n_win_txtbox_unselect( p );
						n_win_txtbox_select( p, p->hover_cch_x, p->hover_cch_y, 0, 1 );

						n_type_int f = p->select_cch_x;
						n_type_int t = p->scroll_pxl_tabbed_x / p->font_pxl_sx;

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", (int) f,  (int) t );

						if ( f < t )
						{
							n_type_int tmp = p->scroll_pxl_tabbed_y;
							n_win_txtbox_autofocus( p, n_posix_true );
							p->scroll_pxl_tabbed_y = tmp;
						}

						n_win_txtbox_drag_select2drag( p );

					}


					if ( ( prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
					{
						if ( prv_sel_y == p->select_cch_y )
						{
//n_win_txtbox_hwndprintf_literal( p, " fast : %d %d ", p->prv_sel_sx, p->select_cch_sx );
//n_win_txtbox_hwndprintf_literal( p, " fast : %d %d ", p->drag_cch_min, p->drag_cch_max );
//n_win_txtbox_hwndprintf_literal( p, " fast : %d ", prv_sel_sx );
							if ( prv_sel_sx == 0 )
							{
//n_win_txtbox_hwndprintf_literal( p, " fast #1 " );
								p->optimization_click_onoff = n_posix_true;
								n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_LBUTTONDOWN, p->select_cch_y, 1 );
								p->optimization_click_onoff = n_posix_false;
							} else {
//n_win_txtbox_hwndprintf_literal( p, " fast #2 " );
								n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_LBUTTONDOWN, p->select_cch_y, 1 );
							}
						} else {
//n_win_txtbox_hwndprintf_literal( p, " fast #3 " );
							n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_LBUTTONDOWN,       prv_sel_y, 1 );
							n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_LBUTTONDOWN, p->select_cch_y, 1 );
						}
					} else {
//n_win_txtbox_hwndprintf_literal( p, " slow " );
						n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_LBUTTONDOWN );
					}

//break;

					p->is_captured = n_posix_true;
					SetCapture( hwnd );

					GetCursorPos( &p->drag_pt );
					p->drag_phase = N_WIN_TXTBOX_DRAG_PHASE_CLICKED;

				}

			} else { break; }

		} else {
//n_win_txtbox_debug_count( p );

			n_posix_bool ret = n_win_txtbox_line_select( p, p->hover_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", ret );


			if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL )
			{
				if ( p->hover_cch_y >= p->txt.sy ) { break; }
			}


			n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_LBUTTONDOWN );

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				n_win_scrollbar_refresh( &p->hscr );
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
			{
				n_win_scrollbar_refresh( &p->vscr );
			}


			if ( ( ret == n_posix_false )&&( p->select_cch_sy ) )
			{
//n_posix_debug_literal( " %d %d %d ", p->hover_cch_y, p->select_cch_y, p->select_cch_sy );
				n_win_txtbox_message_redirect( p, hwnd, msg );
			}

		}

	}
	break;

	case WM_TIMER :
	{
//break;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != p->drag_timer ) { break; }


		n_win_txtbox_is_hovered( p );


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
//break;
			if ( p->is_captured == n_posix_false ) { break; }


			p->is_dragging = n_posix_true;
			n_win_txtbox_drag( p );

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_y, p->select_cch_sy );

			n_win_txtbox_draw_selection( p, N_WIN_TXTBOX_WM_TIMER_MOUSE );

		}

	}
	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :
	{

		if ( ( msg == WM_RBUTTONUP )&&( n_win_is_input( VK_LBUTTON ) ) ) { break; }


		p->vk_mouse = 0;


		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ) { n_win_txtbox_message_redirect( p, hwnd, msg ); break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			if ( msg == WM_RBUTTONUP )
			{
//n_win_txtbox_debug_count( p );

				if ( p->ime_composition_onoff ) { break; }


				// [Needed] : for multiple instances

				if ( n_win_txtbox_is_hovered( p ) )
				{

					if ( n_win_menu_stop_onoff ) { break; }


					p->menu_onoff = n_posix_true;
					n_win_message_send( GetParent( p->hwnd ), WM_SETCURSOR, p->hwnd, 0 );

					if ( p->is_hovered_linenum )
					{
						p->menu_type = N_WIN_TXTBOX_MENU_LINE;

						n_win_simplemenu_show( &p->menu_linenum, hwnd );
					} else {
						p->menu_type = N_WIN_TXTBOX_MENU_MAIN;

						if ( p->style_option & N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT )
						{
							p->menu_delay = n_posix_true;
						} else {
							n_win_simplemenu_show( &p->menu_editbox, hwnd );
						}
					}

				}

			} else
			if ( msg == WM_MBUTTONUP )
			{

				if ( p->is_hovered_linenum )
				{
					n_win_txtbox_autofocus( p, n_posix_false );
					n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_MBUTTONUP );
				}

			} else
			if ( msg == WM_LBUTTONUP )
			{

				// [!] : don't do n_win_txtbox_is_hovered()
				//
				//	capture will not be released when a cursor goes outside of a window

				if ( p->is_captured )
				{

					if ( p->drag_phase )
					{
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", p->shift_dragging, p->shift_dragging_start_x, p->shift_dragging_start_pxl_x );

						if (
							( p->drag_phase == N_WIN_TXTBOX_DRAG_PHASE_STARTED )
							&&
							( p->select_cch_sx != 0 )
						)
						{
							p->shift_dragging_start_x     = p->select_cch_x;
							p->shift_dragging_start_pxl_x = p->ime.x;

							if ( p->shift_dragging == VK_LEFT )
							{
								p->shift_dragging_start_x += p->select_cch_sx;
							}
						}

						p->drag_phase   = N_WIN_TXTBOX_DRAG_PHASE_NEUTRAL;
						p->drag_cch_min = N_WIN_TXTBOX_NOT_SELECTED;
						p->drag_cch_max = N_WIN_TXTBOX_NOT_SELECTED;

						n_win_timer_exit( hwnd, p->drag_timer );
					}

					ReleaseCapture();

					p->hscr.stop_onoff = n_posix_false;
					p->vscr.stop_onoff = n_posix_false;

					p->is_captured = n_posix_false;
					p->is_dragging = n_posix_false;

				}

			}

		}


		n_win_txtbox_message_redirect( p, hwnd, msg );

	}
	break;


	} // switch


	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_RESIZER )
	{
		n_posix_bool ret = n_win_txtbox_input_resizer_proc( hwnd, msg, wparam, lparam, p );
		if ( ret ) { return ret; }
	}


	if ( p->menu_type == N_WIN_TXTBOX_MENU_MAIN )
	{
		n_win_txtbox_proc_menu_editbox( hwnd, msg, wparam, lparam, p );
	}

	if ( p->menu_type == N_WIN_TXTBOX_MENU_LINE )
	{
		n_win_txtbox_proc_menu_linenum( hwnd, msg, wparam, lparam, p );
	}


	n_win_txtbox_proc_mouse_aero_combo( hwnd, msg, wparam, lparam, p );


	return n_posix_false;
}


