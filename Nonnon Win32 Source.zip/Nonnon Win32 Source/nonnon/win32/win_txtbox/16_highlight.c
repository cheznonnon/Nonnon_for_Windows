// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_posix_bool
n_win_txtbox_is_highlighted_main( n_win_txtbox *p, n_type_int x, n_type_int y )
{

	if ( p == NULL ) { return n_posix_false; }


	n_type_int sx = p->select_cch_sx;
	n_type_int sy = p->select_cch_sy;

	if ( sx == 0 ) { return n_posix_false; }
	if ( sy == 0 ) { return n_posix_false; }

	if ( sx == N_WIN_TXTBOX_ALL ) { sx = x + 1; }
	if ( sy == N_WIN_TXTBOX_ALL ) { sy = y + 1; }


	if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS )
	{
		sx += 3;
	}


	n_type_int fx = p->select_cch_x;
	n_type_int fy = p->select_cch_y;
	n_type_int tx = p->select_cch_x + sx - 1;
	n_type_int ty = p->select_cch_y + sy - 1;

	if (
		( ( fx <= x )&&( x <= tx ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		return n_posix_true;
	}

	if (
		( ( y != fy )&&( y != ty ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		if (
			( p->partial_selection_from_onoff )
			||
			( p->partial_selection_to___onoff )
		)
		{
			return n_posix_true;
		}
	}


	return n_posix_false;
}

n_posix_bool
n_win_txtbox_is_highlighted( n_win_txtbox *p, n_type_int x, n_type_int y )
{

	if ( p == NULL ) { return n_posix_false; }


	if ( y == p->select_cch_y )
	{
//n_win_txtbox_hwndprintf_literal( p, " Min " );

		if ( ( p->partial_selection_from_onoff )||( p->partial_selection_to___onoff ) )
		{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );

			if ( p->partial_selection_from_cch_x <= x )
			{
				return n_posix_true;
			}

		} else {
//n_win_txtbox_hwndprintf_literal( p, " 2 " );

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else
	if ( y == ( p->select_cch_y + p->select_cch_sy - 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Max " );

		if ( ( p->partial_selection_from_onoff )||( p->partial_selection_to___onoff ) )
		{

			if ( p->partial_selection_to___cch_x > x )
			{
				return n_posix_true;
			}

		} else {

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else {
//n_win_txtbox_hwndprintf_literal( p, " N/A " );

		return n_win_txtbox_is_highlighted_main( p, x,y );

	}


	return n_posix_false;
}


