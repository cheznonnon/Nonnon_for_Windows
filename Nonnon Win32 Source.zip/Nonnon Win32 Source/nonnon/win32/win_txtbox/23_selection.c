// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_posix_bool
n_win_txtbox_is_selected( n_win_txtbox *p )
{

	if ( p == NULL ) { return n_posix_false; }


	if ( p->select_cch_sx == N_WIN_TXTBOX_ALL ) { return n_posix_true; }
	if ( p->select_cch_sy == N_WIN_TXTBOX_ALL ) { return n_posix_true; }

	if ( p->select_cch_sx > 0 ) { return n_posix_true; }
	if ( p->select_cch_sy > 1 ) { return n_posix_true; }


	return n_posix_false;
}

#define n_win_txtbox_selection_mod( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_MOD )
#define n_win_txtbox_selection_del( p    ) n_win_txtbox_selection( p, NULL, N_WIN_TXTBOX_LINE_DEL )
#define n_win_txtbox_selection_get( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_GET )
#define n_win_txtbox_selection_cat( p, s ) n_win_txtbox_selection( p,    s, N_WIN_TXTBOX_LINE_CAT )
#define n_win_txtbox_selection_cch( p    ) n_win_txtbox_selection( p, NULL, N_WIN_TXTBOX_LINE_CCH )

n_type_int
n_win_txtbox_selection( n_win_txtbox *p, n_posix_char *str, int mode )
{

	if ( p == NULL ) { return 0; }


	if ( mode == N_WIN_TXTBOX_LINE_GET ) { n_string_truncate( str ); }


	// [!] : don't use n_win_txtbox_is_selected( p ) : single line is exluded

	if ( p->select_cch_sy <= 0 ) { return 0; }


	if ( mode == N_WIN_TXTBOX_LINE_CAT )
	{
		if ( n_win_txtbox_is_selected( p ) )
		{
			extern void n_win_txtbox_edit_del( n_win_txtbox *p );
			n_win_txtbox_edit_del( p );
		}
	}


	return n_win_txtbox_line( p, p->select_cch_y, str, mode );
}

n_posix_char*
n_win_txtbox_selection_new( n_win_txtbox *p )
{

	// [!] : n_string_free()/n_string_path_free() a returned string

	n_type_int    cch = n_win_txtbox_selection_cch( p );
	n_posix_char *str = n_string_path_new( cch );


	n_win_txtbox_selection_get( p, str );


	return str;
}


