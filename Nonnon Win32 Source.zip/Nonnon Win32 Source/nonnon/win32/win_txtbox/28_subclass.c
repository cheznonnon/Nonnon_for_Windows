// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_subclass_clamp( n_win_txtbox *p, int vk )
{

	if ( vk == VK_LEFT )
	{

		n_type_int pxl_fx;
		n_type_int pxl_tx = p->scroll_pxl_tabbed_x + p->page_pxl_tabbed_sx - p->number_pxl_sx;

		n_win_txtbox_tabbedmetrics( p, p->select_cch_y, -1,p->select_cch_x,-1, NULL, NULL, &pxl_fx );
		pxl_fx *= p->font_pxl_sx;

//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : %d %lld %lld ", p->client_pxl_sx, pxl_fx, pxl_tx );

		if ( pxl_fx > pxl_tx )
		{
			n_type_int x = pxl_fx - ( p->page_pxl_tabbed_sx / 2 );

			n_win_txtbox_scroll( p, x, p->scroll_pxl_tabbed_y );
		}
	} else
	if ( vk == VK_RIGHT )
	{
		n_type_int pxl_fx;
		n_type_int pxl_tx = p->scroll_pxl_tabbed_x;

		n_win_txtbox_tabbedmetrics( p, p->select_cch_y, -1,p->select_cch_x,-1, NULL, NULL, &pxl_fx );
		pxl_fx *= p->font_pxl_sx;

		if ( pxl_fx < pxl_tx )
		{
			n_win_txtbox_autofocus( p, n_posix_true );
		}
	}


	return;
}

void
n_win_txtbox_caret_on_timer( n_win_txtbox *p )
{
//return;

	if ( p == NULL ) { return; }
//if ( p->hwnd == GetFocus() ) { n_win_txtbox_debug_count( p ); }


	if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX ) { return; }


	n_win_txtbox_metrics_caret( p );


	if ( p->hwnd != GetFocus() ) { return; }


	if ( p->prv_caret_x != p->caret_pxl_x )
	{
		n_win_txtbox_caret_reset( p, n_posix_true );
	}


	// [!] : Slow Mode

	//n_win_txtbox_draw( p, N_WIN_TXTBOX_CARET_ON_TIMER );
	//return;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->select_cch_y, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->caret_pxl_x, p->caret_pxl_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff );

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		// [x] : optimization : currently not working

		p->optimization_stop = n_posix_true;

		n_win_txtbox_draw( p, N_WIN_TXTBOX_CARET_ON_TIMER );

		p->optimization_stop = n_posix_false;
	} else
	if ( p->prv_caret_y == p->caret_pxl_y )
	{
		p->optimization_caret_onoff = n_posix_true;

		n_type_int y = p->select_cch_y;
		if ( p->partial_selection_from_onoff ) { y += p->select_cch_sy - 1; }

		n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_CARET_ON_TIMER, y, 1 );

		p->optimization_caret_onoff = n_posix_false;
	}


	p->prv_caret_x = p->caret_pxl_x;
	p->prv_caret_y = p->caret_pxl_y;


	return;
}

void
n_win_txtbox_on_focus( n_win_txtbox *p, n_posix_bool is_set )
{
//return;

	if ( p == NULL ) { return; }


	if ( p->focus_fade_is_set_prv == is_set ) { return; }

	p->focus_fade_is_set_prv = is_set;


	// [x] : N_WIN_TXTBOX_STYLE_LISTBOX : not supported

	if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
	{

		return;

	} else
	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		||
		( p->global_fade_onoff == n_posix_false )
	)
	{

		n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );

		return;
	}


	n_bmp_free( &p->focus_fade_bmp_old );
	n_bmp_free( &p->focus_fade_bmp_new );


	n_posix_bool p_stop = p->optimization_stop;

	p->bitblt_stop       = n_posix_true;
	p->optimization_stop = n_posix_true;


	n_type_int sel_sx = p->select_cch_sx; p->select_cch_sx = p->focus_fade_prv_sel_sx;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->focus_fade_prv_sel_sx );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
	{
		//
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON )
	{
		p->color_back_noselect = p->color_back_disabled;
		p->color_back_selected = p->color_sel_focus_off;
	} else
	if ( p->grayed_onoff )
	{
		if ( p->is_grayed )
		{
			p->color_back_noselect = p->color_back_disabled;
			p->color_back_selected = p->color_sel_focus_off;
		} else {
			p->color_back_noselect = p->color_back__enabled;
		}
	}

	if ( is_set )
	{
		p->selected_border_onoff = n_posix_false;
	} else {
		p->selected_border_onoff = n_posix_true;
	}

	n_win_txtbox_smallbutton_direct_fade( p, p->selected_border_onoff );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT )
	{
		//
	} else {
		n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );
	}

	n_bmp_carboncopy( &p->bmp, &p->focus_fade_bmp_old );

	p->select_cch_sx = sel_sx;


	if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
	{
		//
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON )
	{
		p->color_back_noselect = p->color_back_disabled;
		p->color_back_selected = p->color_sel_focus_off;
	} else
	if ( p->grayed_onoff )
	{
		if ( p->is_grayed )
		{
			p->color_back_noselect = p->color_back_disabled;
			p->color_back_selected = p->color_sel_focus_off;
		} else {
			p->color_back_noselect = p->color_back__enabled;
		}
	}

	if ( is_set )
	{
		p->selected_border_onoff = n_posix_true;
	} else {
		p->selected_border_onoff = n_posix_false;
	}

	n_win_txtbox_smallbutton_direct_fade( p, p->selected_border_onoff );

	n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );
	n_bmp_carboncopy( &p->bmp, &p->focus_fade_bmp_new );


	p->optimization_stop = p_stop;
	//p->bitblt_stop       = n_posix_false; // [!] : delayed : see WM_TIMER


	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_PARENT_BACKGRND )
	{
		//
	} else {
		n_bmp_alpha_visible( &p->focus_fade_bmp_old );
		n_bmp_alpha_visible( &p->focus_fade_bmp_new );
	}

/*
if ( n_win_is_input( VK_F2 ) )
{
	n_bmp_save_literal( &p->focus_fade_bmp_old, "old.bmp" );
	n_bmp_save_literal( &p->focus_fade_bmp_new, "new.bmp" );
}
*/

	p->focus_fade_is_running = n_posix_true;

	if ( p->focus_fade_timer == 0 ) { p->focus_fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd, p->focus_fade_timer, 16 );


	return;
}

void
n_win_txtbox_ime_fade_go( n_win_txtbox *p )
{

	if ( p->global_fade_onoff == n_posix_false )
	{
		return;
	}


	n_win_txtbox_caret_onoff( p, n_posix_false );

	n_posix_bool prv_onoff = p->ime_onoff;
	n_posix_bool cur_onoff = n_win_ime_is_on( p->hwnd );

	if ( cur_onoff ) { prv_onoff = n_posix_false; } else { prv_onoff = n_posix_true; }
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", prv_onoff, cur_onoff );


	//if ( 0 )
	{
		p->bitblt_stop = n_posix_true;
		p->ime_onoff   = prv_onoff;
		n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
		p->bitblt_stop = n_posix_false;

		n_bmp_free( &p->ime_fade_bmp_old );
		n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_old );
//n_bmp_flush( &p->ime_fade_bmp_old, n_bmp_rgb( 0,100,200 ) );

//if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) ) { n_bmp_save_literal( &p->ime_fade_bmp_old, "old.bmp" ); }
	}


	p->ime_onoff = cur_onoff;
	n_win_txtbox_ime_watch_color( p );

	n_win_txtbox_on_setcursor( p );


	p->bitblt_stop = n_posix_true;
	n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
	p->bitblt_stop = n_posix_false;


	//if ( 0 )
	{
		n_bmp_free( &p->ime_fade_bmp_new );
		n_bmp_carboncopy( &p->bmp, &p->ime_fade_bmp_new );
//n_bmp_flush( &p->ime_fade_bmp_new, n_bmp_rgb( 0,200,255 ) );

//if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) ) { n_bmp_save_literal( &p->ime_fade_bmp_new, "new.bmp" ); }
	}


	p->ime_fade_is_running = n_posix_true;

	if ( p->ime_fade_timer == 0 ) { p->ime_fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd, p->ime_fade_timer, 16 );


	return;
}

void
n_win_txtbox_ime_fade_patch( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->global_fade_onoff == n_posix_false )
	{
		return;
	}


	// [!] : misbehave while fading

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->ime_fade_is_running, p->ime_onoff, n_win_ime_is_on( p->hwnd ) );

	if ( p->ime_fade_is_running )
	{
//n_win_txtbox_hwndprintf_literal( p, " ! " );

		p->ime_fade_percent = 100;

		p->bitblt_stop = n_posix_true;
		n_win_txtbox_draw( p, N_WIN_TXTBOX_IME_FADE );
		p->bitblt_stop = n_posix_false;

		n_bmp_flush_fastcopy( &p->bmp, &p->ime_fade_bmp_old );
		n_bmp_flush_fastcopy( &p->bmp, &p->ime_fade_bmp_new );

		n_win_message_send( p->hwnd, WM_TIMER, p->ime_fade_timer, 0 );

	}


	return;
}

void
n_win_txtbox_focus_fade_patch( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( p->global_fade_onoff == n_posix_false )
	{
		return;
	}


	// [!] : misbehave while fading

	if ( p->focus_fade_is_running )
	{

		p->focus_fade_percent = 100;

		n_win_txtbox_smallbutton_direct_fade( p, n_posix_false );

		n_win_message_send( p->hwnd, WM_TIMER, p->focus_fade_timer, 0 );

	}


	return;
}

void
n_win_txtbox_ime_composition_window_set( n_win_txtbox *p, HIMC himc )
{

	if ( p == NULL ) { return; }


	if ( p->ime.x < 0 ) { return; }
	if ( p->ime.y < 0 ) { return; }


	COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, p->ime, { 0,0,0,0 } };

	ImmSetCompositionWindow( himc, &cf );


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_txtbox *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }
#else  // #ifdef _WIN64
	n_win_txtbox *p = (void*) n_win_property_get( hwnd, N_WIN_TXTBOX_NAMESPACE );
	if ( p == NULL ) { return 0; }
#endif // #ifdef _WIN64


	static HWND hwnd_focus = NULL;


	switch( msg ) {


	case 648 : // WM_IME_REQUEST
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %x ", wparam, lparam );

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		if ( wparam == IMR_RECONVERTSTRING )
		{

			if ( n_posix_false == n_win_txtbox_is_selected( p ) ) { break; }


			// [Needed] : crash prevention

			if ( p->select_cch_sy > 1 )
			{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_REQUEST : %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff );

				n_posix_bool min_onoff = p->partial_selection_from_onoff;
				//n_posix_bool max_onoff = p->partial_selection_to___onoff;

				n_win_txtbox_unselect( p );

				if ( min_onoff ) { p->select_cch_y--; }
				//if ( max_onoff ) { p->select_cch_y++; }

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_IME_REQUEST );

				break;
			}


			n_posix_char *line     = n_txt_get( &p->txt, p->select_cch_y );
			n_posix_char *word     = n_string_carboncopy( &line[ p->select_cch_x ] );

			if ( p->select_cch_sx ) { n_string_terminate( word, p->select_cch_sx ); }

			n_type_int    word_cch = n_posix_strlen( word ) + 1;
			n_type_int    word_cb  = sizeof( n_posix_char    ) * word_cch;
			n_type_int    rcnv_cb  = sizeof( RECONVERTSTRING );
			u8           *data     = (void*) lparam;
			LRESULT       lret     = rcnv_cb + word_cb;

			if ( data != NULL )
			{

				RECONVERTSTRING rcs = { (DWORD) rcnv_cb, 0, (DWORD) word_cch, (DWORD) rcnv_cb, (DWORD) word_cch, 0, (DWORD) word_cch, 0, };
				n_type_int      i   = 0;

				n_memory_copy( &rcs, &data[ i ], rcnv_cb ); i += rcnv_cb;
				n_memory_copy( word, &data[ i ], word_cb ); i += word_cb;

				n_win_message_send( hwnd, WM_IME_COMPOSITION, 0,0 );

				lret = (LRESULT) data;

			}

			n_memory_free( word );
			return lret;

		} else
		if ( wparam == 0x0005 ) // IMR_CONFIRMRECONVERTSTRING
		{

			// [!] : never sent

		} else
		if ( wparam == 0x0006 ) // IMR_QUERYCHARPOSITION
		{
//n_posix_debug_literal( " ! " );

			IMECHARPOSITION *icp = (void*) lparam;
			if ( icp == NULL ) { return n_posix_false; }

			RECT            rect; n_win_rect_set( &rect, 0,0,0,0 );
			POINT           pt   = { p->ime.x, p->ime.y }; ClientToScreen( hwnd, &pt );
			IMECHARPOSITION ret  = { sizeof( IMECHARPOSITION ), 0, pt, p->cell_pxl_sy, rect };
			*icp = ret;

			return n_posix_true;

		}

	}
	break;

	case WM_IME_STARTCOMPOSITION :
	{

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }


		p->ime_composition_onoff = n_posix_true;


		n_win_txtbox_edit_on_typing( p );


		// [!] : rewrite p->ime

		// [x] : called many times when space character is input
//n_win_txtbox_debug_count( p );

		n_type_int y,sy; n_win_txtbox_previous_calc( p, &y, &sy );
		n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_KEYDOWN, y, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime.y );


		HIMC himc = ImmGetContext( hwnd );

		LOGFONT lf = n_win_font_hwnd2logfont( p->hwnd );
		ImmSetCompositionFont( himc, &lf );

		n_win_txtbox_ime_composition_window_set( p, himc );

		ImmReleaseContext( hwnd, himc );

	}
	break;

	case WM_IME_COMPOSITION :
	{
//n_win_txtbox_hwndprintf_literal( p, " WM_IME_COMPOSITION : %d %x ", wparam, lparam );

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }
		if ( p->txt.readonly ) { break; }

		// [!] : this message can replace WM_IME_STARTCOMPOSITION and WM_IME_ENDCOMPOSITION

		// [ Mechanism ]
		//
		//	0x01b9 : Start
		//	0x1e00 : End
		//	0x1fb9 : Auto-Confirmation : End + Start

		const int start = GCS_DELTASTART | GCS_CURSORPOS | GCS_COMPCLAUSE | GCS_COMPATTR | GCS_COMPSTR | GCS_COMPREADSTR;
		const int end   = GCS_RESULTCLAUSE | GCS_RESULTSTR | GCS_RESULTREADCLAUSE | GCS_RESULTREADSTR;

		HIMC himc = ImmGetContext( hwnd );

		if ( lparam & end )
		{

			// [ Mechanism ] : ImmGetCompositionString()
			//
			//	this API doesn't write "\0"
			//
			//	return value will always be DBCS unit
			//	an ASCII character will be 1
			//	a  kanji character will be 2

			n_type_int    n = (n_type_int) ImmGetCompositionString( himc, GCS_RESULTSTR, NULL, 0 );
			if ( n > ULONG_MAX ) { break; }

			n_posix_char *s = n_string_new( n * 4 );
			if ( s == NULL ) { break; }

			ImmGetCompositionString( himc, GCS_RESULTSTR, s, (DWORD) n );

//n_win_txtbox_hwndprintf_literal( p, " %s : %d", s, n );

			if ( ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )&&( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ) )
			{
				n_posix_bool ret = n_win_txtbox_filename_is_safe( s );
				if ( ret == n_posix_false ) { n_memory_free( s ); break; }
			}

			if ( p->txt.readonly == n_posix_false )
			{
				n_win_txtbox_previous( p );

				n_win_txtbox_selection_cat( p, s );

//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				n_type_int y,sy; n_win_txtbox_previous_calc( p, &y, &sy );
				n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_IME_COMPOSITION, y, sy );

				p->shift_dragging_start_x     = p->select_cch_x;
				p->shift_dragging_start_pxl_x = p->ime.x;
			}

			n_memory_free( s );

			n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );

		}

		if ( lparam & start )
		{

			LOGFONT lf = n_win_font_hwnd2logfont( p->hwnd );
			ImmSetCompositionFont( himc, &lf );

			n_win_txtbox_ime_composition_window_set( p, himc );

		}

		ImmReleaseContext( hwnd, himc );


		n_win_txtbox_ime_fade_patch( p );

	}
	break;

	case WM_IME_ENDCOMPOSITION :

		p->ime_composition_onoff = n_posix_false;

	break;

	case WM_IME_NOTIFY :

		if ( wparam == IMN_SETOPENSTATUS )
		{
//n_win_txtbox_debug_count( p );

			n_posix_bool ret = (n_posix_bool) n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );

			if ( ret == n_posix_false ) { n_win_txtbox_ime_fade_go( p ); }

		}

	break;


	case WM_ERASEBKGND :

		//n_win_txtbox_draw( p, 0 );

		return n_posix_true;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/

	case WM_SIZE :

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			n_win_txtbox_metrics( p );
			n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_SIZE );
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{
			n_win_txtbox_metrics( p );
			n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_SIZE );
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
			if (1)//( p->cache_init_done )
			{
				n_win_txtbox_metrics( p );
				n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_SIZE );
			} else {
				p->cache_init_done = n_posix_true;
			}
		}

	break;


	case WM_TIMER :
//n_win_txtbox_debug_count( p );
//break;

		if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { break; }


		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == p->caret_timer )
		{
//break;

//n_win_txtbox_debug_count( p );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->caret_timer );

			n_win_txtbox_caret_on_timer( p );

		} else
		if ( wparam == p->input_timer )
		{
//break;
			n_win_timer_exit( p->hwnd, p->input_timer );

			if ( p->txt.readonly ) { break; }

			p->input_onoff = n_posix_false;

		} else
		if ( wparam == p->ime_fade_timer )
		{
//break;
			if ( p->ime_fade_percent == 0 )
			{
				p->         bmp    .transparent_onoff = n_posix_false;
				p->ime_fade_bmp_old.transparent_onoff = n_posix_false;
				p->ime_fade_bmp_new.transparent_onoff = n_posix_false;
//n_bmp_flush( &p->ime_fade_bmp_old, n_bmp_rgb( 0,200,255 ) );
//n_bmp_flush( &p->ime_fade_bmp_new, n_bmp_rgb( 0,200,255 ) );
			}

			n_posix_bool ret = n_bmp_ui_transition
			(
				&p->bmp,
				&p->ime_fade_bmp_old,
				&p->ime_fade_bmp_new,
				N_BMP_FADE_MSEC,
				&p->ime_fade_percent,
				//N_BMP_UI_TRANSITION_WIPE_X
				N_BMP_UI_TRANSITION_FADE
			);

			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				//
			} else {
				n_bmp_alpha_visible( &p->bmp );
			}

			n_win_txtbox_draw_sync( p );

			if ( ret )
			{
//n_win_txtbox_debug_count( p );
				n_win_timer_exit( p->hwnd, p->ime_fade_timer );

				n_bmp_free( &p->ime_fade_bmp_old );
				n_bmp_free( &p->ime_fade_bmp_new );

				p->ime_fade_is_running = n_posix_false;

				n_win_txtbox_caret_onoff( p, n_posix_true );
			}

		} else
		if ( wparam == p->focus_fade_timer )
		{
//n_win_txtbox_debug_count( p );

			if ( p->focus_fade_percent == 0 )
			{
				p->           bmp    .transparent_onoff = n_posix_false;
				p->focus_fade_bmp_old.transparent_onoff = n_posix_false;
				p->focus_fade_bmp_new.transparent_onoff = n_posix_false;
			}
//n_win_txtbox_hwndprintf_literal( p, " %d ", (int) p->focus_fade_percent );

			n_posix_bool ret = n_bmp_ui_transition
			(
				&p->bmp,
				&p->focus_fade_bmp_old,
				&p->focus_fade_bmp_new,
				N_BMP_FADE_MSEC,
				&p->focus_fade_percent,
				N_BMP_UI_TRANSITION_FADE
			);

			n_win_txtbox_draw_sync( p );

			if ( ret )
			{
				n_win_timer_exit( p->hwnd, p->focus_fade_timer );

				n_bmp_free( &p->focus_fade_bmp_old );
				n_bmp_free( &p->focus_fade_bmp_new );

				p->bitblt_stop = n_posix_false;

				p->smallbutton_once = n_posix_false;

				n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_TIMER );

				if ( p->menu_delay )
				{
					p->menu_delay = n_posix_false;
					n_win_simplemenu_show( &p->menu_editbox, p->hwnd );
				}

				p->focus_fade_is_running = n_posix_false;
			}

		} else
		if ( wparam == p->smallbutton_timer )
		{

			if ( p->ime_fade_is_running ) { break; }

			n_win_txtbox_refresh( p, 0 );

		} else
		if ( wparam == p->aero_combo_timer )
		{

			n_bmp_fade_engine( &p->aero_combo_fade, n_posix_true );
			if ( p->aero_combo_fade.stop )
			{
				n_win_timer_exit( p->hwnd, p->aero_combo_timer );
			}

			n_win_txtbox_refresh( p, 0 );

		}

	break;


	case WM_SETFOCUS :
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime_onoff );
//n_win_txtbox_debug_count( p );
//break;

		hwnd_focus = p->hwnd;

//n_win_txtbox_hwndprintf_literal( p, " SET %x %x %x ", hwnd_focus, GetFocus(), wparam );


		p->ime_onoff = n_win_ime_is_on( p->hwnd );

		if ( p->ime_onoff )
		{

			HIMC himc = ImmGetContext( hwnd );

			n_win_txtbox_ime_composition_window_set( p, himc );

			ImmReleaseContext( hwnd, himc );

		}


//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_sel_sx, p->select_cch_sx );

		n_win_txtbox_caret_reset( p, n_posix_true );

		n_win_txtbox_ime_watch_color( p );

		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );


		if ( p->style_option & N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT )
		{
			n_win_txtbox_on_focus( p, n_posix_true );
		}

	break;

	case WM_KILLFOCUS :
//n_win_txtbox_hwndprintf_literal( p, " KILL %x %x %x ", hwnd_focus, GetFocus(), wparam );
//break;

		p->delayed_focus = n_posix_false;


		n_win_txtbox_ime_watch_color( p );

		if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
		{

			//

		} else
		if ( p->style_option & N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY )
		{

			//

		} else
		if ( p->style_option & N_WIN_TXTBOX_OPTION_STRICT_FOCUS_ON )
		{

			if ( wparam == 0 )
			{
				p->color_back_selected = p->color_sel_focus_off;
			}

		} else {

			if (
				( wparam == 0 )
				||
				( n_win_property_get( hwnd_focus, N_WIN_TXTBOX_NAMESPACE_FOCUS ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " ! " );

				p->color_back_selected = p->color_sel_focus_off;
			}

		}


		p->focus_fade_prv_sel_sx = p->select_cch_sx;

		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, msg, p->hwnd );


		// [Needed] : grayed caret

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
			n_win_txtbox_refresh( p, 0 );
		}


		if ( p->style_option & N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT )
		{
			n_win_txtbox_on_focus( p, n_posix_false );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == p->hscr.hwnd )
		{

			n_type_int prv = p->scroll_pxl_tabbed_x;

			p->scroll_pxl_tabbed_x = (n_type_gfx) wparam;

			if ( p->is_font_monospace )
			{
				p->scroll_pxl_tabbed_x = p->scroll_pxl_tabbed_x / p->font_pxl_sx * p->font_pxl_sx;
			}

			if ( prv != p->scroll_pxl_tabbed_x )
			{
				if ( p->scroll_callback )
				{
					if ( p->scroll_callback( p->hscr.hwnd, WM_HSCROLL, 0,0 ) ) { break; }
				}

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_COMMAND );
				n_win_scrollbar_draw_always( &p->hscr, n_posix_true );
			}


			if ( p->ime_composition_onoff )
			{

				HIMC himc = ImmGetContext( hwnd );

				n_win_txtbox_ime_composition_window_set( p, himc );

				ImmReleaseContext( hwnd, himc );

			}

		} else
		if ( (HWND) lparam == p->vscr.hwnd )
		{
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_shaft, p->vscr.pixel_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", fmod( p->vscr.pixel_shaft, p->vscr.pixel_thumb ) / p->vscr.pixel_thumb, p->vscr.pixel_modulo );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.pixel_pos, p->vscr.unit_pos );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", wparam, p->vscr.pressed_thumb );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_arrow );
//n_win_txtbox_hwndprintf_literal( p, " %f %f ", p->vscr.base_page / p->vscr.base_max, p->vscr.base_max );
//n_win_txtbox_hwndprintf_literal( p, " %f ", p->vscr.pixel_step );
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->vscr.fade_thumb.stop );

			n_type_int pos = (n_type_int) wparam;
			n_type_int prv = p->scroll_pxl_tabbed_y;

			n_type_int aln = 1;

			if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
			{
				aln = n_posix_max_n_type_int( 1, p->cell_pxl_sy );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				aln = n_posix_max_n_type_int( 1, p->cell_pxl_sy );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
			{
				if ( p->vscr.arrow_is_event_running )
				{
					if ( p->vscr.pressed_arrow_ul )
					{
						n_type_real m = fmod( (n_type_real) pos, p->vscr.unit_step );
//n_win_txtbox_hwndprintf_literal( p, " %f ", m );

						if ( m != 0 )
						{
							pos -= (n_type_int) ( m - p->vscr.unit_step );
						}
					} else
					if ( p->vscr.pressed_arrow_dr )
					{
						n_type_real m = fmod( (n_type_real) pos, p->vscr.unit_step );
//n_win_txtbox_hwndprintf_literal( p, " %f ", m );

						if ( m != 0 )
						{
							pos -= (n_type_int) m;
						}
					} else
					if ( p->vscr.pressed_shaft )
					{
						n_type_real m = fmod( (n_type_real) pos, p->vscr.unit_step );

						if ( m != 0 )
						{
							pos -= (n_type_int) ( m - p->vscr.unit_step );
						}
					}
				}
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX )
			{
				aln = n_posix_max_n_type_int( 1, p->cell_pxl_sy );
			} else
			if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
			{
				aln = n_posix_max_n_type_int( 1, p->cell_pxl_sy );
			}

			p->scroll_pxl_tabbed_y = pos / aln * aln;


			if ( prv != p->scroll_pxl_tabbed_y )
			{
//n_posix_debug_literal( "" );
				if ( p->scroll_callback )
				{
					if ( p->scroll_callback( p->vscr.hwnd, WM_VSCROLL, 0,0 ) ) { break; }
				}

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_COMMAND );
				n_win_scrollbar_draw_always( &p->vscr, n_posix_true );
			}


			if ( p->ime_composition_onoff )
			{

				HIMC himc = ImmGetContext( hwnd );

				n_win_txtbox_ime_composition_window_set( p, himc );

				ImmReleaseContext( hwnd, himc );

			}

		}

	break;


	case WM_KEYUP :
//n_win_txtbox_debug_count( p );

		if ( n_win_simplemenu_target != NULL ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }
		if ( n_win_is_input( VK_MBUTTON ) ) { break; }
		if ( n_win_is_input( VK_RBUTTON ) ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			p->vk_key = 0;

			//int vk = wparam;

		}


		n_win_timer_init( p->hwnd, p->input_timer, p->input_msec );

	break;

	case WM_KEYDOWN :
	{
//n_win_txtbox_debug_count( p );

//n_win_txtbox_hwndprintf_literal( p, " %d %x ", wparam, wparam );
//break;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_KEYDOWN )
		{
			if ( n_win_message_send( GetParent( hwnd ), msg, wparam, lparam ) ) { break; }
		}


		if ( wparam == VK_F1  )
		{
			//n_win_txtbox_debug_partial_selection( p );
			break;
		}
		if ( wparam == VK_F2  ) { break; }
		if ( wparam == VK_F3  ) { break; }
		if ( wparam == VK_F4  ) { break; }
		if ( wparam == VK_F5  ) { break; }
		if ( wparam == VK_F6  ) { break; }
		if ( wparam == VK_F7  ) { break; }
		if ( wparam == VK_F8  ) { break; }
		if ( wparam == VK_F9  ) { break; }
		if ( wparam == VK_F10 ) { break; }
		if ( wparam == VK_F11 ) { break; }
		if ( wparam == VK_F12 ) { break; }

		// [!] : IME on/off : not VK_KANJI : VK_PROCESSKEY is 229 (0xE5)
		if ( wparam == VK_PROCESSKEY ) { break; }


		if ( n_win_simplemenu_target != NULL ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }
		if ( n_win_is_input( VK_MBUTTON ) ) { break; }
		if ( n_win_is_input( VK_RBUTTON ) ) { break; }


		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{

			int vk = (int) wparam;


			p->vk_key = vk;


			if ( vk == VK_SHIFT )
			{
				if ( p->shift_dragging_start_x == N_WIN_TXTBOX_NOT_SELECTED )
				{
					p->shift_dragging_start_x     = p->select_cch_x;
					p->shift_dragging_start_pxl_x = p->ime.x;
				}
			}


			// [Needed] : see WM_LBUTTONDOWN
			if ( vk == VK_SHIFT ) { break; }


			p->is_ud = n_posix_false;
			p->is_lr = n_posix_false;

			n_win_txtbox_caret_reset( p, n_posix_true );


			n_win_txtbox_previous( p );


			n_posix_bool debug_output = n_posix_false;
			n_posix_bool debug_detail = n_posix_false;


			if ( vk == VK_UP )
			{
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", p->select_cch_y );

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				n_posix_bool prv_tail = p->is_caret_tail;
				     p->is_caret_tail = n_posix_false;

				p->shift_dragging_last_left = N_WIN_TXTBOX_NOT_SELECTED;


				n_type_int  x = p->select_cch_x;
				n_type_int  y = p->select_cch_y;
				n_type_int sx = p->select_cch_sx;
				n_type_int sy = p->select_cch_sy;


				if ( n_win_is_input( VK_SHIFT ) )
				{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT " ); }

					p->shift_dragging = VK_UP;

					if ( y == 0 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : full stop : %lld %lld %lld %lld ", x,y,sx,sy ); }

						// [!] : full stop

					} else
					if ( p->partial_selection_from_onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : from_onoff : %lld ", sy ); }
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", x,y,sx,sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->drag_cch_min, p->drag_cch_max, p->drag_cch_x );
//n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : from_onoff : %d : %d %d ", sy, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

						if ( sy == 1 )
						{
							//
						} else
						if ( sy == 2 )
						{
							 x = n_win_txtbox_select_up( p, x,y+1 );
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y+1 ) );

							p->partial_selection_from_onoff = n_posix_false;
							p->partial_selection_to___onoff = n_posix_false;

							p->partial_selection_from_cch_x = x;//N_WIN_TXTBOX_NOT_SELECTED;
							p->partial_selection_to___cch_x = x;//N_WIN_TXTBOX_NOT_SELECTED;

							sx = 0;
							sy = 1;
						} else {
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y+sy-1 ) );
							 x = n_win_txtbox_select_up( p, x,y+sy-1 );
							sx = N_WIN_TXTBOX_ALL;
							sy = sy - 1;
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d %d %d ", prv_tail, x,y,sx,sy );
							p->partial_selection_to___cch_x = x;
						}

						n_win_txtbox_select( p, x,y,sx,sy );
					} else
					if ( sx != 0 )
					{

						if ( p->partial_selection_to___onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : ( sx != 0 ) : to != false : %lld %lld %lld %lld ", x, y, sx, sy ); }

							x = p->partial_selection_from_cch_x;

							n_type_int up_x = n_win_txtbox_select_up( p, x,y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y ) );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", up_x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							p->partial_selection_from_cch_x = x = up_x;

						} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : ( sx != 0 ) : to == false : %lld %lld %lld ", x, sx, p->shift_dragging_start_x ); }

							if ( prv_tail )
							{
								x += sx;
							}

							n_type_int up_x = n_win_txtbox_select_up( p, x,y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d : %d : %s ", x, y, sx, sy, up_x, n_txt_get( &p->txt, y ) );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", up_x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							p->partial_selection_to___onoff = n_posix_true;
							p->partial_selection_to___cch_x = x;

							p->partial_selection_from_onoff = n_posix_false;
							p->partial_selection_from_cch_x = x = up_x;
						}

						 y =  y - 1;
						sx = N_WIN_TXTBOX_ALL;
						sy = sy + 1;

						n_win_txtbox_select( p, x,y,sx,sy );

					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : VK_SHIFT : else " ); }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", x,y,sx,sy );

						n_type_int up_x = n_win_txtbox_select_up( p, x,y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y ) );

						p->partial_selection_from_onoff = n_posix_false;
						p->partial_selection_from_cch_x = up_x;

						p->partial_selection_to___onoff = n_posix_true;
						p->partial_selection_to___cch_x = x;

						if ( prv_tail == n_posix_false )
						{
							p->partial_selection_to___cch_x += sx;
						}

						 x = up_x;
						 y =  y - 1;
						sx = N_WIN_TXTBOX_ALL;
						sy = sy + 1;

						n_win_txtbox_select( p, x,y,sx,sy );
					}

				} else {
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : else " ); }

					if (
						( p->partial_selection_from_onoff == n_posix_false )
						&&
						( p->partial_selection_to___onoff == n_posix_false )
					)
					{
						if ( prv_tail )
						{
							x += sx;
						}
					} else
					if ( p->partial_selection_from_onoff )
					{
						n_type_int fx = p->partial_selection_from_cch_x;
						n_type_int tx = p->partial_selection_to___cch_x;
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : else : From : %d %d ", fx, tx ); }

						x = tx;
						y = y + sy - 1;
					} else
					if ( p->partial_selection_to___onoff )
					{
						n_type_int fx = p->partial_selection_from_cch_x;
						n_type_int tx = p->partial_selection_to___cch_x;
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_UP : else : To : %d %d ", fx, tx ); }

						x = fx;
					}

					n_win_txtbox_unselect( p );

					 x = n_win_txtbox_select_up( p, x,y );
					 y = y - 1;
					sx = 0;
					sy = 1;

					if ( y < 0 ) { y = 0; }

					n_win_txtbox_select( p, x,y,sx,sy );

					n_win_txtbox_subclass_clamp( p, VK_RIGHT );
				}

//n_win_txtbox_hwndprintf_literal( p, " VK_UP : %d ", p->shift_dragging );

				if ( p->shift_dragging == 0 ) { p->is_ud = n_posix_true; }

			} else
			if ( vk == VK_DOWN )
			{

				if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }


				n_posix_bool prv_tail = p->is_caret_tail;
				     p->is_caret_tail = n_posix_false;

				p->shift_dragging_last_left = N_WIN_TXTBOX_NOT_SELECTED;


				n_type_int  x = p->select_cch_x;
				n_type_int  y = p->select_cch_y;
				n_type_int sx = p->select_cch_sx;
				n_type_int sy = p->select_cch_sy;


				if ( n_win_is_input( VK_SHIFT ) )
				{
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT " ); }

					p->shift_dragging = VK_DOWN;

					if ( ( y + sy ) >= p->txt.sy )
					{

						// [!] : full stop

					} else
					if ( p->partial_selection_to___onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : to___onoff : %d : %d ", prv_tail, sy ); }
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", x,y,sx,sy );

						if ( sy == 1 )
						{
							//
						} else
						if ( sy == 2 )
						{
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							 x = p->partial_selection_from_cch_x;
							 x = n_win_txtbox_select_down( p, x,y );
//n_win_txtbox_hwndprintf_literal( p, " to : %s ", n_txt_get( &p->txt, y ) );

							p->partial_selection_from_onoff = n_posix_false;
							p->partial_selection_to___onoff = n_posix_false;

							p->partial_selection_from_cch_x = x;//N_WIN_TXTBOX_NOT_SELECTED;
							p->partial_selection_to___cch_x = x;//N_WIN_TXTBOX_NOT_SELECTED;

							 y = y + 1;
							sx = 0;
							sy = 1;
						} else {
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							 x = p->partial_selection_to___cch_x;
							 x = n_win_txtbox_select_down( p, x,y+1 );
//n_win_txtbox_hwndprintf_literal( p, " to : %s ", n_txt_get( &p->txt, y ) );
//n_win_txtbox_hwndprintf_literal( p, " %d : %d %d ", x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							p->partial_selection_from_cch_x = x;

							 y =  y + 1;
							sx = N_WIN_TXTBOX_ALL;
							sy = sy - 1;
						}

						n_win_txtbox_select( p, x,y,sx,sy );
					} else
					if ( sx != 0 )
					{

						if ( p->partial_selection_from_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : ( sx != 0 ) : #1 : %d %d %d ", x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x ); }

							x = p->partial_selection_to___cch_x;

							n_type_int down_x = n_win_txtbox_select_down( p, x,y+sy-1 );
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y+sy-1 ) );
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", down_x, p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

							p->partial_selection_to___cch_x = x = down_x;

						} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : ( sx != 0 ) : #2 : %d %d %d ", prv_tail, x, p->prv_sel_x  ); }

							n_type_int xx = x;
							if ( prv_tail )
							{
								xx += sx;
							}

							n_type_int down_x = n_win_txtbox_select_down( p, xx,y+sy-1 );
//n_win_txtbox_hwndprintf_literal( p, " %s ", n_txt_get( &p->txt, y+sy-1 ) );

							p->partial_selection_from_onoff = n_posix_true;
							p->partial_selection_from_cch_x = x;

							p->partial_selection_to___onoff = n_posix_false;
							p->partial_selection_to___cch_x = x = down_x;
						}

						// y =  y;
						sx = N_WIN_TXTBOX_ALL;
						sy = sy + 1;

						n_win_txtbox_select( p, x,y,sx,sy );
					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : VK_SHIFT : else " ); }

						n_type_int down_x = n_win_txtbox_select_down( p, x,y );

						p->partial_selection_from_onoff = n_posix_true;
						p->partial_selection_from_cch_x = x;

						p->partial_selection_to___onoff = n_posix_false;
						p->partial_selection_to___cch_x = down_x;

						if ( prv_tail == n_posix_false )
						{
							p->partial_selection_to___cch_x += sx;
						}

						 x = down_x;
						 y = y;
						sx = N_WIN_TXTBOX_ALL;
						sy = sy + 1;

						n_win_txtbox_select( p, x,y,sx,sy );
					}

				} else {
if ( debug_output ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : else " ); }

					if (
						( p->partial_selection_from_onoff == n_posix_false )
						&&
						( p->partial_selection_to___onoff == n_posix_false )
					)
					{
						if ( prv_tail )
						{
							x += sx;
						}
					} else
					if ( p->partial_selection_from_onoff )
					{
						n_type_int fx = p->partial_selection_from_cch_x;
						n_type_int tx = p->partial_selection_to___cch_x;
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : else : From : %d %d ", fx, tx ); }

						x = tx;
						y = y + sy - 1;
					}

					n_win_txtbox_unselect( p );

					 x = n_win_txtbox_select_down( p, x,y );
					 y = y + 1;
					sx = 0;
					sy = 1;

					n_win_txtbox_select( p, x,y,sx,sy );

					n_win_txtbox_subclass_clamp( p, VK_RIGHT );
				}

//n_win_txtbox_hwndprintf_literal( p, " VK_DOWN : %d ", p->shift_dragging );

				if ( p->shift_dragging == 0 ) { p->is_ud = n_posix_true; }

			} else
			if ( vk == VK_LEFT )
			{
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT " );

				if ( n_win_is_input( VK_SHIFT ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff, p->is_caret_tail );

					p->shift_dragging = VK_LEFT;

					if ( p->select_cch_sy == 1 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : ( p->select_cch_sy == 1 ) " ); }

						n_type_int  x = p->select_cch_x;
						n_type_int  y = p->select_cch_y;
						n_type_int sx = p->select_cch_sx;
						n_type_int sy = p->select_cch_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d ", sx );
						if ( sx == 0 )
						{
							p->is_caret_tail = n_posix_false;
						}


						n_posix_char *line = n_txt_get( &p->txt, y );

						if ( p->shift_dragging_start_x < ( x + sx ) )
						{
							if ( p->is_caret_tail )
							{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : #1 " ); }
								n_win_txtbox_caret_l( line, sx, &sx );
							} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : #2 " ); }
								n_type_int px = x;
								n_win_txtbox_caret_l( line,  x,  &x );
								sx = sx + n_posix_abs_n_type_int( px - x );
							}
						} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : #3 " ); }
							n_type_int px = x;
							n_win_txtbox_caret_l( line,  x,  &x );
							sx = sx + n_posix_abs_n_type_int( px - x );
						}

						n_win_txtbox_select( p, x,y,sx,sy );

					} else
					if ( p->partial_selection_to___onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : to___onoff " ); }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

						n_type_int x = p->partial_selection_from_cch_x;
						n_type_int y = p->select_cch_y;

						n_posix_char *line = n_txt_get( &p->txt, y );

						n_win_txtbox_caret_l( line, x, &x );

						p->partial_selection_from_cch_x = x;


						p->shift_dragging_last_left = x;
					} else
					if ( p->partial_selection_from_onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : from_onoff " ); }
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_cch_x, p->partial_selection_to___cch_x );

						//n_type_int x = p->partial_selection_to___cch_x;
						n_type_int y = p->select_cch_y + p->select_cch_sy - 1;

						n_posix_char *line = n_txt_get( &p->txt, y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", line );

						// [!] : don't care about this value has large number
						//p->select_cch_sx = p->partial_selection_to___cch_x;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_to___cch_x, p->select_cch_sx );

						n_win_txtbox_caret_l( line, p->partial_selection_to___cch_x, &p->partial_selection_to___cch_x );

						if ( p->select_cch_x > 0 ) { p->select_cch_x--; }
					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_SHIFT : else " ); }
					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : VK_CONTROL " ); }

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					n_type_int f,t;

					f = p->select_cch_x;
					n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
					n_win_txtbox_caret_l( line, f, &f );

					n_win_txtbox_select_word( p, f, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, f, p->select_cch_y, 0, 1, n_posix_false );

				} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT( %d ) : %d ", VK_LEFT, p->shift_dragging );

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->select_cch_x, p->select_cch_y, p->select_cch_sx );

					if ( ( p->select_cch_x == 0 )&&( p->select_cch_y == 0 )&&( p->select_cch_sx == 0 ) )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : full stop " ); }

						// [!] : full stop

					} else
					if ( p->select_cch_x <= 0 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : if ( p->select_cch_x <= 0 ) " ); }

						if ( p->select_cch_y == 0 )
						{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
							n_type_int px = p->select_cch_sx;

							n_win_txtbox_unselect( p );

							p->select_cch_x = px;

							n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
							n_win_txtbox_caret_l( line, p->select_cch_x, &p->select_cch_x );
						} else
						if ( p->select_cch_sx != 0 )
						{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
							n_type_int tx = p->select_cch_x + p->select_cch_sx;
							n_type_int ty = p->select_cch_y;

							n_win_txtbox_unselect( p );

							p->select_cch_x = tx;
							p->select_cch_y = ty;

							n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
							n_win_txtbox_caret_l( line, p->select_cch_x, &p->select_cch_x );
						} else {
//n_win_txtbox_hwndprintf_literal( p, " 3 " );
							p->select_cch_y--;

							n_posix_char *line = n_txt_get( &p->txt, p->select_cch_y );
							n_type_int    tail = n_posix_strlen( line );

							n_win_txtbox_select_set( p, (n_type_int) tail, p->select_cch_y, 0, 1, n_posix_false );

							n_win_txtbox_subclass_clamp( p, VK_LEFT );

						}

					} else {

						n_type_int  x = p->prv_sel_x;
						n_type_int  y = p->prv_sel_y;
						n_type_int sx = 0;
						n_type_int sy = 1;

						if (
							(
								( p->partial_selection_to___onoff == n_posix_false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( p->is_caret_tail )
							)
							||
							( p->partial_selection_from_onoff )
						)
						{
							y = n_posix_max_n_type_int( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( p->partial_selection_from_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : from_onoff : %d ", p->is_caret_tail ); }

							p->partial_selection_from_onoff = n_posix_false;

							if ( p->is_caret_tail )
							{
								x = p->partial_selection_to___cch_x;
							}

							 y = p->select_cch_y + p->select_cch_sy - 1;
							sx = 0;
							sy = 1;

						} else
						if ( p->partial_selection_to___onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : to___onoff : %d %d ", p->partial_selection_from_cch_x, p->partial_selection_to___cch_x ); }

							n_type_int p_sel_x = p->partial_selection_from_cch_x;
							n_type_int p_sel_y = p->select_cch_y;

							n_win_txtbox_unselect( p );

							p->partial_selection_from_onoff = n_posix_false;
							p->partial_selection_to___onoff = n_posix_false;

							 x = p_sel_x;
							 y = p_sel_y;
							sx = 0;
							sy = 1;

							n_win_txtbox_select( p, x,y,sx,sy );

//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max : %d %d ", y, p->select_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : Max : %d ", p->partial_selection_from_onoff );
						} else
						if ( p->prv_sel_sx != N_WIN_TXTBOX_NOT_SELECTED )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_LEFT : NOT_SELECTED : %d %d %d ", p->is_caret_tail, sx, p->shift_dragging_last_left ); }

							if ( p->is_caret_tail )
							{
//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", x, sx, p->select_cch_x, p->select_cch_sx );
								x = x + p->select_cch_sx;
								y = p->select_cch_y + p->select_cch_sy - 1;
							} else
							if ( p->shift_dragging_last_left != N_WIN_TXTBOX_NOT_SELECTED )
							{
								x = p->shift_dragging_last_left;
							}

							sy = 1;

							p->partial_selection_from_onoff = n_posix_false;
							p->partial_selection_to___onoff = n_posix_false;
						}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_from_onoff, p->partial_selection_to___onoff );

						n_posix_char *line = n_txt_get( &p->txt, y );
						n_win_txtbox_caret_l( line, x, &x );
//n_win_txtbox_hwndprintf_literal( p, "%s", line );

						n_win_txtbox_select( p, x,y,sx,sy );

					}


//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->prv_sel_sx, p->select_cch_sx, p->select_cch_sy );
					if ( ( p->prv_sel_sx == 0 )&&( p->select_cch_sx == 0 )&&( p->select_cch_sy == 1 ) )
					{
						p->is_lr = VK_LEFT;
					}
				}

			} else
			if ( vk == VK_RIGHT )
			{

				p->shift_dragging_last_left = N_WIN_TXTBOX_NOT_SELECTED;

				if ( n_win_is_input( VK_SHIFT ) )
				{
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_SHIFT " ); 

					p->shift_dragging = VK_RIGHT;

					if ( p->select_cch_sy == 1 )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_SHIFT : ( p->select_cch_sy == 1 ) " ); }

						n_type_int  x = p->select_cch_x;
						n_type_int  y = p->select_cch_y;
						n_type_int sx = p->select_cch_sx;
						n_type_int sy = p->select_cch_sy;
//n_win_txtbox_hwndprintf_literal( p, " %d ", sx );
						if ( sx == 0 )
						{
							p->is_caret_tail = n_posix_true;
						}


						n_posix_char *line = n_txt_get( &p->txt, y );

						if ( p->is_caret_tail )
						{
							n_win_txtbox_caret_r( line, sx, &sx );
						} else {
							n_type_int px = x;
							n_win_txtbox_caret_r( line,  x,  &x );
							sx = sx - n_posix_abs_n_type_int( px - x );
						}

						n_win_txtbox_select( p, x,y,sx,sy );
					} else
					if ( p->partial_selection_to___onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_SHIFT : to___onoff " ); }

						n_type_int x = p->partial_selection_from_cch_x;
						n_type_int y = p->select_cch_y;

						n_posix_char *line = n_txt_get( &p->txt, y );

						n_win_txtbox_caret_r( line, x, &x );

						p->partial_selection_from_cch_x = x;
					} else
					if ( p->partial_selection_from_onoff )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_SHIFT : from_onoff " ); }

						//n_type_int x = p->partial_selection_to___cch_x;
						n_type_int y = p->select_cch_y + p->select_cch_sy - 1;

						n_posix_char *line = n_txt_get( &p->txt, y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", line );

						// [!] : don't care about this value has large number
						//p->select_cch_sx = p->partial_selection_to___cch_x;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->partial_selection_to___cch_x, p->select_cch_sx );

						n_win_txtbox_caret_r( line, p->partial_selection_to___cch_x, &p->partial_selection_to___cch_x );
					} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_SHIFT : else " ); }
					}

				} else
				if ( n_win_is_input( VK_CONTROL ) )
				{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : VK_CONTROL " ); }

					if ( p->select_cch_sy != 1 ) { break; } else { n_win_txtbox_unselect( p ); }

					n_type_int f,t;
					n_win_txtbox_select_word( p, p->select_cch_x, p->select_cch_y, &f, &t );

					n_win_txtbox_select_set( p, t, p->select_cch_y, 0, 1, n_posix_false );

				} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT( %d ) : %d ", VK_RIGHT, p->shift_dragging );

					n_type_int prv_partial_selection_from_onoff = p->partial_selection_from_onoff;
					n_type_int prv_partial_selection_to___onoff = p->partial_selection_to___onoff;
					n_type_int prv_partial_selection_from_cch_x = p->partial_selection_from_cch_x;
					n_type_int prv_partial_selection_to___cch_x = p->partial_selection_to___cch_x;


					n_win_txtbox_unselect( p );


					if ( p->is_caret_tail )
					{
						p->select_cch_x = p->prv_sel_x + p->prv_sel_sx;
					} else {
						p->select_cch_x = p->prv_sel_x;
					}


					n_type_int target_y = p->prv_sel_y;
					if ( p->is_caret_tail )
					{
						target_y = p->prv_sel_y + p->prv_sel_sy - 1;
					}

					n_posix_char *line = n_txt_get( &p->txt, n_posix_max_n_type_int( 0, target_y ) );
					n_type_int    tail = n_posix_strlen( line );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %s ", line );

					if ( p->prv_sel_x == tail )
					{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : tail " ); }

						//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { break; }

						if ( target_y >= ( p->txt.sy - 1 ) )
						{
							//
						} else {
							n_win_txtbox_select_set( p, 0, (n_type_int) ( target_y + 1 ), 0, 1, n_posix_false );
						}

						n_win_txtbox_subclass_clamp( p, VK_RIGHT );

					} else {
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d : %d ", p->prv_sel_sy, p->prv_sel_y, p->drag_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : %d : %d ", p->prv_sel_x, tail );

						n_type_int  x = p->prv_sel_x;
						n_type_int  y = p->prv_sel_y;
						n_type_int sx = 0;
						n_type_int sy = 1;

						if (
							(
								( prv_partial_selection_to___onoff == n_posix_false )
								&&
								( p->prv_sel_sy > 1 )
								&&
								( p->is_caret_tail )
							)
							||
							( prv_partial_selection_from_onoff )
						)
						{
							y = n_posix_max_n_type_int( 0, p->prv_sel_y + p->prv_sel_sy - 1 );
						}

						if ( prv_partial_selection_from_onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : from_onoff " ); }
							x = prv_partial_selection_to___cch_x;
						} else
						if ( prv_partial_selection_to___onoff )
						{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : to___onoff " ); }
							x = prv_partial_selection_from_cch_x;
						} else
						if ( p->prv_sel_sx != N_WIN_TXTBOX_NOT_SELECTED )
						{
							if ( p->prv_sel_x == p->select_cch_x )
							{
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : ( p->prv_sel_x == p->select_cch_x ) " ); }
								//
							} else {
if ( debug_detail ) { n_win_txtbox_hwndprintf_literal( p, " VK_RIGHT : ( p->prv_sel_x != p->select_cch_x ) " ); }
								x = p->prv_sel_x + p->prv_sel_sx;
							}
						}

						n_posix_char *line = n_txt_get( &p->txt, y );
						n_win_txtbox_caret_r( line, x, &x );
						n_win_txtbox_select_set( p, x,y,sx,sy, n_posix_false );

					}

//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->prv_sel_sx, p->select_cch_sx, p->select_cch_sy );
					if ( ( p->prv_sel_sx == 0 )&&( p->select_cch_sx == 0 )&&( p->select_cch_sy == 1 ) )
					{
						p->is_lr = VK_RIGHT;
					}

				}

			} else
			if ( vk == VK_NEXT )
			{
//n_posix_debug_literal( "" );

				if ( p->ime_composition_onoff ) { break; }

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_pxl_tabbed_y + p->page_pxl_tabbed_sy );

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_KEYDOWN );
				break;

			} else
			if ( vk == VK_PRIOR )
			{

				if ( p->ime_composition_onoff ) { break; }

				n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_pxl_tabbed_y - p->page_pxl_tabbed_sy );

				n_win_txtbox_refresh( p, N_WIN_TXTBOX_WM_KEYDOWN );
				break;

			} else
			if ( vk == VK_HOME )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, 0 );
					n_win_txtbox_select_set( p, 0, 0, 0, 1, n_posix_false );
				} else {
					n_win_txtbox_select_set( p, 0, p->select_cch_y, 0, p->select_cch_sy, n_posix_false );
				}

			} else
			if ( vk == VK_END )
			{

				if ( n_win_is_input( VK_CONTROL ) )
				{
					n_win_txtbox_scroll( p, 0, p->last_pxl_tabbed_sy );
					n_win_txtbox_select_set( p, 0, (n_type_int) ( p->txt.sy - 1 ), 0, 1, n_posix_false );
				} else {
					n_win_txtbox_select( p, 0, p->select_cch_y, N_WIN_TXTBOX_ALL, p->select_cch_sy );
					n_win_txtbox_select_set( p, p->select_cch_sx, p->select_cch_y, 0, p->select_cch_sy, n_posix_false );
				}

			} else
			if ( vk == VK_INSERT )
			{

				// [x] : for usability

				//n_win_txtbox_menu_insert( p );

			} else
			if ( vk == VK_DELETE )
			{

				if ( n_win_is_input( VK_SHIFT ) ) { break; }

				n_win_txtbox_menu_delete( p );

			} else
			if ( n_win_is_input( VK_CONTROL ) )
			{

				if ( n_win_is_input( VK_SHIFT ) ) { break; }

				if ( vk == 'A' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+A" );

					n_win_txtbox_menu_selectall( p );

				} else
				if ( vk == 'C' )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+C" );

					n_win_txtbox_menu_copy( p );

				} else
				if ( ( vk == 'V' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+V" );

					n_win_txtbox_menu_paste( p );

				} else
				if ( ( vk == 'X' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+X" );

					n_win_txtbox_menu_cut( p );

				} else
				if ( ( vk == 'Z' )&&( p->txt.readonly == n_posix_false ) )
				{
//n_win_txtbox_hwndprintf_literal( p, "Ctrl+Z" );

					n_win_txtbox_menu_undo( p );

				}


				n_win_txtbox_focus_fade_patch( p );


				break;

			} else
			if ( vk == VK_TAB )
			{

				// [!] : same as Xcode

				BOOL selected = ( 1 < p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, "%d : %lld", selected, p->select_cch_sy );

				n_win_txtbox_edit_undo( p, n_posix_false );

				// [x] : you cannot use Alt + Tab : system uses

				if ( n_win_is_input( VK_SHIFT ) )
				{
					// [!] : multi-line tab remover

					if ( selected == FALSE )
					{
						if ( p->txt.readonly == n_posix_false )
						{
							goto n_win_txtbox_label_typing;
						}
					}

					int y = 0;
					n_posix_loop
					{
						if ( y >= p->select_cch_sy ) { break; }

						n_posix_char *str = n_win_txtbox_line_get_new( p, p->select_cch_y + y );

						if ( str[ 0 ] == N_STRING_CHAR_TAB )
						{
							n_posix_sprintf_literal( str, "%s", &str[ 1 ] );
						}

						n_win_txtbox_line_mod( p, p->select_cch_y + y, str );

						y++;
					}

					n_win_txtbox_select( p, 0, p->select_cch_y, N_WIN_TXTBOX_ALL, p->select_cch_sy );

					n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );

					n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_KEYDOWN );

				} else {
					// [!] : multi-line tab adder

					if ( selected == FALSE )
					{
						if ( p->txt.readonly == n_posix_false )
						{
							goto n_win_txtbox_label_typing;
						}
					}

					int y = 0;
					n_posix_loop
					{
						if ( y >= p->select_cch_sy ) { break; }

						n_type_int    cch = n_win_txtbox_line_cch( p, p->select_cch_y + y ) + 1;
						n_posix_char *str = n_string_path_new( cch );

						if ( n_posix_false == n_string_is_empty( n_txt_get( &p->txt, p->select_cch_y + y ) ) )
						{
							n_posix_sprintf_literal( str, "%s", N_STRING_TAB );
							n_win_txtbox_line_get( p, p->select_cch_y + y, &str[ 1 ] );

							n_win_txtbox_line_mod( p, p->select_cch_y + y, str );

							p->select_cch_sx                = N_WIN_TXTBOX_ALL;
							p->partial_selection_from_cch_x = 0;
							p->partial_selection_to___cch_x = cch;
						}

						y++;
					}

					n_win_txtbox_select( p, 0, p->select_cch_y, N_WIN_TXTBOX_ALL, p->select_cch_sy );

					n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );

					n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_KEYDOWN );

				}

			} else
			if ( p->txt.readonly == n_posix_false )
			{

				n_win_txtbox_label_typing:

				n_win_txtbox_edit_undo( p, n_posix_false );

//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->ime_fade_is_running, p->focus_fade_is_running );

				if ( n_win_txtbox_edit_input( p, vk ) )
				{
					n_win_message_send( GetParent( hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );
				}

				if ( p->ime_fade_is_running )
				{
//n_win_txtbox_debug_count( p );
					n_win_txtbox_ime_fade_patch( p );
					break;
				}

				if ( p->focus_fade_is_running )
				{
					n_win_txtbox_focus_fade_patch( p );
					break;
				}

			}

			p->input_onoff = n_posix_true;


			n_win_txtbox_edit_on_typing( p );


			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				n_win_txtbox_draw( p, N_WIN_TXTBOX_WM_KEYDOWN );
			} else {
				p->typing_only = n_posix_true;

				n_type_int y,sy; n_win_txtbox_previous_calc( p, &y, &sy );
				n_win_txtbox_draw_partial( p, N_WIN_TXTBOX_WM_KEYDOWN, y, sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", y, sy );

				p->typing_only = n_posix_false;
			}

		}

	}
	break;


	} // switch


	if ( p->mouse_input_stop_onoff == n_posix_false )
	{

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->hscr );
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &p->vscr );
		}

	}


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( p->pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}


