// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_metrics_fade( n_win_txtbox *p )
{

	p->global_fade_onoff = n_win_fade_is_on();

	if ( n_sysinfo_version_8_or_later() )
	{
		//
	} else {
		if ( n_win_dwm_is_on() )
		{
			if ( n_win_fluent_ui_onoff )
			{
				//
			} else {
				p->global_fade_onoff = n_posix_false;
			}
		}
	}

	if ( p->is_classic )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX )
		{
			p->global_fade_onoff = n_posix_false;
		}
	}


	p->caret_blend   = 1.0;
	p->caret_fade_in = n_posix_true;

	// [x] : this feature is too much heavy

	if ( p->global_fade_onoff == n_posix_false )
	{
		p->style_option |= N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF;
	}

//p->style_option |= N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF;

	// [x] : not supported

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		p->style_option |= N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF;
	}


	return;
}

// internal
void
n_win_txtbox_metrics_listbox( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX ) ) { return; }


	// Border

	if ( p->is_classic == n_posix_false )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
		{
			//
		} else {
			p->style |= N_WIN_TXTBOX_STYLE_LINEBDR;
		}
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
	{
		if ( n_win_fluent_ui_onoff )
		{
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
		} else {
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 1 * p->scale_real );
		}
	} else {
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
	}


	// Round Rect

	// [x] : currently not supported
	if ( n_win_dwm_aeroglass_is_on() )
	{
		if (
			( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			||
			( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		)
		{
			p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
			p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC )
	{
		//p->style_option &= ~N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
		p->style_option |=  N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
	{
		p->roundrect_pxl = (n_type_gfx) ( (n_type_real) 3 * p->scale_real );
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
	{
		p->roundrect_pxl = n_win_fluent_ui_round_param( p->hwnd );
	} else {
		p->roundrect_pxl = 0;
	}


	return;
}

// internal
void
n_win_txtbox_metrics_oneline( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) ) { return; }


	// Border

	if ( p->is_classic == n_posix_false )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
		{
			//
		} else {
			p->style |= N_WIN_TXTBOX_STYLE_LINEBDR;
		}
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
	{
		if ( n_win_fluent_ui_onoff )
		{
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
		} else {
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 1 * p->scale_real );
		}
	} else {
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
	}


	// Round Rect

	if ( n_win_fluent_ui_onoff )
	{
		p->style_option |= N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
	}

	if ( p->is_classic )
	{
		//
	} else {
		if ( n_win_fluent_ui_onoff )
		{
			//
		} else {
			p->style_option |= N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	// [x] : currently not supported
	if ( n_win_dwm_aeroglass_is_on() )
	{
		if (
			( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			||
			( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		)
		{
			p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
			p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
	{
		p->roundrect_pxl = (n_type_gfx) ( (n_type_real) 3 * p->scale_real );
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
	{
		p->roundrect_pxl = n_win_fluent_ui_round_param( p->hwnd );
	} else {
		p->roundrect_pxl = 0;
	}


	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE )
	{
		p->maclike_offset = 4 * (n_type_gfx) floor( p->scale_real );
	}


	return;
}

// internal
void
n_win_txtbox_metrics_editbox( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return; }


	// Border

	if ( p->is_classic == n_posix_false )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
		{
			//
		} else {
			p->style |= N_WIN_TXTBOX_STYLE_LINEBDR;
		}
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
	{
		if ( n_win_fluent_ui_onoff )
		{
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
		} else {
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 1 * p->scale_real );
		}
	} else {
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
	}


	// Round Rect

	// [x] : currently not supported
	if ( n_win_dwm_aeroglass_is_on() )
	{
		if (
			( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			||
			( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		)
		{
			p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
			p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
	{
		p->roundrect_pxl = (n_type_gfx) ( (n_type_real) 3 * p->scale_real );
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
	{
		p->roundrect_pxl = n_win_fluent_ui_round_param( p->hwnd );
	} else {
		p->roundrect_pxl = 0;
	}


	return;
}

// internal
void
n_win_txtbox_metrics_cmb_box( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX ) ) { return; }


	// Border

	if ( p->is_classic == n_posix_false )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
		{
			//
		} else {
			p->style |= N_WIN_TXTBOX_STYLE_LINEBDR;
		}
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
	{
		if ( n_win_fluent_ui_onoff )
		{
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
		} else {
			p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 1 * p->scale_real );
		}
	} else {
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
	}


	// Aero

	p->aero_combo_onoff = p->aero_combo_focus_only = n_posix_false;

	if ( n_win_fluent_ui_onoff )
	{
		//
	} else
	if ( n_win_darkmode_onoff )
	{
		//
	} else
	if ( n_win_style_is_classic() )
	{
		//
	} else
	if ( n_sysinfo_version_8_or_later() )
	{
		//
	} else
	if ( n_sysinfo_version_vista_or_later() )
	{
		p->aero_combo_onoff = n_posix_true;
	} else {
		// [x] : not working
		//p->aero_combo_onoff = p->aero_combo_focus_only = n_posix_true;
	}
//p->aero_combo_onoff = n_posix_true;


	// Round Rect

	// [x] : currently not supported
	if ( n_win_dwm_aeroglass_is_on() )
	{
		if (
			( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			||
			( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		)
		{
			p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
			p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	if ( n_win_fluent_ui_onoff )
	{
		p->style_option |= N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
	{
		p->roundrect_pxl = (n_type_gfx) ( (n_type_real) 3 * p->scale_real );
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
	{
		p->roundrect_pxl = n_win_fluent_ui_round_param( p->hwnd );
	} else {
		p->roundrect_pxl = 0;
	}


	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE )
	{
		p->maclike_offset = 4 * (n_type_gfx) floor( p->scale_real );
	}


	return;
}

// internal
void
n_win_txtbox_metrics_cmb_pop( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP ) ) { return; }


	// Border

	if ( p->is_classic == n_posix_false )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
		{
			//
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_FLATBDR )
		{
			//
		} else {
			p->style |= N_WIN_TXTBOX_STYLE_LINEBDR;
		}
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = 0;
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LINEBDR )
	{
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 1 * p->scale_real );
	} else {
		p->border_pxl_sx = p->border_pxl_sy = (n_type_gfx) ( (n_type_real) 2 * p->scale_real );
	}


	// Round Rect

	// [x] : currently not supported
	if ( n_win_dwm_aeroglass_is_on() )
	{
		if (
			( p->style & N_WIN_TXTBOX_STYLE_VISIBLE )
			||
			( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
		)
		{
			p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
			p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}
	}

	p->style_option &= ~N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
	p->style_option &= ~N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;

	if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC )
	{
		//p->style_option &= ~N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
		p->style_option |=  N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC;
	}

	if ( p->style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
	{
		p->roundrect_pxl = (n_type_gfx) ( (n_type_real) 3 * p->scale_real );
	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC )
	{
		p->roundrect_pxl = n_win_fluent_ui_round_param( p->hwnd );
	} else {
		p->roundrect_pxl = 0;
	}


	return;
}

#define n_win_txtbox_on_settingchange( p ) n_win_txtbox_metrics( p )

// internal
void
n_win_txtbox_metrics( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->metrics_changed = n_posix_true;


	// Compatibility

	p->is_9x          = n_sysinfo_version_9x();
	p->is_nt          = n_sysinfo_version_nt();
	p->is_2k_or_later = n_sysinfo_version_2000_or_later();
	p->is_classic     = n_win_style_is_classic();

	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"EDIT" );


	// Fade

	n_win_txtbox_metrics_fade( p );


	// Style

	n_win_txtbox_scale_set( p );


	// [!] : order is important

	if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
	{
		n_win_txtbox_metrics_cmb_pop( p );
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_CMB_BOX )
	{
		n_win_txtbox_metrics_cmb_box( p );
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
	{
		n_win_txtbox_metrics_listbox( p );
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		n_win_txtbox_metrics_oneline( p );
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		n_win_txtbox_metrics_editbox( p );
	}


	// Padding

	n_type_gfx m = (n_type_gfx) ( (n_type_real) p->scale_real * 2 );

	p->number_pad_pxl_sx = 0;

	if ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG )
	{

		p->pad_pxl_sx = 0;
		p->pad_pxl_sy = 0;


	} else {

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		{
			p->pad_pxl_sx = ( m * 1 );
			p->pad_pxl_sy = ( m * 1 );

			p->number_pad_pxl_sx = ( m * 2 );
		} else {
			p->pad_pxl_sx = ( m * 2 );
			p->pad_pxl_sy = ( m * 2 );
		}

	}


	// Tabstop

	p->tabstop = 8;


	// Scrollbar

	p->scrollbar_pxl_sx = GetSystemMetrics( SM_CXVSCROLL );
	p->scrollbar_pxl_sy = GetSystemMetrics( SM_CYHSCROLL );

	n_win_scrollbar_on_settingchange( &p->hscr, n_posix_true, n_posix_true );
	n_win_scrollbar_on_settingchange( &p->vscr, n_posix_true, n_posix_true );


	// IME : for future version

	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		p->ime_onoff = n_win_ime_is_on( p->hwnd );
	}


	// Color Scheme

	p->color_base_selected = n_bmp_argb2colorref( n_win_dwm_windowcolor_arranged() );
	p->color_base__padding = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE       );
	p->color_text_selected = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
	p->color_back_noselect = n_win_darkmode_systemcolor_ui( COLOR_WINDOW        );

	p->color_text_noselect = n_win_darkmode_systemcolor_ui( COLOR_WINDOWTEXT    );

	if ( 32 != n_win_desktop_bpp() )
	{
		p->color_back_noselect = n_bmp_argb2colorref( n_gdi_colorref2argb( p->hwnd, p->color_back_noselect ) );
	}

	p->color_border___flat = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );

	p->color_back__enabled = p->color_back_noselect;

	if ( n_win_darkmode_onoff )
	{
		COLORREF back_base = n_win_darkmode_systemcolor_ui( COLOR_BTNHIGHLIGHT  );

		p->color_border__focus = p->color_base_selected;
		p->color_border_normal = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
		p->color_back_disabled = n_win_color_blend( p->color_back_noselect, p->color_text_selected, 0.10 );
		p->color___ime_watcher = p->color_base_selected;
		p->color_sel_focus__on = n_win_color_blend( back_base, p->color_text_selected, 0.250 );
		p->color_sel_focus_off = n_win_color_blend( back_base, p->color_text_selected, 0.125 );
	} else
	if ( n_win_color_is_highcontrast() )
	{
		p->color_border__focus = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT     );
		p->color_border_normal = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
		p->color_back_disabled = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.75 );
		p->color___ime_watcher = RGB( 128,128,128 );
		p->color_sel_focus__on = p->color_border__focus;
		p->color_sel_focus_off = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW    );
	} else {
		p->color_border__focus = p->color_base_selected;
		p->color_border_normal = p->color_base_selected;
		p->color_back_disabled = p->color_base__padding;
		p->color___ime_watcher = p->color_base_selected;
		p->color_sel_focus__on = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
		p->color_sel_focus_off = n_win_darkmode_systemcolor_ui( COLOR_3DDKSHADOW    );
	}

	if ( 32 != n_win_desktop_bpp() )
	{
		p->color_back_disabled = n_bmp_argb2colorref( n_gdi_colorref2argb( p->hwnd, p->color_back_disabled ) );
	}

	if ( p->is_grayed )
	{
		p->color_back_noselect = p->color_back_disabled;
		p->color_back_selected = p->color_sel_focus_off;
	} else {
		p->color_back_noselect = p->color_back__enabled;
		//p->color_back_selected = p->color_sel_focus__on; // [!] : set by n_win_txtbox_ime_watch_color()
	}


	p->color_text_linenum1 = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.50 );


	p->color___placeholder = n_win_color_blend( p->color_text_noselect, p->color_back_noselect, 0.50 );

	n_win_txtbox_ime_watch_color( p );


	// DrawText modes

	p->drawtext_modes = DT_NOPREFIX | DT_NOCLIP;
	p->drawtext_modes = p->drawtext_modes | ( DT_SINGLELINE | DT_VCENTER );


	// Timer

	if ( p->      input_timer == 0 ) { p->      input_timer = n_win_timer_id_get(); }
	if ( p->      caret_timer == 0 ) { p->      caret_timer = n_win_timer_id_get(); }
	if ( p->smallbutton_timer == 0 ) { p->smallbutton_timer = n_win_timer_id_get(); }
	if ( p-> aero_combo_timer == 0 ) { p-> aero_combo_timer = n_win_timer_id_get(); }

	p->input_msec = GetCaretBlinkTime();

	n_win_txtbox_caret_onoff( p, n_posix_true );


	return;
}

// internal
void
n_win_txtbox_metrics_caret( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->caret_pxl_sx = n_win_stdsize_caret( p->hwnd );
	p->caret_pxl_sy = p->cell_pxl_sy;


	// [!] : Debug Center

	//p->caret_pxl_sx = 10;


	return;
}

// internal
void
n_win_txtbox_metrics_canvas( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// Font

	// [!] : Win95 : font height has larger size than set value
	//
	//	example : 16px at CreateFont() will be 18px

	// [!] : Classic Style
	//
	//	border will be overritten

	{
		SIZE size = n_win_txtbox_size_text( p, n_posix_literal( "W" ) );

		p->font_pxl_sx = n_posix_max_n_type_gfx( 1, size.cx );

		if (
			( ( p->style & N_WIN_TXTBOX_STYLE_NO_BRDR ) == n_posix_false )
			&&
			(
				( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
				||
				( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			)
		)
		{
			n_type_gfx m; n_win_stdsize( p->hwnd, NULL, NULL, &m );// m = 0;
			p->font_pxl_sy = n_posix_max_n_type_gfx( 1, size.cy + m );
		} else {
			p->font_pxl_sy = n_posix_max_n_type_gfx( 1, size.cy );
		}

		p->cell_pxl_sy = n_posix_max_n_type_gfx( p->font_pxl_sy + ( p->font_pxl_sy % 2 ), p->cell_pxl_sy );
	}

	{
		SIZE size = n_win_txtbox_size_text( p, n_posix_literal( "i" ) );

		size.cx = n_posix_max_n_type_gfx( 1, size.cx );

		if ( size.cx == p->font_pxl_sx ) { p->is_font_monospace = n_posix_true; }
	}


	SIZE halfwidth = { p->font_pxl_sx * 1, p->cell_pxl_sy };
	SIZE fullwidth = { p->font_pxl_sx * 2, p->cell_pxl_sy };

	p->size_halfwidth = halfwidth;
	p->size_fullwidth = fullwidth;


	// Caret

	n_win_txtbox_metrics_caret( p );


	// Canvas

	n_win_size( p->hwnd, &p->client_pxl_sx, &p->client_pxl_sy );


	p->shadow_u = p->shadow_d = p->shadow_l = p->shadow_r = 0;

	if ( p->style_option & N_WIN_TXTBOX_OPTION_COMBOBOX_SHADOW )
	{
		n_win_fluent_ui_shadow_metrics
		(
			p->hwnd,
			&p->shadow_u,
			&p->shadow_d,
			&p->shadow_l,
			&p->shadow_r
		);

		p->client_pxl_sx -= p->shadow_l + p->shadow_r;
		p->client_pxl_sy -= p->shadow_u + p->shadow_d;
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG )
		{
			p->pad_pxl_sy = 0;
		} else {
			SIZE size = n_win_txtbox_size_text( p, n_posix_literal( "Ay" ) );
			p->pad_pxl_sy = ( p->client_pxl_sy - size.cy ) / 2;
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", p->pad_pxl_sy, p->client_pxl_sy, size.cy );
		}
	}

	n_type_gfx sx = p->client_pxl_sx - ( p->border_pxl_sx * 2 ) - ( p->pad_pxl_sx * 2 );
	n_type_gfx sy = p->client_pxl_sy - ( p->border_pxl_sy * 2 ) - ( p->pad_pxl_sy * 2 );

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= p->scrollbar_pxl_sy; }
	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= p->scrollbar_pxl_sx + p->pad_pxl_sx; }


	n_type_gfx linenum = 0;

	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	{
		SIZE size_linenum = n_win_txtbox_size_text( p, n_posix_literal( " wwww " ) );
		p->number_pxl_sx = size_linenum.cx;
		p->number_offset = size_linenum.cx / 6;
		linenum          = size_linenum.cx + p->number_pad_pxl_sx;
	}

	p->canvas_pxl_sx = n_posix_max_n_type_gfx( 0, sx );
	p->canvas_pxl_sy = n_posix_max_n_type_gfx( 0, sy );

	//if ( 96 != n_win_dpi( p->hwnd ) )
	{
		//p->canvas_pxl_sx = n_posix_max_n_type_gfx( 0, sx - ( p->pad_pxl_sx * 2 ) );
	}

	p->canvas_real_pxl_sx = p->canvas_pxl_sx - linenum - p->smallbutton_margin;

	n_type_gfx    eol_sx  = 0;
	n_posix_char *eol_str = n_win_txtbox_eol_string_get( p );
	if ( n_posix_false == n_string_is_empty( eol_str ) )
	{
		SIZE size_eol = n_win_txtbox_size_text( p, eol_str );
		eol_sx = size_eol.cx;
	}

	if ( p->is_font_monospace )
	{
		n_win_txtbox_txt_stream( p, n_posix_true );

		p->page_pxl_tabbed_sx = p->canvas_real_pxl_sx / p->font_pxl_sx * p->font_pxl_sx;
		p->last_pxl_tabbed_sx = n_posix_max_n_type_gfx( 0, (n_type_gfx) ( ( p->txt.sx * p->font_pxl_sx ) - p->page_pxl_tabbed_sx + p->smallbutton_margin - eol_sx ) );
	} else {
		if ( p->style & N_WIN_TXTBOX_STYLE_NO_PDNG )
		{
			//
		} else {
			p->canvas_pxl_sx += p->font_pxl_sx;
		}

		n_type_gfx nc_sx = ( p->border_pxl_sx + p->pad_pxl_sx + p->maclike_offset ) * 2;
		p->page_pxl_tabbed_sx = p->canvas_pxl_sx - nc_sx - linenum - p->smallbutton_margin;

		SIZE size = n_win_txtbox_size_text( p, n_win_txtbox_txt_get( p, p->txt_maxwidth_y ) );
		p->last_pxl_tabbed_sx = size.cx - p->page_pxl_tabbed_sx - eol_sx;
	}

	p->page_pxl_tabbed_sy = p->canvas_pxl_sy;

	{
		n_type_int all  = p->txt.sy * p->cell_pxl_sy;
		n_type_int page = p->page_pxl_tabbed_sy;

		all += ( p->canvas_pxl_sy % p->cell_pxl_sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
		{
			all -= p->cell_pxl_sy;
		}

		p->last_pxl_tabbed_sy = n_posix_max_n_type_int( 0, all - page );
	}


	// [Needed]

	//n_win_scrollbar_refresh( &p->hscr );
	//n_win_scrollbar_refresh( &p->vscr );

	n_win_scrollbar_refresh_cache( &p->hscr );
	n_win_scrollbar_refresh_cache( &p->vscr );


	return;
}

void
n_win_txtbox_metrics_vertical_spacing( n_win_txtbox *p, n_type_gfx value )
{

	if ( p == NULL ) { return; }


	p->cell_pxl_sy = value;


	n_win_txtbox_metrics_caret ( p );
	n_win_txtbox_metrics_canvas( p );

	n_win_txtbox_metrics( p );


	//n_win_txtbox_refresh( p, 0 );


	return;
}

#define n_win_txtbox_metrics_maxwidth_all( p ) n_win_txtbox_metrics_maxwidth( p, 0, N_WIN_TXTBOX_ALL )

void
n_win_txtbox_metrics_maxwidth( n_win_txtbox *p, n_type_int y, n_type_int sy )
{

	if ( p == NULL ) { return; }


	n_posix_bool redraw = n_posix_false;


	HDC   hdc = GetDC( p->hwnd );
	HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	n_type_int max_sy = y + sy;
	n_posix_loop
	{

		n_type_int sx = n_win_txtbox_nonascii( p, n_win_txtbox_txt_get( p, y ), p->tabstop );
		if ( p->txt.sx < sx )
		{
//n_posix_debug_literal( "%d : %s", sx, n_win_txtbox_txt_get( p, y ) );
			redraw    = n_posix_true;
			p->txt.sx = sx;
		}

		y++;
		if ( y >= max_sy ) { break; }
	}

	SelectObject( hdc, hf );
	ReleaseDC( p->hwnd, hdc );


	p->cell_pxl_sy = 0;

	n_win_txtbox_metrics_canvas( p );


	n_win_txtbox_linenumber_cache( p );


	if ( redraw ) { n_win_txtbox_refresh( p, N_WIN_TXTBOX_METRICS_MAXWIDTH ); }


	return;
}

void
n_win_txtbox_tabbedmetrics
(
	n_win_txtbox *p,
	n_type_int    line_index,
	n_type_int stop_x, n_type_int stop_cch, n_type_int stop_tab,
	n_type_int *ret_x, n_type_int *ret_cch, n_type_int *ret_tab
)
{

	if ( p == NULL ) { return; }


	HDC   hdc = GetDC( p->hwnd );
	HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	n_posix_char *str_line = n_win_txtbox_txt_get( p, line_index );

	n_win_txtbox_character_tabbed( p, hdc, str_line, stop_x, stop_cch, stop_tab, ret_x, ret_cch, ret_tab );

	SelectObject( hdc, hf );

	ReleaseDC( p->hwnd, hdc );


	return;
}


