// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_vector_stream( n_win_txtbox *p, const n_posix_char *newline, n_posix_bool calc_width )
{

	// [!] : this module based on n_vector_stream()


	if ( p == NULL ) { return; }

	if ( p->txt.line == NULL ) { return; }


	n_type_int cch_newline = 0;
	if ( newline != NULL ) { cch_newline = n_posix_strlen( newline ); }


	n_type_int i, cch;


	if ( calc_width )
	{

		HDC   hdc = GetDC( p->hwnd );
		HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

		i = cch = p->txt.sx = 0;
		n_posix_loop
		{

//n_posix_debug( p->txt.line[ i ] );

			n_posix_char *line = p->txt.line[ i ];

			n_type_int sx = n_win_txtbox_nonascii( p, line, p->tabstop );
			if ( newline != NULL ) { sx += cch_newline; }


			if ( p->txt.sx < sx ) { p->txt.sx = sx; p->txt_maxwidth_y = i; }


			cch += sx;


			i++;
			if ( i >= p->txt.sy ) { break; }
		}

		SelectObject( hdc, hf );
		ReleaseDC( p->hwnd, hdc );

	} else {

		i = cch = 0;
		n_posix_loop
		{

//n_posix_debug( p->txt.line[ i ] );

			n_posix_char *line = p->txt.line[ i ];

			n_type_int sx = n_posix_strlen( line );
			if ( newline != NULL ) { sx += cch_newline; }


			cch += sx;


			i++;
			if ( i >= p->txt.sy ) { break; }
		}

	}

//n_posix_debug_literal( str, "%d : %d", p->txt.byte, cch * sizeof( n_posix_char ) );

	n_memory_free( p->txt.stream );

	p->txt.stream = n_string_new_fast( cch );
	p->txt.byte   = cch * sizeof( n_posix_char );

	if ( p->txt.stream == NULL )
	{
		p->txt.byte = 0;
		return;
	}


	n_posix_char *strm = (void*) p->txt.stream;


	i = cch = 0;
	n_posix_loop
	{

		cch += n_posix_sprintf_literal( &strm[ cch ], "%s", (n_posix_char*) p->txt.line[ i ] );

		if ( newline != NULL )
		{
			cch += n_posix_sprintf_literal( &strm[ cch ], "%s", newline );
		}


		i++;
		if ( i >= p->txt.sy ) { break; }
	}


	return;
}

void
n_win_txtbox_txt_stream( n_win_txtbox *p, n_posix_bool calc_width )
{

	// [!] : this module based on n_txt_stream()

	if ( p == NULL ) { return; }


	n_posix_char *newline = NULL;


	if ( p->txt.newline == N_TXT_NEWLINE_CR   ) { newline = N_STRING_CR;   } else
	if ( p->txt.newline == N_TXT_NEWLINE_LF   ) { newline = N_STRING_LF;   } else
	if ( p->txt.newline == N_TXT_NEWLINE_CRLF ) { newline = N_STRING_CRLF; }


	n_win_txtbox_vector_stream( p, newline, calc_width );


	return;
}

void
n_win_txtbox_txt_copy( n_win_txtbox *p, n_txt *p_old, n_txt *p_new, n_posix_bool txt_stream_onoff )
{

	// [!] : this module based on n_txt_copy()

	if ( n_txt_error( p_old ) ) { return; }
	if ( p_new == NULL ) { return; }


	n_txt_new( p_new );


	n_type_int i = 0;
	n_posix_loop
	{//break;

		// [!] : don't use n_txt_set()

		if ( i == 0 )
		{
			n_txt_mod( p_new, i, n_txt_get( p_old, i ) );
		} else {
			n_txt_add( p_new, i, n_txt_get( p_old, i ) );
		}

		i++;
		if ( i >= p_old->sy ) { break; }
	}


	p_new->newline  = p_old->newline;
	p_new->unicode  = p_old->unicode;
	p_new->readonly = p_old->readonly;

	if ( txt_stream_onoff ) { n_win_txtbox_txt_stream( p, n_posix_true ); }


	return;
}

#define n_win_txtbox_vector_load(          p, fname        ) n_win_txtbox_vector_load_internal( p, (void*) fname,    0, n_posix_true  )
#define n_win_txtbox_vector_load_onmemory( p, stream, byte ) n_win_txtbox_vector_load_internal( p,        stream, byte, n_posix_false )

// internal
n_posix_bool
n_win_txtbox_vector_load_internal( n_win_txtbox *p, void *stream, n_type_int byte, n_posix_bool is_file )
{

	// [!] : this module based on n_vector_load_onmemory()


	// [!] : load_onmemory() : don't free "stream" after calling this function


	if ( p == NULL ) { return n_posix_true; }


	if ( is_file )
	{

		FILE *fp = n_posix_fopen_read( stream );
		if ( fp == NULL ) { return n_posix_true; }

		byte   = n_posix_stat_size( stream );
		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	}


	// [!] : add stream NUL
	//
	//	unicode : file size may have odd number byte

	{

		n_type_int unit = sizeof( n_posix_char );
		n_type_int pad  = ( byte % unit );
		n_type_int nul  = unit;


		// [!] : stream can be NULL

		stream = n_memory_resize( stream, byte + pad + nul );

		n_posix_char *s = stream;
		s[ ( byte + pad ) / unit ] = N_STRING_CHAR_NUL;

	}


	n_vector_free( (void*) &p->txt );


	n_type_int cch = byte / sizeof( n_posix_char );


	HDC   hdc = GetDC( p->hwnd );
	HFONT hf  = SelectObject( hdc, n_win_font_get( p->hwnd ) );

	n_type_int i = 0;
	n_posix_loop
	{//break;

		n_type_int    sx = 0;
		n_posix_char *l  = n_vector_stream_enumline( stream, cch, &sx, &i );
		if ( l == NULL ) { break; }

		p->txt.sy++;
		p->txt.line = n_memory_resize( p->txt.line, p->txt.sy * sizeof( void** ) );

		p->txt.line[ p->txt.sy - 1 ] = l;

//n_posix_debug( v->line[ p->txt.sy - 1 ] );

		n_type_int line_sx = n_win_txtbox_nonascii( p, l, p->tabstop );
		if ( p->txt.sx < line_sx ) { p->txt.sx = line_sx; p->txt_maxwidth_y = p->txt.sy - 1; }

	}

	SelectObject( hdc, hf );
	ReleaseDC( p->hwnd, hdc );


	if ( p->txt.sy == 0 )
	{

		n_memory_free( stream );

		n_vector_new( (void*) &p->txt );

	} else {

		p->txt.stream = stream;
		p->txt.byte   = byte;

	}


	return n_posix_false;
}

#define n_win_txtbox_txt_load(          v, fname        ) n_win_txtbox_txt_load_internal( v, (void*) fname,    0, n_posix_true  )
#define n_win_txtbox_txt_load_onmemory( v, stream, byte ) n_win_txtbox_txt_load_internal( v,        stream, byte, n_posix_false )

//static n_posix_bool n_win_txtbox_txt_load_force_utf8 = n_posix_false;

// internal
n_posix_bool
n_win_txtbox_txt_load_internal( n_win_txtbox *p, void *stream, n_type_int byte, n_posix_bool is_file )
{

	// [!] : this module based on n_txt_load_onmemory()


	// [!] : load_onmemory() : don't free "stream" after calling this function


	if ( p == NULL ) { return n_posix_true; }


	n_type_int bom_offset = 0;


	p->txt.unicode = N_TXT_UNICODE_NIL;

	if ( is_file )
	{

		FILE *fp = n_posix_fopen_read( stream );
		if ( fp == NULL ) { return n_posix_true; }

		byte = n_posix_stat_size( stream );


		// [!] : remember original spec

		u8 sniffer[ 3 ]; n_posix_fread( sniffer, 3, 1, fp );

		if ( ( byte >= 3 )&&( n_unicode_bom_is_utf8    ( sniffer, 3 ) ) )
		{
//n_posix_debug_literal( "UTF" );
			p->txt.unicode = N_TXT_UNICODE_UTF;
			n_posix_fseek( fp, 3, SEEK_SET );
			byte -= 3;
		} else
		if ( ( byte >= 2 )&&( n_unicode_bom_is_utf16_le( sniffer, 2 ) ) )
		{
//n_posix_debug_literal( "LIL" );
			p->txt.unicode = N_TXT_UNICODE_LIL;
			n_posix_fseek( fp, 2, SEEK_SET );
			byte -= 2;
		} else
		if ( ( byte >= 2 )&&( n_unicode_bom_is_utf16_be( sniffer, 2 ) ) )
		{
//n_posix_debug_literal( "BIG" );
			p->txt.unicode = N_TXT_UNICODE_BIG;
			n_posix_fseek( fp, 2, SEEK_SET );
			byte -= 2;
		} else {
//n_posix_debug_literal( "ANSI" );
			n_posix_fseek( fp, 0, SEEK_SET );
		}


		stream = n_memory_new( byte );
		n_posix_fread( stream, byte, 1, fp );

		n_posix_fclose( fp );

	} else {

		// [!] : remember original spec

		if ( n_unicode_bom_is_utf8   ( stream, byte ) )
		{
//n_posix_debug_literal( "UTF" );

			p->txt.unicode = N_TXT_UNICODE_UTF;

			bom_offset = 3;

		} else
		if ( n_unicode_bom_is_utf16_le( stream, byte ) )
		{
//n_posix_debug_literal( "LIL" );

			p->txt.unicode = N_TXT_UNICODE_LIL;

			bom_offset = 2;

		} else
		if ( n_unicode_bom_is_utf16_be( stream, byte ) )
		{
//n_posix_debug_literal( "BIG" );

			p->txt.unicode = N_TXT_UNICODE_BIG;

			bom_offset = 2;

		}

		byte -= bom_offset;

	}


	// [!] : add stream NUL
	//
	//	unicode : file size may have odd number byte

	{

		n_type_int unit = sizeof( n_posix_char );
		n_type_int pad  = ( byte % unit );
		n_type_int nul  = unit;


		// [!] : stream can be NULL

		stream = n_memory_resize( stream, byte + pad + nul );

		n_posix_char *s = stream;
		s[ ( byte + pad ) / unit ] = N_STRING_CHAR_NUL;

	}


	// Decoder

	char         *ptr;
	n_posix_bool  lost = n_posix_false;

#ifdef UNICODE


	if ( p->txt.unicode == N_TXT_UNICODE_NIL )
	{

		n_posix_bool is_utf8 = n_posix_false;


		n_type_int  test_b = 0;
		u8         *test_p = NULL;

		//if ( n_win_txtbox_txt_load_force_utf8 )
		{
			test_b = byte;
			test_p = n_unicode_alloccopy( &test_b, (u8*) stream );


			BOOL is_ascii = TRUE;

			n_type_int i = 0;
			n_posix_loop
			{
				if ( test_p[ i ] == 0 ) { break; }

				if ( test_p[ i ] > 127 ) { is_ascii = FALSE; break; }
				i++;
			}


			if ( is_ascii == FALSE )
			{
				n_unicode_utf8_decode_no_bom( test_p, test_b );
				is_utf8 = ( n_posix_false == n_memory_is_same( stream, test_p, test_b ) );
			}
		}


		if ( is_utf8 )
		{

			p->txt.unicode = N_TXT_UNICODE_UTF;

			n_memory_free( stream );

			byte   = test_b;
			stream = test_p;

		} else {

			n_memory_free( test_p );


			// [!] : ANSI only : don't use n_txt_newline_check()

			n_posix_bool binary = n_posix_false;

			u8 *ptr_u8 = (u8*) stream;

			n_type_int i = 0;
			n_posix_loop
			{

				if ( ptr_u8[ i ] == 0 ) { binary = n_posix_true; break; }

				// [!] : some files have NUL at end of file

				i++;
				if ( i >= ( byte - 1 ) ) { break; }
			}


			if ( binary == n_posix_false )
			{

				ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );
//MessageBoxA( NULL, (char*) ptr, "DEBUG", 0 );


				// [!] : n_posix_false is returned always

				//lost = n_unicode_codec_char2wchar( ptr, byte );
				//n_unicode_bom_remove( ptr, byte );

				lost = n_unicode_codec_char2wchar_no_bom( ptr, byte );
//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );


				n_memory_free( stream );


				byte   = n_posix_strlen( (void*) ptr ) * sizeof( wchar_t );
				stream = ptr;

			}

		}

	} else {

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( p->txt.unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		} else
		if ( p->txt.unicode == N_TXT_UNICODE_UTF )
		{
			n_unicode_utf8_decode_no_bom( ptr, byte );
		}


		n_memory_free( stream );

		//n_unicode_bom_remove( ptr, byte );

		byte   = n_posix_strlen( (void*) ptr ) * sizeof( n_posix_char );
		stream = ptr;

	}


#else // #ifdef UNICODE


	if ( p->txt.unicode != N_TXT_UNICODE_NIL )
	{

		u8 *ptr_u8 = (u8*) stream;

		ptr = n_unicode_alloccopy( &byte, &ptr_u8[ bom_offset ] );


		if ( p->txt.unicode == N_TXT_UNICODE_BIG )
		{
			n_unicode_endianness( ptr, byte );
		} else
		if ( p->txt.unicode == N_TXT_UNICODE_UTF )
		{
			n_unicode_utf8_decode_no_bom( ptr, byte );
		}


//MessageBoxW( NULL, (wchar_t*) ptr, L"DEBUG", 0 );

		lost = n_unicode_codec_wchar2char_no_bom( ptr, byte );

//MessageBoxA( NULL, ptr, "DEBUG", 0 );


		n_memory_free( stream );

		byte   = strlen( ptr );
		stream = ptr;

	}


#endif // #ifdef UNICODE


	p->txt.newline = n_txt_newline_check( stream, byte );

//n_posix_debug( stream );

	n_win_txtbox_vector_load_onmemory( p, stream, byte );

//n_posix_debug( p->txt.stream );


	if (
		( lost )
		||
		( p->txt.newline == N_TXT_NEWLINE_BINARY )
	)
	{
		p->txt.readonly = N_TXT_READONLY_ON;
	} else {
		p->txt.readonly = N_TXT_READONLY_OFF;
	}


	extern void n_win_txtbox_edit_undo( n_win_txtbox *p, n_posix_bool reverse );
	n_win_txtbox_edit_undo( p, n_posix_false );


	return n_posix_false;
}

n_posix_bool
n_win_txtbox_txt_save( n_win_txtbox *p, const n_posix_char *fname )
{

	// [!] : this module based on n_txt_save()

	if ( p == NULL ) { return n_posix_true; }


	if ( p->txt.readonly ) { return n_posix_true; }


	n_win_txtbox_txt_stream( p, n_posix_false );


	return n_txt_save_main( &p->txt, fname );
}



