// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_scroll_get( n_win_txtbox *p, n_type_int *x, n_type_int *y )
{

	if ( p == NULL ) { return; }

	if ( x != NULL ) { (*x) = p->scroll_pxl_tabbed_x / p->font_pxl_sx; }
	if ( y != NULL ) { (*y) = p->scroll_pxl_tabbed_y; }


	return;
}

#define n_win_txtbox_scroll( p, x,y ) n_win_txtbox_scroll_set( p, x,y, n_posix_true )

void
n_win_txtbox_scroll_set( n_win_txtbox *p, n_type_int x, n_type_int y, n_posix_bool clamp_onoff )
{

	if ( p == NULL ) { return; }


	// [Needed] : set default

	p->scroll_pxl_tabbed_x = 0;
	p->scroll_pxl_tabbed_y = 0;


	if ( clamp_onoff )
	{

		if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		{

			p->scroll_pxl_tabbed_x = n_posix_minmax_n_type_int( 0, p->last_pxl_tabbed_sx, x );

			if ( p->is_font_monospace )
			{
				p->scroll_pxl_tabbed_x = p->scroll_pxl_tabbed_x / p->font_pxl_sx * p->font_pxl_sx;
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				p->hscr.unit_pos = (n_type_real) p->scroll_pxl_tabbed_x;
			}
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			p->scroll_pxl_tabbed_y = n_posix_minmax_n_type_int( 0, p->last_pxl_tabbed_sy, y );

			p->vscr.unit_pos = (n_type_real) p->scroll_pxl_tabbed_y;

//n_win_txtbox_hwndprintf_literal( p, " %d ", (int) p->vscr.unit_pos );
		}

	} else {

		if ( ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
		{
			p->scroll_pxl_tabbed_x = x;

			if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
			{
				p->hscr.unit_pos = (n_type_real) p->scroll_pxl_tabbed_x;
			}
		}

		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
		{
			p->scroll_pxl_tabbed_y = y;

			p->vscr.unit_pos = (n_type_real) p->scroll_pxl_tabbed_y;
		}

	}


	return;
}

void
n_win_txtbox_scroll_refresh( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// [Needed] : clamp when resized

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_pxl_tabbed_y );


	// [!] : some functions rewrite position for calling through WM_COMMAND

	p->hscr.unit_pos = 0;
	p->vscr.unit_pos = 0;

	extern void n_win_txtbox_draw_scrollbars( n_win_txtbox *p, n_posix_bool redraw );
	n_win_txtbox_draw_scrollbars( p, n_posix_false );
//n_posix_debug_literal( " %f ", p->vscr.unit_pos );


	// [Needed] : Win9x : reason is unknown

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_refresh( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_refresh( &p->vscr );
	}


	return;
}

void
n_win_txtbox_scroll_tail( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	SIZE size = n_win_txtbox_size_text( p, n_win_txtbox_txt_get( p, p->select_cch_y ) );
	size.cx -= p->page_pxl_tabbed_sx;

	n_win_txtbox_scroll( p, size.cx, p->scroll_pxl_tabbed_y );


	return;
}

