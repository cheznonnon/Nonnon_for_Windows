// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_RADIOBUTTON
#define _H_NONNON_WIN32_WIN_RADIOBUTTON




#include "../neutral/bmp/fade.c"


#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./uxtheme.c"




typedef struct {

	HWND         hwnd;

	n_uxtheme    uxtheme;

	n_bmp_fade   fade;
	n_posix_bool fade_onoff;
	UINT         fade_timer_id;

	int          state;

	n_posix_bool press_onoff;
	n_posix_bool check_onoff;
	n_posix_bool p_chk_onoff;

	n_posix_bool is_classic;

} n_win_radio;




#define n_win_radio_zero( p ) n_memory_zero( p, sizeof( n_win_radio ) )

n_posix_bool
n_win_radio_is_enabled( n_win_radio *p )
{

	n_posix_bool ret = n_posix_true;


	if (
		( p->state == RBS_UNCHECKEDDISABLED )
		||
		( p->state == RBS_CHECKEDDISABLED   )
	)
	{
		ret = n_posix_false;
	}


	return ret;
}

n_posix_bool
n_win_radio_is_checked( n_win_radio *p )
{

	n_posix_bool ret = n_posix_false;


	if (
		( p->state == RBS_CHECKEDNORMAL   )
		||
		( p->state == RBS_CHECKEDHOT      )
		||
		( p->state == RBS_CHECKEDPRESSED  )
		||
		( p->state == RBS_CHECKEDDISABLED )

	)
	{
		ret = n_posix_true;
	}


	return ret;
}

void
n_win_radio_state_change( n_win_radio *p, int state_new )
{

	n_win_property_set_literal( p->hwnd, "State", p->state );
	p->state = state_new;

	n_bmp_fade_always_on( &p->fade, n_bmp_black, n_bmp_white );

	n_win_timer_init( p->hwnd, p->fade_timer_id, 1 );


	return;
}

void
n_win_radio_check( n_win_radio *p )
{

	int state = p->state;

	if ( p->state == 0 )
	{
		state = RBS_CHECKEDNORMAL;
	} else
	if ( p->state == RBS_UNCHECKEDNORMAL   )
	{
		state = RBS_CHECKEDNORMAL;
	} else
	if ( p->state == RBS_UNCHECKEDHOT      )
	{
		state = RBS_CHECKEDHOT;
	} else
	if ( p->state == RBS_UNCHECKEDPRESSED  )
	{
		state = RBS_CHECKEDPRESSED;
	} else
	if ( p->state == RBS_UNCHECKEDDISABLED )
	{
		state = RBS_CHECKEDDISABLED;
	}

	p->check_onoff = n_posix_true;

	n_win_radio_state_change( p, state );


	return;
}

void
n_win_radio_uncheck( n_win_radio *p )
{

	int state = p->state;

	if ( p->state == 0 )
	{
		state = RBS_UNCHECKEDNORMAL;
	} else
	if ( p->state == RBS_CHECKEDNORMAL   )
	{
		state = RBS_UNCHECKEDNORMAL;
	} else
	if ( p->state == RBS_CHECKEDHOT      )
	{
		state = RBS_UNCHECKEDHOT;
	} else
	if ( p->state == RBS_CHECKEDPRESSED  )
	{
		state = RBS_UNCHECKEDPRESSED;
	} else
	if ( p->state == RBS_CHECKEDDISABLED )
	{
		state = RBS_UNCHECKEDDISABLED;
	}

	p->check_onoff = n_posix_false;

	n_win_radio_state_change( p, state );


	return;
}

n_posix_bool
n_win_radiobutton_xp_is_zune( n_win_radio *p )
{

	n_posix_char theme_name[ N_UXTHEME_THEMENAME_CCH_MAX ];
	n_uxtheme_themename( &p->uxtheme, theme_name );

	return n_string_is_same_literal( "Zune", theme_name );
}

// internal
n_posix_bool
n_win_radiobutton_original_draw( n_win_radio *p, n_type_gfx ctl, n_type_gfx m, n_type_gfx sy, n_type_gfx dpi, int state )
{

	if ( NULL == N_BMP_PTR( &n_gdi_doublebuffer_32bpp_instance.bmp ) ) { return n_posix_true; }


	// [ Mechanism ] : hard to implement
	//
	//                 | hovered | checked   |
	//	-----------|---------|-----------| 
	//	WinXP      |  orange | green     | [!] : all except for "Zune"
	//	WinXP Zune |   gray  | dark gray |
	//	WinVista/7 |   blue  | dark blue |
	//
	//	highlight in XP uses middle of the circle
	//	highlight in Vista/7 use frame color change
	//	middle of the circle uses dark blue
	//	XP compatible circle uses light blue
	//
	//	spot highlight is used when checked

	//if ( n_posix_false == n_sysinfo_version_8_or_later() ) { return n_posix_true; }


	u32 color_1, color_2, color_3, color_4, color_5;

	n_posix_bool spot_onoff = n_posix_false;

	if (
//(1)&&
		( n_sysinfo_version_xp() )
	)
	{

		ctl += 2;

		if ( n_win_radiobutton_xp_is_zune( p ) )
		{
			color_1 = n_bmp_rgb(  83, 84, 86 );
			color_2 = n_bmp_rgb( 251,251,251 );
			color_3 = color_2;
			color_4 = n_bmp_rgb(  55, 55, 55 );
			color_5 = n_bmp_rgb( 114,114,114 );
		} else {
			color_1 = n_bmp_rgb(  28, 81,128 );
			color_2 = n_bmp_rgb( 255,255,255 );
			color_3 = color_2;
			color_4 = n_bmp_rgb(  33,161, 33 );
			color_5 = n_bmp_rgb(  93,234, 89 );
		}


		if ( ( state == RBS_UNCHECKEDHOT )||( state == RBS_CHECKEDHOT ) )
		{
			color_2 = n_bmp_rgb( 255,235,190 );
		} else
		if ( ( state == RBS_UNCHECKEDPRESSED )||( state == RBS_CHECKEDPRESSED ) )
		{
			color_2 = n_bmp_blend_pixel( color_2, n_bmp_black, 0.125 );
			color_3 = color_2;
			if ( state == RBS_UNCHECKEDPRESSED )
			{
				color_4 = color_3;
			}
		}

		if (
			( state != RBS_CHECKEDNORMAL     )
			&&
			( state != RBS_CHECKEDHOT        )
			&&
			( state != RBS_CHECKEDPRESSED    )
			&&
			( state != RBS_CHECKEDDISABLED   )
		)
		{
			//color_3 = color_2;
			color_4 = color_3;
		} else
		if (
			( state == RBS_CHECKEDNORMAL     )
			||
			( state == RBS_CHECKEDHOT        )
			||
			( state == RBS_CHECKEDPRESSED    )
			||
			( state == RBS_CHECKEDDISABLED   )
		)
		{
			spot_onoff = n_posix_true;
		}

	} else
	if (
//(1)
//
		( n_sysinfo_version_vista() )
		||
		( n_sysinfo_version_7() )
//
	)
	{

		color_1 = n_bmp_rgb( 145,146,146 );
		color_2 = n_bmp_rgb( 242,242,242 );
		color_3 = color_2; if ( dpi == 96 ) { color_3 = n_bmp_rgb(  24, 53, 74 ); }
		color_4 = n_bmp_rgb(  15,131,199 );
		color_5 = n_bmp_rgb( 199,235,253 );

		u32 hl = n_bmp_colorref2argb( n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT ) );

		if ( ( state == RBS_UNCHECKEDHOT )||( state == RBS_CHECKEDHOT ) )
		{
			color_1 = n_bmp_blend_pixel( color_1, hl, 0.25 );
			color_2 = n_bmp_blend_pixel( color_2, hl, 0.25 );
		} else
		if ( state == RBS_UNCHECKEDPRESSED )
		{
			color_2 = n_bmp_blend_pixel( color_2, n_bmp_black, 0.125 );
			color_3 = color_2;
			color_4 = color_3;
		} else
		if ( state == RBS_CHECKEDPRESSED )
		{
			color_2 = n_bmp_blend_pixel( color_2, n_bmp_black, 0.25 );
			color_3 = n_bmp_blend_pixel( color_3, n_bmp_black, 0.25 );
			color_4 = n_bmp_blend_pixel( color_4, n_bmp_black, 0.25 );
		}

		if (
			( state != RBS_CHECKEDNORMAL     )
			&&
			( state != RBS_CHECKEDHOT        )
			&&
			( state != RBS_CHECKEDPRESSED    )
			&&
			( state != RBS_CHECKEDDISABLED   )
		)
		{
			color_3 = color_2;
			color_4 = color_3;
		} else
		if (
			( state == RBS_CHECKEDNORMAL     )
			||
			( state == RBS_CHECKEDHOT        )
			||
			( state == RBS_CHECKEDPRESSED    )
			||
			( state == RBS_CHECKEDDISABLED   )
		)
		{
			spot_onoff = n_posix_true;
		}

	} else {

		u32 bg = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_WINDOW    );

		color_1 = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );
		color_2 = bg;
		color_3 = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNTEXT   );
		color_4 = color_3;
		color_5 = 0;

		if ( n_win_fluent_ui_onoff )
		{
			color_4 = color_3 = bg;

			if (
				( state == RBS_CHECKEDNORMAL   )
				||
				( state == RBS_CHECKEDHOT      )
				||
				( state == RBS_CHECKEDPRESSED  )
				||
				( state == RBS_CHECKEDDISABLED )
			)
			{
				color_1 = color_2 = n_win_fluent_ui_accent_color();
			}

			if (
				( state == RBS_UNCHECKEDNORMAL   )
				||
				( state == RBS_UNCHECKEDHOT      )
				||
				( state == RBS_UNCHECKEDPRESSED  )
				||
				( state == RBS_UNCHECKEDDISABLED )
			)
			{
				color_2 = bg;
			}
		}

		if ( color_1 == n_bmp_black_invisible ) { color_1 = n_bmp_black + 1; }
		if ( color_2 == n_bmp_black_invisible ) { color_2 = n_bmp_black + 1; }
		if ( color_3 == n_bmp_black_invisible ) { color_3 = n_bmp_black + 1; }
		if ( color_4 == n_bmp_black_invisible ) { color_4 = n_bmp_black + 1; }

		u32 hl = n_win_fluent_ui_accent_color();

		if ( ( state == RBS_UNCHECKEDHOT )||( state == RBS_CHECKEDHOT ) )
		{
			color_1 = n_bmp_blend_pixel( color_1, hl, 1.000 );
			color_2 = n_bmp_blend_pixel( color_2, hl, 0.125 );
		} else
		if ( ( state == RBS_UNCHECKEDPRESSED )||( state == RBS_CHECKEDPRESSED ) )
		{
			color_1 = n_bmp_blend_pixel( color_1, hl, 1.000 );
			color_2 = n_bmp_blend_pixel( color_2, hl, 0.250 );
		}

		if (
			( state != RBS_CHECKEDNORMAL   )
			&&
			( state != RBS_CHECKEDHOT      )
			&&
			( state != RBS_CHECKEDPRESSED  )
			&&
			( state != RBS_CHECKEDDISABLED )
		)
		{
			color_3 = color_2;
			color_4 = color_3;
		}

	}


	n_type_gfx  xx = m;
	n_type_gfx  yy = abs( sy - ctl ) / 2;
	n_type_gfx sxx = ctl;
	n_type_gfx syy = ctl;

	n_bmp_circle( &n_gdi_doublebuffer_32bpp_instance.bmp, xx,yy,sxx,syy, color_1 );

	n_type_gfx n = m / 2;

	 xx += n * 1;
	 yy += n * 1;
	sxx -= n * 2;
	syy -= n * 2;

	n_bmp_circle( &n_gdi_doublebuffer_32bpp_instance.bmp, xx,yy,sxx,syy, color_2 );

	 xx += n * 1;
	 yy += n * 1;
	sxx -= n * 2;
	syy -= n * 2;

	if ( dpi == 96 )
	{
		 xx += n * 1;
		 yy += n * 1;
		sxx -= n * 2;
		syy -= n * 2;
	}

	n_bmp_circle( &n_gdi_doublebuffer_32bpp_instance.bmp, xx,yy,sxx,syy, color_3 );

	 xx += n * 1;
	 yy += n * 1; 
	sxx -= n * 2;
	syy -= n * 2;

	n_bmp_circle( &n_gdi_doublebuffer_32bpp_instance.bmp, xx,yy,sxx,syy, color_4 );

	if ( spot_onoff )
	{

		n_type_gfx spot = 2; if ( dpi != 96 ) { spot = 3; }

		 xx += n * ( spot * 1 );
		 yy += n * ( spot * 1 );
		sxx -= n * ( spot * 2 );
		syy -= n * ( spot * 2 );

		 xx -= n * 1;
		 yy -= n * 1;

		n_bmp_circle( &n_gdi_doublebuffer_32bpp_instance.bmp, xx,yy,sxx,syy, color_5 );

	}


	return n_posix_false;
}

// internal
void
n_win_radio_draw( n_win_radio *p, HDC hdc_override, RECT *rect )
{

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc;
hdc_override = NULL;
	if ( hdc_override == NULL )
	{
		hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx,sy );
	} else {
		hdc = hdc_override;
	}


	n_type_gfx dpi = n_win_dpi( p->hwnd );

	n_type_gfx ctl = n_win_stdsize_radio( p->hwnd );
	n_type_gfx m   = ctl / 3;


	// Background

	{
		u32 bg = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE );

		n_bmp_box( &n_gdi_doublebuffer_32bpp_instance.bmp, x,y,sx,sy, bg );
	}


	// Main

	if (
//(0)&&
		( ( p->is_classic == n_posix_false )&&( p->uxtheme.onoff ) )
	)
	{

//n_posix_debug_literal( "%d %d", sy, ctl );


		n_type_gfx step;
		if ( dpi == 96 )
		{
			step = (n_type_gfx) ( (double) n_win_scale( p->hwnd ) * 2 );
		} else {
			step = ctl / 4;
		}


		int state_f = n_win_property_get_literal( p->hwnd, "State" );

		if ( n_win_radiobutton_original_draw( p, ctl, step, sy, dpi, state_f ) )
		{
			// [!] : currently this code is not used

			RECT rect = n_win_rect_set( NULL, m, abs( sy - ctl ) / 2, ctl, ctl );
			int  part = BP_RADIOBUTTON;

			p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, part, state_f, &rect, NULL );
		}

		n_bmp bmp_f; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_f );


		int state_t = p->state;

		if ( n_win_radiobutton_original_draw( p, ctl, step, sy, dpi, state_t ) )
		{
			// [!] : currently this code is not used

			RECT rect = n_win_rect_set( NULL, m, abs( sy - ctl ) / 2, ctl, ctl );
			int  part = BP_RADIOBUTTON;

			p->uxtheme.DrawThemeBackground( p->uxtheme.htheme, hdc, part, state_t, &rect, NULL );
		}

		n_bmp bmp_t; n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &bmp_t );


		n_bmp_alpha_visible( &bmp_f );
		n_bmp_alpha_visible( &bmp_t );
//n_bmp_save_literal( &bmp_f, "f.bmp" );
//n_bmp_save_literal( &bmp_t, "t.bmp" );


		n_type_real ratio = (n_type_real) p->fade.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_flush_fastcopy( &bmp_t, &n_gdi_doublebuffer_32bpp_instance.bmp );


		n_bmp_free_fast( &bmp_f );
		n_bmp_free_fast( &bmp_t );

	} else {

		// [Patch] : Y : +1 for patch
		RECT r = n_win_rect_set( NULL, m, ( abs( sy - ctl ) / 2 ) + 1, ctl, ctl );

		int dfcs = DFCS_BUTTONRADIO;

		if ( p->state == RBS_UNCHECKEDNORMAL   ) { } else
		if ( p->state == RBS_UNCHECKEDHOT      ) { } else
		if ( p->state == RBS_UNCHECKEDPRESSED  ) { dfcs |= DFCS_PUSHED  ; } else
		if ( p->state == RBS_UNCHECKEDDISABLED ) { dfcs |= DFCS_INACTIVE; } else
		if ( p->state == RBS_CHECKEDNORMAL     ) { dfcs |= DFCS_CHECKED ; } else
		if ( p->state == RBS_CHECKEDHOT        ) { dfcs |= DFCS_CHECKED ; } else
		if ( p->state == RBS_CHECKEDPRESSED    ) { dfcs |= DFCS_CHECKED | DFCS_PUSHED  ; } else
		if ( p->state == RBS_CHECKEDDISABLED   ) { dfcs |= DFCS_CHECKED | DFCS_INACTIVE; }// else

		DrawFrameControl( hdc, &r, DFC_BUTTON, dfcs );

	}


	// Text

	{

		n_type_gfx gap = m * 2; x += ctl + gap;

		if ( dpi > 96 ) { y -= dpi / 96; }


		n_posix_char str[ 1024 ]; n_win_text_get( p->hwnd, str, 1024 );


		RECT     r  = { x, y, x+sx, y+sy };
		COLORREF fg = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT   );
		HFONT    hf = SelectObject( hdc, n_win_font_get( p->hwnd ) );
		int      dt = ( DT_SINGLELINE | DT_VCENTER );


		SetBkMode( hdc, TRANSPARENT );

		if ( p->is_classic )
		{

			if ( n_posix_false == n_win_radio_is_enabled( p ) )
			{

				COLORREF color_shadow;
				COLORREF color_text;

				if ( n_win_darkmode_onoff )
				{
					color_shadow = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
					color_text   = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW     );
				} else {
					color_shadow = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
					color_text   = n_win_darkmode_systemcolor_ui( COLOR_GRAYTEXT      );
				}

				RECT r_shadow  = { x+1, y+2, x+sx, y+sy };
				SetTextColor( hdc, color_shadow );
				DrawText( hdc, str,-1, &r_shadow, dt );

				SetTextColor( hdc, color_text );
				DrawText( hdc, str,-1, &r, dt );

			} else {

				SetTextColor( hdc, fg );
				DrawText( hdc, str,-1, &r, dt );

			}

		} else {

			SetTextColor( hdc, fg );
			DrawText( hdc, str,-1, &r, dt );

		}

/*
		UINT dst = DST_TEXT;
		if ( n_posix_false == n_win_radio_is_enabled( p ) ) { dst |= DSS_DISABLED; }

		HBRUSH hbrush = n_win_darkmode_brush_bg( COLOR_BTNFACE );
		DrawState( hdc, hbrush, NULL, (LPARAM) str, 0, x+m,y,sx,sy, dst );
		DeleteObject( hbrush );
*/

		SelectObject( hdc, hf );

	}


	if ( ( p->is_classic == n_posix_false )&&( n_posix_false == n_win_radio_is_enabled( p ) ) )
	{
		u32 bg = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE );
		n_bmp_flush_mixer( &n_gdi_doublebuffer_32bpp_instance.bmp, bg, 0.5 );
	}


	if ( hdc_override == NULL ) { n_gdi_doublebuffer_32bpp_simple_exit(); }


	return;
}

// internal
LRESULT CALLBACK
#ifdef _WIN64
n_win_radio_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_radio_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	n_win_radio *p = (void*) dwRefData;
#else  // #ifdef _WIN64
	n_win_radio *p = (void*) n_win_property_get_literal( hwnd, "n_win_radio" );
#endif // #ifdef _WIN64

	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam != p->fade_timer_id ) { break; }

		n_bmp_fade_engine( &p->fade, p->fade_onoff );
		n_win_refresh( p->hwnd, n_posix_false );

		if ( p->fade.percent == 100 )
		{
			n_win_timer_exit( hwnd, p->fade_timer_id );
			n_win_property_set_literal( p->hwnd, "State", p->state );
		}

//n_win_hwndprintf_literal( GetParent( p->hwnd ), "%d", (int) p->fade.percent );
	break;


	case WM_MOUSEMOVE :

		// [!] : this code depends SetCapture()/ReleaseCapture()

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "Radio : WM_MOUSEHOVER" );

		if ( n_posix_false == n_win_radio_is_enabled( p ) ) { break; }

//n_win_hwndprintf_literal( GetParent( p->hwnd ), " %d %d ", p->press_onoff, n_win_is_input( VK_LBUTTON ) );
		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if ( p->state == RBS_CHECKEDNORMAL   )
		{
			n_win_radio_state_change( p, RBS_CHECKEDHOT );
		} else
		if ( p->state == RBS_UNCHECKEDNORMAL )
		{
			n_win_radio_state_change( p, RBS_UNCHECKEDHOT );
		}

	break;

	case WM_MOUSELEAVE :
//n_win_text_set_literal( n_win_hwnd_toplevel( hwnd ), "Radio : WM_MOUSELEAVE" );

		if ( n_posix_false == n_win_radio_is_enabled( p ) ) { break; }

		if ( p->press_onoff )
		{
			p->check_onoff = p->p_chk_onoff;

			int state;
			if ( p->check_onoff )
			{
				state = RBS_CHECKEDNORMAL;
			} else {
				state = RBS_UNCHECKEDNORMAL;
			}

			n_win_radio_state_change( p, state );

		} else
		if ( p->state == RBS_CHECKEDHOT     )
		{

			n_win_radio_state_change( p, RBS_CHECKEDNORMAL );

		} else
		if ( p->state == RBS_UNCHECKEDHOT   )
		{

			n_win_radio_state_change( p, RBS_UNCHECKEDNORMAL );

		} else
		if ( p->state == RBS_CHECKEDPRESSED )
		{

			n_win_radio_state_change( p, RBS_CHECKEDNORMAL );

		}

	break;


	case WM_ERASEBKGND :

		return n_posix_true;

	break;


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN   :

		p->press_onoff = n_posix_true;

		SetCapture( hwnd );

		if ( n_posix_false == n_win_radio_is_enabled( p ) ) { break; }

		p->p_chk_onoff = p->check_onoff;

		if ( p->check_onoff == n_posix_false )
		{
			p->check_onoff = n_posix_true;

			n_win_radio_state_change( p, RBS_UNCHECKEDPRESSED );
		} else {
			p->check_onoff = n_posix_false;

			n_win_radio_state_change( p, RBS_CHECKEDPRESSED );
		}

	break;

	case WM_LBUTTONUP :

		p->press_onoff = n_posix_false;

		ReleaseCapture();

		if ( p->check_onoff )
		{
			p->check_onoff = n_posix_true;

			n_win_radio_state_change( p, RBS_CHECKEDHOT );
		} else {
			if ( p->state == RBS_CHECKEDPRESSED )
			{
				n_win_radio_state_change( p, RBS_CHECKEDHOT );
			}
		}

		n_win_message_send( GetParent( hwnd ), WM_COMMAND, p->state, hwnd );

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64

	// [Needed] : Win95 : crash

	WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "Subclass" );
	if ( pfunc == NULL ) { return 0; }

	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_radio_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_radio *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		n_win_radio_draw( p, di->hDC, &di->rcItem );

	}
	break;


	} // switch


	return;
}

void
n_win_radio_onoff( n_win_radio *p, n_posix_bool onoff )
{

	int state = p->state;

	if ( onoff )
	{

		EnableWindow( p->hwnd, onoff );

		if ( p->state == RBS_CHECKEDDISABLED   )
		{
			state = RBS_CHECKEDNORMAL;
		} else
		if ( p->state == RBS_UNCHECKEDDISABLED )
		{
			state = RBS_UNCHECKEDNORMAL;
		}// else

	} else {

		if ( ( p->state == RBS_UNCHECKEDNORMAL )||( p->state == RBS_UNCHECKEDHOT ) )
		{
			state = RBS_UNCHECKEDDISABLED;
		} else
		if ( ( p->state == RBS_CHECKEDNORMAL   )||( p->state == RBS_CHECKEDHOT   ) )
		{
			state = RBS_CHECKEDDISABLED;
		}// else

		EnableWindow( p->hwnd, onoff );

	}

	if ( state != p->state )
	{
		n_win_radio_state_change( p, state );
	}


	return;
}

void
n_win_radio_on_settingchange( n_win_radio *p )
{

	p->is_classic = n_win_style_is_classic();


	n_win_stdfont_exit( &p->hwnd, 1 );
	n_win_stdfont_init( &p->hwnd, 1 );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );
	n_uxtheme_init( &p->uxtheme, p->hwnd, L"BUTTON" );


	p->fade_onoff = n_win_fade_is_on();
	n_bmp_fade_init( &p->fade, n_bmp_black );


	return;
}

#define n_win_radio_init_literal( p, h, t, s ) n_win_radio_init( p, h, n_posix_literal( t ), s )

void
n_win_radio_init( n_win_radio *p, HWND hwnd_parent, n_posix_char *text, int state )
{

	n_win_gui( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, text, &p->hwnd );
//n_win_style_add( p->hwnd, WS_BORDER );

	p->state = state;
	n_win_property_set_literal( p->hwnd, "State", p->state );


	p->fade_timer_id = n_win_timer_id_get();


#ifdef _WIN64

	SetWindowSubclass( p->hwnd, n_win_radio_subclass, 0, (DWORD_PTR) p );

#else  // #ifdef _WIN64

	WNDPROC pfunc = n_win_gui_subclass_set( p->hwnd, n_win_radio_subclass );

	n_win_property_init_literal( p->hwnd, "n_win_radio", (int) p     );
	n_win_property_init_literal( p->hwnd, "Subclass"   , (int) pfunc );

#endif // #ifdef _WIN64


	n_win_property_init_literal( p->hwnd, "n_win_move_patch_button().radio", n_posix_true );


	n_win_radio_on_settingchange( p );


	return;
}

void
n_win_radio_exit( n_win_radio *p )
{

	n_win_property_exit_literal( p->hwnd, "State" );


#ifdef _WIN64

	RemoveWindowSubclass( p->hwnd, n_win_radio_subclass, 0 );

#else  // #ifdef _WIN64

	n_win_property_exit_literal( p->hwnd, "n_win_radio" );
	n_win_property_exit_literal( p->hwnd, "Subclass"    );

#endif // #ifdef _WIN64


	n_win_property_exit_literal( p->hwnd, "n_win_move_patch_button().radio" );


	n_uxtheme_exit( &p->uxtheme, p->hwnd );


	n_win_stdfont_exit( &p->hwnd, 1 );


	DestroyWindow( p->hwnd );


	return;
}


#endif // _H_NONNON_WIN32_WIN_RADIOBUTTON


