// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// Link : -lole32


// [!] : don't use WM_DROPFILES handler together


// [x] : into Explorer : crash : use n_IDropSource_instant_dnd()




#ifndef _H_NONNON_WIN32_OLE_IDROPSOURCE
#define _H_NONNON_WIN32_OLE_IDROPSOURCE




#include "../../neutral/string.c"


#include <ole2.h>
#include <oleidl.h>
#include <shlobj.h>




#include "./IDataObject.c"




const GUID n_IDropSource_guid_IID_IUnknown    = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_IDropSource_guid_IID_IDropSource = { 0x00000121,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




void
n_IDropSource_instant_dnd( void )
{

	// [!] : cheap trick!

	POINT pt; GetCursorPos( &pt );


	const int drag_sx = GetSystemMetrics( SM_CXDRAG ) + 1;
	const int drag_sy = GetSystemMetrics( SM_CYDRAG ) + 1;


	SetCursorPos( pt.x - drag_sx, pt.y - drag_sy );


	return;
}




HRESULT __stdcall
n_IDropSource_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	(*ppvObject) = NULL;

	if (
		( n_memory_is_same( iid, &n_IDropSource_guid_IID_IUnknown,    sizeof( GUID ) ) )
		||
		( n_memory_is_same( iid, &n_IDropSource_guid_IID_IDropSource, sizeof( GUID ) ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

ULONG __stdcall
n_IDropSource_AddRef( void *_this )
{
	return S_OK;
}

ULONG __stdcall
n_IDropSource_Release( void *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IDropSource_QueryContinueDrag( void *_this, BOOL fEscapePressed, DWORD grfKeyState )
{
//n_posix_debug_literal( " n_IDropSource_QueryContinueDrag() " );


	if ( fEscapePressed ) { return DRAGDROP_S_CANCEL; }


	if ( grfKeyState ) { return S_OK; } else { return DRAGDROP_S_DROP; }


	return DRAGDROP_S_CANCEL;
}

HRESULT __stdcall
n_IDropSource_GiveFeedback( void *_this, DWORD grfKeyState )
{
//n_posix_debug_literal( " n_IDropSource_GiveFeedback() " );

	return DRAGDROP_S_USEDEFAULTCURSORS;
}




// [!] : you can override before starting

static void *n_IDropSource_Vtbl[] = {

	n_IDropSource_QueryInterface,
	n_IDropSource_AddRef,
	n_IDropSource_Release,

	n_IDropSource_QueryContinueDrag,
	n_IDropSource_GiveFeedback,

};


static IDropSource n_IDropSource_instance = { (void*) n_IDropSource_Vtbl };




void
n_IDropSource_start( n_posix_char *path )
{

	// [!] : "path"
	//
	//	"path1\0" + "path2\0" + "\0"


	if ( n_string_is_empty( path ) ) { return; }


	n_type_int path_cch = 0;
	n_posix_loop
	{
		if ( ( path[ path_cch ] == N_STRING_CHAR_NUL )&&( path[ path_cch + 1 ] == N_STRING_CHAR_NUL ) )
		{
			path_cch += 2;
			break;
		}
		path_cch++;
	}


	IDataObject *p_IDataObject = NULL;
	n_IDataObject_dnd_init( &p_IDataObject, path, path_cch );


	// [Needed] : DoDragDrop() returns immediately if doing this patch

	n_IDropSource_instant_dnd();


	// [x] : you cannot redraw while DoDragDrop()
	//
	//	use combo for SetCapture() + ReleaseCapture() + WM_*BUTTONUP

//n_posix_debug_literal( "DoDragDrop()" );

	static DWORD pdwEffect = DROPEFFECT_COPY;
	DoDragDrop( p_IDataObject, &n_IDropSource_instance, DROPEFFECT_COPY, &pdwEffect );


	n_IDataObject_dnd_exit( &p_IDataObject );


	return;
}


#endif // _H_NONNON_WIN32_OLE_IDROPSOURCE

