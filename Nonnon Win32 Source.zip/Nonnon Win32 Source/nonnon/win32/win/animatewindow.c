// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Vista or later : not working when non-popup windows




#ifndef _H_NONNON_WIN32_WIN_AMIMATEWINDOW
#define _H_NONNON_WIN32_WIN_AMIMATEWINDOW




//#include "../neutral/posix.c"




#define n_AW_HOR_POSITIVE 0x00000001
#define n_AW_HOR_NEGATIVE 0x00000002
#define n_AW_VER_POSITIVE 0x00000004
#define n_AW_VER_NEGATIVE 0x00000008
#define n_AW_CENTER       0x00000010
#define n_AW_HIDE         0x00010000
#define n_AW_ACTIVATE     0x00020000
#define n_AW_SLIDE        0x00040000
#define n_AW_BLEND        0x00080000




/*
void
n_win_animatewindow_debug( void )
{

	// [!] : Win2000
	//
	//	off   : 0-0-0-0-0-0
	//	slide : 0-1-0-1-0-1
	//	fade  : 1-1-1-1-1-1
	//
	//	SPI_GETMENUFADE needs SPI_GETMENUANIMATION is TRUE


	BOOL b[ 6 ];


	ZeroMemory( b, sizeof( BOOL ) * 6 );

	SystemParametersInfo( SPI_GETMENUFADE,          0, &b[ 0 ], 0 );
	SystemParametersInfo( SPI_GETMENUANIMATION,     0, &b[ 1 ], 0 );
	SystemParametersInfo( SPI_GETSELECTIONFADE,     0, &b[ 2 ], 0 );
	SystemParametersInfo( SPI_GETTOOLTIPANIMATION,  0, &b[ 3 ], 0 );
	SystemParametersInfo( SPI_GETTOOLTIPFADE,       0, &b[ 4 ], 0 );
	SystemParametersInfo( SPI_GETCOMBOBOXANIMATION, 0, &b[ 5 ], 0 );


	n_posix_debug
	(
		"SPI_GETMENUFADE          %d \n"
		"SPI_GETMENUANIMATION     %d \n"
		"SPI_GETSELECTIONFADE     %d \n"
		"SPI_GETTOOLTIPANIMATION  %d \n"
		"SPI_GETTOOLTIPFADE       %d \n"
		"SPI_GETCOMBOBOXANIMATION %d \n",
		b[0],b[1],b[2],b[3],b[4],b[5]
	);


	return;
}
*/

#define N_WIN_ANIMATEWINDOW_MODE_NONE ( 0 )
#define N_WIN_ANIMATEWINDOW_MODE_SCRL ( 1 )
#define N_WIN_ANIMATEWINDOW_MODE_FADE ( 2 )

int
n_win_simplemenu_animatewindow_mode( void )
{

	int ret = N_WIN_ANIMATEWINDOW_MODE_NONE;

	n_posix_bool onoff_anim = n_posix_false;
	SystemParametersInfo( SPI_GETMENUANIMATION, 0, &onoff_anim, 0 );

	if ( onoff_anim )
	{
		n_posix_bool onoff_fade = n_posix_false;
		SystemParametersInfo( SPI_GETMENUFADE, 0, &onoff_fade, 0 );

		if ( onoff_fade )
		{
			ret = N_WIN_ANIMATEWINDOW_MODE_FADE;
		} else {
			ret = N_WIN_ANIMATEWINDOW_MODE_SCRL;
		}
	}


	return ret;
}

n_posix_bool
n_win_animatewindow( HWND hwnd, DWORD msec, DWORD aw )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
	FARPROC func = GetProcAddress( hmod, "AnimateWindow" );

	if ( func != NULL )
	{
		(*func)( hwnd, msec, aw );
	}

	FreeLibrary( hmod );


	return ( func == NULL );
}


#endif // _H_NONNON_WIN32_WIN_AMIMATEWINDOW

