// Nonnon FLOSS
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism]
//
//	1 : headers need include guard
//	2 : /* for buggy compilers */ need to be comment-out'ed, see NO_DUMMY_DECL
//	3 : crc32.c   : DO1 DO8 need to be crc32_DO1 crc32_DO8
//	4 : deflate.c : config needs to be zlib_config
//	5 : inflate.h : FLAGS needs tobe zlib_FLAGS (conflict with mapi.h)
//	6 : inflate.c : FLAGS needs tobe zlib_FLAGS (conflict with mapi.h)




#ifndef _H_NONNON_FLOSS_ZLIB
#define _H_NONNON_FLOSS_ZLIB




#ifdef __APPLE__


#include <zlib.h>


// [x] : bit length overflow happens

//#define __MACTYPES__
//#define MACOS
////#define TARGET_OS_MAC

//#define NOBYFOUR

//#pragma clang diagnostic ignored "-Wcomma"


// [!] : comment-out #else if you want to use embedded code

#else // #ifdef __APPLE__


#define NO_DUMMY_DECL

#include "zlib/zlib.h"

#include "zlib/zutil.c"

#include "zlib/adler32.c"
#include "zlib/crc32.c"

#include "zlib/trees.c"
#include "zlib/deflate.c"

#include "zlib/inffast.c"
#include "zlib/inftrees.c"
#include "zlib/inflate.c"

#include "zlib/compress.c"
#include "zlib/uncompr.c"


#endif // #ifdef __APPLE__




#endif // _H_NONNON_FLOSS_ZLIB


