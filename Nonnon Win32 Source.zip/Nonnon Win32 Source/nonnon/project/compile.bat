
:Instruction

@echo off

REM	[ Usage ]
REM	
REM	1 : "set name=entry_point"
REM	2 : a : "set window=-mwindows" for  window application
REM	    b : "set window="          for console application
REM	3 : call this file


REM	[ Memo ]
REM	
REM	Win9x : not supported : "else" in "if" command
REM	Win9x : not supported : if %errorlevel% neq 0
REM     Win9x : SET has limitation in length and count
REM     Win9x : SET cannot handle "=" character in right-hand side
REM	
REM	WinVista : ld.exe : "Permission Denied" frequently
REM	see :Patch for details


:Init

@echo off

REM	2017 October : "-mtune=amdfam10"
REM
REM	GCC4 : OrangeCat : Windows Defender handles as a malware

set     warn=-Wall -Werror
set      opt=-Os
set     tune=-mtune=athlon64

REM set lib_w32=-lcomctl32 -limm32 -lversion -lvfw32 -lwinmm
REM set lib_ole=-lole32 -loleaut32 -ld3d9
REM set lib_net=-lwininet
REM set lib_all=%lib_w32% %lib_ole% %lib_net%


:Main

@echo on

windres -i %name%.rc -o rc.o
gcc %warn% %opt% %tune% -c %name%.c -o obj.o
gcc %window% -s -mthreads obj.o rc.o -o %name%.tmp -lcomctl32 -limm32 -lversion -lvfw32 -lwinmm -lole32 -loleaut32 -ld3d9 -lwininet


:ErrorChecker

@echo off

if errorlevel 1 goto :Error


:Patch

@echo off

if exist %name%.exe del %name%.exe
if errorlevel 1 goto :Error

ren %name%.tmp %name%.exe
if errorlevel 1 goto :Error

goto :Exit


:Error

del %name%.tmp

@echo off

pause


:Exit

@echo off

del *.o


