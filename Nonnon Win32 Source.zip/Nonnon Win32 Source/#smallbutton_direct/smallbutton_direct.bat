
@echo off

set compile=..\nonnon\project\compile.bat
set    name=smallbutton_direct
set  window=-mwindows

%compile%

