
@echo off

set compile=..\nonnon\project\compile.bat
set    name=watchcat
set  window=-mwindows

%compile%

