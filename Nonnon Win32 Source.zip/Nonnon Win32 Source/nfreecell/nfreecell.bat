
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nfreecell
set  window=-mwindows

%compile%

