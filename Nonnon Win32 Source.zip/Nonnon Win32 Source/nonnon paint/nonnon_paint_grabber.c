// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static RECT       n_paint_grabber_rect;
static n_type_gfx n_paint_grabber_fx;
static n_type_gfx n_paint_grabber_fy;




// internal
void
n_paint_grabber_system_get( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy, n_type_gfx *fx, n_type_gfx *fy )
{

	// [!] : Why is this messy?
	//
	//	a : for reserving namespace
	//	b : for avoiding silent reference to global variables

	if ( x  != NULL ) { *x  = n_paint_grabber_rect.left;   }
	if ( y  != NULL ) { *y  = n_paint_grabber_rect.top;    }
	if ( sx != NULL ) { *sx = n_paint_grabber_rect.right;  }
	if ( sy != NULL ) { *sy = n_paint_grabber_rect.bottom; }
	if ( fx != NULL ) { *fx = n_paint_grabber_fx;          }
	if ( fy != NULL ) { *fy = n_paint_grabber_fy;          }


	return;
}

// internal
void
n_paint_grabber_system_set( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy, n_type_gfx *fx, n_type_gfx *fy )
{

	if ( x  != NULL ) { n_paint_grabber_rect.left   = *x;  }
	if ( y  != NULL ) { n_paint_grabber_rect.top    = *y;  }
	if ( sx != NULL ) { n_paint_grabber_rect.right  = *sx; }
	if ( sy != NULL ) { n_paint_grabber_rect.bottom = *sy; }
	if ( fx != NULL ) { n_paint_grabber_fx          = *fx; }
	if ( fy != NULL ) { n_paint_grabber_fy          = *fy; }


	return;
}

// internal
void
n_paint_grabber_system_zero( void )
{

	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	x = y = sx = sy = fx = fy = 0;

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

// internal
void
n_paint_grabber_status( void )
{

	n_posix_char str[ 100 ];


	if ( N_PAINT_GRABBER_IS_NEUTRAL()              ) { n_string_copy_literal( " Neutral",    str ); } else
	if ( N_PAINT_GRABBER_IS_SELECTING()            ) { n_string_copy_literal( " Selecting",  str ); } else
	if ( N_PAINT_GRABBER_IS_DRAG_OK()              ) { n_string_copy_literal( " Drag OK",    str ); } else
	if ( N_PAINT_GRABBER_IS_DRAGGING()             ) { n_string_copy_literal( " Dragging",   str ); } else
	if ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() ) { n_string_copy_literal( " Stretching", str ); } else
	if ( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM()    ) { n_string_copy_literal( " Stretching", str ); }

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 0 );


	n_type_gfx x,y,sx,sy,fx,fy;

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{
		x = y = sx = sy = fx = fy = 0;
	} else {
		n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );
	}


	n_posix_char str_x[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_x, x );
	n_posix_char str_y[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_y, y );

	n_posix_sprintf_literal( str, "\t\t%s %s ", str_x,str_y );

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 1 );


	n_posix_char str_sx[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sx, sx );
	n_posix_char str_sy[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_sy, sy );

	n_posix_sprintf_literal( str, "\t\t%sx%s ", str_sx,str_sy );

	n_win_statusbar_od_text( &n_paint_tool_grabber_status, str, 2 );


	return;
}

// internal
void
n_paint_grabber_init( void )
{

	grabber = N_PAINT_GRABBER_NEUTRAL;

	n_paint_grabber_system_zero();


	return;
}

// internal
void
n_paint_grabber_resync( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool reset_scrl )
{

//n_paint_refresh_all(); return;


	static n_type_gfx pfx = 0;
	static n_type_gfx pfy = 0;
	static n_type_gfx ptx = 0;
	static n_type_gfx pty = 0;


	pfx = n_posix_min_n_type_gfx( pfx, x      );
	pfy = n_posix_min_n_type_gfx( pfy, y      );
	ptx = n_posix_max_n_type_gfx( ptx, x + sx );
	pty = n_posix_max_n_type_gfx( pty, y + sy );

//n_bmp_box( n_paint_bmp_data, pfx,pfy, ptx-pfx,pty-pfy, n_bmp_rgb( 0,0,n_random_range( 256 ) ) );

	n_bmp_box( &n_paint_bmp_scrl, x,y,sx,sy, 0 );

	if ( n_paint_layer_is_locked_partially() )
	{
		n_paint_cache_zero( &n_paint_bmp_wgrb );
	}

	n_paint_refresh( NULL, pfx,pfy, ptx,pty, N_PAINT_REFRESH_CLIENT, N_PAINT_REFRESH_ID_GRABBER );

	pfx = x;
	pfy = y;
	ptx = x + sx;
	pty = y + sy;


	return;
}

void
n_paint_grabber_resync_auto( void )
{

	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

	n_paint_grabber_resync( x,y,sx,sy, n_posix_true );


	return;
}

void
n_paint_grabber_resync_auto_fast( void )
{

	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

	n_paint_grabber_resync( x,y,sx,sy, n_posix_false );


	return;
}

// internal
void
n_paint_grabber_composition( n_bmp *grab, n_bmp *target, n_bool finalize, n_bool frame )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return; }


	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

	if ( frame )
	{
		n_draw_frame( target, x-1,y-1,sx+2,sy+2, n_bmp_white, n_bmp_black );
	}

//return;
	if ( n_paint_tool_per_pixel_alpha_onoff )
	{
		n_bmp_blendcopy_all( grab, target, 0,0,sx,sy, x,y, n_false,n_false, finalize, n_paint_tool_blend_ratio );
	} else
	if ( n_paint_tool_blend )
	{
		n_bmp_blendcopy_all( grab, target, 0,0,sx,sy, x,y, n_true ,n_false, finalize, n_paint_tool_blend_ratio );
	} else {
		n_bmp_fastcopy( grab, target, 0,0,sx,sy, x,y );
	}


	return;
}

// internal
void
n_paint_grabber_reset( void )
{

	if ( n_paint_layer_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else {

		n_bmp_free( n_paint_bmp_grab );

	}

	n_paint_grabber_init();

	n_paint_cache_zero( &n_paint_bmp_scrl );
	n_paint_cache_zero( &n_paint_bmp_wgrb );

	n_paint_grabber_resync_auto();


	// [!] : for usability
	//n_paint_tool_grabber_trans_onoff( n_false );


	n_paint_tool_grabber_blend_zero();


	n_paint_layer_grabber_check_enable( n_true );
	n_paint_layer_grabber_location( -1 );


	return;
}

#define N_PAINT_GRABBER_WHOLEGRAB_THREAD_FINISH     ( 1 )
#define N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT     ( 2 )
#define N_PAINT_GRABBER_WHOLEGRAB_THREAD_CLEAR      ( 3 )
#define N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT_ALL ( 4 )

typedef struct {

	int        mode;
	n_type_int oy, cores;

} n_paint_grabber_wholegrb_thread_struct;

void
n_paint_grabber_wholegrb_thread_main( n_paint_grabber_wholegrb_thread_struct *p )
{

	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_THREAD_FINISH )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{

			if ( n_paint_layer_is_locked( i ) )
			{
				//
			} else
			if ( n_paint_layer_data[ i ].visible )
			{
				n_paint_grabber_composition
				(
					&n_paint_layer_data[ i ].bmp_grab,
					&n_paint_layer_data[ i ].bmp_data,
					n_posix_true,
					n_false
				);
			}

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{

			// [!] : trick : make .bmp_grab always
			//
			//	usability for visibility on/off
			//	other logic simply ignores

			if ( n_paint_layer_is_locked( i ) )
			{
				//
			} else
			//if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp *bmp_f = &n_paint_layer_data[ i ].bmp_data;
				n_bmp *bmp_t = &n_paint_layer_data[ i ].bmp_grab;

				n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

				n_bmp_new_fast( bmp_t, sx,sy );
				n_bmp_fastcopy( bmp_f, bmp_t, x,y,sx,sy, 0,0 );
			}

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_THREAD_CLEAR )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{

			if ( n_paint_layer_is_locked( i ) )
			{
				//
			} else
			if ( n_paint_layer_data[ i ].visible )
			{
				if ( n_paint_tool_per_pixel_alpha_onoff )
				{
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, n_bmp_white_invisible );
				} else {
					n_bmp_flush( &n_paint_layer_data[ i ].bmp_grab, n_bmp_white           );
				}
			}

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT_ALL )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{
			n_type_gfx  x = 0;
			n_type_gfx  y = 0;
			n_type_gfx sx = N_BMP_SX( &n_paint_layer_data[ 0 ].bmp_data );
			n_type_gfx sy = N_BMP_SY( &n_paint_layer_data[ 0 ].bmp_data );

			if ( n_paint_layer_is_locked( i ) )
			{
				//
			} else
			if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp_new_fast( &n_paint_layer_data[ i ].bmp_grab, sx,sy );
				n_bmp_fastcopy( &n_paint_layer_data[ i ].bmp_data, &n_paint_layer_data[ i ].bmp_grab, x,y,sx,sy, 0,0 );
			} else {
				n_bmp_new( &n_paint_layer_data[ i ].bmp_grab, sx,sy );
			}

			n_paint_grabber_system_set( &x,&y,&sx,&sy, 0,0 );

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	}


	return;
}

n_thread_return
n_paint_grabber_wholegrb_thread( n_thread_argument p )
{

	n_paint_grabber_wholegrb_thread_main( (void*) p );

	return 0;
}

void
n_paint_grabber_wholegrb( int mode )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_grabber_wholegrb() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		n_type_int cores = n_thread_core_count;

		n_thread                               *h = (void*) n_memory_new( cores * sizeof( n_thread                               ) );
		n_paint_grabber_wholegrb_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_grabber_wholegrb_thread_struct ) );


		n_type_int i = 0;
		n_posix_loop
		{

			n_paint_grabber_wholegrb_thread_struct tmp = { mode, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_grabber_wholegrb_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_grabber_wholegrb_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_grabber_wholegrb_thread_struct tmp = { mode, 0,1 };
		n_paint_grabber_wholegrb_thread_main( &tmp );

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return;
}

#define N_PAINT_GRABBER_WHOLEGRAB_STRETCH_BACKUP   ( 1 )
#define N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESAMPLE ( 2 )
#define N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESET    ( 3 )
#define N_PAINT_GRABBER_WHOLEGRAB_STRETCH_FREE     ( 4 )

typedef struct {

	int          mode;
	n_bmp       *stretch_bmp;
	n_type_real  ratio_x, ratio_y;
	n_type_int   oy, cores;

} n_paint_grabber_wholegrb_stretch_thread_struct;

void
n_paint_grabber_wholegrb_stretch_thread_main( n_paint_grabber_wholegrb_stretch_thread_struct *p )
{

	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_STRETCH_BACKUP )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{
			n_bmp_carboncopy( &n_paint_layer_data[ i ].bmp_grab, &p->stretch_bmp[ i ] );

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESAMPLE )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{
			// [!] : see grabber_select()
			//if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp b; n_bmp_carboncopy( &p->stretch_bmp[ i ], &b );

				n_bmp_resampler( &b, p->ratio_x,p->ratio_y );

//n_paint_grabber_select( &b, n_true );

				n_bmp_free_fast( &n_paint_layer_data[ i ].bmp_grab );
				n_bmp_alias( &b, &n_paint_layer_data[ i ].bmp_grab );
			}

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESET )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{
			// [!] : see grabber_select()
			//if ( n_paint_layer_data[ i ].visible )
			{
				n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );
				n_bmp_carboncopy( &p->stretch_bmp[ i ], &n_paint_layer_data[ i ].bmp_grab );

				//sx = N_BMP_SX( &n_paint_layer_data[ i ].bmp_grab );
				//sy = N_BMP_SY( &n_paint_layer_data[ i ].bmp_grab );
			}

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else
	if ( p->mode == N_PAINT_GRABBER_WHOLEGRAB_STRETCH_FREE )
	{

		n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
		n_posix_loop
		{
			n_bmp_free( &p->stretch_bmp[ i ] );

			i += p->cores;
			if ( i >= n_paint_layer_count ) { break; }
		}

	}


	return;
}

n_thread_return
n_paint_grabber_wholegrb_stretch_thread( n_thread_argument p )
{

	n_paint_grabber_wholegrb_stretch_thread_main( (void*) p );

	return 0;
}

void
n_paint_grabber_wholegrb_stretch( int mode, n_bmp *stretch_bmp, n_type_real ratio_x, n_type_real ratio_y )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_grabber_wholegrb_stretch() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		n_type_int cores = n_thread_core_count;

		n_thread                                       *h = (void*) n_memory_new( cores * sizeof( n_thread                                       ) );
		n_paint_grabber_wholegrb_stretch_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_grabber_wholegrb_stretch_thread_struct ) );


		n_type_int i = 0;
		n_posix_loop
		{

			n_paint_grabber_wholegrb_stretch_thread_struct tmp = { mode, stretch_bmp, ratio_x,ratio_y, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_grabber_wholegrb_stretch_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_grabber_wholegrb_stretch_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_grabber_wholegrb_stretch_thread_struct tmp = { mode, stretch_bmp, ratio_x,ratio_y, 0,1 };
		n_paint_grabber_wholegrb_stretch_thread_main( &tmp );

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return;
}

// internal
void
n_paint_grabber_finish( void )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{
		n_type_int i = 0;
		n_posix_loop
		{
			n_paint_layer_is_mod[ i ] = n_true;

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

		n_paint_grabber_wholegrb( N_PAINT_GRABBER_WHOLEGRAB_THREAD_FINISH );
	} else
	if ( n_paint_layer_onoff )
	{
		n_type_int i = n_paint_grabber_selected_index;

		if ( n_paint_layer_data[ i ].visible )
		{
			n_paint_layer_is_mod[ i ] = n_true;

			n_paint_grabber_composition
			(
				&n_paint_layer_data[ i ].bmp_grab,
				&n_paint_layer_data[ i ].bmp_data,
				n_true,//n_paint_grabber_is_rotated,
				n_false
			);
		}
	} else {
		n_paint_grabber_composition( n_paint_bmp_grab, n_paint_bmp_data, n_true, n_false );
	}


	if ( n_paint_layer_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else {

		n_bmp_free( n_paint_bmp_grab );

	}

	n_paint_grabber_init();

	n_paint_grabber_status();


	n_paint_grabber_resync_auto();


	// [!] : for usability
	//n_paint_tool_grabber_trans_onoff( n_false );


	n_paint_tool_grabber_blend_zero();


	n_paint_layer_grabber_check_enable( n_true );
	n_paint_layer_grabber_location( -1 );


	n_paint_thumbnail_refresh();


	n_paint_grabber_is_rotated = n_false;


	return;
}

// internal
void
n_paint_grabber_select( n_bmp *b, n_bool redraw )
{

	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


	if ( n_paint_grabber_wholegrb_onoff )
	{
//n_posix_debug_literal( " 1 " );

		n_paint_grabber_wholegrb( N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT );

		if ( n_paint_fastmode )
		{
			n_bmp_new_fast( &n_paint_bmp_wgrb, sx,sy );
			n_paint_cache_zero( &n_paint_bmp_wgrb );
		}

	} else
	if ( n_paint_layer_onoff )
	{

		if ( b == NULL )
		{
//n_posix_debug_literal( " 2-0 " );

			n_bmp_new_fast( n_paint_bmp_grab, sx,sy );
			n_bmp_fastcopy( n_paint_bmp_data, n_paint_bmp_grab, x,y,sx,sy, 0,0 );

		} else {
//n_posix_debug_literal( " 2-1 " );

			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
			n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;

			n_bmp_free( n_paint_bmp_grab );
			n_bmp_carboncopy( b, n_paint_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );

		}

	} else {
//n_posix_debug_literal( " 3 " );

		if ( b == NULL )
		{

			n_bmp_new_fast( n_paint_bmp_grab, sx,sy );
			n_bmp_fastcopy( n_paint_bmp_data, n_paint_bmp_grab, x,y,sx,sy, 0,0 );

		} else {
//n_posix_debug_literal( " %d %d ", (int) n_paint_bmp_grab, (int) &n_paint_layer_data[ 0 ].bmp_grab );

			n_bmp_free( n_paint_bmp_grab );
			n_bmp_carboncopy( b, n_paint_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );
//n_posix_debug_literal( " %d %d ", sx, sy );
		}

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


	if ( redraw ) { n_paint_grabber_resync_auto(); }


	return;
}

// internal
void
n_paint_grabber_clear( void )
{

	if ( n_paint_grabber_wholegrb_onoff )
	{

		n_paint_grabber_wholegrb( N_PAINT_GRABBER_WHOLEGRAB_THREAD_CLEAR );

	} else
	if ( n_paint_layer_onoff )
	{

		if ( n_paint_tool_per_pixel_alpha_onoff )
		{
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
		} else {
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white           );
		}

	} else {

		if ( n_paint_tool_per_pixel_alpha_onoff )
		{
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
		} else {
//n_paint_grabber_select( NULL, n_false );
			n_bmp_flush( n_paint_bmp_grab, n_bmp_white           );
		}

	}

	n_paint_grabber_resync_auto();


	return;
}

void
n_paint_grabber_position_reset( void )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return; }


	n_type_gfx x,y, fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	x = fx;
	y = fy;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );

	n_paint_grabber_resync_auto();


	return;
}

// internal
void
n_paint_grabber_filter_sync_calc( const n_bmp *bmp, int filter_type )
{

	n_type_gfx psx = N_BMP_SX( bmp );
	n_type_gfx psy = N_BMP_SY( bmp );

	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	n_type_gfx px = x;
	n_type_gfx py = y;

	if ( filter_type == N_PAINT_FILTER_SCALE_LIL )
	{
		x = x / 2;
		y = y / 2;
	} else
	if ( filter_type == N_PAINT_FILTER_SCALE_BIG )
	{
		x = x * 2;
		y = y * 2;
	} else
	if ( filter_type == N_PAINT_FILTER_MIRROR    )
	{
		x = psx - ( x + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_L  )
	{
		x = py;
		y = psx - ( px + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_R  )
	{
		x = psy - ( py + sy );
		y = px;
	}

	fx = x;
	fy = y;

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

// internal
void
n_paint_grabber_filter_sync_calc_grabbed( int filter_type )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return; }


	// [!] : prevent cascading : zero only

	n_bmp *bmp_data = &n_paint_layer_data[ 0 ].bmp_data;

	n_paint_grabber_filter_sync_calc( bmp_data, filter_type );


	// [!] : find applied area

	n_type_int i = 0;
	n_posix_loop
	{

		n_bmp *bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

		if ( NULL != N_BMP_PTR( bmp_grab ) )
		{
			n_type_gfx sx = N_BMP_SX( bmp_grab );
			n_type_gfx sy = N_BMP_SY( bmp_grab );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );

			break;
		}

		i++;
		if ( i >= n_paint_layer_count ) { break; }
	}


	n_paint_grabber_status();


	return;
}

void
n_paint_grabber_filter_go( n_bmp *b, int mode )
{

	const int mirror = N_BMP_MIRROR_LEFTSIDE_RIGHT;


	if ( mode == N_PAINT_FILTER_SCALE_LIL ) { n_bmp_scaler_lil( b, 2 );              } else
	if ( mode == N_PAINT_FILTER_SCALE_BIG ) { n_bmp_scaler_big( b, 2 );              } else
	if ( mode == N_PAINT_FILTER_MIRROR    ) { n_bmp_flush_mirror( b, mirror );       } else
	if ( mode == N_PAINT_FILTER_ROTATE_L  ) { n_bmp_rotate( b, N_BMP_ROTATE_LEFT );  } else
	if ( mode == N_PAINT_FILTER_ROTATE_R  ) { n_bmp_rotate( b, N_BMP_ROTATE_RIGHT ); } else
	if ( mode == N_PAINT_FILTER_CLEAR     ) { n_bmp_flush( b, n_bmp_white );         } else
	if ( mode == N_PAINT_FILTER_ALPHA_CLR ) { n_bmp_alpha_visible( b );              } else
	if ( mode == N_PAINT_FILTER_ALPHA_REV ) { n_bmp_alpha_reverse( b );              }// else


	return;
}

// internal
n_bool
n_paint_grabber_filter_sync( int filter_type, n_bool calc, n_bool refresh )
{

	if ( N_PAINT_GRABBER_IS_NEUTRAL() ) { return n_false; }


	if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
	{
		n_paint_grabber_filter_go( n_paint_bmp_data, filter_type );
	}


	if ( calc ) { n_paint_grabber_filter_sync_calc( n_paint_bmp_data, filter_type ); }


	n_bmp b; n_bmp_carboncopy( n_paint_bmp_grab, &b );

	n_paint_grabber_filter_go( &b, filter_type );

//n_paint_grabber_select( &b, n_false );

	{
		n_bmp_free( n_paint_bmp_grab );
		n_bmp_alias( &b, n_paint_bmp_grab );

		if ( calc )
		{
			n_type_gfx sx = N_BMP_SX( &b );
			n_type_gfx sy = N_BMP_SY( &b );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
		}

		if ( refresh ) { n_paint_grabber_resync_auto(); }
	}


	if ( refresh ) { n_paint_refresh_all(); }


	n_paint_grabber_status();


	return n_true;
}

void
n_paint_grabber_dropname( void )
{
//return;

	n_posix_char *dir = n_explorer_cursor2path_new();

	if ( n_false == n_string_is_empty( dir ) )
	{

		n_posix_char *name;

		if ( n_paint_layer_onoff )
		{
			name = n_string_path_tmpname_new( N_PAINT_EXT_PNG );
		} else {
			name = n_string_path_name_new( n_paint_grbname );
		}

		n_string_path_free( n_paint_grbname );
		n_paint_grbname = n_string_path_make_new( dir, name );
//n_posix_debug_literal( "%s\n%s\n%s", dir, name, n_paint_grbname );

		n_string_path_free( name );

	}

	n_string_path_free( dir );


	return;
}

void
n_paint_grabber_newname( void )
{

	n_posix_char *dir = n_string_path_upperfolder_new( n_paint_bmpname );
	n_posix_char *tmp = n_string_path_tmpname_new( N_PAINT_EXT_NUL );

	n_string_path_free( n_paint_grbname );
	n_paint_grbname = n_string_path_make_new( dir, tmp );

	if ( n_paint_format_is_bmp( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_grbname );
	} else
	if ( n_paint_format_is_ico( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_ICO, n_paint_grbname );
	} else
	if ( n_paint_format_is_cur( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_CUR, n_paint_grbname );
	} else
	if ( n_paint_format_is_jpg( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_JPG, n_paint_grbname );
	} else
	if ( n_paint_format_is_png( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_grbname );
	} else
	if ( n_paint_format_is_lyr( n_paint_bmpname ) )
	{
		n_string_path_ext_mod( N_PAINT_EXT_LYR, n_paint_grbname );
	} else {
		n_string_path_ext_mod( N_PAINT_EXT_BMP, n_paint_grbname );
	}

	n_string_path_free( dir );
	n_string_path_free( tmp );

//n_posix_debug_literal( "n_paint_grabber_newname() : %s", n_paint_grbname );
	return;
}

#define N_PAINT_GRABBER_FILTER_LAYER_ALL  ( 0 )
#define N_PAINT_GRABBER_FILTER_LAYER_DATA ( 1 )
#define N_PAINT_GRABBER_FILTER_LAYER_GRAB ( 2 )

typedef struct {

	int        mode;
	int        filter_type;
	n_type_int oy, cores;

} n_paint_grabber_filter_layer_thread_struct;

void
n_paint_grabber_filter_layer_thread_main( n_paint_grabber_filter_layer_thread_struct *p )
{

	n_type_int i = p->oy; if ( i >= n_paint_layer_count ) { return; }
	n_posix_loop
	{
		// [!] : see grabber_select()

		if ( p->mode == N_PAINT_GRABBER_FILTER_LAYER_ALL  )
		{
			n_paint_grabber_filter_go( &n_paint_layer_data[ i ].bmp_data, p->filter_type );
			n_paint_grabber_filter_go( &n_paint_layer_data[ i ].bmp_grab, p->filter_type );
		} else
		if ( p->mode == N_PAINT_GRABBER_FILTER_LAYER_DATA )
		{
			n_paint_grabber_filter_go( &n_paint_layer_data[ i ].bmp_data, p->filter_type );
		} else
		if ( p->mode == N_PAINT_GRABBER_FILTER_LAYER_GRAB )
		{
			n_paint_grabber_filter_go( &n_paint_layer_data[ i ].bmp_grab, p->filter_type );
		}

		i += p->cores;
		if ( i >= n_paint_layer_count ) { break; }
	}


	return;
}

n_thread_return
n_paint_grabber_filter_layer_thread( n_thread_argument p )
{

	n_paint_grabber_filter_layer_thread_main( (void*) p );

	return 0;
}

void
n_paint_grabber_filter_layer( int mode, int filter_type )
{

	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_paint_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_paint_grabber_filter_layer() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		n_type_int cores = n_thread_core_count;

		n_thread                                   *h = (void*) n_memory_new( cores * sizeof( n_thread                                   ) );
		n_paint_grabber_filter_layer_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_paint_grabber_filter_layer_thread_struct ) );


		n_type_int i = 0;
		n_posix_loop
		{

			n_paint_grabber_filter_layer_thread_struct tmp = { mode, filter_type, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_paint_grabber_filter_layer_thread_struct ) );

			h[ i ] = n_thread_init( n_paint_grabber_filter_layer_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_paint_grabber_filter_layer_thread_struct tmp = { mode, filter_type, 0,1 };
		n_paint_grabber_filter_layer_thread_main( &tmp );

	}

//n_posix_debug_literal( " %d ", (int) n_posix_tickcount() - tick );


	return;
}

#define N_PAINT_GRABBER_LOAD_NEW       0
#define N_PAINT_GRABBER_LOAD_FILE      1
#define N_PAINT_GRABBER_LOAD_CLIPBOARD 2
#define N_PAINT_GRABBER_LOAD_FILL      3
#define N_PAINT_GRABBER_LOAD_FILTER    4

#define n_paint_grabber_new(          ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_NEW,       0 )
#define n_paint_grabber_newfile( name ) n_paint_grabber_load( name, N_PAINT_GRABBER_LOAD_FILE,      0 )
#define n_paint_grabber_clipboard(    ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_CLIPBOARD, 0 )
#define n_paint_grabber_fill(         ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_FILL,      0 )
#define n_paint_grabber_filter(  f    ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_FILTER,    f )

// internal
n_bool
n_paint_grabber_load( n_posix_char *name, int mode, int filter_type )
{

	n_bmp b; n_bmp_zero( &b );


	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{

		// [!] : currently unused

		n_bmp_new( &b, N_BMP_SX( n_paint_bmp_data ), N_BMP_SY( n_paint_bmp_data ) );

//n_bmp_flush( &b, n_bmp_rgb( 0, 200, 255 ) );

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{
			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{
				return n_false;
			} else {
				return n_true;
			}
		}


		if ( n_paint_layer_onoff )
		{
			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			if ( n_paint_layer_is_locked( y ) ) { return n_true; }
		}


		n_curico c; n_curico_zero( &c );

		if ( n_paint_load( name, &b, &c ) )
		{
			n_paint_dialog_info( n_project_string_error );

			return n_true;
		}


		if ( n_paint_layer_onoff )
		{
			n_type_int y = n_paint_layer_txtbox.select_cch_y;

			n_paint_bmp_data = &n_paint_layer_data[ y ].bmp_data;
			n_paint_bmp_grab = &n_paint_layer_data[ y ].bmp_grab;
		}


#ifdef N_PAINT_FRAME_ANIM

		n_paint_frame_anim_lock = n_posix_true;
		n_paint_frame_anim_on();

#endif // #ifdef N_PAINT_FRAME_ANIM

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{

		if ( tooltype != N_PAINT_TOOL_TYPE_GRAB )
		{

			if ( N_PAINT_GRABBER_IS_NEUTRAL() )
			{

				if ( n_clipboard_nbmp_get( &n_paint_layer_data[ 0 ].bmp_data ) ) { return n_true; }
//n_posix_debug_literal( "1" );


				ShowWindow( hwnd_layr, SW_HIDE );
				n_paint_layer_reset();


				n_paint_grabber_reset();


				n_string_path_free( n_paint_bmpname );

				n_paint_bmpname = n_paint_newname_new();
				n_string_path_ext_mod( N_PAINT_EXT_PNG, n_paint_bmpname );


				n_paint_refresh_all();

				n_paint_title();
				n_paint_tool_saveicon_refresh( n_true );


				return n_false;

			} else {
//n_posix_debug_literal( "2" );

				return n_true;

			}

		} else {

			if ( n_clipboard_nbmp_get( &b ) ) { return n_true; }

		}

//n_bmp_free( &b ); return n_true;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{

		if ( tooltype == N_PAINT_TOOL_TYPE_GRAB ) { return n_true; }

		n_bool ret = n_paint_layer_bmp_fill( &b );
		if ( ret ) { return ret; }

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		//n_bool is_scaler = ( ( filter_type == N_PAINT_FILTER_SCALE_LIL )||( filter_type == N_PAINT_FILTER_SCALE_BIG ) );

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
//n_posix_debug_literal( "1" );

			if ( n_paint_layer_onoff )
			{

				n_type_int i = 0;
				n_posix_loop
				{

					n_paint_layer_is_mod[ i ] = n_true;

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

				n_paint_grabber_filter_layer( N_PAINT_GRABBER_FILTER_LAYER_DATA, filter_type );

				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );

			} else {

				n_paint_grabber_filter_go( n_paint_bmp_data, filter_type );

			}

			n_paint_refresh_all();

			return n_false;
		}

		if ( filter_type == N_PAINT_FILTER_CLEAR )
		{

			n_paint_grabber_clear();

			return n_false;
		}

		if ( n_paint_layer_onoff )
		{
//n_win_debug_count( hwnd_layr );
//n_posix_debug_literal( "2" );

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				n_paint_grabber_filter_layer( N_PAINT_GRABBER_FILTER_LAYER_GRAB, filter_type );
			} else {
				n_paint_grabber_filter_layer( N_PAINT_GRABBER_FILTER_LAYER_ALL , filter_type );

				n_type_int i = 0;
				n_posix_loop
				{

					n_paint_layer_is_mod[ i ] = n_true;

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}
			}


			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				n_type_gfx sx = N_BMP_SX( n_paint_bmp_grab );
				n_type_gfx sy = N_BMP_SY( n_paint_bmp_grab );
				n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
			} else {
				n_paint_grabber_filter_sync_calc_grabbed( filter_type );
			}


			n_paint_cache_zero( &n_paint_bmp_scrl );
			n_paint_cache_zero( &n_paint_bmp_wgrb );

			n_paint_refresh_all();

			return n_false;

		} else {

			if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
			{
				n_bmp_carboncopy( n_paint_bmp_grab, &b );
				n_paint_grabber_filter_go( &b, filter_type );
			} else {
				return n_paint_grabber_filter_sync( filter_type, n_true, n_true );
			}

		}

	} else { return n_false; }


	grabber = N_PAINT_GRABBER_DRAG_OK;


	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{

		x = y = fx = fy = 0;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		if ( hwnd_main == n_win_cursor2hwnd() )
		{

			n_type_gfx bmpsx = N_BMP_SX( &b );
			n_type_gfx bmpsy = N_BMP_SY( &b );


			n_paint_canvaspos( &x, &y );

			x -= bmpsx / 2;
			y -= bmpsy / 2;

			if ( ( x + bmpsx ) >= nwin_main.csx ) { x = nwin_main.csx - bmpsx; }
			if ( ( y + bmpsy ) >= nwin_main.csy ) { y = nwin_main.csy - bmpsy; }

			if ( x < 0 ) { x = 0; }
			if ( y < 0 ) { y = 0; }

		} else {

			x = y = 0;

		}

		fx = x;
		fy = y;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{

		x = y = fx = fy = 0;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{

		//

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		//

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	n_paint_grabber_select( &b, n_true );


	// [Patch] : WM_PAINT doesn't come when dropped

	if ( mode == N_PAINT_GRABBER_LOAD_FILE ) { n_paint_refresh_client(); }


	n_bmp_free( &b );


	n_paint_grabber_status();


	if ( mode == N_PAINT_GRABBER_LOAD_NEW )
	{
		n_paint_grabber_newname();
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{
		n_string_path_free( n_paint_grbname );
		n_paint_grbname = n_string_path_carboncopy( name );
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_CLIPBOARD )
	{
		n_paint_grabber_newname();
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILL )
	{
		//
	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{
		//
	}
//n_posix_debug_literal( "%s\n%s", name, n_paint_grbname );


	if ( n_paint_layer_onoff )
	{
		n_paint_grabber_selected_index = n_paint_layer_txtbox.select_cch_y;
	}


	return n_true;
}

// internal
void
n_paint_grabber_pixel_get( n_bmp *grab, n_type_gfx tx, n_type_gfx ty, u32 picked, u32 *before, u32 *after, n_type_real blend )
{

	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		//n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_b );

		color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if ( n_bmp_ptr_is_accessible( grab, gx,gy ) )
		{
			//n_bmp_ptr_get_fast(             grab, gx,gy, &color_b );
			color_b = n_bmp_antialias_pixel(             grab, gx,gy, blend );
		} else {
			//n_bmp_ptr_get     ( n_paint_bmp_data, tx,ty, &color_b );
			color_b = n_bmp_antialias_pixel( n_paint_bmp_data, tx,ty, blend );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		//if ( n_false )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

// internal
void
n_paint_grabber_pixel_set( n_type_gfx tx, n_type_gfx ty, u32 before, u32 after )
{

	if ( before == after ) { return; }


	if ( N_PAINT_GRABBER_IS_NEUTRAL() )
	{

		n_bmp_ptr_set( n_paint_bmp_data, tx,ty, after );

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

/*
		int a = n_bmp_a( before );

		if ( a == N_BMP_ALPHA_CHANNEL_INVISIBLE )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &after );
		}
*/

		n_type_gfx grab_x = tx - x;
		n_type_gfx grab_y = ty - y;

		n_bmp_ptr_set( n_paint_bmp_grab, grab_x,grab_y, after );

		if ( n_paint_fastmode )
		{
			n_bmp_ptr_set( &n_paint_bmp_wgrb, grab_x,grab_y, 0 );
		}

	}


	return;
}

// internal
u32
n_paint_grabber_colorpicker( void )
{

	u32 color = n_bmp_white_invisible;


	n_type_gfx mx,my; n_paint_margin_get( &mx, &my );
	n_type_gfx sx = nwin_main.csx - ( mx * 2 );
	n_type_gfx sy = nwin_main.csy - ( my * 2 );

	if ( n_win_is_hovered_offset( hwnd_main, mx,my,sx,sy ) )
	{
//n_win_hwndprintf_literal( hwnd_main, " In " );

		if ( n_win_is_input( VK_CONTROL ) )
		{
			n_type_gfx x,y; n_win_cursor_position_relative( hwnd_main, &x, &y );
			n_bmp_ptr_get( &n_paint_bmp_dbuf, x, y, &color );
		} else {
			n_type_gfx x,y; n_paint_canvaspos( &x,&y );
			n_paint_grabber_pixel_get( n_paint_bmp_grab, x,y, 0, &color, NULL, 0.0 );
		}

	} else {
//n_win_hwndprintf_literal( hwnd_main, " Out " );

		color = n_paint_tool_color_transparent_get();

	}


	return color;
}

void
n_paint_grabber_cursor_automove( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	n_type_gfx cursor_x = ( x + sx );
	n_type_gfx cursor_y = ( y + sy );

	{
		n_type_gfx cur_x, cur_y;
		n_win_cursor_position_relative( hwnd_main, &cur_x, &cur_y ); 
		n_paint_canvaspos( &cur_x, &cur_y );

		if ( cur_x < ( x + ( sx / 2 ) ) ) { cursor_x = x; } 
		if ( cur_y < ( y + ( sy / 2 ) ) ) { cursor_y = y; } 
	}


	n_type_gfx z = n_paint_zoom_get( zoom );

	if ( n_paint_is_zoom_in( zoom ) )
	{
		cursor_x *= z;
		cursor_y *= z;
	} else
	if ( n_paint_is_zoom_out( zoom ) )
	{
		cursor_x /= z;
		cursor_y /= z;
	}


	n_type_gfx margin_sx,margin_sy; n_paint_margin_get( &margin_sx, &margin_sy );

	POINT p;
	p.x = margin_sx + cursor_x - nwin_main.scrollx;
	p.y = margin_sy + cursor_y - nwin_main.scrolly;
	ClientToScreen( hwnd_main, &p );
	SetCursorPos( p.x, p.y );



	return;
}

void
n_paint_grabber_select_all( void )
{

	if ( n_paint_layer_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			n_bmp_free( &n_paint_layer_data[ i ].bmp_grab );

			i++;
			if ( i >= n_paint_layer_count ) { break; }
		}

	} else {

		n_bmp_free( n_paint_bmp_grab );

	}

	n_paint_grabber_init();

	if ( n_paint_grabber_wholegrb_onoff )
	{
		n_paint_grabber_wholegrb( N_PAINT_GRABBER_WHOLEGRAB_THREAD_SELECT_ALL );
	} else {
		n_paint_grabber_select( n_paint_bmp_data, n_true );
	}


	n_paint_status();


	grabber = N_PAINT_GRABBER_DRAG_OK;
	n_paint_grabber_status();


	n_paint_layer_grabber_location( n_paint_layer_txtbox.select_cch_y );


	return;
}

void
n_paint_grabber_copy( void )
{

	n_type_gfx x,y,fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );
	n_paint_grabber_select( NULL, n_false );

	fx = x;
	fy = y;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );
	n_paint_grabber_status();

	n_paint_grabber_resync_auto();


	return;
}

void
n_paint_grabber_paste( void )
{

	// [Needed] : n_bmp_flush() for out-of-bound

	n_paint_grabber_composition( n_paint_bmp_grab, n_paint_bmp_data, n_true, n_false );
	n_bmp_flush( n_paint_bmp_grab, n_bmp_white_invisible );

	n_paint_grabber_select( NULL, n_false );

	n_paint_grabber_resync_auto();


	return;
}

n_bool
n_paint_grabber_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	// [Mechanism]
	//
	//	[ DRAGGING ]
	//
	//	drag_ox/_oy      : offset from top-left
	//	drag_fx/_fy      : for reverse selection like bottom-right to top-left
	//
	//
	//	[ STRETCH_* ]
	//
	//	stretch_bmp      : a temporary buffer
	//	stretch_sx/_sy   : original size
	//	stretch_ox/_oy   :  center position
	//	stretch_px/_py   : restore position
	//	stretch_ratio    : for STRETCH_PROPORTIONAL


	if ( n_paint_vscr.drag_onoff ) { return n_false; }
	if ( n_paint_hscr.drag_onoff ) { return n_false; }


	if ( n_paint_on_setcursor_condition() )
	{
		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
		}
	}


	if ( n_paint_resizer_backup_onoff )
	{
		return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
	}


	static n_type_gfx  drag_ox        = 0;
	static n_type_gfx  drag_oy        = 0;
	static n_type_gfx  drag_fx        = 0;
	static n_type_gfx  drag_fy        = 0;

	static n_bmp      *stretch_bmp    = NULL;
	static n_type_gfx  stretch_fx     = 0;
	static n_type_gfx  stretch_fy     = 0;
	static n_type_gfx  stretch_sx     = 0;
	static n_type_gfx  stretch_sy     = 0;
	static n_type_gfx  stretch_ox     = 0;
	static n_type_gfx  stretch_oy     = 0;
	static n_type_gfx  stretch_px     = 0;
	static n_type_gfx  stretch_py     = 0;
	static n_type_real stretch_ratio  = 0;

	static n_type_gfx  p_cursor_x     = 0;
	static n_type_gfx  p_cursor_y     = 0;

	static n_posix_bool is_resel      = n_posix_false;


	// [!] : grabber : OFF

	if ( tooltype != N_PAINT_TOOL_TYPE_GRAB ) { return n_false; }


	switch( msg ) {


	case WM_LBUTTONDBLCLK :

//n_win_hwndprintf_literal( hwnd, "%d", grabber );

		if ( n_paint_layer_onoff )
		{
			if ( n_paint_layer_is_locked( n_paint_layer_txtbox.select_cch_y ) )
			{
				break;
			}
		}

		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
//n_win_text_set_literal( hwnd, "Grabber : NEUTRAL : WM_LBUTTONDBLCLK" );


			// [ Mechanism ]
			//
			//	# : WM_*             : grabber   : size
			//	1 : WM_LBUTTONDOWN   : SELECTING : 0 0
			//	2 : WM_LBUTTONUP     : NEUTRAL   : 0 0
			//	3 : WM_LBUTTONDBLCLK : NEUTRAL   : 0 0


			n_paint_grabber_select_all();

		} else

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_LBUTTONDBLCLK" );

			n_paint_grabber_position_reset();

		}


	break;

	case WM_LBUTTONDOWN :

		if ( n_paint_layer_onoff )
		{
			if ( n_paint_layer_is_locked( n_paint_layer_txtbox.select_cch_y ) )
			{
				break;
			}
		}


		SetCapture( hwnd );


		n_win_cursor_position_relative( hwnd_main, &p_cursor_x, &p_cursor_y );


		if ( N_PAINT_GRABBER_IS_NEUTRAL() )
		{
//n_win_text_set_literal( hwnd, "Grabber : NEUTRAL : WM_LBUTTONDOWN" );


			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			{

				const n_type_gfx maxsx = N_BMP_SX( n_paint_bmp_data ) - 1;
				const n_type_gfx maxsy = N_BMP_SY( n_paint_bmp_data ) - 1;

				n_paint_canvaspos( &x, &y );

				if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
				if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

			}


			drag_fx = fx = x;
			drag_fy = fy = y;

			sx = sy = 0;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			n_paint_grabber_newname();


			if ( n_paint_layer_onoff )
			{
				n_paint_grabber_selected_index = n_paint_layer_txtbox.select_cch_y;
				n_paint_bmp_grab = &n_paint_layer_data[ n_paint_grabber_selected_index ].bmp_grab;
			}


#ifdef N_PAINT_FRAME_ANIM

			n_paint_frame_anim_lock = n_posix_false;
			n_paint_frame_anim_on();

#endif // #ifdef N_PAINT_FRAME_ANIM


			grabber = N_PAINT_GRABBER_SELECTING;

		} else

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_LBUTTONDOWN" );

#ifdef N_PAINT_FRAME_ANIM

			if ( n_paint_frame_anim_lock == n_posix_false )
			{
				if ( n_paint_frame_is_hovered( 0 ) ) { n_win_cursor_add( NULL, IDC_SIZENWSE ); break; }
				if ( n_paint_frame_is_hovered( 1 ) ) { n_win_cursor_add( NULL, IDC_SIZENESW ); break; }
				if ( n_paint_frame_is_hovered( 2 ) ) { n_win_cursor_add( NULL, IDC_SIZENWSE ); break; }
				if ( n_paint_frame_is_hovered( 3 ) ) { n_win_cursor_add( NULL, IDC_SIZENESW ); break; }
			}

#endif // #ifdef N_PAINT_FRAME_ANIM


			// Phase 1 : starting position and size

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );


			// Phase 2 : switching to DnD mode

			n_type_gfx canvas_x,canvas_y;
			n_paint_canvaspos( &canvas_x, &canvas_y );

			if (
				( canvas_x < x )||( canvas_x >= ( x + sx ) )
				||
				( canvas_y < y )||( canvas_y >= ( y + sy ) )
			)
			{
				break;
			}

//n_win_text_set_literal( hwnd, "Selected" );

			if ( n_false == n_win_is_input( VK_CONTROL ) )
			{

				grabber = N_PAINT_GRABBER_DRAGGING;

				drag_ox = canvas_x - x;
				drag_oy = canvas_y - y;

			} else {

				if ( n_win_is_input( VK_SHIFT ) )
				{
					grabber = N_PAINT_GRABBER_STRETCH_TRANSFORM;
				} else {
					grabber = N_PAINT_GRABBER_STRETCH_PROPORTIONAL;
					stretch_ratio = (n_type_real) sx / sy;
				}


				// [!] : Backup

				if ( n_paint_grabber_wholegrb_onoff )
				{
					stretch_bmp = n_memory_new( sizeof( n_bmp ) * n_paint_layer_count );
					n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_BACKUP, stretch_bmp, 0,0 );
				} else
				if ( n_paint_layer_onoff )
				{
					stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( n_paint_bmp_grab, stretch_bmp );
				} else {
					stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( n_paint_bmp_grab, stretch_bmp );
				}

				stretch_px = x;
				stretch_py = y;


				// [!] : Init

				stretch_sx = sx;
				stretch_sy = sy;
				stretch_ox =  x + ( stretch_sx / 2 );
				stretch_oy =  y + ( stretch_sy / 2 );

				n_paint_grabber_cursor_automove( x,y, sx,sy );

				n_paint_canvaspos( &stretch_fx, &stretch_fy );

				n_paint_grabber_status();

			}

		}

	break;

	case WM_MOUSEMOVE :


		// [!] : for VirtualPC

		{
			n_type_gfx cursor_x, cursor_y;
			n_win_cursor_position_relative( hwnd_main, &cursor_x, &cursor_y );

			if ( ( p_cursor_x == cursor_x )&&( p_cursor_y == cursor_y ) )
			{
				break;
			}
		}


		if ( N_PAINT_GRABBER_IS_RESELECT() )
		{
//n_win_debug_count( hwnd_main );

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			if ( n_paint_frame_is_hovered( 0 ) )
			{
				x = drag_fx = x + sx - 1;
				y = drag_fy = y + sy - 1;
			} else 
			if ( n_paint_frame_is_hovered( 1 ) )
			{
				x = drag_fx = x;
				y = drag_fy = y + sy - 1;
			} else 
			if ( n_paint_frame_is_hovered( 2 ) )
			{
				x = drag_fx = x;
				y = drag_fy = y;
			} else 
			if ( n_paint_frame_is_hovered( 3 ) )
			{
				x = drag_fx = x + sx - 1;
				y = drag_fy = y;
			}

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );

			grabber = N_PAINT_GRABBER_SELECTING;

			is_resel = n_posix_true;

		} else

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{

#ifdef N_PAINT_FRAME_ANIM

			if ( n_paint_frame_anim_lock == n_posix_false )
			{
				if ( n_paint_frame_is_hovered( 0 ) ) { n_win_cursor_add( NULL, IDC_SIZENWSE ); break; }
				if ( n_paint_frame_is_hovered( 1 ) ) { n_win_cursor_add( NULL, IDC_SIZENESW ); break; }
				if ( n_paint_frame_is_hovered( 2 ) ) { n_win_cursor_add( NULL, IDC_SIZENWSE ); break; }
				if ( n_paint_frame_is_hovered( 3 ) ) { n_win_cursor_add( NULL, IDC_SIZENESW ); break; }
			}

#endif // #ifdef N_PAINT_FRAME_ANIM

		} else

		if ( N_PAINT_GRABBER_IS_SELECTING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : WM_MOUSEMOVE : WM_MOUSEMOVE" );

			// Phase 1 : init

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			{

				const n_type_gfx maxsx = N_BMP_SX( n_paint_bmp_data ) - 1;
				const n_type_gfx maxsy = N_BMP_SY( n_paint_bmp_data ) - 1;

				n_paint_canvaspos( &x, &y );

				if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
				if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

			}


			// Phase 2 : size : +1 for including outer

			sx = abs( drag_fx - x ) + 1;
			sy = abs( drag_fy - y ) + 1;


			// Phase 3 : position : top-left

			fx = x = n_posix_min_n_type_gfx( drag_fx, x );
			fy = y = n_posix_min_n_type_gfx( drag_fy, y );


			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			// [!] : selection is delayed : see WM_LBUTTONUP below
			//
			//	n_paint_grabber_resync_auto() adds a frame automatically

			n_bmp_free( &n_paint_bmp_wgrb );

			if ( is_resel )
			{
				n_paint_grabber_select( NULL, n_true );
			} else {
				n_paint_grabber_resync_auto_fast();
			}


			n_paint_layer_grabber_check_enable( n_false );

		} else

		if ( N_PAINT_GRABBER_IS_DRAGGING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_MOUSEMOVE" );


			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			n_paint_canvaspos( &x, &y );

			x -= drag_ox;
			y -= drag_oy;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			n_paint_grabber_resync_auto();

		} else

		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{
//n_win_text_set_literal( hwnd, "Grabber : STRETCHING : WM_MOUSEMOVE" );


			// Phase 1 : init

			n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );


			// [!] : don't clip for usability

			n_paint_canvaspos( &x, &y );

			if ( ( stretch_fx == x )&&( stretch_fy == y ) ) { break; }

			stretch_fx = x;
			stretch_fy = y;


			// Phase 2 : size

			if ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )
			{
				sy = ( abs( stretch_oy - y ) * 2 );
				sx = (n_type_gfx) ( (n_type_real) sy * stretch_ratio );
			} else {
				sx = ( abs( stretch_ox - x ) * 2 );
				sy = ( abs( stretch_oy - y ) * 2 );
			}

			if ( sx == 0 ) { sx = 1; }
			if ( sy == 0 ) { sy = 1; }

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


			// Phase 3 : position

			x = stretch_ox - ( sx / 2 );
			y = stretch_oy - ( sy / 2 );


			n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


			{ // n_paint_grabber_transform()

			n_type_real ratio_x = (n_type_real) sx / stretch_sx;
			n_type_real ratio_y = (n_type_real) sy / stretch_sy;

			if ( ( ratio_x * stretch_sx ) == 0 ) { break; }
			if ( ( ratio_y * stretch_sy ) == 0 ) { break; }

			if ( n_paint_grabber_wholegrb_onoff )
			{

				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );

				n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESAMPLE, stretch_bmp, ratio_x,ratio_y );

				sx = 0;
				sy = 0;

				int i = 0;
				n_posix_loop
				{

					sx = n_posix_max_n_type_gfx( sx, N_BMP_SX( &n_paint_layer_data[ i ].bmp_grab ) );
					sy = n_posix_max_n_type_gfx( sy, N_BMP_SY( &n_paint_layer_data[ i ].bmp_grab ) );

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

				n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
				n_paint_grabber_resync_auto();

			} else
			if ( n_paint_layer_onoff )
			{

				n_bmp b; n_bmp_carboncopy( stretch_bmp, &b );

				n_bmp_resampler( &b, ratio_x,ratio_y );
				n_paint_grabber_select( &b, n_true );

				n_bmp_free( &b );

			} else {

				n_bmp b; n_bmp_carboncopy( stretch_bmp, &b );

				n_bmp_resampler( &b, ratio_x,ratio_y );
				n_paint_grabber_select( &b, n_true );

				n_bmp_free( &b );

			}

			} // n_paint_grabber_transform()

		}// else


		n_paint_status();
		n_paint_grabber_status();

	break;

	case WM_LBUTTONUP :

		ReleaseCapture();

		if ( N_PAINT_GRABBER_IS_SELECTING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : SELECTING : WM_LBUTTONUP" );


			is_resel = n_posix_false;


			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


			if ( ( sx <= 0 )&&( sy <= 0 ) )
			{

				grabber = N_PAINT_GRABBER_NEUTRAL;

				break;
			}


			// position : use the last position
			// size     : use the last size


			// [!] : delayed
			n_paint_grabber_select( NULL, n_true );


			grabber = N_PAINT_GRABBER_DRAG_OK;


			n_paint_layer_grabber_check_enable( n_false );
			n_paint_layer_grabber_location( n_paint_layer_txtbox.select_cch_y );

		} else

		if ( N_PAINT_GRABBER_IS_DRAGGING() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_LBUTTONUP" );

			grabber = N_PAINT_GRABBER_DRAG_OK;

			if ( n_win_is_hovered( hwnd_main ) )
			{
				break;
			}

			if ( n_win_is_hovered( hwnd_tool ) )
			{
				n_paint_grabber_position_reset();
				n_paint_grabber_status();

				break;
			}

			if ( n_win_is_hovered( hwnd_layr ) )
			{
				n_paint_grabber_position_reset();
				n_paint_grabber_status();

				break;
			}

			n_paint_grabber_dropname();

			n_paint_formatter_mode = N_PAINT_FORMATTER_MODE_DROP2SAVE;
			n_paint_formatter_name = n_paint_grbname;


			n_win_gui( hwnd_main, WINDOW, n_paint_formatter_wndproc, &n_paint_hpopup );


			n_paint_refresh_client();

		} else

		if ( ( N_PAINT_GRABBER_IS_STRETCH_PROPORTIONAL() )||( N_PAINT_GRABBER_IS_STRETCH_TRANSFORM() ) )
		{
//n_win_text_set_literal( hwnd, "Grabber : STRETCHING : WM_LBUTTONUP" );


			n_bool ret = n_paint_dialog_yesno( n_project_string_really_ok );
			if ( ret )
			{

				n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

				fx = x;
				fy = y;

				n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );

			} else {

				// [!] : reselect an area before stretching

				n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

				x = stretch_px;
				y = stretch_py;

				n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


				n_paint_cache_zero( &n_paint_bmp_scrl );
				n_paint_cache_zero( &n_paint_bmp_wgrb );


				if ( n_paint_grabber_wholegrb_onoff )
				{
					n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESET, stretch_bmp, 0,0 );

					sx = 0;
					sy = 0;

					int i = 0;
					n_posix_loop
					{

						sx = n_posix_max_n_type_gfx( sx, N_BMP_SX( &n_paint_layer_data[ i ].bmp_grab ) );
						sy = n_posix_max_n_type_gfx( sy, N_BMP_SY( &n_paint_layer_data[ i ].bmp_grab ) );

						i++;
						if ( i >= n_paint_layer_count ) { break; }
					}

					n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
					n_paint_grabber_resync_auto();
				} else
				if ( n_paint_layer_onoff )
				{
					n_paint_grabber_select( stretch_bmp, n_true );
				} else {
					n_paint_grabber_select( stretch_bmp, n_true );
				}

			}


			if ( n_paint_grabber_wholegrb_onoff )
			{
				n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_FREE, stretch_bmp, 0,0 );
			} else
			if ( n_paint_layer_onoff )
			{
				n_bmp_free( stretch_bmp );
			} else {
				n_bmp_free( stretch_bmp );
			}

			n_memory_free( stretch_bmp );


			grabber = N_PAINT_GRABBER_DRAG_OK;


			n_paint_refresh_client();

		}

	break;

	case WM_RBUTTONDOWN :

		if ( N_PAINT_GRABBER_IS_DRAG_OK() )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_RBUTTONDOWN" );

#ifdef N_PAINT_FRAME_ANIM

			n_paint_frame_anim_off();

			n_paint_grabber_finish();

			n_paint_refresh_client();

#else  // #ifdef N_PAINT_FRAME_ANIM

			n_paint_grabber_finish();

#endif // #ifdef N_PAINT_FRAME_ANIM

		}

	break;


	} // switch


#ifdef N_PAINT_FRAME_ANIM

	n_paint_frame_anim_proc( hwnd, msg, wparam, lparam );

#endif // #ifdef N_PAINT_FRAME_ANIM


	return n_false;
}

