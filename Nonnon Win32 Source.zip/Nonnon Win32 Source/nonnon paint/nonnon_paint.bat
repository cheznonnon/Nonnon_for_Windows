
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nonnon_paint
set  window=-mwindows

%compile%

