// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




//#include <windowsx.h> // GET_X_LPARAM()




void
n_paint_thumbnail_refresh( void )
{

	if ( thumbnail )
	{
		//n_win_message_send( hwnd_thmb, WM_PAINT, 0,0 );

		//n_win_refresh( hwnd_thmb, n_true );

		SendMessageTimeout( hwnd_thmb, WM_PAINT, 0,0, SMTO_ABORTIFHUNG, 12, NULL );
	}


	return;
}

void
n_paint_thumbnail_show( void )
{

	if ( thumbnail )
	{
		ShowWindowAsync( hwnd_thmb, SW_NORMAL );
	} else {
		ShowWindowAsync( hwnd_thmb, SW_HIDE   );
	}


	return;
}

void
n_paint_thumbnail_make( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	if ( NULL == N_BMP_PTR( &n_paint_bmp_thmb ) )
	{
		if ( nwin_thmb.posx == -1 )
		{
			n_type_gfx dsx,dsy; n_win_desktop_size( &dsx, &dsy );

			nwin_thmb.posy = dsy - sy - ( (n_type_gfx) ( (n_type_real) dsy * 0.01 ) );

			if ( n_win_is_lefthanded() )
			{
				nwin_thmb.posx = dsx - sx - ( (n_type_gfx) ( (n_type_real) dsx * 0.01 ) );
			} else {
				nwin_thmb.posx =            ( (n_type_gfx) ( (n_type_real) dsx * 0.01 ) );
			}
		}

		n_win_set( hwnd_thmb, &nwin_thmb, sx,sy, N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS );

		n_bmp_new( &n_paint_bmp_thmb, sx,sy );
	}


	n_bool trans_onoff = n_false;
	u32    trans_color = N_PAINT_CANVAS_COLOR;

	if ( n_paint_format == N_PAINT_FORMAT_CUR )
	{
		trans_onoff = n_true;
		trans_color = n_gdi_systemcolor( COLOR_DESKTOP );
	} else
	if ( n_paint_format == N_PAINT_FORMAT_ICO )
	{
		if ( n_win_darkmode_onoff == n_false )
		{
			trans_onoff = n_true;
			trans_color = n_gdi_systemcolor( COLOR_WINDOW );
		}
	}


	n_bmp_box( &n_paint_bmp_thmb, 0,0,sx,sy, trans_color );


	if ( trans_onoff )
	{
		n_paint_bmp_data->transparent_onoff = n_true;
	}


	{

		n_type_gfx bmpsx = N_BMP_SX( n_paint_bmp_data );
		n_type_gfx bmpsy = N_BMP_SY( n_paint_bmp_data );
//n_win_hwndprintf_literal( hwnd_main, "%d %d", sx, bmpsx );

		if ( sx > bmpsx ) { x += abs( sx - bmpsx ) / 2; }
		if ( sy > bmpsy ) { y += abs( sy - bmpsy ) / 2; }

	}


	if ( n_paint_layer_onoff == n_false )
	{

		n_bmp_transcopy
		(
			 n_paint_bmp_data,
			&n_paint_bmp_thmb,
			 x, y, sx,sy,
			 0, 0
		);

		if ( n_false == N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_type_gfx gx,gy,gsx,gsy; n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );

			n_bmp_transcopy
			(
				 n_paint_bmp_grab,
				&n_paint_bmp_thmb,
				 0,0, gsx,gsy,
				 gx - x, gy - y
			);

			n_draw_frame( &n_paint_bmp_thmb, gx - x, gy - y,gsx,gsy, n_bmp_black, n_bmp_white );
		}

	} else {

		n_bmp_layercopy_main
		(
			 n_paint_layer_data,
			&n_paint_bmp_thmb,
			 x, y, sx,sy,
			 0, 0,
			 N_PAINT_CANVAS_COLOR,
			 n_true
		);

		if ( n_false == N_PAINT_GRABBER_IS_NEUTRAL() )
		{
			n_type_gfx gx,gy,gsx,gsy; n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );

			n_draw_frame( &n_paint_bmp_thmb, gx - x, gy - y,gsx,gsy, n_bmp_black, n_bmp_white );
		}

	}


	if ( trans_onoff )
	{
		n_paint_bmp_data->transparent_onoff = n_false;
	}



	return;
}

void
n_paint_thumbnail_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_MOUSEMOVE :

		n_paint_thumbnail_refresh();

	break;


	} // switch


	return;
}

void
n_paint_thumbnail_drag_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bool onoff = n_false;

	static n_type_gfx offset_x = 0;
	static n_type_gfx offset_y = 0;


	switch( msg ) {


	case WM_LBUTTONDOWN :

		if ( onoff == n_false )
		{
			n_type_gfx cx,cy; n_win_cursor_position( &cx, &cy );
//n_win_hwndprintf_literal( hwnd_tool, "%d %d", cx, cy );

			RECT r; GetWindowRect( hwnd, &r );
//n_win_hwndprintf_literal( hwnd_tool, "%d %d", r.left, r.top );

			offset_x = cx - r.left;
			offset_y = cy - r.top;
//n_win_hwndprintf_literal( hwnd_tool, "%d %d", offset_x, offset_y );

			onoff = n_true;

			SetCapture( hwnd );
		}

	break;

	case WM_LBUTTONUP :

		if ( onoff )
		{
			onoff = n_false;

			offset_x = offset_y = 0;

			ReleaseCapture();

			n_paint_thumbnail_refresh();
		}

	break;

	case WM_MOUSEMOVE :

		// [x] : glitch : currently live preview is not available

		if ( onoff )
		{
			n_type_gfx cx,cy; n_win_cursor_position( &cx, &cy );

			cx = cx - offset_x;
			cy = cy - offset_y;

			SetWindowPos( hwnd_thmb, NULL, cx,cy,0,0, SWP_NOSIZE | SWP_NOACTIVATE );

			n_type_gfx sx = n_paint_thumbnail_size;
			n_type_gfx sy = n_paint_thumbnail_size;
			n_bmp_box( &n_paint_bmp_thmb, 0,0,sx,sy, N_PAINT_CANVAS_COLOR );
			n_gdi_bitmap_draw( hwnd, &n_paint_bmp_thmb, 0,0,sx,sy, 0,0 );

			//n_paint_thumbnail_refresh();
		} else {
			n_paint_thumbnail_refresh();
		}

	break;


	} // switch


	return;
}

LRESULT CALLBACK
n_paint_thmb_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		// Style

		n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

		//n_win_topmost( hwnd, n_true );


		// Display

		//ShowWindowAsync( hwnd_thmb, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		return n_true;

	break;

	case WM_PAINT :
	{

		PAINTSTRUCT ps; BeginPaint( hwnd, &ps );


		n_type_gfx sx = n_paint_thumbnail_size;
		n_type_gfx sy = n_paint_thumbnail_size;
//n_win_hwndprintf_literal( hwnd_main, "%d %d", sx, sy );

		n_type_gfx x,y; n_paint_canvaspos( &x, &y );
//n_win_hwndprintf_literal( hwnd_main, "%d %d", x, y );

		x -= sx / 2;
		y -= sy / 2;

		x = n_posix_max( 0, x );
		y = n_posix_max( 0, y );

		x = n_posix_min( N_BMP_SX( n_paint_bmp_data ) - sx, x );
		y = n_posix_min( N_BMP_SY( n_paint_bmp_data ) - sy, y );

		n_paint_thumbnail_make( x, y, sx, sy );

		n_gdi_bitmap_draw( hwnd, &n_paint_bmp_thmb, 0,0,sx,sy, 0,0 );


		EndPaint( hwnd, &ps );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_paint_thumbnail_drag_proc( hwnd, msg, wparam, lparam );


	n_paint_tool_input_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


