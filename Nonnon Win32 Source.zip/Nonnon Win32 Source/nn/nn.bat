
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nn
set  window=-mwindows

%compile%

