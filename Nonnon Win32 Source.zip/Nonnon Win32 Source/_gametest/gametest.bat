
@echo off

set compile=..\nonnon\project\compile.bat
set    name=gametest
set  window=-mwindows

%compile%

