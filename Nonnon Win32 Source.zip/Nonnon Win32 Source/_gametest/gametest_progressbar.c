// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_bmp  b;

	n_bool init;
	n_bool input;

	u32    fg,bg;
	int    percent;

} n_gametest_progressbar;




void
n_gametest_progressbar_init( n_gametest_progressbar *p )
{

	n_game_title_literal( "Progressbar Test" );


	if ( p->init == n_false )
	{

		p->init = n_true;

		p->fg = n_bmp_rgb( 0,150,200 );
		p->bg = n_bmp_rgb( 0,200,255 );

	}


	n_bmp_flush( &game.bmp, n_bmp_black );


	p->input = n_true;


	n_bmp_ui_progressbar_animation = N_BMP_UI_PROGRESSBAR_ANIMATION_ON_UP;
	//n_bmp_ui_progressbar_animation_interval = 0;
	//p->percent = 100;


	return;
}

void
n_gametest_progressbar_loop( n_gametest_progressbar *p )
{

	if ( n_game_refresh_is_resize() )
	{

		p->init = n_false;

		n_gametest_progressbar_init( p );

	}


	p->percent++;

	if ( p->percent > 100 )
	{
		p->percent = 0;

		p->bg = p->fg;
		p->fg = n_bmp_blend_pixel( n_game_randomcolor(), n_bmp_black, 0.5 );
	}


	static int    stripe       = 0;
	static n_bool stripe_onoff = n_false;
	if ( n_win_is_input( VK_SPACE ) )
	{
		if ( stripe_onoff )
		{
			stripe_onoff = n_false;
			stripe       = 10;
		} else {
			stripe_onoff = n_true;
			stripe       = 0;
		}
		n_posix_sleep( 100 );
	} 


	{

		n_type_gfx x,y,sx,sy;

		sx = game.sx / 2;
		sy = game.sy / 10;
		x  = 0;
		y  = game.sy - sy;

		n_bmp_box                ( &game.bmp, x,y,sx,sy, n_bmp_black );
		n_bmp_ui_progressbar_horz( &game.bmp, x,y,sx,sy, p->fg,p->bg, p->percent, stripe );


		sx = game.sx / 10;
		sy = game.sy / 2;
		x  = game.sx - sx;
		y  = 0;

		n_bmp_box                ( &game.bmp, x,y,sx,sy, n_bmp_black );
		n_bmp_ui_progressbar_vert( &game.bmp, x,y,sx,sy, p->fg,p->bg, p->percent, stripe );

	}


	n_game_refresh_on();

	return;
}

void
n_gametest_progressbar_exit( n_gametest_progressbar *p )
{
	return;
}

