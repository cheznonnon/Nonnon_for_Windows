
@echo off

set compile=..\nonnon\project\compile.bat
set    name=tutorial
set  window=-mwindows

%compile%

