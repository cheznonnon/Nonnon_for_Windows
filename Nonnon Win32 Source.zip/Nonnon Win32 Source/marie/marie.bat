
@echo off

set compile=..\nonnon\project\compile.bat
set    name=marie
set  window=-mwindows

%compile%

