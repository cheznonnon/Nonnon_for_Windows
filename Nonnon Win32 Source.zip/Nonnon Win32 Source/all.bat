
:WIN9xCHECKER

@echo off

if %OS% == Windows_NT goto INIT:

echo Windows9x are not supported

pause

goto END


:INIT

@echo off

set batchdrop=nonnonapps.exe


if exist %batchdrop% goto MAIN

echo Please copy %batchdrop% in this folder.

pause

goto END


:MAIN

@echo on

cd arcdrop
..\%batchdrop% arcdrop.bat
cd ..

cd gameconsole
..\%batchdrop% gameconsole.bat
cd ..

cd nonnonapps
..\%batchdrop% nonnonapps.bat
cd ..


:END
