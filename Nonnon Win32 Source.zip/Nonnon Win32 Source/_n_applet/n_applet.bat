
@echo off

set compile=..\nonnon\project\compile.bat
set    name=n_applet
set  window=-mwindows

%compile%

