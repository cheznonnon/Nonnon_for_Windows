// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_ie_mousegesture( int sensitivity )
{

	// [!] : IE4 or later only
	//
	//	IE may use GetAsyncKeyState()

	// [x] : IE3 : beep
	//
	//	"HTML_Internet Explorer"
	//	<= : VK_BACK
	//	=> : VK_SHIFT + VK_BACK


	if ( n_false == n_win_class_is_same_literal( n_win_cursor2hwnd(), "Internet Explorer_Server" ) )
	{
		return;
	}


	// BUTTONDOWN

	static n_bool onoff = n_false;
	static POINT  ppos;
	       POINT   pos;

	if ( n_win_is_input( VK_RBUTTON ) )
	{

		if ( onoff == n_false )
		{
			onoff = n_true;
			GetCursorPos( &ppos );
		}

		return;
	}


	// BOTTONUP

	if ( onoff == n_false ) { return; }


	onoff = n_false;


	GetCursorPos( &pos );

	if ( sensitivity > abs( pos.x - ppos.x ) ) { return; }


	const int vk[] = { VK_MENU, VK_LEFT, VK_MENU,  VK_RIGHT };

	if ( ppos.x > pos.x )
	{
		n_win_input( vk[ 0 ], vk[ 1 ] );
	} else
	if ( ppos.x < pos.x )
	{
		n_win_input( vk[ 2 ], vk[ 3 ] );
	}


	return;
}

