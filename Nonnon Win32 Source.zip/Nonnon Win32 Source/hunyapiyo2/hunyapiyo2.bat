
@echo off

set compile=..\nonnon\project\compile.bat
set    name=hunyapiyo2
set  window=-mwindows

%compile%

