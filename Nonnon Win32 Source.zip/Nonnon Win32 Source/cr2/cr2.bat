
@echo off

set compile=..\nonnon\project\compile.bat
set    name=cr2
set  window=-mwindows

%compile%

