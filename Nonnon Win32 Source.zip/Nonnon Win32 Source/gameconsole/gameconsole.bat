
@echo off

set compile=..\nonnon\project\compile.bat
set    name=gameconsole
set  window=-mwindows

%compile%

