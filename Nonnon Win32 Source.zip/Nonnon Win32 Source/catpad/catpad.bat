
@echo off

set compile=..\nonnon\project\compile.bat
set    name=catpad
set  window=-mwindows

%compile%

