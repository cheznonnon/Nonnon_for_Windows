// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/time.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/ole/IDropTarget.c"
#include "../nonnon/win32/explorer.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_combobox.c"
#include "../nonnon/win32/win_menu.c"
#include "../nonnon/win32/win_smallbutton_direct.c"
#include "../nonnon/win32/win_statusbar_ownerdraw.c"
#include "../nonnon/win32/win_titlemenu.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/small_close.c"
#include "../nonnon/project/small_find.c"
#include "../nonnon/project/macro.c"


#include "_font.c"
#include "_privacy_protection.c"




// [!] : Shared

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_CATPAD ( 0 )

#endif // #ifndef NONNON_APPS


#define N_CATPAD_APPNAME                          "CatPad"
#define N_CATPAD_APPNAME_LITERAL n_posix_literal( "CatPad" )


#define N_CATPAD_MSG_BINARY      n_posix_literal( "BINARY" )
#define N_CATPAD_MSG_UNICODE_NIL n_posix_literal( "Non-Unicode" )
#define N_CATPAD_MSG_UNICODE_LIL n_posix_literal( "Unicode Little Endian" )
#define N_CATPAD_MSG_UNICODE_BIG n_posix_literal( "Unicode Big Endian" )
#define N_CATPAD_MSG_UNICODE_UTF n_posix_literal( "Unicode UTF-8" )
#define N_CATPAD_MSG_CR          n_posix_literal( "CR" )
#define N_CATPAD_MSG_LF          n_posix_literal( "LF" )
#define N_CATPAD_MSG_CRLF        n_posix_literal( "CRLF" )
#define N_CATPAD_MSG_READONLY    n_posix_literal( "Read Only" )
#define N_CATPAD_MSG_FIND        n_project_string_go


#define N_CATPAD_CALC            n_posix_literal( "calc.exe" )




// [!] : Components

#define N_CATPAD_INI_CCH  ( 1024 )
#define N_CATPAD_SYNC_CCH ( 1024 ) 


extern void n_catpad_status_refresh( void );
extern void n_catpad_overwrite_onoff( n_bool );
extern void n_catpad_font_init( void );
extern void n_catpad_search( HWND );
extern void n_catpad_focus ( HWND );
extern void n_catpad_ini_write( void );
extern void n_catpad_sync_send( HWND, const n_posix_char* );


static n_win_txtbox  n_catpad_txtbox_editor;
static n_bool        n_catpad_txtbox_onoff;
static n_bool        n_catpad_txtbox_onoff_default;
static n_win_txtbox  n_catpad_txtbox_search;
static n_win         n_catpad_nwin;
static n_win         n_catpad_nwin_ini;
static HFONT         n_catpad_hfont;
static HWND          n_catpad_hfind;
static HWND          n_catpad_heditor;
static HWND          n_catpad_hpopup;
static n_posix_char *n_catpad_fname_last =  NULL;

static n_posix_char  n_catpad_find[ N_CATPAD_SYNC_CCH ];
static n_posix_char  n_catpad_tab [ N_CATPAD_INI_CCH  ];
static n_posix_char  n_catpad_eol [ N_CATPAD_INI_CCH  ];




#include "./catpad_flashwindow.c"

#include "./catpad_config.c"
#include "./catpad_filter.c"
#include "./catpad_fontchooser.c"
#include "./catpad_history.c"
#include "./catpad_ini.c"
#include "./catpad_keyfocus.c"
#include "./catpad_printer.c"
#include "./catpad_search.c"
#include "./catpad_sync.c"




// CatPad

#define H_TOOLBAND       n_catpad_hgui[ 0 ]
#define H_BTN_FIND       n_catpad_hgui[ 1 ]
#define H_BTN_RESET      n_catpad_hgui[ 2 ]
#define GUI_MAX                         3

#define H_BTN_TOPMOST    n_catpad_hbtn[ 0 ]
#define H_BTN_OVERWRITE  n_catpad_hbtn[ 1 ]
#define H_BTN_CONFIG     n_catpad_hbtn[ 2 ]
#define H_BTN_FONT       n_catpad_hbtn[ 3 ]
#define H_BTN_CALC       n_catpad_hbtn[ 4 ]
#define H_BTN_NDUMP      n_catpad_hbtn[ 5 ]
#define BTN_MAX                         6

#define H_EDITOR         n_catpad_heditor
#define H_TXTBOX         n_catpad_txtbox_editor.hwnd
#define H_SEARCH         n_catpad_txtbox_search.hwnd


#define N_CATPAD_ICON_OFFSET_NDUMP    ( 7 )
#define N_CATPAD_ICON_OFFSET_TOPMOST  ( 2 )


#define N_CATPAD_SMALLBUTTON_ID_FIND  ( 1 )
#define N_CATPAD_SMALLBUTTON_ID_RESET ( 2 )


static HWND              n_catpad_hgui[ GUI_MAX ];
static n_bool            n_catpad_ndump_onoff      = n_false;
static n_bool            n_catpad_input_gray_onoff = n_true;

static n_win_button      n_catpad_hbtn[ BTN_MAX ];


static n_win_smallbutton_direct n_catpad_findicon;
static n_win_smallbutton_direct n_catpad_reseticon;


static n_win_statusbar_ownerdraw n_catpad_statusbar;


static n_bool            n_catpad_search_monospace = n_false;
static n_bool            n_catpad_txtbox_monospace = n_true;


static n_bool            n_catpad_dwm_transbg_onoff = n_false;


static n_win_titlemenu   n_catpad_titlemenu;
static n_win_simplemenu  n_catpad_simplemenu;


static UINT              n_catpad_fade_timer = 0;


static n_bool            n_catpad_trans_client_onoff = n_false;




// internal
void
n_catpad_day_of_week( n_posix_char *str, n_type_int cch )
{

	// [Needed] : an explicit name like "ja-JP" will not work

	setlocale( LC_ALL, "" );


	time_t     rawtime; time( &rawtime );
	struct tm *timeinfo = localtime( &rawtime );

	n_posix_strftime_literal( str, cch, "%A", timeinfo );

//n_posix_debug_literal( "%s", str );

	return;

}

// internal
void
n_catpad_overwrite_onoff( n_bool onoff )
{

	if ( H_BTN_OVERWRITE.active_onoff != onoff )
	{
		n_win_button_grayed_onoff( &H_BTN_OVERWRITE, ( onoff == n_false ) );
		n_win_button_grayed_onoff( &H_BTN_NDUMP    , ( onoff != n_false ) );
	}


	return;
}

// internal
void
n_catpad_editor_refresh( void )
{

	// [!] : n_true only available

	n_win_refresh( H_EDITOR, n_true );
	n_win_refresh( H_TXTBOX, n_true );

	return;
}

// internal
void
n_catpad_focus( HWND hwnd )
{

	HWND h = GetFocus();


	if ( n_catpad_txtbox_onoff )
	{
		if ( h != H_TXTBOX ) { SetFocus( H_TXTBOX ); }
	} else {
		if ( h != H_EDITOR ) { SetFocus( H_EDITOR ); }
	}


	return;
}

// internal
void
n_catpad_font_init( void )
{

	// [Needed] : set every time

	n_win_edit_margin_set( H_EDITOR, 4,0 );


	if ( n_catpad_txtbox_monospace )
	{
		n_win_font_exit( n_win_font_get( H_EDITOR ) );
		n_win_font_exit( n_win_font_get( H_TXTBOX ) );

		n_win_font_set( H_EDITOR, n_catpad_hfont, n_true );
		n_win_font_set( H_TXTBOX, n_catpad_hfont, n_true );
	}

	if ( n_catpad_search_monospace )
	{
		n_win_font_set( H_SEARCH, n_catpad_hfont, n_true );
	}


	n_win_txtbox_glyph_cache_reset   ( &n_catpad_txtbox_editor );
	n_win_txtbox_metrics_maxwidth_all( &n_catpad_txtbox_editor );


	n_catpad_editor_refresh();


	return;
}

// internal
void
n_catpad_title( HWND hwnd, n_posix_char *name )
{

	n_posix_char *s = n_string_carboncopy( name );
	n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );


	// [!] : default

	n_posix_char *title = n_string_path_cat( s, n_posix_literal( " - " ), N_CATPAD_APPNAME_LITERAL, NULL );


	// [!] : set readonly if the same titled window is running

	HWND h = NULL;
	n_posix_loop
	{
		h = FindWindowEx( NULL, h, NULL, title );
		if ( h == NULL ) { break; }
		if ( h != hwnd ) { break; }
	}

	if ( h != NULL )
	{
		n_catpad_txtbox_editor.txt.readonly = N_TXT_READONLY_ON;
		n_string_path_free( title );
		title = n_string_path_cat( s, n_posix_literal( " (Read Only)- " ), N_CATPAD_APPNAME_LITERAL, NULL );
	}


	n_win_text_set( hwnd, title );
	n_string_path_free( title );


	n_string_free( s );


	return;
}

// internal
void
n_catpad_editor_ntxt_set( void )
{

	// [MSDN] : multiline edit control's limit
	//
	//	WinNT : 0x7FFFFFFE :  2 GB (auto-expansion)
	//	Win9x : 0x0000FFFF : 64 KB (default 32 KB)

	// [!] : Win9x : reality
	//
	//	Text   : cannot display 40KB to 50KB or higher
	//	Binary : cannot display 25KB to 35KB or higher


	const int limitsize = 1024 * 32;


	if ( n_sysinfo_version_9x() )
	{
		if ( n_catpad_txtbox_editor.txt.byte >= limitsize ) { n_catpad_txtbox_onoff = n_true; }
		if ( n_catpad_txtbox_editor.txt.readonly          ) { n_catpad_txtbox_onoff = n_true; }
	}


	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY )
	{
		n_catpad_ntxt_binary2text( &n_catpad_txtbox_editor.txt );
	} else {
		n_win_txtbox_vector_stream( &n_catpad_txtbox_editor, N_STRING_CRLF, n_true );
	}


	if ( n_catpad_txtbox_onoff )
	{

		// [Patched] : edit control compatible behavior

		//n_win_txtbox_line_add( &n_catpad_txtbox_editor, n_catpad_txtbox_editor.txt.sy, N_STRING_EMPTY );


		n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor      );
		n_win_txtbox_scroll      ( &n_catpad_txtbox_editor, 0,0 );

	} else {

		// [!] : Win9x : previous one remains

		n_win_text_set_literal( H_EDITOR, "" );
		n_win_message_send( H_EDITOR, EM_SETLIMITTEXT, 0, limitsize );

		n_win_text_set( H_EDITOR, n_catpad_txtbox_editor.txt.stream );


		if ( n_catpad_txtbox_editor.txt.readonly == n_false )
		{
			n_win_message_send( H_EDITOR, EM_SETREADONLY, n_false, 0 );
		} else {
			n_win_message_send( H_EDITOR, EM_SETREADONLY, n_true , 0 );
		}

	}


	return;
}

// internal
void
n_catpad_linenumber_refresh( n_bool redraw )
{

	static n_type_int line_cur = -1;
	static n_type_int line_prv = -1;
	static n_type_int line_max = -1;


	if ( redraw ) { line_prv = -1; }


	if ( n_catpad_txtbox_onoff )
	{
		line_cur = n_win_txtbox_line_cur( &n_catpad_txtbox_editor ) + 1;
		line_max = n_win_txtbox_line_max( &n_catpad_txtbox_editor );
	} else {
		line_cur = n_win_edit_line_cur( H_EDITOR ) + 1;
		line_max = n_win_edit_line_max( H_EDITOR );
	}

	if ( line_prv != line_cur )
	{
		line_prv = line_cur;

		n_posix_char str_line_cur[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line_cur, line_cur );
		n_posix_char str_line_max[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line_max, line_max );

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "  Line : %s/%s", str_line_cur, str_line_max );

		n_win_statusbar_od_text( &n_catpad_statusbar, str, 0 );
	}


	return;
}

// internal
void
n_catpad_status_refresh( void )
{

	n_catpad_linenumber_refresh( n_true );


	n_posix_char str[ 100 ];

	n_type_int size = 0;
	if ( n_posix_stat_is_exist( n_catpad_fname_last ) ) { size = n_posix_stat_size( n_catpad_fname_last ); }

	n_posix_char str_size[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_size, size );
	n_posix_sprintf_literal( str, "  %s Byte ", str_size );

	n_win_statusbar_od_text( &n_catpad_statusbar, str, 1 );


	n_posix_char *str_ch = N_STRING_EMPTY;
	n_posix_char *str_nl = N_STRING_EMPTY;

	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_NIL    ) { str_ch = N_CATPAD_MSG_UNICODE_NIL; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_LIL    ) { str_ch = N_CATPAD_MSG_UNICODE_LIL; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_BIG    ) { str_ch = N_CATPAD_MSG_UNICODE_BIG; } else
	if ( n_catpad_txtbox_editor.txt.unicode == N_TXT_UNICODE_UTF    ) { str_ch = N_CATPAD_MSG_UNICODE_UTF; }

	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY ) { str_nl = N_CATPAD_MSG_BINARY;      } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_CR     ) { str_nl = N_CATPAD_MSG_CR;          } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_LF     ) { str_nl = N_CATPAD_MSG_LF;          } else
	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_CRLF   ) { str_nl = N_CATPAD_MSG_CRLF;        }

	if ( n_catpad_txtbox_editor.txt.newline == N_TXT_NEWLINE_BINARY )
	{
		n_posix_sprintf_literal( str, "  %s ", str_nl );
	} else {
		n_posix_sprintf_literal( str, "  %s : %s ", str_ch, str_nl );
	}

	n_win_statusbar_od_text( &n_catpad_statusbar, str, 2 );


	return;
}

// internal
void
n_catpad_resize_window( HWND hwnd, n_bool is_first )
{

	if ( is_first )
	{

		// [!] : n_catpad_ini_read() needs to be already done

		int nwset = N_WIN_SET_INNERPOS;

		if ( ( n_catpad_nwin.posx == -1 )||( n_catpad_nwin.posy == -1 ) )
		{
			nwset |= N_WIN_SET_CENTERING;
		} else {
			nwset |= N_WIN_SET_NEEDPOS;
		}

		if ( ( n_catpad_nwin.rcsx == -1 )||( n_catpad_nwin.rcsy == -1 ) )
		{
			n_catpad_nwin.rcsy = GetSystemMetrics( SM_CYMAXIMIZED ) / 2;
			n_catpad_nwin.rcsx = n_catpad_nwin.rcsy * 2;
		}

//n_posix_debug_literal( "%d", n_catpad_nwin.state );
		n_win_set( hwnd, &n_catpad_nwin, n_catpad_nwin.rcsx,n_catpad_nwin.rcsy, nwset );

	} else {

		n_win_set( hwnd, &n_catpad_nwin, -1,-1, n_project_n_win_set() );

	}

}

// internal
void
n_catpad_resize( HWND hwnd )
{

	const n_bool redraw = n_true;


	n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );

	n_type_gfx gap = H_BTN_TOPMOST.maclike_offset / 2;


	n_type_gfx csx = n_catpad_nwin.csx;
	n_type_gfx csy = n_catpad_nwin.csy;

	n_win_move_simple( H_TOOLBAND, 0,0, csx,ico+gap, redraw );

	{
		n_type_gfx ox = 0 * ico;


		n_win_button_move_toolband( &H_BTN_TOPMOST  , ox,0, ico,ico, redraw ); ox += ico + gap;
		n_win_button_move_toolband( &H_BTN_OVERWRITE, ox,0, ico,ico, redraw ); ox += ico + gap;
		n_win_button_move_toolband( &H_BTN_CONFIG   , ox,0, ico,ico, redraw ); ox += ico + gap;
		n_win_button_move_toolband( &H_BTN_FONT     , ox,0, ico,ico, redraw ); ox += ico + gap;
		n_win_button_move_toolband( &H_BTN_CALC     , ox,0, ico,ico, redraw ); ox += ico + gap;
		n_win_button_move_toolband( &H_BTN_NDUMP    , ox,0, ico,ico, redraw ); ox += ico + gap;

		n_catpad_txtbox_search.input_resizer_icon_sx = ox;
	}


	{

		if ( n_catpad_txtbox_search.input_resizer_max == 0 )
		{
			n_catpad_txtbox_search.input_resizer_max = ( ctl * 12 );
		}


		n_type_gfx sx = n_posix_min_n_type_gfx( n_catpad_txtbox_search.input_resizer_max, csx - n_catpad_txtbox_search.input_resizer_icon_sx - ( m * 2 ) );
		n_type_gfx sy = ( ctl *  1 );
		n_type_gfx x  = ( csx - m ) - sx;
		n_type_gfx y  = ( ico - ctl ) / 2;

		n_win_txtbox_move( &n_catpad_txtbox_search, x,y, sx,sy, redraw );

		n_win_txtbox_smallbutton_direct_embed( &n_catpad_txtbox_search, &n_catpad_findicon,  0 );
		n_win_txtbox_smallbutton_direct_embed( &n_catpad_txtbox_search, &n_catpad_reseticon, 1 );

		n_win_smallbutton_direct_bitmap_init( &n_catpad_findicon  );
		n_win_smallbutton_direct_bitmap_init( &n_catpad_reseticon );

	}


	{

		n_type_gfx toolsy, statsy, editsy;


		toolsy = ico + gap;
		statsy = ctl;
		editsy = csy - ( toolsy + statsy );

		n_win_move_simple       (  H_EDITOR              , 0,toolsy, csx,editsy, redraw );
		n_win_txtbox_move_simple( &n_catpad_txtbox_editor, 0,toolsy, csx,editsy, redraw );


		// [Needed] : Win9x : scroll metrics is not reset
		// [x] : scroll position will reset when theme is changed

		//n_win_txtbox_scroll_refresh( &n_catpad_txtbox_editor );

	}

	n_win_statusbar_od_automove( &n_catpad_statusbar );


	return;
}

// internal
void
n_catpad_ui_refresh( HWND hwnd )
{

	// [Needed] : EnableWindow() before uncheck

	n_catpad_overwrite_onoff( n_false );

	n_win_button_grayed_onoff( &H_BTN_CONFIG, ( n_catpad_txtbox_editor.txt.readonly != N_TXT_READONLY_OFF ) );


	if ( n_catpad_txtbox_onoff == n_false )
	{
		ShowWindow( H_TXTBOX, SW_HIDE   );
		ShowWindow( H_EDITOR, SW_NORMAL );
	} else {
		ShowWindow( H_EDITOR, SW_HIDE   );
		ShowWindow( H_TXTBOX, SW_NORMAL );
	}


	n_catpad_nwin.scrollx = n_catpad_nwin.scrolly = 0;


	n_win_txtbox_refresh( &n_catpad_txtbox_editor, N_WIN_TXTBOX_CATPAD_UI_REFRESH );

	// [Needed] : Win9x : scroll metrics is not reset
	n_win_txtbox_scroll_refresh( &n_catpad_txtbox_editor );


	n_catpad_focus( hwnd );
	n_catpad_status_refresh();
	n_catpad_linenumber_refresh( n_true );


	return;
}

n_bool
n_catpad_txt_load( n_win_txtbox *p, const n_posix_char *cmdline )
{

	n_bool ret = n_true;


	if ( n_catpad_txtbox_onoff )
	{
		n_win_txtbox_txt_load_force_utf8 = n_win_is_input( VK_CONTROL );
		ret = n_win_txtbox_txt_load(  p     , cmdline );
		n_win_txtbox_txt_load_force_utf8 = n_posix_false;
	} else {
//n_posix_debug_literal("" );
		ret = n_txt_load           ( &p->txt, cmdline );
	}


	if ( p->txt.unicode == N_TXT_UNICODE_NIL )
	{
		if (
			( n_string_path_ext_is_same_literal( ".txt" , cmdline ) )
			||
			( n_string_path_ext_is_same_literal( ".html", cmdline ) )
		)
		{
			if ( p->txt.byte == 0 ) { p->txt.unicode = N_TXT_UNICODE_UTF; }
		}
	}


	return ret;
}

// internal
void
n_catpad_newfile( HWND hwnd, n_posix_char *fname )
{

	if ( n_catpad_txtbox_onoff ) { n_win_txtbox_reset( &n_catpad_txtbox_editor ); }

	if ( n_catpad_txt_load( &n_catpad_txtbox_editor, fname ) ) 
	{

		n_posix_char *dir = n_string_path_folder_current_new();
		n_posix_char *pth = n_string_path_make_new( dir, n_posix_literal( "new.txt" ) );

		if ( n_catpad_txt_load( &n_catpad_txtbox_editor, pth ) )
		{
			n_txt_new( &n_catpad_txtbox_editor.txt );
		}

		n_catpad_title( hwnd, pth );

		n_string_path_free( n_catpad_fname_last );
		n_catpad_fname_last = n_string_path_carboncopy( pth );

		n_string_path_free( dir );
		n_string_path_free( pth );

	} else {

		if ( n_catpad_fname_last != fname )
		{
			n_string_path_free( n_catpad_fname_last );
			n_catpad_fname_last = n_string_path_carboncopy( fname );
		}

		n_catpad_title( hwnd, fname );

	}


	n_catpad_editor_ntxt_set();
	n_catpad_ui_refresh( hwnd );


	// [!] : Tricky : to turn off

	int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_NDUMP;

	n_catpad_ndump_onoff = n_true;
	n_catpad_ndump_onoff = n_win_button_checklike( &H_BTN_NDUMP, index, index, n_catpad_ndump_onoff );


	return;
}

// internal
void
n_catpad_save( HWND hwnd )
{

	if ( n_catpad_txtbox_onoff )
	{

		// [Patched] : edit control compatible behavior

		//n_win_txtbox_line_del( &n_catpad_txtbox_editor, n_catpad_txtbox_editor.txt.sy );

	} else {

		// [!] : add NUL('\0') at allocation

		int cch      = n_win_text_len( H_EDITOR ) + 1;
		int byte     = cch * sizeof( n_posix_char );
		int newline  = n_catpad_txtbox_editor.txt.newline;
		int unicode  = n_catpad_txtbox_editor.txt.unicode;
		int readonly = n_catpad_txtbox_editor.txt.readonly;


		n_posix_char *ptr = n_memory_new( byte );

		n_win_text_get( H_EDITOR, ptr, cch );

#ifdef UNICODE

		n_unicode_bom_restore_utf16_le( ptr, byte );

#else // #ifdef UNICODE

		// [!] : EditControlA adds an extra newline

		n_catpad_string_remove_newline( ptr, ptr );
//n_posix_debug( ptr );

#endif // #ifdef UNICODE

		if ( n_catpad_txtbox_onoff )
		{
			n_win_txtbox_txt_load_onmemory( &n_catpad_txtbox_editor    , ptr, byte );
		} else {
			n_txt_load_onmemory           ( &n_catpad_txtbox_editor.txt, ptr, byte );
		}

		n_catpad_txtbox_editor.txt.byte     = byte;
		n_catpad_txtbox_editor.txt.newline  = newline;
		n_catpad_txtbox_editor.txt.unicode  = unicode;
		n_catpad_txtbox_editor.txt.readonly = readonly;

	}


	// [!] : make a file writable 
	//
	//	"readonly", "system", "hidden"

	n_bool ret = n_false;

	u32 attrib;


	attrib = GetFileAttributes( n_catpad_fname_last );
	SetFileAttributes( n_catpad_fname_last, 0 );

	ret = n_win_txtbox_txt_save( &n_catpad_txtbox_editor, n_catpad_fname_last );

	if ( attrib != INVALID_FILE_ATTRIBUTES )
	{
		SetFileAttributes( n_catpad_fname_last, attrib );
	}

	n_explorer_refresh( n_false );


	if ( ret )
	{
		n_project_dialog_info( hwnd, n_project_string_error );
	} else {
		n_catpad_overwrite_onoff( n_false );
	}

	n_catpad_status_refresh();


	return;
}

// internal
void
n_catpad_dump( HWND hwnd )
{

	if ( n_win_button_is_enabled( &H_BTN_OVERWRITE ) ) { return; }


	if ( n_catpad_ndump_onoff == n_false )
	{
		n_catpad_newfile( hwnd, n_catpad_fname_last );
		return;
	}


	n_catpad_ntxt_dump( &n_catpad_txtbox_editor.txt, n_catpad_fname_last );

	n_catpad_txtbox_editor.txt.readonly = n_true;


	n_catpad_editor_ntxt_set();
	n_catpad_ui_refresh( hwnd );


	return;
}

#ifndef _WIN64
static WNDPROC n_catpad_toolband_pfunc;
#endif // #ifndef _WIN64

LRESULT CALLBACK
#ifdef _WIN64
n_catpad_toolband_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_catpad_toolband_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_COMMAND :
	{

		HWND h       = (HWND) lparam;
		HWND hparent = n_win_hwnd_toplevel( hwnd );

		if ( h == H_BTN_TOPMOST.hwnd )
		{

			static n_bool topmost = n_false;

			int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_TOPMOST;
			topmost = n_win_button_checklike( &H_BTN_TOPMOST, index, index, topmost );

			n_win_topmost( hparent, topmost );

			n_catpad_focus( hparent );

		} else

		if ( h == H_BTN_OVERWRITE.hwnd )
		{

			n_catpad_save( hparent );

			n_catpad_focus( hparent );

		} else

		if ( h == H_BTN_CONFIG.hwnd )
		{

			n_win_gui( hparent, WINDOW, n_catpad_config_wndproc, &n_catpad_hpopup );

		} else

		if ( h == H_BTN_FONT.hwnd )
		{

			n_win_gui( hparent, WINDOW, n_catpad_fontchooser_wndproc, &n_catpad_hpopup );

		} else

		if ( h == H_BTN_CALC.hwnd )
		{
//n_posix_debug_literal( "%s", n_catpad_fname_last );

			n_win_exec( N_CATPAD_CALC, SW_NORMAL );

		} else

		if ( h == H_BTN_NDUMP.hwnd )
		{

			int index = N_APPS_ICON_OFFSET_CATPAD + N_CATPAD_ICON_OFFSET_NDUMP;
			n_catpad_ndump_onoff = n_win_button_checklike( &H_BTN_NDUMP, index, index, n_catpad_ndump_onoff );


			n_catpad_dump( hparent );

			n_catpad_focus( hparent );

		}// else

	}
	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_TOPMOST   );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_OVERWRITE );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_CONFIG    );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_FONT      );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_CALC      );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_NDUMP     );


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( n_catpad_toolband_pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_catpad_smallbutton_metrics( void )
{

	n_catpad_findicon .color_bg      = n_bmp_white_invisible;
	n_catpad_reseticon.color_bg      = n_bmp_white_invisible;
	n_catpad_reseticon.color_hovered = n_bmp_rgb( 255,  0,  0 );


	return;
}

int
n_catpad_txtbox_input_style( void )
{

	int style = N_WIN_TXTBOX_STYLE_ONELINE | N_WIN_TXTBOX_STYLE_EDITBOX | N_WIN_TXTBOX_STYLE_FLATBDR;

	if ( n_catpad_dwm_transbg_onoff )
	{
		style |= N_WIN_TXTBOX_STYLE_TRANSBG;
	} else {
		if ( n_sysinfo_version_vista_or_later() )
		{
			style |= N_WIN_TXTBOX_STYLE_VISIBLE;
		}
	}


	return style;
}

void
n_catpad_icon_add( void )
{

	n_posix_char *exe = n_win_exepath_new();

	n_win_icon_init_callback = n_project_system_icon_color;

	H_BTN_TOPMOST  .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_OVERWRITE.hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_CONFIG   .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_FONT     .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 5, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_CALC     .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 6, N_WIN_ICON_INIT_OPTION_RESOURCE );
	H_BTN_NDUMP    .hicon = n_win_icon_init( exe, N_APPS_ICON_OFFSET_CATPAD + 7, N_WIN_ICON_INIT_OPTION_RESOURCE );

	n_string_path_free( exe );


	return;
}

void
n_catpad_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }
		n_win_timer_exit( hwnd, timer_id );

//break;

		// [x] : not working accurately
		//n_project_darkmode();
		//n_project_toolband_dwm_onoff( hwnd );


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_refresh( H_TOOLBAND, n_true );

		n_catpad_icon_add();

		n_win_button_on_settingchange( &H_BTN_TOPMOST   );
		n_win_button_on_settingchange( &H_BTN_OVERWRITE );
		n_win_button_on_settingchange( &H_BTN_CONFIG    );
		n_win_button_on_settingchange( &H_BTN_FONT      );
		n_win_button_on_settingchange( &H_BTN_CALC      );
		n_win_button_on_settingchange( &H_BTN_NDUMP     );


		n_catpad_dwm_transbg_onoff = n_project_dwm_is_on();


		n_win_stdfont_init( n_catpad_hgui, GUI_MAX );

		if ( n_catpad_txtbox_monospace == n_false )
		{
			n_win_stdfont_init( &H_EDITOR, 1 );
			n_win_stdfont_init( &H_TXTBOX, 1 );
		}

		n_win_txtbox_metrics( &n_catpad_txtbox_editor );


		if ( n_catpad_search_monospace == n_false )
		{
			n_win_stdfont_init( &H_SEARCH, 1 );
		}

		n_catpad_txtbox_search.style = n_catpad_txtbox_input_style();

		n_win_txtbox_metrics( &n_catpad_txtbox_search );

		n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );


		n_catpad_smallbutton_metrics();

		n_win_smallbutton_direct_on_settingchange( &n_catpad_findicon , n_project_small_find  );
		n_win_smallbutton_direct_on_settingchange( &n_catpad_reseticon, n_project_small_close );


		n_catpad_resize_window( hwnd, n_false );
		n_catpad_resize( hwnd );

	break;


	} // switch


}

LRESULT CALLBACK
n_catpad_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_catpad_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( wparam == n_catpad_fade_timer )
		{

			n_win_txtbox *p = &n_catpad_txtbox_search;

			if ( p->text_fade_ratio == 0.0 )
			{
				p->caret_blend_override_onoff = n_posix_true;
				p->caret_blend_override_value = 0.0;
			}

			p->text_fade_ratio += 0.1;

			p->smallbutton[ 1 ]->fade_blend = p->text_fade_ratio;

			if ( p->is_grayed )
			{
				p->color_back_selected = p->color_sel_focus_off;
			}

			if ( p->text_fade_ratio >= 1.0 )
			{
				p->text_fade_ratio = 0.0;

				p->caret_blend_override_onoff = n_posix_false;

				n_win_timer_exit( hwnd, n_catpad_fade_timer );

				n_win_smallbutton_direct_hide( p->smallbutton[ 1 ], n_posix_true );

				n_win_txtbox_on_setcursor( p );

				n_string_truncate( n_catpad_find );
				n_catpad_sync_send( hwnd, n_catpad_find );
			} else {
				n_win_txtbox_refresh( p, 0 );
			}

		}

	break;


	case WM_CREATE :
	{

		// Global

		n_bmp_safemode = n_false;

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_exedir2curdir();

		n_catpad_sync_init();
		n_catpad_ini_read( hwnd );

		n_catpad_txtbox_onoff = n_catpad_txtbox_onoff_default;


		n_win_smallbutton_direct_zero( &n_catpad_findicon  );
		n_win_smallbutton_direct_zero( &n_catpad_reseticon );

		n_win_txtbox_zero( &n_catpad_txtbox_editor );
		n_win_txtbox_zero( &n_catpad_txtbox_search );

		n_catpad_dwm_transbg_onoff = n_project_dwm_is_on();

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_catpad_trans_client_onoff = n_posix_false;

		if ( n_catpad_trans_client_onoff )
		{
			if ( n_false == n_sysinfo_version_10_or_later() )
			{
				n_project_toolband_mode = N_PROJECT_TOOLBAND_MODE_ALL;
			}
		}


		// Window

		n_win_init_literal( hwnd, "", "CATPAD_0_MAIN", "" );


		n_win_gui_literal( hwnd, CANVAS,  "", &H_BTN_FIND  );
		n_win_gui_literal( hwnd, CANVAS,  "", &H_BTN_RESET );

		{
			int style        = n_catpad_txtbox_input_style();
			int style_option = N_WIN_TXTBOX_OPTION_DELAYEDFOCUS_ON;

			style_option |= N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT;
			style_option |= N_WIN_TXTBOX_OPTION_ONELINE_RESIZER;

			if ( n_win_style_is_classic() )
			{
				//
			} else
			if (
				( n_win_darkmode_onoff )
				||
				( n_posix_false == n_win_dwm_aeroglass_is_on() )
			)
			{
				style_option |= N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE;
			}

			if (
				( n_win_darkmode_onoff == n_posix_false )
				&&
				( n_win_dwm_is_on() )
			)
			{
				style_option |= N_WIN_TXTBOX_OPTION_PARENT_BACKGRND;
			}

			n_win_txtbox_init( &n_catpad_txtbox_search, hwnd, style, style_option );

			n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );

			n_catpad_txtbox_search.style_option &= ~N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE;

			n_win_property_set_literal( n_catpad_txtbox_search.hwnd, "Toolband", n_posix_true );
		}

		n_win_gui_literal( hwnd, CANVAS,  "", &H_TOOLBAND  );
		n_win_gui_literal( hwnd, EDITOR,  "", &H_EDITOR    );

		n_win_statusbar_od_init( &n_catpad_statusbar, hwnd, 3 );

		{
			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_EDITBOX;
			style = style | N_WIN_TXTBOX_STYLE_HSCROLL | N_WIN_TXTBOX_STYLE_VSCROLL;
			style = style | N_WIN_TXTBOX_STYLE_STRIPED;

			if ( n_project_toolband_mode )
			{
				if ( n_sysinfo_version_vista_or_later() )
				{
					style = style | N_WIN_TXTBOX_STYLE_VISIBLE;
				}
			}

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM;
			style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;

			n_win_txtbox_init( &n_catpad_txtbox_editor, hwnd, style, style_option );

			n_catpad_txtbox_editor.tab_mark = n_catpad_tab;
			n_catpad_txtbox_editor.eol_mark = n_catpad_eol;
		}


		n_win_button_init_dwm( &H_BTN_TOPMOST  , H_TOOLBAND, N_STRING_EMPTY, PBS_NORMAL   );
		n_win_button_init_dwm( &H_BTN_OVERWRITE, H_TOOLBAND, N_STRING_EMPTY, PBS_DISABLED );
		n_win_button_init_dwm( &H_BTN_CONFIG   , H_TOOLBAND, N_STRING_EMPTY, PBS_NORMAL   );
		n_win_button_init_dwm( &H_BTN_FONT     , H_TOOLBAND, N_STRING_EMPTY, PBS_NORMAL   );
		n_win_button_init_dwm( &H_BTN_CALC     , H_TOOLBAND, N_STRING_EMPTY, PBS_NORMAL   );
		n_win_button_init_dwm( &H_BTN_NDUMP    , H_TOOLBAND, N_STRING_EMPTY, PBS_NORMAL   );

		n_project_toolband_dwm_onoff_margin = H_BTN_TOPMOST.maclike_offset;

		n_catpad_icon_add();


		// Style

		n_project_window_resizable( hwnd );


		n_win_simplemenu_zero( &n_catpad_simplemenu );
		n_win_simplemenu_init( &n_catpad_simplemenu );

		//n_win_simplemenu_set( &n_catpad_simplemenu, 0, NULL, n_posix_literal( "[ ]Close" ), NULL );


		n_win_titlemenu_zero( &n_catpad_titlemenu );
		n_win_titlemenu_init_main( &n_catpad_titlemenu, hwnd, &n_catpad_simplemenu );


		n_catpad_keyfocus_init( H_SEARCH, H_EDITOR, H_TXTBOX );


		n_win_smallbutton_direct_init_by_data( &n_catpad_findicon , H_SEARCH, hwnd, hwnd, N_CATPAD_SMALLBUTTON_ID_FIND , n_project_small_find  );
		n_win_smallbutton_direct_init_by_data( &n_catpad_reseticon, H_SEARCH, hwnd, hwnd, N_CATPAD_SMALLBUTTON_ID_RESET, n_project_small_close );

		n_catpad_findicon.show_onoff = n_posix_true;

		n_catpad_smallbutton_metrics();


#ifdef _WIN64
		SetWindowSubclass( H_TOOLBAND, n_catpad_toolband_subclass, 0, 0 );
#else  // #ifdef _WIN64
		n_catpad_toolband_pfunc = n_win_gui_subclass_set( H_TOOLBAND, n_catpad_toolband_subclass );
#endif // #ifdef _WIN64


		// Init

		n_win_stdfont_init( n_catpad_hgui, GUI_MAX );

		if ( n_catpad_txtbox_monospace == n_false )
		{
			n_win_stdfont_init( &H_EDITOR, 1 );
			n_win_stdfont_init( &H_TXTBOX, 1 );
		}

		if ( n_catpad_search_monospace == n_false )
		{
			n_win_stdfont_init( &H_SEARCH, 1 );
		}

		n_catpad_font_init();

		n_catpad_hfind = H_SEARCH;

		if ( n_false == n_catpad_sync_is_first_check( hwnd ) )
		{
//n_posix_debug_literal( " %s ", n_catpad_sync_str );

			n_posix_char str[ N_CATPAD_SYNC_CCH ];

			n_catpad_sync_recv( hwnd, str );

			if ( n_false == n_string_is_empty( str ) )
			{
				n_string_copy( str, n_catpad_find );
			}

		}
		n_win_txtbox_line_set( &n_catpad_txtbox_search, 0, n_catpad_find );
		n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

		n_win_message_send( hwnd, WM_COMMAND, WM_KILLFOCUS, H_SEARCH );
		n_win_message_send( hwnd, WM_COMMAND, WM_KEYDOWN  , H_SEARCH );

		n_catpad_history_init();


		// Display

		{

			n_posix_char *cmdline = n_win_commandline_new();

#ifdef NONNON_APPS

			// [Needed] : for Nonnon Apps

			n_string_commandline_option( N_APPS_OPTION_CATPAD, cmdline );

#endif // #ifdef NONNON_APPS

			n_catpad_newfile( hwnd, cmdline );

			n_string_path_free( cmdline );

		}


		// [x] : Win7 or earlier and Win10 : restore animation will start from zero co-ord

		// [x] : there may be a way : Firefox has no problem

		if ( n_catpad_nwin_ini.state == SIZE_MAXIMIZED )
		{
			n_catpad_nwin_ini.restore_x  = n_catpad_nwin_ini.posx;
			n_catpad_nwin_ini.restore_y  = n_catpad_nwin_ini.posy;
			n_catpad_nwin_ini.restore_sx = n_catpad_nwin_ini.rcsx;
			n_catpad_nwin_ini.restore_sy = n_catpad_nwin_ini.rcsy;

			ShowWindowAsync( hwnd, SW_NORMAL );
			DefWindowProc( hwnd, msg, wparam, lparam );

			ShowWindowAsync( hwnd, SW_MAXIMIZE );
		} else {
			n_catpad_resize_window( hwnd, n_true );
			n_catpad_resize( hwnd );

			ShowWindowAsync( hwnd, SW_NORMAL );
		}

	}
	break;


	case WM_MOVE :

		if (
			( n_false == IsIconic( hwnd ) )
			&&
			( n_false == IsZoomed( hwnd ) )
		)
		{
			n_win_position( hwnd, &n_catpad_nwin_ini.posx, &n_catpad_nwin_ini.posy );
		}

	break;

	case WM_SIZE :
	{

		int state = (int) wparam;

		if ( state == SIZE_MINIMIZED )
		{
			//
		} else
		if ( state == SIZE_RESTORED )
		{
			if ( n_catpad_nwin_ini.state == SIZE_MAXIMIZED )
			{
				n_catpad_nwin.posx = n_catpad_nwin_ini.restore_x;
				n_catpad_nwin.posy = n_catpad_nwin_ini.restore_y;
				n_catpad_nwin.rcsx = n_catpad_nwin_ini.restore_sx;
				n_catpad_nwin.rcsy = n_catpad_nwin_ini.restore_sy;

				n_catpad_resize_window( hwnd, n_true );
			} else {
				n_catpad_resize_window( hwnd, n_false );
			}

			n_catpad_nwin_ini = n_catpad_nwin;

			n_catpad_resize( hwnd );
		} else
		if ( state == SIZE_MAXIMIZED )
		{
			n_catpad_nwin_ini.restore_x  = n_catpad_nwin.posx;
			n_catpad_nwin_ini.restore_y  = n_catpad_nwin.posy;
			n_catpad_nwin_ini.restore_sx = n_catpad_nwin.rcsx;
			n_catpad_nwin_ini.restore_sy = n_catpad_nwin.rcsy;

			n_catpad_resize_window( hwnd, n_false );
			n_catpad_resize( hwnd );

			n_catpad_nwin_ini.state = SIZE_MAXIMIZED;
		}

	}
	break;


	case WM_CTLCOLORSTATIC :

		if ( (HWND) lparam == H_EDITOR )
		{
			return (LRESULT) GetStockObject( WHITE_BRUSH );
		}

	break;


	case WM_DROPFILES :
	{

		// [!] : for popup windows

		if ( n_false == IsWindowEnabled( hwnd ) ) { break; }

		n_posix_char *fname = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_catpad_newfile( hwnd, fname );

		n_string_path_free( fname );

	}
	break;


	case WM_SETFOCUS :

//n_win_hwndprintf_literal( hwnd, " %x %x : %x %x %x ", wparam, lparam, GetFocus(), H_TXTBOX, H_SEARCH );
//n_win_hwndprintf_literal( hwnd, " SET %x %x %x %x ", wparam, lparam, GetActiveWindow(), GetFocus() );

		n_catpad_focus( hwnd );

	break;

	case WM_KILLFOCUS :

//n_win_hwndprintf_literal( hwnd, " %x %x : %x %x %x ", wparam, lparam, GetFocus(), H_TXTBOX, H_SEARCH );
//n_win_hwndprintf_literal( hwnd, " KILL %x %x %x %x ", wparam, lparam, GetActiveWindow(), GetFocus() );

	break;


	case WM_ACTIVATE :

		// [Needed] : WinXP or earlier : tearing prevention
		//
		//	don't use Vista or later : this causes flickering

		//if ( n_catpad_txtbox_onoff == n_false ) { break; }

		//if ( n_sysinfo_version_vista_or_later() ) { break; }

	break;


	case WM_ERASEBKGND :

		// [Needed] : prevent redraw error

		return n_true;

	break;


	case WM_MBUTTONDOWN :

		if ( n_catpad_txtbox_onoff == n_false ) { break; }

		if ( n_win_is_input( VK_CONTROL ) )
		{
			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), n_font_size_default( hwnd ) );
			n_catpad_font_init();
		}

	break;

	case WM_MOUSEWHEEL :
//n_win_hwndprintf_literal( hwnd, " %d ", n_catpad_txtbox_editor.menu_onoff );

		if ( n_catpad_txtbox_editor.menu_onoff )
		{
			n_catpad_txtbox_editor.menu_editbox.silent_onoff = n_true;
			n_catpad_txtbox_editor.menu_linenum.silent_onoff = n_true;

			n_win_simplemenu_hide( &n_catpad_txtbox_editor.menu_editbox );
			n_win_simplemenu_hide( &n_catpad_txtbox_editor.menu_linenum );
		}

		if ( n_win_is_input( VK_CONTROL ) )
		{

			int delta = n_win_scrollbar_wheeldelta( wparam, 1, n_true ) * -1;
			int size  = n_font_size( n_catpad_hfont );
//n_win_hwndprintf_literal( hwnd, " %d : %d ", delta, size );

			n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), size + delta );
			n_catpad_font_init();

			return 0;
		}

		if ( n_catpad_txtbox_onoff ) { break; }

	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;

		if ( h == n_catpad_history_menu.hwnd )
		{
//n_win_debug_count( hwnd );

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( ( wparam >= 0 )&&( wparam < N_CATPAD_HISTORY_MAX ) )
			{
				n_posix_char *str = n_catpad_history_string[ wparam ];
				n_string_copy( &str[ 3 ], n_catpad_find );
				n_catpad_sync_send( hwnd, n_catpad_find );
			}

		} else
		if ( h == H_EDITOR )
		{
			if ( EN_CHANGE == HIWORD( wparam ) )
			{
				n_catpad_overwrite_onoff( n_true );
			}
		} else
		if ( h == n_catpad_txtbox_editor.hwnd )
		{
			if ( wparam == WM_SETFOCUS )
			{
				//
			} else
			if ( wparam == WM_KEYDOWN )
			{
				n_catpad_overwrite_onoff( n_true );
			} else
			if ( wparam == WM_MBUTTONDOWN )
			{
				n_catpad_hfont = n_win_font_name2hfont( n_font_name( n_catpad_hfont ), n_font_size_default( hwnd ) );
				n_catpad_font_init();
			} else
			if ( wparam == WM_IME_NOTIFY )
			{
				n_win_txtbox_ime_fade_go( &n_catpad_txtbox_search );
				n_win_txtbox_ime_fade_go( &n_catpad_txtbox_editor );

				return n_true;
			}
		} else
		if ( h == H_SEARCH )
		{
//n_win_debug_count( hwnd );
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), "" );

			if ( wparam == WM_RBUTTONUP )
			{

				if ( n_win_smallbutton_direct_is_hovered( &n_catpad_findicon ) )
				{
					n_catpad_history_show();
				}

			} else
			if ( wparam == WM_SETFOCUS )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " SETFOCUS " );

				n_catpad_input_gray_onoff = n_false;
				n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );

			} else
			if ( wparam == WM_KILLFOCUS )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " KILLFOCUS " );

				//n_win_txtbox_unselect( &n_catpad_txtbox_search );
				//n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

				n_catpad_input_gray_onoff = n_true;
				n_win_txtbox_grayed( &n_catpad_txtbox_search, n_catpad_input_gray_onoff );

			} else
			if ( wparam == WM_KEYDOWN )
			{
//n_win_text_set_literal( n_win_hwnd_toplevel( h ), " WM_KEYDOWN " );

				n_posix_char *str = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );

				if ( n_string_is_empty( str ) )
				{
					n_catpad_reseticon.show_onoff = n_false;
				} else {
					n_catpad_reseticon.show_onoff = n_true;
				}

				n_string_free( str );

			} else
			if ( wparam == WM_IME_NOTIFY )
			{
				n_win_txtbox_ime_fade_go( &n_catpad_txtbox_search );
				n_win_txtbox_ime_fade_go( &n_catpad_txtbox_editor );

				return n_true;
			}

		} else
		if ( ( h == n_catpad_findicon .hwnd_msg )&&( wparam == N_CATPAD_SMALLBUTTON_ID_FIND  ) )
		{
//n_win_debug_count( hwnd );

			n_catpad_search( hwnd );

		} else
		if ( ( h == n_catpad_reseticon.hwnd_msg )&&( wparam == N_CATPAD_SMALLBUTTON_ID_RESET ) )
		{

			if ( n_catpad_txtbox_search.global_fade_onoff )
			{
				if ( n_catpad_fade_timer == 0 ) { n_catpad_fade_timer = n_win_timer_id_get(); }
				n_win_timer_init( hwnd, n_catpad_fade_timer, 16 );
			} else {
				n_string_truncate( n_catpad_find );
				n_catpad_sync_send( hwnd, N_STRING_EMPTY );
			}

		}// else

	}
	break;


	case WM_KEYDOWN :


		if ( wparam == VK_F11 )
		{

			if ( n_project_dialog_yesno( hwnd, n_posix_literal( "Delete Suggestion History of Japanese IME" ) ) )
			{
				n_catpad_privacy_protection();
			}

		} else
		if ( wparam == VK_F12 )
		{

			n_catpad_printer( hwnd, n_catpad_hfont, &n_catpad_txtbox_editor.txt );

		} else
		if ( wparam == VK_F1 )
		{

			// [!] : WinXP or later : ANSI DBCS : byte count will return

			//n_posix_debug_literal( "%d", GetWindowTextLength( H_EDITOR ) );


			//n_clipboard_text_set( hwnd, N_STRING_EMPTY );

		} else
		if ( wparam == VK_F2 )
		{
//n_posix_debug_literal( "!" );
			//n_win_scrollbar_reset( &n_catpad_txtbox_editor.vscr );
			//n_win_txtbox_reset_scroll( &n_catpad_txtbox_editor );

			//n_win_scrollbar_metrics( &n_catpad_txtbox_editor.vscr );

			//n_bmp_free( &n_catpad_txtbox_editor.vscr.bmp_th );

			//n_win_scrollbar_scroll_unit( &n_catpad_txtbox_editor.vscr, 0, N_WIN_SCROLLBAR_SCROLL_AUTO );
			//n_win_scrollbar_draw_always( &n_catpad_txtbox_editor.vscr, n_true );

			//n_win_txtbox_refresh( &n_catpad_txtbox_editor, 0 );

		} else
		if ( wparam == VK_F5 )
		{

			if ( n_catpad_txtbox_editor.txt.readonly ) { break; }

			n_posix_char str[ 100 ];

			if ( n_win_is_input( VK_CONTROL ) )
			{
				n_catpad_day_of_week( str, 100 );
			} else {
				n_time_string_stime( str );
			}

			if ( n_catpad_txtbox_onoff )
			{
				n_win_txtbox_selection_cat( &n_catpad_txtbox_editor, str );
			} else {
				n_win_edit_line_insert    ( H_EDITOR, str );
			}

			n_catpad_overwrite_onoff( n_true );

			n_catpad_editor_refresh();

		} else
		if ( wparam == VK_F9 )
		{
/*
			n_type_int    cch = n_clipboard_text_get( hwnd, NULL );
			n_posix_char *str = n_string_new( cch ); n_clipboard_text_get( hwnd, str );

			n_posix_debug_literal( "%d %x", cch, str[ 0 ] );

			n_string_free( str );
*/
		}

	break;


	case WM_CLOSE :

		if ( n_catpad_trans_client_onoff )
		{
			n_project_toolband_mode = N_PROJECT_TOOLBAND_MODE_PARTIAL;
			n_project_toolband_dwm_onoff( hwnd );
		}


		ShowWindow( hwnd, SW_HIDE );


		n_catpad_ini_write();

#ifdef _WIN64
		RemoveWindowSubclass( H_TOOLBAND, n_catpad_toolband_subclass, 0 );
#else  // #ifdef _WIN64
		n_win_gui_subclass_set( H_TOOLBAND, n_catpad_toolband_pfunc );
#endif // #ifdef _WIN64


		n_win_smallbutton_direct_exit( &n_catpad_findicon  );
		n_win_smallbutton_direct_exit( &n_catpad_reseticon );


		n_win_property_exit_literal( n_catpad_txtbox_search.hwnd, "Toolband" );

		n_win_txtbox_exit( &n_catpad_txtbox_editor );
		n_win_txtbox_exit( &n_catpad_txtbox_search );


		n_catpad_sync_exit();


		n_win_button_exit( &H_BTN_TOPMOST   );
		n_win_button_exit( &H_BTN_OVERWRITE );
		n_win_button_exit( &H_BTN_CONFIG    );
		n_win_button_exit( &H_BTN_FONT      );
		n_win_button_exit( &H_BTN_CALC      );
		n_win_button_exit( &H_BTN_NDUMP     );


		n_win_font_exit( n_catpad_hfont );

		n_win_stdfont_exit( n_catpad_hgui, GUI_MAX );

		n_win_statusbar_od_exit( &n_catpad_statusbar );

		if ( n_catpad_txtbox_monospace == n_false )
		{
			n_win_stdfont_exit( &H_EDITOR, 1 );
			n_win_stdfont_exit( &H_TXTBOX, 1 );
		}

		if ( n_catpad_search_monospace == n_false )
		{
			n_win_stdfont_exit( &H_SEARCH, 1 );
		}


		n_catpad_keyfocus_exit( H_SEARCH, H_EDITOR, H_TXTBOX );


		n_win_titlemenu_exit( &n_catpad_titlemenu );

		n_win_simplemenu_exit( &n_catpad_simplemenu );


		n_catpad_history_exit();


		n_string_path_free( n_catpad_fname_last );


#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_cornercolor_proc( hwnd, msg, wparam, lparam );


	n_catpad_linenumber_refresh( n_false );


	if ( n_catpad_sync_proc( hwnd, msg, wparam, lparam ) )
	{

		n_catpad_sync_recv( hwnd, n_catpad_find );


		n_posix_char *str = n_win_txtbox_line_get_new( &n_catpad_txtbox_search, 0 );
//n_posix_debug_literal( " Get %s\n Find %s ", str, n_catpad_find );

		if ( n_false == n_string_is_same( str, n_catpad_find ) )
		{
			n_win_txtbox_line_set( &n_catpad_txtbox_search, 0, n_catpad_find );
			n_win_txtbox_select_tail_set( &n_catpad_txtbox_search );

			n_win_txtbox_refresh( &n_catpad_txtbox_search, N_WIN_TXTBOX_CATPAD_SYNC );

			n_win_message_send( hwnd, WM_COMMAND, WM_KEYDOWN, n_catpad_txtbox_search.hwnd );
		}

		n_string_free( str );

	}


	if ( msg == n_catpad_sync_msg_is_exist )
	{
		return n_true;
	}


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_catpad_txtbox_editor );
		if ( ret ) { return ret; }

		if ( n_catpad_txtbox_onoff )
		{
			n_win_txtbox_grab_n_drag_proc( hwnd, msg, wparam, lparam, &n_catpad_txtbox_editor );
		}
	}


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_catpad_txtbox_search );
		if ( ret ) { return ret; }
	}


	n_win_statusbar_od_proc( hwnd,msg,wparam,lparam, &n_catpad_statusbar );

	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &n_catpad_findicon  );
	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &n_catpad_reseticon );


	n_project_toolband_proc( hwnd, msg, wparam, lparam, H_TOOLBAND, n_true );


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );


	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	// [!] : for performance check
	//n_posix_sleep( 20 );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_catpad_wndproc );
}

#endif // #ifndef NONNON_APPS


#undef H_TOOLBAND
#undef H_BTN_FIND
#undef H_BTN_RESET
#undef GUI_MAX

#undef H_BTN_TOPMOST
#undef H_BTN_OVERWRITE
#undef H_BTN_CONFIG
#undef H_BTN_FONT
#undef H_BTN_CALC
#undef H_BTN_NDUMP
#undef BTN_MAX

#undef H_EDITOR
#undef H_TXTBOX
#undef H_SEARCH

