
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nonnonapps
set  window=-mwindows

%compile%

