
@echo off

set compile=..\nonnon\project\compile.bat
set    name=n_attrib
set  window=-mwindows

%compile%

