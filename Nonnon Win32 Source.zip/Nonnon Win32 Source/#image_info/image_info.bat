
@echo off

set compile=..\nonnon\project\compile.bat
set    name=image_info
set  window=-mwindows

%compile%

