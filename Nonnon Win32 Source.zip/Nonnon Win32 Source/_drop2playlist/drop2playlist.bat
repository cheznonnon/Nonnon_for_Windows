
@echo off

set compile=..\nonnon\project\compile.bat
set    name=drop2playlist
set  window=-mwindows

%compile%

