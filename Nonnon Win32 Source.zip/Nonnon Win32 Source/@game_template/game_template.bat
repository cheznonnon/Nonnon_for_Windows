
@echo off

set compile=..\nonnon\project\compile.bat
set    name=game_template
set  window=-mwindows

%compile%

