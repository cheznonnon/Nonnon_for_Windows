
@echo off

set compile=..\nonnon\project\compile.bat
set    name=mail_manager
set  window=-mwindows

%compile%

