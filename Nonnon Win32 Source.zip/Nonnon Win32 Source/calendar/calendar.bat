
@echo off

set compile=..\nonnon\project\compile.bat
set    name=calendar
set  window=-mwindows

%compile%

