
@echo off

set compile=..\nonnon\project\compile.bat
set    name=ntyping
set  window=-mwindows

%compile%

