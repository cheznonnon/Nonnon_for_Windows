
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nmidi
set  window=-mwindows

%compile%

