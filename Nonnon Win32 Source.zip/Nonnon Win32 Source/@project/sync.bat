
@echo off

set compile=..\nonnon\project\compile.bat
set    name=sync
set  window=-mwindows

%compile%

