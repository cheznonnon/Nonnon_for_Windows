
@echo off

set compile=..\nonnon\project\compile.bat
set    name=timestamp
set  window=-mwindows

%compile%

