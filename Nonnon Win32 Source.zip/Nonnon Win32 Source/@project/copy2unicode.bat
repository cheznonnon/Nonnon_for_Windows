
@echo off

set compile=..\nonnon\project\compile.bat
set    name=copy2unicode
set  window=-mwindows

%compile%

