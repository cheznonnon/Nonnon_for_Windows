
@echo off

set compile=..\nonnon\project\compile.bat
set    name=upx_pack
set  window=-mwindows

%compile%

