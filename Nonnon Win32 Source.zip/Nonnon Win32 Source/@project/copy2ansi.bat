
@echo off

set compile=..\nonnon\project\compile.bat
set    name=copy2ansi
set  window=-mwindows

%compile%

