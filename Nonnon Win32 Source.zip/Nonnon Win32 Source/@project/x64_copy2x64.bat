
@echo off

set compile=..\nonnon\project\compile.bat
set    name=x64_copy2x64
set  window=-mwindows

%compile%

