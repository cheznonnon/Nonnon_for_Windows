
@echo off

set compile=..\nonnon\project\compile.bat
set    name=dot_file_remover
set  window=-mwindows

%compile%

