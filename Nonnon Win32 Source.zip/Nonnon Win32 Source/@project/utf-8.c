// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE


#include "../nonnon/neutral/path.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/win/commandline.c"




void
n_text_replacer_file( const n_posix_char *fname )
{

	n_txt txt; n_txt_zero( &txt );
	if ( n_txt_load( &txt, fname ) ) { return; }

	if ( txt.newline != N_TXT_NEWLINE_BINARY )
	{
		txt.unicode = N_TXT_UNICODE_UTF;
		n_txt_save( &txt, fname );
	}


	return;
}

n_posix_bool
n_text_replacer_directory( n_posix_char *path )
{

	n_text_replacer_file( path );


	n_posix_DIR *dp = n_posix_opendir_nodot( path );
	if ( dp == NULL ) { return n_posix_true; }

	while( 1 )
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }

		n_posix_char name[ N_PATH_MAX ];
		n_path_maker( path, dirent->d_name, name );

		n_text_replacer_directory( name );

	}

	n_posix_closedir( dp );


	return n_posix_false;
}

int
main( void )
{

	n_posix_char cmdline[ N_PATH_MAX ];
	n_win_commandline( cmdline );

	n_text_replacer_directory( cmdline );


	return 0;
}

