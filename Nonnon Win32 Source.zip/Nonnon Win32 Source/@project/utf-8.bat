
@echo off

set compile=..\nonnon\project\compile.bat
set    name=utf-8
set  window=-mwindows

%compile%

