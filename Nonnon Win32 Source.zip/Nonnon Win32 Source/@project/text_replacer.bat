
@echo off

set compile=..\nonnon\project\compile.bat
set    name=text_replacer
set  window=-mwindows

%compile%

