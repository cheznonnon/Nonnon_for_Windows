
@echo off

set compile=..\nonnon\project\compile.bat
set    name=x64_sync
set  window=-mwindows

%compile%

