// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE


#include "../nonnon/neutral/path.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win32/win/commandline.c"




void
n_text2html( const n_posix_char *fname )
{

	//if ( false == n_path_ext_is_same_literal( ".HTML", fname ) ) { return; }


	n_txt txt; n_txt_zero( &txt );
	if ( n_txt_load( &txt, fname ) ) { return; }

	int i = 0;
	while( 1 )
	{

		n_txt_mod_fast( &txt, i, n_string_tab2space( txt.line[ i ], 8, NULL ) );

		txt.line[ i ] = n_memory_resize( txt.line[ i ], 1024 );

		n_string_replace( txt.line[ i ], txt.line[ i ], L"&" , L"&amp;"        );
		n_string_replace( txt.line[ i ], txt.line[ i ], L">" , L"&gt;"         );
		n_string_replace( txt.line[ i ], txt.line[ i ], L"<" , L"&lt;"         );
		n_string_replace( txt.line[ i ], txt.line[ i ], L"  ", L"&nbsp;&nbsp;" );


		i++;
		if ( i >= txt.sy ) { break; }
	}

	n_txt_save( &txt, fname );


	return;
}
int
main( void )
{

	n_posix_char cmdline[ N_PATH_MAX ];
	n_win_commandline( cmdline );

	n_text2html( cmdline );


	return 0;
}

