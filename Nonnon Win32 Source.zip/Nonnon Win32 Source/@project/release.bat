
@echo off

set compile=..\nonnon\project\compile.bat
set    name=release
set  window=-mwindows

%compile%

