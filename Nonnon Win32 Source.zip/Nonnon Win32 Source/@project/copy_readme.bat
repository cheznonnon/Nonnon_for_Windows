
@echo off

set compile=..\nonnon\project\compile.bat
set    name=copy_readme
set  window=-mwindows

%compile%

