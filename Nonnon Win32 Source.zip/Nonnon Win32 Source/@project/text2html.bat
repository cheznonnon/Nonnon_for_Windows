
@echo off

set compile=..\nonnon\project\compile.bat
set    name=text2html
set  window=-mwindows

%compile%

