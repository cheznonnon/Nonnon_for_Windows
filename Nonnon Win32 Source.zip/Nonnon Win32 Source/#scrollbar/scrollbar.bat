
@echo off

set compile=..\nonnon\project\compile.bat
set    name=scrollbar
set  window=-mwindows

%compile%

