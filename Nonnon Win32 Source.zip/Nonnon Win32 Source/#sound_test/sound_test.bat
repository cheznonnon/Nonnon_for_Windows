
@echo off

set compile=..\nonnon\project\compile.bat
set    name=sound_test
set  window=-mwindows

%compile%

