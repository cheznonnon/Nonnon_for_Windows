
@echo off

set compile=..\nonnon\project\compile.bat
set    name=projectchecker
set  window=-mwindows

%compile%

