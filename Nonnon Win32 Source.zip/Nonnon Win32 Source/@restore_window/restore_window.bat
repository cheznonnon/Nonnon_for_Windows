
@echo off

set compile=..\nonnon\project\compile.bat
set    name=restore_window
set  window=-mwindows

%compile%

