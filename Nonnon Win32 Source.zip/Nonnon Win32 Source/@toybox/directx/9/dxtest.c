// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : once running, currently broken : I don't know why




#define UNICODE


#include "../../../nonnon/win32/win.c"

#include "../../../nonnon/win32/gdi/bitmap.c"

#include "../../../nonnon/project/macro.c"




#include "./direct3d9.c"




void
n_dxtest_load( HWND hwnd, n_bmp *bmp, const n_posix_char *name )
{

	n_win_text_set_literal( hwnd, "Nonnon D3D9 Test" );


	if ( n_bmp_load( bmp, name ) )
	{

		n_type_gfx sx = 512;
		n_type_gfx sy = 512;

		n_bmp_new( bmp, sx,sy );
		n_bmp_flush( bmp, n_bmp_rgb( 0,200,255 ) );
//n_bmp_save_literal( bmp, "ret.bmp" );

		n_win_set( hwnd, NULL, sx, sy, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );

		n_gdi_bitmap_draw( hwnd, bmp, 0,0,sx,sy, 0,0 );

	} else {

		n_type_gfx sx = N_BMP_SX( bmp );
		n_type_gfx sy = N_BMP_SY( bmp );

		n_win_set( hwnd, NULL, sx, sy, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );

//n_gdi_bitmap_draw( hwnd, bmp, 0,0,sx,sy, 0,0 );

		n_d3d9_bitmap_init( sx, sy );
		//n_d3d9_bitmap_sync_all( bmp );

		n_d3d9_bitmap_flush( sx, sy, n_bmp_rgb( 255,255,255 ) );

		n_d3d9_bitmap_draw_all( bmp );
		//n_win_refresh( hwnd, n_posix_false );

	}



	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char cmdline[ 1024 ];
	static n_bmp        bmp;


	switch( msg ) {


	case WM_CREATE :

		if ( n_d3d9_init( hwnd ) )
		{
n_posix_debug_literal( " n_d3d9_init() " );
			return -1;
		}


		n_win_init_literal( hwnd, "Nonnon D3D9 Test", "", "" );
		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		ShowWindow( hwnd, SW_NORMAL );


		// [Needed] : after ShowWindow()

		n_win_commandline( cmdline );

		n_bmp_zero( &bmp );
		n_dxtest_load( hwnd, &bmp, cmdline );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_dxtest_load( hwnd, &bmp, cmdline );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_bmp_free( &bmp );

		n_d3d9_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );


	{ // grabNdrag

	static n_posix_bool onoff = n_posix_false;
	static POINT        prv, cur;


	switch( msg ) {


	case WM_MBUTTONDOWN :

		n_win_cursor_add( NULL, IDC_SIZEALL );
		SetCapture( hwnd );

		GetCursorPos( &prv );

		onoff = n_posix_true;

	break;

	case WM_MOUSEMOVE :
	{

		if ( onoff == n_posix_false ) { break; }


		GetCursorPos( &cur );

		prv.x -= cur.x;
		prv.y -= cur.y;


		n_d3d9_bitmap_scroll( &bmp, -prv.x, -prv.y );
		n_d3d9_clear( RGB( 128,128,128 ) );

		n_d3d9_bitmap_draw_all( &bmp );

/*
		s32 sx,sy;
		n_win_size_client( hwnd, &sx, &sy );

		sx += abs( prv.x * 2 );
		sy += abs( prv.y * 2 );

		n_d3d9_bitmap_draw( &bmp, 0,0,sx,sy );
*/

		prv = cur;

	}
	break;


	case WM_MBUTTONUP :

		onoff = n_posix_false;

		ReleaseCapture();

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	} // switch

	} // grabNdrag


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

