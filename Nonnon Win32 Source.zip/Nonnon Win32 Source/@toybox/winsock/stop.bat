winsock.exe a
pause
