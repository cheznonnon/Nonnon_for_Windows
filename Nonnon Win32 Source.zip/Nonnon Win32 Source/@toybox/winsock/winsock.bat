gcc -Wall -mwindows winsock.c -o winsock.exe -lwsock32
pause