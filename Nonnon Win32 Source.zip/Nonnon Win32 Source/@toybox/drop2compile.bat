
REM set    warn=-Wall -Werror

REM set lib_w32=-lcomctl32 -limm32 -lversion -lvfw32 -lwinmm
REM set lib_ole=-lole32 -loleaut32 -ld3d9
REM set lib_net=-lwininet
REM set lib_all=%lib_w32% %lib_ole% %lib_net%

gcc -Wall -Werror -s -mwindows %1 -o %1.exe -lcomctl32 -limm32 -lversion -lvfw32 -lwinmm -lole32 -loleaut32 -ld3d9 -lwininet

@echo off
if errorlevel 1 pause
