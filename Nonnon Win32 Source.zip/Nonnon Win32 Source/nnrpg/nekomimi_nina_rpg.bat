
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nekomimi_nina_rpg
set  window=-mwindows

%compile%

