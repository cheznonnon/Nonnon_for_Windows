
@echo off

set compile=compile_dll.bat
set    name="Nonnon Mouse Hook"

%compile%

