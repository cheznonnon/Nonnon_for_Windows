
:Main

@echo on

windres -i %name%.rc -o rc.o
gcc -Wall -Werror -O2 -c %name%.c -o obj.o
gcc -mwindows -s -mthreads -shared -Wl,--kill-at obj.o rc.o -o %name%.tmp


:ErrorChecker

@echo off

if errorlevel 1 goto :Error


:Patch

@echo off

if exist %name%.dll del %name%.dll
if errorlevel 1 goto :Error

ren %name%.tmp %name%.dll
if errorlevel 1 goto :Error

goto :Exit


:Error

del %name%.tmp

@echo off

pause


:Exit

@echo off

del *.o


