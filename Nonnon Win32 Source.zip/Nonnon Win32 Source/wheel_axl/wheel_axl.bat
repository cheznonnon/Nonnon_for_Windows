
@echo off

set compile=..\nonnon\project\compile.bat
set    name=wheel_axl
set  window=-mwindows

%compile%

