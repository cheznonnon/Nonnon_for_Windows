
@echo off

set compile=..\nonnon\project\compile.bat
set    name=neko_no_te
set  window=-mwindows

%compile%

