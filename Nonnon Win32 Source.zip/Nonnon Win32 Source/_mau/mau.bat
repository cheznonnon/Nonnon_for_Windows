
@echo off

set compile=..\nonnon\project\compile.bat
set    name=mau
set  window=

%compile%

