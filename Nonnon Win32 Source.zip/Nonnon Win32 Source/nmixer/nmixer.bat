
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nmixer
set  window=-mwindows

%compile%

