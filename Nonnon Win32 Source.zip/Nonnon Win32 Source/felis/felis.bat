
@echo off

set compile=..\nonnon\project\compile.bat
set    name=felis
set  window=-mwindows

%compile%

