
@echo off

set compile=..\nonnon\project\compile.bat
set    name=arcdrop
set  window=-mwindows

%compile%

