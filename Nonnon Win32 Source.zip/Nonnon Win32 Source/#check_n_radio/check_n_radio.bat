
@echo off

set compile=..\nonnon\project\compile.bat
set    name=check_n_radio
set  window=-mwindows

%compile%

