
@echo off

set compile=..\nonnon\project\compile.bat
set    name=hunyapiyo3
set  window=-mwindows

%compile%

