// hunyapiyo3
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/gdi.c"



/*
void
n_hunyapiyo3_gdi_template( n_bmp *bmp )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = 0;
	gdi.sy                  = 0;
	gdi.scale               = 0;
	gdi.style               = N_GDI_SMOOTH;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_rgb( 255,255,255 );
	gdi.base_color_fg       = n_bmp_rgb( 255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.icon                = n_posix_literal( "" );
	gdi.icon_index          = 0;
	gdi.icon_style          = N_GDI_ICON_DEFAULT;
	gdi.icon_color_shadow   = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_contour  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_sink_tl  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_color_sink_br  = n_bmp_rgb(  10, 10, 10 );
	gdi.icon_fxsize1        = 0;
	gdi.icon_fxsize2        = 0;
	gdi.icon_sx             = 0;
	gdi.icon_sy             = 0;

	gdi.text                = n_posix_literal( "" );
	gdi.text_font           = n_posix_literal( "" );
	gdi.text_size           = 16;
	gdi.text_style          = N_GDI_TEXT_DEFAULT;
	gdi.text_color_main     = n_bmp_rgb( 255,255,255 );
	gdi.text_color_gradient = n_bmp_rgb( 255,255,255 );
	gdi.text_color_shadow   = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_contour  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_tl  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_color_sink_br  = n_bmp_rgb(  10, 10, 10 );
	gdi.text_fxsize1        = 0;
	gdi.text_fxsize2        = 0;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}
*/

n_posix_char*
n_hunyapiyo3_stdfont( void )
{

	static n_bool       init = n_false;
	static n_posix_char name[ 100 ];

	if ( init == n_false )
	{
		init = n_true;

		n_posix_char *font = n_gdi_font_find( n_posix_literal( "Trebuchet MS" ), n_posix_literal( "Verdana" ), n_posix_literal( "Arial" ) );
		n_posix_sprintf_literal( name, "%s", font );
	}


	return name;
}

void
n_hunyapiyo3_gdi_background( n_hunyapiyo3 *p, n_bmp *bmp )
{

	//n_bmp_new_fast( bmp, game.sx, game.sy );
	//n_bmp_flush( bmp, p->color_bg );

	//return;


	u32 bg = n_bmp_white;
	u32 fg = p->color_bg;

	if ( game.dwm_onoff )
	{
		bg = n_bmp_black_invisible;
		fg = n_bmp_white;
	}


	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = game.sx;
	gdi.sy                  = game.sy;

	gdi.base_color_bg       = bg;
	gdi.base_color_fg       = fg;
	gdi.base_style          = N_GDI_BASE_VERTICAL;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );
//n_bmp_save_literal( bmp, "bg.bmp" );


	return;
}

void
n_hunyapiyo3_gdi_clickhere( n_hunyapiyo3 *p, n_bmp *bmp, int fontsize, int contoursize )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%s", n_posix_literal( "Click!" ) );

	gdi.base_color_bg       = n_bmp_white_invisible;

	if ( game.dwm_onoff )
	{
		gdi.base_color_bg = n_bmp_black_invisible;
	}

	gdi.text                = str;
	gdi.text_font           = n_hunyapiyo3_stdfont();
	gdi.text_size           = fontsize;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = p->color_text;
	gdi.text_color_contour  = p->color_contour;
	gdi.text_fxsize2        = contoursize;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_hunyapiyo3_gdi_countdown( n_hunyapiyo3 *p, n_bmp *bmp, int number, int fontsize, int contoursize )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d", number );

	gdi.base_color_bg       = n_bmp_white_invisible;

	if ( game.dwm_onoff )
	{
		gdi.base_color_bg = n_bmp_black_invisible;
	}

	gdi.text                = str;
	gdi.text_font           = n_hunyapiyo3_stdfont();
	gdi.text_size           = fontsize;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = p->color_text;
	gdi.text_color_contour  = p->color_contour;
	gdi.text_fxsize2        = contoursize;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_hunyapiyo3_gdi_question( n_hunyapiyo3 *p, n_bmp *bmp, int size, int fontsize, int contoursize )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%s", n_posix_literal( "?" ) );

	gdi.sx                  = size;
	gdi.sy                  = size;

	gdi.base_color_bg       = n_bmp_white_invisible;

	if ( game.dwm_onoff )
	{
		gdi.base_color_bg = n_bmp_black_invisible;
	}

	gdi.text                = str;
	gdi.text_font           = n_hunyapiyo3_stdfont();
	gdi.text_size           = fontsize;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = p->color_text;
	gdi.text_color_contour  = p->color_contour;
	gdi.text_fxsize2        = contoursize;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_hunyapiyo3_gdi_percent( n_hunyapiyo3 *p, n_bmp *bmp, int percent, int fontsize, int contoursize )
{

	n_gdi gdi; n_gdi_zero( &gdi );


	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%d%%", percent );

	gdi.base_color_bg       = n_bmp_white_invisible;

	if ( game.dwm_onoff )
	{
		gdi.base_color_bg = n_bmp_black_invisible;
	}

	gdi.text                = str;
	gdi.text_font           = n_hunyapiyo3_stdfont();
	gdi.text_size           = fontsize;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = p->color_text;
	gdi.text_color_contour  = p->color_contour;
	gdi.text_fxsize2        = contoursize;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_hunyapiyo3_gdi_frame( n_hunyapiyo3 *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;

	gdi.frame_style         = N_GDI_FRAME_FLAT;

	gdi.base_color_bg       = n_gdi_systemcolor( COLOR_BTNFACE );
	gdi.base_style          = N_GDI_BASE_SOLID;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_hunyapiyo3_gdi_button( n_hunyapiyo3 *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, n_posix_char *str, u32 fg, n_bool is_pressed )
{

	int              cb = sizeof( NONCLIENTMETRICS );
	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.scale               = n_posix_max_s32( 1, n_win_dpi( game.hwnd ) / 75 );

	gdi.base_color_fg       = fg;
	gdi.base_color_bg       = n_bmp_rgb( 236,233,216 );
	gdi.base_style          = N_GDI_BASE_LUNA;

	if ( is_pressed )
	{
		gdi.base_style = N_GDI_BASE_LUNA_PRESS;
	}

	gdi.frame_style         = N_GDI_FRAME_LUNA;

	gdi.text                = str;
	gdi.text_color_main     = n_gdi_systemcolor( COLOR_BTNTEXT );
	gdi.text_font           = ncm.lfMessageFont.lfFaceName;
	gdi.text_size           = ncm.lfMessageFont.lfHeight;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;

	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}


