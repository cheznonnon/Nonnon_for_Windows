
@echo off

set compile=..\nonnon\project\compile.bat
set    name=simplemenu
set  window=-mwindows

%compile%

