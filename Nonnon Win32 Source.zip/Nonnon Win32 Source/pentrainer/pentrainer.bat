
@echo off

set compile=..\nonnon\project\compile.bat
set    name=pentrainer
set  window=-mwindows

%compile%

