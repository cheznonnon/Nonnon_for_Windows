
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nmemo
set  window=-mwindows

%compile%

