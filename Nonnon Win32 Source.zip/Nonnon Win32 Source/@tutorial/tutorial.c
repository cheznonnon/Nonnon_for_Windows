// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );

		n_win_gui_literal( hwnd, N_WIN_GUI_BUTTON, "Button", &hgui );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		n_type_gfx ctl; n_win_stdsize( hwnd, NULL, &ctl, NULL );

		n_type_gfx sx = 100;
		n_type_gfx sy = ctl;

		n_win_move( hgui, ( w.csx - sx ) / 2, ( w.csy - sy ) / 2, sx,sy, n_posix_true );

	}
	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hgui )
		{
			n_posix_debug_literal( "%s", n_posix_literal( "Hello!" ) );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


