
@echo off

set compile=..\nonnon\project\compile.bat
set    name=inputpopup
set  window=-mwindows

%compile%

