// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define n_oc_item_zero( p ) n_memory_zero( p, sizeof( n_oc_item ) )

n_bool
n_oc_item_error( n_oc_item *p )
{

	if ( p == NULL ) { return n_true; }


	return n_false;
}

n_type_real
n_oc_item_orangecat2scroll( n_oc_item *p, n_type_real pos )
{

	n_type_real ret;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		ret = n_oc_orangecat2scroll( pos, p->sx );
	} else {
		ret = n_oc_orangecat2scroll( pos, p->sy );
	}

	return ret;
}

n_type_real
n_oc_item_scroll2orangecat( n_oc_item *p, n_type_real pos )
{

	n_type_real ret;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		ret = n_oc_scroll2orangecat( pos, p->sx );
	} else {
		ret = n_oc_scroll2orangecat( pos, p->sy );
	}

	return ret;
}

void
n_oc_item_scan_index( n_oc_item *p, n_type_int *fr, n_type_int *to, n_bool is_loading )
{

	n_type_int i = (n_type_int) ( ( oc.scrollbar.unit_pos / oc.scrollbar.unit_page ) * p->scroll_item_per_page );
	n_type_int l = (n_type_int) ( p->scroll_item_per_line * 2 );

	n_type_int f = n_posix_minmax_n_type_int( 0, p->count, i                                        - l );
	n_type_int t = n_posix_minmax_n_type_int( 0, p->count, i + (n_type_int) p->scroll_item_per_page + l );
/*
	// [x] : buggy

	if ( ( is_loading )&&( f < p->count )&&( t < p->count ) )
	{
		n_type_int c = 0;
		n_type_int n = f;
		n_posix_loop
		{

			if ( p->load_item[ n ] == N_ORANGECAT_LOAD_DONE ) { c++; }

			n++;
			if ( n >= t ) { break; }
		}

		if ( c == ( t - f ) )
		{
			f = p->load_index;
			t = p->count;
		}
	}
*/
	if ( fr != NULL ) { (*fr) = f; }
	if ( to != NULL ) { (*to) = t; }


	return;
}

void
n_oc_item_zebrastripe( n_oc_item *p )
{

	p->zebra_onoff = n_false;

	// [x] : not supported : maybe impossible
	if ( oc.dwm_onoff ) { return; }

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH ) { p->zebra_onoff = n_true; } else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE ) { p->zebra_onoff = n_true; } else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE ) { p->zebra_onoff = n_true; }// else


	return;
}

u32
n_oc_item_color_bg( n_oc_item *p, n_type_int index )
{

	// Zebra Stripe

	u32 color_zebra = oc_color.bg;

	if ( n_oc_item_error( p ) ) { return color_zebra; }

	n_oc_item_zebrastripe( p );

	if ( p->zebra_onoff )
	{
		if ( index & 1 )
		{
			color_zebra = oc_color.item_zebra;
		}
	}

	return color_zebra;
}

void
n_oc_item_debug_fade_color( n_oc_item *p, n_type_int index )
{

	n_posix_debug_literal
	(
		" %x %x %x %x ",
		oc_color.item_zebra,
		n_oc_item_color_bg( p, index ),
		p->fade[ index ].color_fg,
		p->fade[ index ].color_bg
	);


	return;
}

n_bool
n_oc_item_fade_is_stopped( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return n_true; }


	if ( p->count <= 0 ) { return n_true; }


	n_type_int stop = 0;


	n_type_int i = 0;
	n_posix_loop
	{//break;


		n_bmp_fade *fade = &p->fade[ i ];

		if ( fade->stop ) { stop++; }


		i++;
		if ( i >= p->count ) { break; }
	}


	return ( stop == p->count );
}

void
n_oc_item_fade( n_oc_item *p, n_bool redraw )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }


//oc_color.item_focus = n_bmp_rgb( 255, 0, 0 );

	n_type_int stop = 0;


	n_type_int i = 0;
	n_posix_loop
	{

		n_bmp_fade *fade = &p->fade[ i ];

		if ( p->multifocus[ i ] )
		{
			n_bmp_fade_go( fade, oc_color.item_focus );
		} else
		if ( p->hover == i )
		{
			n_bmp_fade_go( fade, oc_color.item_hover );
		} else {
			n_bmp_fade_go( fade, n_oc_item_color_bg( p, i ) );
		}

		if ( fade->stop )
		{
			stop++;
		} else {
			if ( redraw )
			{
				n_oc_item_draw_single( p, i, n_false );
			}
		}


		i++;
		if ( i >= p->count ) { break; }
	}


	// [Patch] : n_oc_item_on_click() : prevent redraw too many times
	//
	//	Win9x/NT4 : a cursor flicker will be better

	if ( ( redraw )&&( stop != p->count ) )
	{
		n_game_refresh_on();
	}


	return;
}

void
n_oc_item_fade_partial( n_oc_item *p, n_bool redraw )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }


//oc_color.item_focus = n_bmp_rgb( 255, 0, 0 );

	n_type_int stop = 0;


	n_type_int index_f, index_t; n_oc_item_scan_index( &item, &index_f, &index_t, n_false );
	n_posix_loop
	{

		if ( index_f >= index_t ) { break; }


		n_bmp_fade *fade = &p->fade[ index_f ];

		if ( p->multifocus[ index_f ] )
		{
			n_bmp_fade_go( fade, oc_color.item_focus );
		} else
		if ( p->hover == index_f )
		{
			n_bmp_fade_go( fade, oc_color.item_hover );
		} else {
			n_bmp_fade_go( fade, n_oc_item_color_bg( p, index_f ) );
		}

		if ( fade->stop ) { stop++; }

		if ( redraw ) { n_oc_item_draw_single( p, index_f, n_false ); }


		index_f++;

	}


	// [Patch] : n_oc_item_on_click() : prevent redraw too many times
	//
	//	Win9x/NT4 : a cursor flicker will be better

	if ( ( redraw )&&( stop != p->count ) ) { n_game_refresh_on(); }


	return;
}

n_type_int
n_oc_item_index2path_cch( n_oc_item *p, n_type_int index )
{

	if ( n_oc_item_error( p ) ) { return 0; }


	if (
		( p->count <= 0 )
		||
		( ( index < 0 )||( index >= p->count ) )
	)
	{
		return 0;
	}


	n_type_int ret = 0;

	if ( oc.view_is_computer )
	{

		n_posix_char *s = n_dir_name( &p->dir, index );

		if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, s ) )
		{
			ret = n_posix_strlen( oc.cpnl );
		} else
		if ( n_string_is_same( N_ORANGECAT_SETTINGS,     s ) )
		{
			ret = n_posix_strlen( N_ORANGECAT_SETTINGS_EXE );
		} else
		if ( n_string_is_same( N_ORANGECAT_SHUTDOWN,     s ) )
		{
			ret = n_posix_strlen( N_ORANGECAT_SHUTDOWN_EXE );
		} else {
			ret = n_posix_strlen( s );
		}

	} else {

		ret = n_string_path_make_cch( n_dir_path( &p->dir, index ), n_dir_name( &p->dir, index ) );

	}


	return ret;
}

void
n_oc_item_index2path( n_oc_item *p, n_type_int index, n_posix_char *path )
{

	if ( n_oc_item_error( p ) ) { return; }


	if (
		( p->count <= 0 )
		||
		( ( index < 0 )||( index >= p->count ) )
	)
	{

		n_string_copy( N_STRING_EMPTY, path );

		return;
	}


	if ( oc.view_is_computer )
	{

		n_posix_char *s = n_dir_name( &p->dir, index );

		if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, s ) )
		{
			n_string_copy( oc.cpnl, path );
		} else
		if ( n_string_is_same( N_ORANGECAT_SETTINGS,     s ) )
		{
			n_string_copy( N_ORANGECAT_SETTINGS_EXE, path );
		} else
		if ( n_string_is_same( N_ORANGECAT_SHUTDOWN,     s ) )
		{
			n_string_copy( N_ORANGECAT_SHUTDOWN_EXE, path );
		} else {
			n_string_copy( s, path );
		}

	} else {

		n_string_path_make( n_dir_path( &p->dir, index ), n_dir_name( &p->dir, index ), path );

	}


	return;
}

n_posix_char*
n_oc_item_index2path_new( n_oc_item *p, n_type_int index )
{

	// [!] : you need to n_string_path_free() a returned variable

	n_type_int    cch = n_oc_item_index2path_cch( p, index );
	n_posix_char *ret = n_string_path_new( cch );


	n_oc_item_index2path( p, index, ret );


	return ret;
}

n_type_int
n_oc_item_path2index( n_oc_item *p, n_posix_char *path )
{

	n_type_int i = 0;
	n_posix_loop
	{//break;

		if ( i >= p->count ) { break; }


		n_bool is_found = n_false;

		n_posix_char *str = n_string_path_carboncopy( path );
//n_posix_debug_literal( "%s\n%s", n_dir_name( &p->dir, i ), str );

		if ( oc.view_is_computer )
		{
			//
		} else {
			n_string_path_name( str, str );
		}

		if ( n_string_is_same( n_dir_name( &p->dir, i ), str ) )
		{
			is_found = n_true;
		}

		n_string_path_free( str );

		if ( is_found ) { break; }


		i++;

	}


	return i;
}

void
n_oc_item_patch_hover_on( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( p->hover != N_ORANGECAT_NOTHING ) { p->patch_forced_hover = p->hover; }


	return;
}

void
n_oc_item_patch_focus_on( n_oc_item *p, n_bool autoscroll )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( 0 < n_oc_item_multifocus_count( p ) )
	{
		n_memory_copy( p->multifocus, p->patch_forced_focus, sizeof( n_bool ) * p->count );

		if ( autoscroll )
		{
			n_type_int index = n_oc_item_multifocus_single( p );
			n_oc_item_autoscroll( p, index, N_OC_ITEM_AUTOSCROLL_SMART );
		}
	}


	return;
}

void
n_oc_item_sort( n_oc_item *p, int option )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_dir *d = &p->dir;
	if ( 1 >= n_dir_all( d ) ) { return; }


	n_type_int i  = 0;
	n_type_int ii = i + 1;
	n_posix_loop
	{
//n_posix_debug_literal( "%s\n%s", n_dir_name( d, i ), n_dir_name( d, ii ) );

		n_bool is_swapped = n_dir_swap( d, i, ii, option );

		if ( is_swapped )
		{
			n_memory_element_swap( p->bmp               , sizeof( n_bmp      ), i, ii );
			n_memory_element_swap( p->fade              , sizeof( n_bmp_fade ), i, ii );
			n_memory_element_swap( p->multifocus        , sizeof( n_bool     ), i, ii );
			n_memory_element_swap( p->multifocus_move   , sizeof( n_bool     ), i, ii );
			n_memory_element_swap( p->multifocus_fade   , sizeof( n_bool     ), i, ii );
			n_memory_element_swap( p->patch_forced_focus, sizeof( n_bool     ), i, ii );
			n_memory_element_swap( p->patch_forced_frame, sizeof( n_type_int ), i, ii );
			n_memory_element_swap( p->sync_item         , sizeof( int        ), i, ii );
			n_memory_element_swap( p->sync_type         , sizeof( int        ), i, ii );
			n_memory_element_swap( p->load_item         , sizeof( int        ), i, ii );
		}

		ii++;
		if ( ii >= n_dir_all( d ) )
		{

			i++;
			if ( i >= ( n_dir_all( d ) - 1 ) ) { break; }

			ii = i + 1;

		}
	}


	n_oc_item_fade( p, n_true );


	return;
}

void
n_oc_item_sort_go( n_oc_item *p )
{

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		n_oc_item_sort( p, N_DIR_SWAP_EXT );
		n_oc_item_sort( p, N_DIR_SWAP_ALL );
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		n_oc_item_sort( p, N_DIR_SWAP_EXT );
		n_oc_item_sort( p, N_DIR_SWAP_ALL );
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	{
		n_oc_item_sort( p, N_DIR_SWAP_PATH );
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{
		n_oc_item_sort( p, N_DIR_SWAP_MTIME );
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
	{
		n_oc_item_sort( p, N_DIR_SWAP_SIZE );
	}


	return;
}

void
n_oc_item_add( n_oc_item *p, const n_posix_char *name )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( n_string_is_empty( name ) ) { return; }


	{

		p->count++;

		n_type_int index = 0;

		if ( oc.view_is_computer )
		{

			index = n_dir_add( &p->dir, oc.main, name, name );

		} else {

			n_posix_char *abspath = n_string_path_make_new( oc.main, name );

			index = n_dir_add( &p->dir, oc.main, name, abspath );
//n_posix_debug_literal( " %d : %s ", index, name );
			n_string_path_free( abspath );

		}


		p->bmp                = n_memory_element_add( p->bmp               , sizeof( n_bmp      ), p->count, index );
		p->fade               = n_memory_element_add( p->fade              , sizeof( n_bmp_fade ), p->count, index );
		p->multifocus         = n_memory_element_add( p->multifocus        , sizeof( n_bool     ), p->count, index );
		p->multifocus_move    = n_memory_element_add( p->multifocus_move   , sizeof( n_bool     ), p->count, index );
		p->multifocus_fade    = n_memory_element_add( p->multifocus_fade   , sizeof( n_bool     ), p->count, index );
		p->patch_forced_focus = n_memory_element_add( p->patch_forced_focus, sizeof( n_bool     ), p->count, index );
		p->patch_forced_frame = n_memory_element_add( p->patch_forced_frame, sizeof( n_type_int ), p->count, index );
		p->sync_item          = n_memory_element_add( p->sync_item         , sizeof( int        ), p->count, index );
		p->sync_type          = n_memory_element_add( p->sync_type         , sizeof( int        ), p->count, index );
		p->load_item          = n_memory_element_add( p->load_item         , sizeof( int        ), p->count, index );

		n_bmp_fade_init( &p->fade[ index ], n_oc_item_color_bg( p, index ) );
//n_oc_item_debug_fade_color( p, index );

		extern void n_oc_item_sync_resync( n_oc_item*, n_type_int );
		n_oc_item_sync_resync( p, index );

		extern void n_oc_item_preload_single_internal( n_oc_item*, n_type_int, n_bool, n_bool );
		n_oc_item_preload_single_internal( p, index, n_false, n_true );

//n_oc_item_sync_reset( p );

	}


	n_oc_item_sort_go( p );


	return;
}

void
n_oc_item_del( n_oc_item *p, n_type_int index )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( index < 0 ) { return; }

	if ( p->count <= 0 ) { return; }


	p->multifocus[ index ] = n_false;

	if ( p->hover == index ) { p->hover = N_ORANGECAT_NOTHING; }// else { n_posix_debug_literal( " ! " ); }
	if ( p->drag  == index ) { p->drag  = N_ORANGECAT_DRAG_NEUTRAL; }


	p->sync_index = p->load_index = 0;

	n_oc_item_progressbar_reset( &p->progress_sync, N_ITASKBARLIST_MODE_GREEN );


	n_dir_del( &p->dir, index );

	n_bmp_free( &p->bmp[ index ] );

	p->bmp                = n_memory_element_del( p->bmp               , sizeof( n_bmp      ), p->count, index );
	p->fade               = n_memory_element_del( p->fade              , sizeof( n_bmp_fade ), p->count, index );
	p->multifocus         = n_memory_element_del( p->multifocus        , sizeof( n_bool     ), p->count, index );
	p->multifocus_move    = n_memory_element_del( p->multifocus_move   , sizeof( n_bool     ), p->count, index );
	p->multifocus_fade    = n_memory_element_del( p->multifocus_fade   , sizeof( n_bool     ), p->count, index );
	p->patch_forced_focus = n_memory_element_del( p->patch_forced_focus, sizeof( n_bool     ), p->count, index );
	p->patch_forced_frame = n_memory_element_del( p->patch_forced_frame, sizeof( n_type_int ), p->count, index );
	p->sync_item          = n_memory_element_del( p->sync_item         , sizeof( int        ), p->count, index );
	p->sync_type          = n_memory_element_del( p->sync_type         , sizeof( int        ), p->count, index );
	p->load_item          = n_memory_element_del( p->load_item         , sizeof( int        ), p->count, index );


	p->count--;
	p->load_count--;


	return;
}

void
n_oc_item_gdi2bitmap_dwm_shadow( n_oc_item *p, n_bmp *bmp, n_type_real ratio )
{

	// [!] : no error check for performance

	if ( oc.dwm_onoff == n_false ) { return; }


	const n_type_gfx sx = N_BMP_SX( bmp );
	const n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );
		int alpha = n_bmp_a( color );

		if (
			( alpha != N_BMP_ALPHA_CHANNEL_VISIBLE   )
			&&
			( alpha != N_BMP_ALPHA_CHANNEL_INVISIBLE )
		)
		{
			alpha = n_bmp_blend_channel( alpha, N_BMP_ALPHA_CHANNEL_VISIBLE, ratio );
			color = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_ptr_set_fast( bmp, x,y, color );
		}

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

// internal
void
n_oc_item_gdi2bitmap_make( n_oc_item *p, n_gdi *gdi, n_bmp *bmp, n_type_int index )
{

	if ( n_win_darkmode_onoff )
	{

		gdi->base_color_bg = n_bmp_white_invisible;

	} else {

		gdi->base_color_bg = oc_color.bg;

		if ( p->zebra_onoff )
		{
			if ( index & 1 ) { gdi->base_color_bg = n_oc_item_color_bg( p, index ); }
		}

	}


	n_bool rc_resolve_removed = n_false;

	if ( oc.view_is_computer )
	{
		if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, gdi->text ) )
		{
			rc_resolve_removed = n_true;
			gdi->icon_style &= ~N_GDI_ICON_RC_RESOLVE;
		} else
		if ( n_string_is_same( N_ORANGECAT_SHUTDOWN    , gdi->text ) )
		{
			rc_resolve_removed = n_true;
			gdi->icon_style &= ~N_GDI_ICON_RC_RESOLVE;
		}
	} else {
		if ( n_oc_patch_is_recyclebin( gdi->text ) )
		{
			rc_resolve_removed = n_true;
			gdi->icon_style &= ~N_GDI_ICON_RC_RESOLVE;
		}
	}


	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
	{

		n_bmp bmp_ico; n_bmp_zero( &bmp_ico );
		n_bmp bmp_txt; n_bmp_zero( &bmp_txt );
		n_bmp bmp_sub; n_bmp_zero( &bmp_sub );

		n_gdi gdi_ico; n_gdi_alias( gdi, &gdi_ico ); gdi_ico.text = NULL;
		n_gdi gdi_txt; n_gdi_alias( gdi, &gdi_txt ); gdi_txt.icon = NULL; gdi_txt.sx = gdi_txt.sy = 0;
		n_gdi gdi_sub; n_gdi_alias( gdi, &gdi_sub ); gdi_sub.icon = NULL; gdi_sub.sx = gdi_sub.sy = 0;

		n_posix_char str_sub[ 100 ];

		if ( oc.view_is_computer )
		{

			if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, gdi->text ) )
			{
				n_posix_sprintf_literal( str_sub, "Shortcut" );
			} else
			if ( n_string_is_same( N_ORANGECAT_SETTINGS,     gdi->text ) )
			{
				n_posix_sprintf_literal( str_sub, "Shortcut" );
			} else
			if ( n_string_is_same( N_ORANGECAT_SHUTDOWN,     gdi->text ) )
			{
				n_posix_sprintf_literal( str_sub, "Shortcut" );
			} else {
//n_posix_sprintf_literal( str_sub, "%s", gdi->text );

				u64 disksize = 0;
				u64 freesize = 0;
				u64 usedsize = 0;

				n_posix_char *name = n_dir_name( &p->dir, index );

				// [x] : error dialog will appear when ejected

				if ( n_false == n_sysinfo_drive_is_empty( name ) )
				{
					n_sysinfo_drive_size( name, &disksize, &freesize );
				}

				usedsize = disksize - freesize;

				n_type_real gigabyte_disk = (n_type_real) disksize / 1000 / 1000 / 1000;
				n_type_real gigabyte_used = (n_type_real) usedsize / 1000 / 1000 / 1000;

				n_posix_sprintf_literal( str_sub, "%.3f GB / %.3f GB", gigabyte_used, gigabyte_disk );
			}

		} else {

			n_posix_char *name = n_oc_item_index2path_new( p, index );

			extern void n_oc_info_file_size( const n_posix_char*, n_posix_char* );
			n_oc_info_file_size( name, str_sub );

			n_string_path_free( name );

		}

		gdi_sub.text = str_sub;

		//gdi_sub.text_style      = gdi_sub.text_style & ~( N_GDI_TEXT_BOLD | N_GDI_TEXT_CLEAR );
		gdi_sub.text_color_main = n_bmp_blend_pixel( oc_color.bg, oc_color.item_text, 0.75 );


		n_gdi_bmp( &gdi_ico, &bmp_ico );
		n_gdi_bmp( &gdi_txt, &bmp_txt );
		n_gdi_bmp( &gdi_sub, &bmp_sub );


		n_type_gfx ico_sx = N_BMP_SX( &bmp_ico );
		n_type_gfx ico_sy = N_BMP_SY( &bmp_ico );

		n_type_gfx txt_sx = N_BMP_SX( &bmp_txt );
		n_type_gfx txt_sy = N_BMP_SY( &bmp_txt );

		n_type_gfx sub_sx = N_BMP_SX( &bmp_sub );
		n_type_gfx sub_sy = N_BMP_SY( &bmp_sub );

		n_type_gfx sx = ico_sx + n_posix_max_n_type_gfx( txt_sx, sub_sx ) + ( (n_type_gfx) ( p->ox * 2 ) );
		n_type_gfx sy = n_posix_max_n_type_gfx( ico_sy, txt_sy + sub_sy );

		n_bmp_new( bmp, sx,sy ); n_bmp_flush( bmp, n_bmp_white_invisible );

		n_type_gfx oy = ( sy / 2 ) - ( ico_sy / 2 );

		n_bmp_fastcopy( &bmp_ico, bmp, 0,0,ico_sx,ico_sy,      0,oy ); oy = ( sy / 2 ) - txt_sy;
		n_bmp_fastcopy( &bmp_txt, bmp, 0,0,txt_sx,txt_sy, ico_sx,oy ); oy = ( sy / 2 );
		n_bmp_fastcopy( &bmp_sub, bmp, 0,0,sub_sx,sub_sy, ico_sx,oy );

		n_bmp_free( &bmp_ico );
		n_bmp_free( &bmp_txt );
		n_bmp_free( &bmp_sub );

		p->cell_sy_custom = N_BMP_SY( bmp );

	} else {

		if ( oc.debug_icon )
		{
			gdi->icon_loaded_bpp  = -1;
			gdi->icon_loaded_size = -1;
		}

		n_gdi_bmp( gdi, bmp );
//n_bmp_new( bmp, 32,32 );

//n_posix_char *name = n_string_path_name_new( gdi->icon );
//n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "./_empty/%s.bmp", name );
//n_bmp_save( bmp, str );
//n_string_path_free( name );

		if ( oc.debug_drag2select_onoff )
		{
			n_posix_char str[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str, index );

			n_gdi gdi_number; n_gdi_zero( &gdi_number );

			gdi_number.sx                 = gdi->sx;
			gdi_number.sy                 = gdi->sy;
			gdi_number.text_style         = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD | N_GDI_TEXT_CONTOUR;
			gdi_number.text               = str;
			gdi_number.text_size          = n_oc_font_size;
			gdi_number.text_color_main    = n_bmp_rgb( 255,255,255 );
			gdi_number.text_color_contour = n_bmp_rgb(  10, 10, 10 );
			gdi_number.text_fxsize2       = oc.view_text_fxsize * 2;

			n_bmp bmp_number; n_bmp_zero( &bmp_number );
			n_gdi_bmp( &gdi_number, &bmp_number );

			n_bmp_flush_transcopy( &bmp_number, bmp );

			n_bmp_free_fast( &bmp_number );
		}

		if ( oc.debug_icon )
		{
			n_type_gfx icon_x  = gdi->icon_x;
			n_type_gfx icon_y  = gdi->icon_y;
			n_type_gfx icon_sx = gdi->icon_sx;
			n_type_gfx icon_sy = gdi->icon_sy;

			n_posix_char str[ 100 ];
			if ( gdi->icon_loaded_bpp == -1 )
			{
				n_posix_sprintf_literal( str, "%s", n_posix_literal( "Image" ) );
			} else
			if ( gdi->icon_loaded_bpp == N_CURICO_LOADED_PNG )
			{
				n_posix_sprintf_literal( str, "PNG\n%d px", (int) gdi->icon_loaded_size );
			} else {
				n_posix_sprintf_literal( str, "%d bpp\n%d px", (int) gdi->icon_loaded_bpp, (int) gdi->icon_loaded_size );
			}

			n_gdi gdi_number; n_gdi_zero( &gdi_number );

			//gdi_number.sx                 = gdi->sx;
			//gdi_number.sy                 = gdi->sy;
			//gdi_number.frame_style        = N_GDI_FRAME_SIMPLE;
			gdi_number.text_style         = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD | N_GDI_TEXT_CONTOUR;
			gdi_number.text               = str;
			gdi_number.text_size          = n_oc_font_size;
			gdi_number.text_color_main    = n_bmp_rgb( 255,255,255 );
			gdi_number.text_color_contour = n_bmp_rgb(   0,100,150 );
			gdi_number.text_fxsize2       = oc.view_text_fxsize * 2;

			n_bmp bmp_number; n_bmp_zero( &bmp_number );
			n_gdi_bmp( &gdi_number, &bmp_number );

			n_type_gfx x = icon_x + n_game_centering( icon_sx, gdi_number.sx );
			n_type_gfx y = icon_y + n_game_centering( icon_sy, gdi_number.sy );

			n_bmp_transcopy( &bmp_number, bmp, 0,0,gdi_number.sx,gdi_number.sy, x,y );

			n_bmp_free_fast( &bmp_number );
		}

		p->cell_sy_custom = gdi->sy;

//static int i = 0; if ( i == 52 ) { n_bmp_save_literal( bmp, "bmp.bmp" ); } i++;

	}


	if ( rc_resolve_removed )
	{
		gdi->icon_style |= N_GDI_ICON_RC_RESOLVE;
	}


	//extern void n_oc_item_on_resize( n_oc_item *p );
	//n_oc_item_on_resize( p );


	return;
}

n_posix_char*
n_oc_item_drivename_new( n_oc_item *p, n_posix_char *abspath )
{

	n_posix_char label[ 100 ]; n_string_zero( label, 100 );
	n_sysinfo_drive_name( abspath, label, 100 );

	n_posix_char *str = n_string_path_new( 100 );

	n_posix_sprintf_literal( str, "(%s) %s", abspath, label );

	n_string_replace( str, str, N_STRING_BSLASH, N_STRING_EMPTY );


	return str;
}

void
n_oc_item_gdi2bitmap( n_oc_item *p, n_type_int index )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }

	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	if ( p->load_item == NULL ) { return; }


	n_gdi gdi;

	{
		// [Needed] : multi-thread

		HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_oc_item_gdi2bitmap().0" );

		n_gdi_alias( &p->gdi, &gdi );

		hmutex = n_win_mutex_exit( hmutex );
	}


	n_bool is_allocated_icon = n_false;
	n_bool is_allocated_text = n_false;

	n_bool setting_patch     = n_false;

	if ( p->load_item[ index ] == N_ORANGECAT_LOAD_NONE )
	{

		p->load_item[ index ] = N_ORANGECAT_LOAD_INIT;
		gdi.icon_index        = 0;
		gdi.icon              = N_GDI_ICON_NAME_EMPTY;

	} else
	if ( p->load_item[ index ] == N_ORANGECAT_LOAD_INIT )
	{

		return;

	} else
	if ( p->load_item[ index ] == N_ORANGECAT_LOAD_MAIN )
	{
//return;

		p->load_count++;


		// [Mechanism] : why this will not be insufficient length
		//
		//	"shell32.dll"
		//	"C:\recycled"
		//	"C:\recycler"
		//	"C:\$Recycle.bin"

		n_posix_char *path_default = n_oc_item_index2path_new( p, index );


		p->load_item[ index ] = N_ORANGECAT_LOAD_DONE;

		gdi.icon              = n_oc_patch_iconpath_new  ( path_default, n_false );
		gdi.icon_index        = n_oc_patch_iconpath_index( path_default, n_false );

		is_allocated_icon     = n_true;


		// [x] : buggy : Settings has a 256px icon, but that is a blank icon

		if ( oc.view_is_computer )
		{
			if ( n_string_is_same( N_ORANGECAT_SETTINGS_EXE, path_default ) )
			{
				if ( gdi.icon_rsrc == 256 )
				{
					setting_patch = n_true;
					gdi.icon_rsrc = 64;
				}
			}
		}


		n_string_path_free( path_default );


//n_string_path_free( gdi.icon );
//gdi.icon       = n_string_alloccopy( 1024, L"C:\\windows\\system32\\shell32.dll" );
//gdi.icon       = n_string_alloccopy( 1024, L"orangecat.exe" );
//gdi.icon_index = 0;

	} else { return; }


	// Text

	n_posix_char *s = n_dir_name( &p->dir, index );

	if ( oc.view_is_computer )
	{

		if ( n_string_path_is_abspath( s ) )
		{

			gdi.text = n_oc_item_drivename_new( p, s );

			is_allocated_text = n_true;

		} else {

			gdi.text = s;

		}

	} else {

		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			gdi.text = s;
			if ( ( oc.lnk_onoff == n_false )&&( n_IShellLink_is_shortcut( gdi.text ) ) )
			{
				gdi.text = n_string_path_carboncopy( s );
				n_string_path_ext_del( gdi.text );
				is_allocated_text = n_true;
			}
		} else
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
		{
			gdi.text = s;
			if ( ( oc.lnk_onoff == n_false )&&( n_IShellLink_is_shortcut( gdi.text ) ) )
			{
				gdi.text = n_string_path_carboncopy( s );
				n_string_path_ext_del( gdi.text );
				is_allocated_text = n_true;
			}
		} else
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH )
		{
			gdi.text = n_oc_item_index2path_new( p, index );
			is_allocated_text = n_true;
		} else
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
		{
			const n_posix_char *dir  = n_dir_path( &p->dir, index );
			const n_posix_char *file = s;

			n_posix_char *path = n_string_path_make_new( dir, file );
			n_posix_char *date = n_string_path_new( 100 ); n_time_string_mtime( path, date );

			gdi.text = n_string_path_cat( date, n_posix_literal( " : " ), file, NULL );
			is_allocated_text = n_true;

			n_string_path_free( path );
			n_string_path_free( date );
		} else
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
		{
			gdi.text = s;
		}

	}


	// Done

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH ) { gdi.sx = 0; } else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE ) { gdi.sx = 0; } else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE ) { gdi.sx = 0; }// else

	//if ( p->load_item[ index ] == N_ORANGECAT_LOAD_DONE )
	{

		//HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_oc_item_gdi2bitmap().2" );


		// [!] : leak test
		//int *mem = n_memory_new( 100 );
		//if ( mem ) {}


		// [!] : sync test
		//if ( p->load_item[ index ] == N_ORANGECAT_LOAD_DONE )
		//{
		//	if ( index == 100 ) { n_posix_debug_literal( "" ); }
		//}


		n_oc_item_gdi2bitmap_make( p, &gdi, &p->bmp[ index ], index );

		n_oc_item_gdi2bitmap_dwm_shadow( p, &p->bmp[ index ], 0.25 );

		//hmutex = n_win_mutex_exit( hmutex );

	}


	if ( is_allocated_icon ) { n_string_path_free( gdi.icon ); gdi.icon = NULL; }
	if ( is_allocated_text ) { n_string_path_free( gdi.text ); gdi.text = NULL; }


	if ( setting_patch ) { gdi.icon_rsrc = 256; }


	{
		// [Needed] : multi-thread

		HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_oc_item_gdi2bitmap().1" );

		n_gdi_alias( &gdi, &p->gdi );

		hmutex = n_win_mutex_exit( hmutex );
	}


	return;
}

#define n_oc_item_preload_single( p, i, r ) n_oc_item_preload_single_internal( p, i, n_false, r )
#define n_oc_item_preload_silent( p, i, r ) n_oc_item_preload_single_internal( p, i, n_true , r )

void
n_oc_item_preload_single_internal( n_oc_item *p, n_type_int index, n_bool silent, n_bool redraw )
{
//if ( oc.view_is_computer ) { n_posix_debug_literal( " ! " ); }
//if ( index <= 0 ) { n_posix_debug_literal( " ! " ); }


	// [Needed] : multi-thread

	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	if ( p->load_count >= p->count ) { return; }

	if ( p->load_item[ index ] == N_ORANGECAT_LOAD_DONE ) { return; }


	p->load_item[ index ] = N_ORANGECAT_LOAD_MAIN;

	n_oc_item_gdi2bitmap( p, index );


	if ( silent == n_false )
	{
		n_bmp_fade_init( &p->fade[ index ], n_oc_item_color_bg( p, index ) );
	}


	if ( redraw )
	{
		n_oc_event_redraw_fast();
		//n_oc_item_draw_single( p, index, n_true );
		//n_game_refresh_on();
	}


	return;
}

void
n_oc_item_preload( n_oc_item *p, u32 interval, n_bool redraw )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }


	if ( interval == 0 )
	{
		n_oc_item_preload_single( p, p->load_index, redraw );

		return;
	}


	u32 timeout = n_posix_tickcount() + interval;
	n_posix_loop
	{

		n_oc_item_preload_single( p, p->load_index, redraw );

		if ( timeout < n_posix_tickcount() ) { break; }

		n_posix_sleep( 0 );

		p->load_index++;
		if ( p->load_index >= p->count ) { p->load_index = 0; }

		if ( p->load_count >= p->count ) { break; }

	}


	return;
}

void
n_oc_item_preload_all( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_type_int i = 0;
	n_posix_loop
	{
		if ( i >= p->count ) { break; }

		n_oc_item_preload_single( p, i, n_true );

		i++;
	}


	return;
}

void
n_oc_item_bitmap_free( n_oc_item *p )
{

	if ( p == NULL ) { return; }


	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= p->count ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		i++;

	}


	return;
}

void
n_oc_item_position_calculate( n_oc_item *p, n_type_int index, n_type_gfx *ret_x, n_type_gfx *ret_y, n_bool is_relative )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	if ( p->scroll_item_per_line <= 0 ) { return; }


	n_type_gfx x = (n_type_gfx) ( p->ox +            0 );
	n_type_gfx y = (n_type_gfx) ( p->oy + oc.unit_path );

	n_type_gfx item_per_line = (n_type_gfx) p->scroll_item_per_line;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{

		x += (n_type_gfx) ( p->cell_sx * ( index / item_per_line ) );
		y += (n_type_gfx) ( p->cell_sy * ( index % item_per_line ) );

		if ( is_relative ) { x -= (n_type_gfx) n_oc_item_scroll2orangecat( p, oc.scrollbar.unit_pos ); }

	} else {

		if ( n_win_is_lefthanded() ) { x += oc.unit_scrl; }

		x += (n_type_gfx) ( p->cell_sx * ( index % item_per_line ) );
		y += (n_type_gfx) ( p->cell_sy * ( index / item_per_line ) );

		if ( is_relative ) { y -= (n_type_gfx) n_oc_item_scroll2orangecat( p, oc.scrollbar.unit_pos ); }

	}


	if ( ret_x != NULL ) { (*ret_x) = x; }
	if ( ret_y != NULL ) { (*ret_y) = y; }


	return;
}

void
n_oc_item_on_resize( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	// [Needed] : launch by Name/Text Search

	p->view_type = oc.view_type;


	// Client Area Metrics

	p->sx = game.sx;
	p->sy = game.sy - oc.unit_path;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		p->sy -= oc.unit_scrl;
	} else {
		p->sx -= oc.unit_scrl;
	}

	p->sx = n_posix_max_n_type_real( 1, p->sx );
	p->sy = n_posix_max_n_type_real( 1, p->sy );


	// Scrollbar Metrics


	// [!] : set zero for "no margin"

	p->ox = p->oy = oc.unit_icon / 6;
//p->ox = p->oy = 0;


	if ( p->cell_sy_custom == 0 ) { p->cell_sy_custom = p->gdi.sy; }

	p->cell_sx = n_posix_max_n_type_real( 1, p->gdi.sx         + ( p->ox * 2 ) );
	p->cell_sy = n_posix_max_n_type_real( 1, p->cell_sy_custom + ( p->oy * 2 ) );

	n_type_gfx csx = (n_type_gfx) n_posix_max_n_type_real( p->cell_sx, p->sx - ( p->ox * 2 ) );
	n_type_gfx csy = (n_type_gfx) n_posix_max_n_type_real( p->cell_sy, p->sy - ( p->oy * 2 ) );

	n_type_gfx items_per_x = (n_type_gfx) n_posix_max_n_type_real( 1, trunc( (n_type_real) csx / p->cell_sx ) );
	n_type_gfx items_per_y = (n_type_gfx) n_posix_max_n_type_real( 1, trunc( (n_type_real) csy / p->cell_sy ) );
//n_game_hwndprintf_literal( " %d ", items_per_y );


	// [!] : Scrollbar

	n_type_real maxim = 0;
	n_type_real page  = 0;
	n_type_real step  = 0;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{

		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL;


		n_type_gfx x,y,sx,sy;

		 x = 0;
		 y = game.sy - oc.unit_scrl;
		sx = game.sx;
		sy = oc.unit_scrl;

		n_win_scrollbar_move( &oc.scrollbar, x,y,sx,sy, n_false );


		step  = p->cell_sx;
		maxim = p->cell_sx * ceil( (n_type_real) p->count / items_per_y );
		page  = p->cell_sx * items_per_x;

		maxim -= fmod( csx, p->cell_sx );
		maxim -= ( p->ox * 2 );

		p->scroll_item_per_line = items_per_y;
		p->scroll_item_per_page = items_per_x * items_per_y;


		n_win_scrollbar_parameter( &oc.scrollbar, step, page, maxim, oc.scrollbar.unit_pos, n_false );

	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{

		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_VERTICAL;


		n_type_gfx x,y,sx,sy;

		 x = game.sx - oc.unit_scrl;
		 y = oc.unit_path;
		sx = oc.unit_scrl;
		sy = game.sy - oc.unit_path;

		if ( n_win_is_lefthanded() ) { x = 0; }

		n_win_scrollbar_move( &oc.scrollbar, x,y,sx,sy, n_false );


		step  = p->cell_sy;
		maxim = p->cell_sy * ceil( (n_type_real) p->count / items_per_x );
		page  = p->cell_sy * items_per_y;

		maxim -= fmod( csy, p->cell_sy );
		maxim -= ( p->oy * 2 );

		p->scroll_item_per_line = items_per_x;
		p->scroll_item_per_page = items_per_x * items_per_y;


		n_win_scrollbar_parameter( &oc.scrollbar, step, page, maxim, oc.scrollbar.unit_pos, n_false );

//static n_bool first = n_true; if ( first ) { first = n_false; n_posix_debug_literal( " %g ", oc.scrollbar.rect_thumb.sx ); }
	} else
	//if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{

		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_VERTICAL;


		n_type_gfx x,y,sx,sy;

		 x = game.sx - oc.unit_scrl;
		 y = oc.unit_path;
		sx = oc.unit_scrl;
		sy = game.sy - oc.unit_path;

		if ( n_win_is_lefthanded() ) { x = 0; }

		n_win_scrollbar_move( &oc.scrollbar, x,y,sx,sy, n_false );


		step  = p->cell_sy;
		maxim = p->cell_sy * ceil( (n_type_real) p->count / 1 );
		page  = p->cell_sy * items_per_y;

		maxim -= fmod( csy, p->cell_sy );
		maxim -= ( p->oy * 2 );

		p->scroll_item_per_line = 1;
		p->scroll_item_per_page = 1 * items_per_y;


		n_win_scrollbar_parameter( &oc.scrollbar, step, page, maxim, oc.scrollbar.unit_pos, n_false );

	}


	{
		static n_bool      pstate = n_false;
		static n_type_real scroll =  0;

		n_bool state = IsZoomed( game.hwnd );

		if ( pstate != state )
		{
			if (  state )
			{
				scroll = oc.scrollbar.unit_pos;
			} else
			if ( pstate )
			{
				oc.scrollbar.unit_pos = 0;
				n_win_scrollbar_scroll_unit( &oc.scrollbar, scroll, N_WIN_SCROLLBAR_SCROLL_SEND );
			}

			pstate = state;
		}
	}


	n_win_scrollbar_metrics( &oc.scrollbar );


	n_win_scrollbar_refresh( &oc.scrollbar );


	return;
}

void
n_oc_item_view_set_unitsize( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_type_gfx unit_icon = oc.unit_icon;

	if ( oc.view_gallery_size != 32 )
	{
//if ( p->sy == 0 ) { n_posix_debug_literal( " ! " ); }

		unit_icon           =  oc.view_gallery_size;
		p->gdi.icon_style  |=  oc.view_gallery_style;

	} else {

		unit_icon           =  oc.unit_icon;
		p->gdi.icon_style  &= ~oc.view_gallery_style;

	}

	p->gdi.icon_sx = p->gdi.icon_sy = unit_icon;


	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{

		p->gdi.sx = (n_type_gfx) ( (n_type_real) unit_icon * 4.00 );
		p->gdi.sy = (n_type_gfx) ( (n_type_real) unit_icon * 1.25 );

	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{

		p->gdi.sx = p->gdi.sy = (n_type_gfx) ( (n_type_real) unit_icon * 2.0 );

	} else
	//if ( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	//if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{

		p->gdi.sx = 0;
		p->gdi.sy = (n_type_gfx) ( (n_type_real) unit_icon * 1.25 );

	}

	n_oc_item_on_resize( p );


	return;
}

n_type_gfx
n_oc_item_lineselection( n_oc_item *p, n_type_gfx fsx )
{

	if (
		( p->view_type == N_ORANGECAT_VIEW_TYPE_PATH )
		||
		( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
		||
		( p->view_type == N_ORANGECAT_VIEW_TYPE_SIZE )
	)
	{
		if ( oc.lineselection_onoff )
		{
			fsx = n_posix_max_n_type_gfx( fsx, (n_type_gfx) ( p->sx - ( p->ox * 2 ) ) );
		}
	}


	return fsx;
}

void
n_oc_item_draw_single( n_oc_item *p, n_type_int index, n_bool always )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count <= 0 ) { return; }
	if ( ( index < 0 )||( index >= p->count ) ) { return; }


	if (
		( always == n_false )
		&&
		( p->load_count == p->count )
	)
	{
		if ( p->fade[ index ].stop ) { return; }
	}


	// Metric

	n_type_gfx tx = 0;
	n_type_gfx ty = 0;

	n_oc_item_position_calculate( p, index, &tx, &ty, n_true );


	// Fade Engine

	// [Needed] : for invisible items

	n_bmp_fade *fade = &p->fade[ index ];

	u32 fg = n_bmp_fade_engine( fade, oc.fade_onoff );

	if ( oc.view_is_key_operation )
	{
		fade->percent = 100;
	}

//n_game_hwndprintf_literal( " %d %d ", p->hover, p->patch_forced_hover );
	if ( p->patch_forced_focus[ index ] )
	{
		//fg = n_bmp_rgb( 0, 200, 255 );
		fg = oc_color.item_focus;

		if ( p->patch_forced_focus_change )
		{
			p->patch_forced_focus_change = n_false;

			p->patch_forced_focus[ index ] = n_false;
			p->multifocus        [ index ] = n_true;

			n_bmp_fade_init( fade, fg );
		}
	} else
	if ( p->patch_forced_hover == index )
	{
//n_game_debug_count();
		//fg = n_bmp_rgb( 0, 200, 255 );
		fg = oc_color.item_hover;
	}


	// Clipping

	if ( ( tx < -p->gdi.sx )||( tx >= ( p->sx + p->gdi.sx ) ) ) { return; }
	if ( ( ty < -p->gdi.sy )||( ty >= ( p->sy + p->gdi.sy ) ) ) { return; }


	// Bitmap Maker

	n_oc_item_gdi2bitmap( p, index );

	n_type_gfx fsx = N_BMP_SX( &p->bmp[ index ] );
	n_type_gfx fsy = N_BMP_SY( &p->bmp[ index ] );


	// Erase Background

	// [!] : round is on : focus frame will be larger than item size

	if ( p->is_blank == n_false )
	{
		n_type_gfx o  = -2;
		n_type_gfx oo =  4;
		n_bmp_box( &game.bmp, tx+o,ty+o,fsx+oo,fsy+oo, n_oc_item_color_bg( p, index ) );
	}


	// Focus Frame
//fg = 0;

	if ( ( p->noframe == n_false )||( fg != fade->color_fg ) )
	{

		n_bool draw = n_false;

		u32 outer = fg;
		u32 inner = fg;//oc_color.item_focus;

		n_type_gfx m = 0;

		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
		{
//n_game_hwndprintf_literal( " N_ORANGECAT_VIEW_FOCUS_ITEM " );

			if ( p->multifocus_move[ index ] )
			{
//n_game_hwndprintf_literal( " N_ORANGECAT_VIEW_FOCUS_ITEM : move " );

				inner = n_oc_item_color_bg( p, index );
				m     = oc.unit / 8;

				outer = n_bmp_blend_pixel( oc_color.item_key_i, inner, (n_type_real) fade->percent * 0.01 );

				if ( fade->percent == 100 )
				{
					p->multifocus_move[ index ] = n_false;
				}

				draw = n_true;

			} else
			if ( p->multifocus_fade[ index ] )
			{
//n_game_hwndprintf_literal( " N_ORANGECAT_VIEW_FOCUS_ITEM : fade " );

				inner = n_oc_item_color_bg( p, index );
				m     = oc.unit / 8;

				if ( fade->percent == 100 )
				{
					p->multifocus_fade[ index ] = n_false;
				}

				draw = n_true;

			} else {
//n_game_hwndprintf_literal( " %d %d ", oc.view_is_key_operation, index );

				if ( p->multifocus[ index ] )
				{
//n_game_hwndprintf_literal( " %d ", oc.view_is_key_operation );

					if ( oc.view_is_key_operation )
					{
						m     = oc.unit / 8;
						outer = n_bmp_blend_pixel( inner, oc_color.item_key_i, (n_type_real) fade->percent * 0.01 );

						oc.view_is_key_operation_fade_out = n_true;
					} else
					if ( oc.view_is_key_operation_fade_out )
					{
						m     = oc.unit / 8;
						outer = n_bmp_blend_pixel( oc_color.item_key_i, inner, (n_type_real) fade->percent * 0.01 );

						if ( fade->stop ) { oc.view_is_key_operation_fade_out = n_false; }
					}

				}

				draw = n_true;

			}

		} else
		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
		{
//n_game_hwndprintf_literal( " N_ORANGECAT_VIEW_FOCUS_PATH " );

//n_game_hwndprintf_literal( "%d", fade->percent );

			inner = n_oc_item_color_bg( p, index );
			m     = oc.unit / 8;

			if ( p->multifocus[ index ] )
			{
				outer = n_bmp_blend_pixel( inner, oc_color.item_key_i, (n_type_real) fade->percent * 0.01 );
			}

			draw = n_true;

		}

//if(m){}
		if ( draw )
		{

			n_type_gfx tmp_fsx = n_oc_item_lineselection( p, fsx );

			if ( p->patch_forced_frame[ index ] )
			{

				if ( fade->color_bg != n_oc_item_color_bg( p, index ) )
				{
					u32 inner = n_oc_item_color_bg( p, index );

					n_type_gfx m = oc.unit / 8;

					n_oc_frame_item_view( &game.bmp, tx,ty,tmp_fsx,fsy, m,oc.unit_rect, outer, inner );
				} else {
					n_oc_frame_item_view( &game.bmp, tx,ty,tmp_fsx,fsy, m,oc.unit_rect, outer, inner );
				}

				if ( fade->stop ) { p->patch_forced_frame[ index ] = n_false; }

			} else {
//inner = n_bmp_black;
				if ( inner == oc_color.bg )
				{
					//
				} else {
					n_oc_frame_item_view( &game.bmp, tx,ty,tmp_fsx,fsy, m,oc.unit_rect, outer, inner );
				}

			}


//n_bmp_squircle( &game.bmp, tx,ty,fsx,fsy, inner, 3.75 );

		}

	}

	if ( p->patch_forced_frame_phase == N_OC_ITEM_FORCED_FRAME_ON_2 )
	{
//n_game_hwndprintf_literal( " %d ", n_oc_item_multifocus_count_forced_frame( p ) );
		if ( 0 == n_oc_item_multifocus_count_forced_frame( p ) )
		{
			p->patch_forced_frame_phase = N_OC_ITEM_FORCED_FRAME_NONE;

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
			path.focus    = N_ORANGECAT_NOTHING;
		}
	}


	// Item

	n_bmp_transcopy( &p->bmp[ index ], &game.bmp, 0,0,fsx,fsy, tx,ty );


	// [!] : other components will be overwritten when hovered

	if ( ty <= oc.unit_path )
	{
		extern void n_oc_path_draw( n_oc_path* );
		n_oc_path_draw( &path );
	}

	if (
		(
			( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			&&
			( ( ty + fsy ) >= p->sy )
		)
		||
		(
			( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
			&&
			( ( tx + fsx ) >= p->sx )
		)
	)
	{

		n_win_scrollbar_refresh( &oc.scrollbar );

	}

	p->tooltip_percent = -1;


	game.simplemenu_refresh = n_true;


	return;
}

void
n_oc_item_exit( n_oc_item *p )
{

	if ( p == NULL ) { return; }


	n_thread_exit( p->tooltip_thread );


	n_dir_free( &p->dir );


	n_oc_item_bitmap_free( p );

	n_memory_free( p->bmp                );
	n_memory_free( p->fade               );
	n_memory_free( p->multifocus         );
	n_memory_free( p->multifocus_move    );
	n_memory_free( p->multifocus_fade    );
	n_memory_free( p->patch_forced_focus );
	n_memory_free( p->patch_forced_frame );

	n_oc_item_sync_exit( p );


	n_bmp_free( &p->tooltip_bmp );


	n_oc_item_zero( p );


	return;
}

void
n_oc_item_erase( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_type_gfx  x = 0;
	n_type_gfx  y = oc.unit_path;
	n_type_gfx sx = (n_type_gfx) p->sx;
	n_type_gfx sy = (n_type_gfx) p->sy;

	if ( n_win_is_lefthanded() )
	{
		 x += oc.unit_scrl;
		sx += oc.unit_scrl;
	}


	if ( p->is_blank == n_false )
	{

		p->is_blank = n_true;

		//n_bmp_box( &game.bmp, x,y,sx,sy, n_bmp_rgb( 0, 200, 255 ) );
		n_bmp_box( &game.bmp, x,y,sx,sy, game.color );

	}


	if ( p->zebra_onoff )
	{

		y += (n_type_gfx) p->cell_sy;

		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
		{
			y -= (n_type_gfx) n_oc_item_scroll2orangecat( p, oc.scrollbar.unit_pos );
		}

		n_posix_loop
		{

			n_bmp_box( &game.bmp, x, y, sx, (n_type_gfx) p->cell_sy, oc_color.item_zebra );

			y += (n_type_gfx) ( p->cell_sy * 2 );
			if ( y >= game.sy ) { break; }
		}

	}


	return;
}

void
n_oc_item_draw( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_type_int i = 0;
	n_posix_loop
	{//break;

		if ( i >= p->count ) { break; }

		//n_bmp_fade_redraw( &p->fade[ i ] );
		n_oc_item_draw_single( p, i, n_true );

//n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "./_empty/%d.bmp", i );
//n_bmp_save( &p->bmp[ i ], str );


		i++;

	}


	p->is_blank = n_false;


	n_game_refresh_on();
	return;
}

void
n_oc_item_gdi_set( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	n_gdi_zero( &p->gdi );

	p->gdi.sx                 = 0;
	p->gdi.sy                 = 0;
	p->gdi.style              = N_GDI_DEFAULT;
	p->gdi.align              = N_GDI_ALIGN_CENTER;

	p->gdi.base_color_bg      = n_oc_color_background( oc_color.bg, oc_color.item_focus );
	p->gdi.base_color_fg      = 0;
	p->gdi.base_style         = N_GDI_BASE_SOLID;

	p->gdi.frame_style        = N_GDI_FRAME_TRANS;

	p->gdi.icon               = n_posix_literal( "" );
	p->gdi.icon_index         = 0;
	p->gdi.icon_bpp           = oc.unit__bpp;
	p->gdi.icon_rsrc          = oc.unit_rsrc;
	p->gdi.icon_style         = oc.icon_resource;
	p->gdi.icon_fxsize1       = 0;
	p->gdi.icon_fxsize2       = oc.view_icon_fxsize;

	p->gdi.text               = n_posix_literal( "" );
	p->gdi.text_font          = n_oc_font_name;
	p->gdi.text_size          = n_oc_font_size;
	p->gdi.text_color_main    = oc_color.item_text;
	p->gdi.text_color_contour = oc_color.item_shadow;
	p->gdi.text_style         = n_oc_font_smooth | N_GDI_TEXT_NO_MARGIN;
	p->gdi.text_fxsize1       = 0;
	p->gdi.text_fxsize2       = oc.view_text_fxsize;


	// [Patch] : overridden by oc.view_type

	p->view_type = oc.view_type;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		p->gdi.align        = N_GDI_ALIGN_LEFT;
		p->gdi.layout       = N_GDI_LAYOUT_HORIZONTAL;
		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL;
	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{
		p->gdi.layout       = N_GDI_LAYOUT_VERTICAL;
		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_VERTICAL;
	} else
	//if ( p->view_type == N_ORANGECAT_VIEW_TYPE_DATE )
	{
		p->gdi.layout       = N_GDI_LAYOUT_HORIZONTAL;
		oc.scrollbar.layout = N_WIN_SCROLLBAR_LAYOUT_VERTICAL;
	}

	if ( oc.dwm_onoff == n_false )
	{
		p->gdi.icon_style |= N_GDI_ICON_FASTMODE;
	}


	return;
}

void
n_oc_item_view_set( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	// Layout

	n_oc_item_gdi_set( p );


	// Zebra Stripe

	n_oc_item_zebrastripe( p );


	// [Patch] : redraw error in an empty folder

	if ( p->count == 0 ) { p->is_blank = n_false; }


	// Unit Size

	n_oc_item_view_set_unitsize( p );


	// Sort

	if ( p->count != 0 )
	{

		n_posix_char *name_focus = n_oc_item_multifocus_focus2path_new( p );
//n_oc_item_multifocus_debug( name_focus );
		if ( name_focus == NULL ) { return; }

		n_oc_item_multifocus_off( p );

		n_oc_item_sort_go( p );

		n_oc_item_multifocus_path2focus( p, name_focus, n_false );

		if ( p->hover != N_ORANGECAT_NOTHING )
		{
//n_memory_zero( p->fade, p->count * sizeof( n_bmp_fade ) );
			n_bmp_fade_go( &p->fade[ p->hover ], n_oc_item_color_bg( p, p->hover ) );
			p->hover = N_ORANGECAT_NOTHING;
		}

		n_oc_item_sync_reset( p );

		n_string_path_free( name_focus );

	}


	return;
}

void
n_oc_item_view_change( n_oc_item *p )
{

	n_posix_char *str = n_oc_item_multifocus_focus2path_new( p );


	n_oc_item_view_set( p );


	if ( oc.global_thread_onoff )
	{
		n_oc_item_preload_thread_go( N_ORANGECAT_INTERVAL_INIT );
	} else {
		n_oc_item_preload( p, N_ORANGECAT_INTERVAL_INIT, n_false );
	}

	n_oc_item_multifocus_sync_image( p );


	// [ Needed ] : to make layout

	n_oc_item_on_resize( p );


	// [ Needed ] : path/date/size view to icon view

	oc.scrollbar.unit_pos = n_win_scrollbar_position_pixel2unit( &oc.scrollbar );


	n_oc_item_multifocus_path2focus_light( p, str, n_true, n_true );
	n_string_path_free( str );


	n_oc_event_redraw();


	return;
}

void
n_oc_item_gallery_set( n_oc_item *p, n_type_gfx size )
{

	oc.view_gallery_size = size;

//n_oc_event_init();

//extern void n_oc_event_on_init( void );
//n_oc_event_on_init();

	n_oc_item_bitmap_free( p );
	n_oc_item_view_change( p );
	n_oc_event_redraw();


	return;
}

void
n_oc_item_dir_load( n_oc_item *p, n_dir *dir )
{

	if ( p == NULL ) { return; }


	p->count_fake = 0;


	if ( oc.view_is_computer )
	{

		n_dir_load( dir, NULL );

		// [!] : add a fake entry

		n_vector_add( &dir->path, dir->dir, N_STRING_EMPTY );
		n_vector_add( &dir->name, dir->dir, N_ORANGECAT_CONTROLPANEL );
		n_vector_add( &dir->low,  dir->dir, N_ORANGECAT_CONTROLPANEL );
		n_vector_add( &dir->ext,  dir->dir, N_ORANGECAT_CONTROLPANEL );

		dir->file++;
		p->count_fake++;

		if ( n_sysinfo_version_8_or_later() )
		{

			n_vector_add( &dir->path, dir->dir, N_STRING_EMPTY );
			n_vector_add( &dir->name, dir->dir, N_ORANGECAT_SETTINGS );
			n_vector_add( &dir->low,  dir->dir, N_ORANGECAT_SETTINGS );
			n_vector_add( &dir->ext,  dir->dir, N_ORANGECAT_SETTINGS );

			dir->file++;
			p->count_fake++;

		}

		if ( n_sysinfo_version_xp_or_later() )
		{

			n_vector_add( &dir->path, dir->dir, N_STRING_EMPTY );
			n_vector_add( &dir->name, dir->dir, N_ORANGECAT_SHUTDOWN );
			n_vector_add( &dir->low,  dir->dir, N_ORANGECAT_SHUTDOWN );
			n_vector_add( &dir->ext,  dir->dir, N_ORANGECAT_SHUTDOWN );

			dir->file++;
			p->count_fake++;

		}

	} else {

		if ( n_dir_load( dir, oc.main ) )
		{
			n_dir_new( dir );
		}

//n_posix_debug_literal( "%d", n_dir_all( dir ) );

/*
n_type_int i = 0;
n_posix_loop
{
	n_posix_debug_literal( "%s", n_dir_name( dir, i ) );
	i++;
	if ( i >= n_dir_all( dir ) ) { break; }
}
*/
	}


	return;
}

typedef struct {

	n_dir      *dir;
	n_bool     *del;
	n_type_int  oy, cores;

} n_oc_item_find_thread_struct;

void
n_oc_item_find_thread_main( n_oc_item_find_thread_struct *p )
{

	n_posix_char *query = n_string_path_carboncopy( oc.find );
//n_posix_debug_literal( "%s", query );

	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_NAME )
	{

		n_string_lower( query, query );

		n_bool wildcard_onoff =
		(
			( n_string_search_simple_literal( query, "?" ) )
			||
			( n_string_search_simple_literal( query, "*" ) )
		);

		n_type_int i = p->oy;
		n_posix_loop
		{//break;

			// [!] : don't use MessageBox() in a thread

			if ( n_win_is_input( VK_ESCAPE ) ) { n_posix_sleep( 200 ); break; }


			if ( i >= n_dir_all( p->dir ) ) { break; }

			n_posix_char *s = n_dir_low( p->dir, i );

			if (
				(
					( wildcard_onoff )
					&&
					( n_string_wildcard( query, s ) )
				)
				||
				(
					( wildcard_onoff == n_false )
					&&
					( n_string_search_simple( s, query ) )
				)
			)
			{
				//
			} else {
				p->del[ i ] = n_true;
			}

			i += p->cores;

		}

	} else
	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_TEXT )
	{

		n_txt txt; n_txt_zero( &txt );

		n_type_int i = p->oy;
		n_posix_loop
		{//break;

			// [!] : don't use MessageBox() in a thread

			if ( n_win_is_input( VK_ESCAPE ) ) { n_posix_sleep( 200 ); break; }


			if ( i >= n_dir_all( p->dir ) ) { break; }

			n_posix_char *path = n_dir_path( p->dir, i );
			n_posix_char *name = n_dir_name( p->dir, i );
			n_posix_char *str  = n_string_path_make_new( path, name );

			n_oc_find_txt_load( &txt, str );

			n_string_path_free( str );

			if ( n_false == n_string_search_simple( txt.stream, query ) )
			{
				p->del[ i ] = n_true;
			}

			n_txt_free( &txt );

			i += p->cores;

		}

	}


	n_memory_free( query );


	return;
}

n_thread_return
n_oc_item_find_thread( n_thread_argument p )
{

	n_oc_item_find_thread_main( p );

	return 0;
}

n_bool
n_oc_item_init( n_oc_item *p )
{

	if ( p == NULL ) { return n_true; }


	// Phase 1 : list
//n_posix_debug_literal( " %s ", oc.find );

	// [!] : non-breaking

	n_bool find_onoff = n_false;

	n_dir dir; n_dir_zero( &dir );

	if ( oc.view_is_computer )
	{
//n_posix_debug_literal( " Computer " );

		n_oc_item_dir_load( p, &dir );

	} else
	if (
		( oc.find_mode == N_ORANGECAT_FIND_MODE_NONE )
		||
		( n_string_is_empty( oc.find ) )
	)
	{
//n_posix_debug_literal( " Folder " );

		n_bool ret = n_dir_load( &dir, oc.main );
		if ( ret ) { return n_true; }
//n_vector_debug( &dir.name );

		oc.find_mode = N_ORANGECAT_FIND_MODE_NONE;

	} else {
//n_posix_debug_literal( " Find " );

		find_onoff = n_true;


		if ( p->find_onoff )
		{
			if ( 0 == n_dir_all( &p->dir ) ) { n_dir_new( &p->dir ); }
			n_dir_carboncopy( &p->dir, &dir );
			n_dir_free( &p->dir );
		} else {
			n_dir_load_recursive( &dir, oc.main );
		}


		n_bool *del = n_memory_new( n_dir_all( &dir ) * sizeof( n_bool ) );
		n_memory_zero( del, n_dir_all( &dir ) * sizeof( n_bool ) );


		// [x] : Win9x : can run but not working

//u32 tick = n_posix_tickcount();

		n_type_int cores = n_thread_core_count;

		if (
//(0)&&
			( n_thread_onoff() )
			&&
			( cores <= n_dir_all( &dir ) )
		)
		{

			n_thread                     *h = n_memory_new( cores * sizeof( n_thread                     ) );
			n_oc_item_find_thread_struct *s = n_memory_new( cores * sizeof( n_oc_item_find_thread_struct ) );


			n_type_int i = 0;
			n_posix_loop
			{

				n_oc_item_find_thread_struct tmp = { &dir, del, i,cores };
				n_memory_copy( &tmp, &s[ i ], sizeof( n_oc_item_find_thread_struct ) );

				h[ i ] = n_thread_init( n_oc_item_find_thread, &s[ i ] );

				i++;
				if ( i >= cores ) { break; }
			}

			i = 0;
			n_posix_loop
			{

				n_thread_wait( h[ i ] );

				i++;
				if ( i >= cores ) { break; }
			}

			i = 0;
			n_posix_loop
			{

				n_thread_exit( h[ i ] );

				i++;
				if ( i >= cores ) { break; }
			}


			n_memory_free( h );
			n_memory_free( s );


		} else {

			n_oc_item_find_thread_struct s = { &dir, del, 0,1 };

			n_oc_item_find_thread_main( &s );

		}


		if ( 0 < n_dir_all( &dir ) )
		{
			n_type_int i = n_dir_all( &dir ) - 1;
			n_posix_loop
			{
				if ( del[ i ] )
				{
					n_dir_del( &dir, i );
				}

				if ( i == 0 ) { break; }
				i--;
			}
		}

		n_memory_free( del );


		n_clipboard_text_set( NULL, oc.find );

//n_posix_debug_literal( " %d ", n_posix_tickcount() - tick );


		// [Needed] : to reset

		oc.find_mode = N_ORANGECAT_FIND_MODE_NONE;
		n_string_path_free( oc.find ); oc.find = NULL;

	}


	// Phase 2 : Initialization

	n_oc_item_exit( p );

	p->dir                = dir;
	p->count              = n_dir_all( &p->dir );
	p->bmp                = n_memory_new( sizeof( n_bmp      ) * p->count );
	p->fade               = n_memory_new( sizeof( n_bmp_fade ) * p->count );
	p->multifocus         = n_memory_new( sizeof( n_bool     ) * p->count );
	p->multifocus_move    = n_memory_new( sizeof( n_bool     ) * p->count );
	p->multifocus_fade    = n_memory_new( sizeof( n_bool     ) * p->count );
	p->patch_forced_focus = n_memory_new( sizeof( n_bool     ) * p->count );
	p->patch_forced_frame = n_memory_new( sizeof( n_type_int ) * p->count );

	{

		n_type_int i = 0;
		n_posix_loop
		{

			if ( i >= p->count ) { break; }


			n_memory_zero( &p->bmp[ i ], sizeof( n_bmp ) );

			p->multifocus        [ i ] = n_false;
			p->multifocus_move   [ i ] = n_false;
			p->multifocus_fade   [ i ] = n_false;
			p->patch_forced_focus[ i ] = n_false;
			p->patch_forced_frame[ i ] = n_false;

			n_bmp_fade_zero( &p->fade[ i ] );

			i++;

		}

		p->patch_forced_hover = N_ORANGECAT_NOTHING;

	}


	if ( n_false == n_sysinfo_version_vista_or_later() )
	{
		p->recyclebin = n_oc_patch_is_recyclebin( oc.main );
	}

	p->find_onoff = find_onoff;

	p->hover      = N_ORANGECAT_NOTHING;
	p->hover_prv  = N_ORANGECAT_NOTHING;
	p->drag       = N_ORANGECAT_DRAG_NEUTRAL;


	n_oc_item_sync_init( p );


	n_oc_item_progressbar_reset( &p->progress_sync, N_ITASKBARLIST_MODE_GREEN );


	n_oc_item_view_set( p );


	if ( oc.view_is_key_operation )
	{

		n_type_int count = n_string_path_multiple_count( oc.head );
		if ( count == 0 )
		{
			p->multifocus[ 0 ] = p->patch_forced_focus[ 0 ] = n_true;
			p->patch_forced_focus_change = n_true;
		}

		oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
		path.focus    = N_ORANGECAT_NOTHING;

		n_oc_key_operation_onoff(  n_true );

	} else {

		n_oc_key_operation_onoff( n_false );

	}


	p->view_type = oc.view_type;

	//oc.scrollbar.unit_pos = oc.scrollbar.pixel_pos = 0;
	n_win_scrollbar_reset( &oc.scrollbar );

	n_win_scrollbar_bulk_fade_init( &oc.scrollbar );


	if ( n_false == n_string_is_empty( oc.head ) )
	{
//n_posix_debug_literal( " %s ", oc.head );

		n_oc_item_multifocus_path2focus( p, oc.head, n_true );

		n_string_path_free( oc.head ); oc.head = NULL;

		oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

		p->patch_forced_focus_change = n_true;
		n_oc_item_patch_focus_on( p, n_false );

	}


	n_oc_navigate_history( oc.navi );


	p->hover_prv = N_ORANGECAT_NOTHING;


	return n_false;
}

void
n_oc_item_go( n_oc_item *p, n_type_int index )
{
//n_posix_debug_literal( " %d ", index );


	if ( index == N_ORANGECAT_NOTHING ) { return; }


	n_posix_char *name = n_oc_item_index2path_new( p, index );
	n_posix_char *args = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( args, N_OC_LNK2PATH_CCH_MAX );

//n_posix_debug_literal( "%d : %s", index, name );


	if ( oc.view_is_computer )
	{

		if ( n_string_is_same( N_ORANGECAT_SHUTDOWN_EXE, name ) )
		{
			if ( n_project_dialog_yesno( game.hwnd, n_project_string_really_ok ) )
			{
				n_win_exec( name, SW_MINIMIZE );
			}

			n_string_path_free( name );
			n_string_path_free( args );

			return;
		} else
		if (
			( n_string_path_is_abspath( name ) )
			&&
			( n_false == n_oc_drive_is_accessible( name ) )
		)
		{
			n_string_path_free( name );
			n_string_path_free( args );

			return;
		}

	} else {

		n_posix_char *path = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( path, N_OC_LNK2PATH_CCH_MAX );

		n_oc_lnk2path( name, path, args );

		n_string_path_free( name );
		name = n_string_carboncopy( path );

		n_string_path_free( path );

	}

//n_posix_debug( name ); n_string_path_free( name ); return;


	if ( n_posix_stat_is_dir( name ) )
	{

		if ( n_posix_access_is_denied( name ) )
		{
			n_project_dialog_info( game.hwnd, n_project_string_error );
		} else {
//n_posix_debug( name );
			n_oc_navigate( name );
		}

	} else
	if ( n_false == n_string_is_empty( name ) )
	{
//n_posix_debug_literal( "%s %s", name, args );

		int    sw  = SW_SHOWNORMAL;
		n_bool ret = n_oc_shellexecute( NULL, name, args, sw );
		if ( ret )
		{
			// [Needed] : fallback

			n_posix_char *exe;
			if ( n_string_is_empty( args ) )
			{
				exe = n_string_path_carboncopy( name );
			} else {
				exe = n_string_path_cat( name, N_STRING_SPACE, args, NULL );
			}

			n_win_exec( exe, SW_NORMAL );

			n_string_path_free( exe );
		}


		//extern void n_oc_item_select_add( n_oc_item*, int );
		//n_oc_item_select_add( &item, index );


		// [Patch] : "-find" needs this

		//n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

//n_game_hwndprintf_literal( " %d : %s :  %s ", ret, name, args );
	} else {
//n_posix_debug_literal( " Empty " );
	}

	n_string_path_free( name );
	n_string_path_free( args );


	return;
}

#define n_oc_item_dnd_off( p    ) n_oc_item_dnd_onoff( p, 0, n_false )
#define n_oc_item_dnd_on(  p, d ) n_oc_item_dnd_onoff( p, d, n_true  )

// internal
void
n_oc_item_dnd_onoff( n_oc_item *p, int drag, n_bool is_on )
{

	if ( n_oc_item_error( p ) ) { return; }

//n_game_hwndprintf_literal( " %d %d ", oc.is_internal_dnd, drag );

	if ( is_on )
	{
		p->drag = drag;

		// [x] : buggy : Win10 : hangup when you use n_win_message_send()
		n_win_message_post( HWND_BROADCAST, oc.msg_drag_oc2oc, is_on, 0 );
	} else {
		p->drag = N_ORANGECAT_DRAG_NEUTRAL;
	}


	return;
}

n_bool
n_oc_item_is_droppable_env( n_oc_item *p, const n_posix_char *name )
{

	// [!] : Win9x : an environment variable "PATHEXT" is missing


	n_bool ret = n_false;


	HMODULE hmod = LoadLibrary( n_posix_literal( "kernel32.dll" ) );
	if ( hmod == NULL ) { return ret; }

#ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "GetEnvironmentVariableW" );
#else  // #ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "GetEnvironmentVariableA" );
#endif // #ifdef UNICODE

	if ( func != NULL )
	{

		n_type_int    cch = 32767;
		n_posix_char *str = n_string_new( cch );

		func( n_posix_literal( "PATHEXT" ), str, cch );
//n_game_hwndprintf_literal( " %s ", str );

		n_posix_char *ext = n_string_new( cch );
		if ( ext == NULL ) { n_string_free( str ); return ret; }

		n_type_int count = n_string_parameter_count_literal( str, ";", "" );
		n_type_int i = 0;
		n_posix_loop
		{

			if ( i >= count ) { break; }

			n_string_parameter_literal( str, ";", "", i, ext );
//n_posix_debug_literal( " %s ", ext );

			if ( n_string_path_ext_is_same( name, ext ) ) { ret = n_true; }

			i++;

		} 

		n_string_free( ext );
		n_string_free( str );

	}

	FreeLibrary( hmod );


	return ret;
}

n_bool
n_oc_item_computer_is_droppable( n_oc_item *p )
{

	n_bool ret = n_false;

	if ( oc.view_is_computer )
	{

		if ( p->hover != N_ORANGECAT_NOTHING )
		{
			n_posix_char *path = n_oc_item_index2path_new( p, p->hover );
//n_posix_debug_literal( " %d ", n_string_path_is_drivename( path ) );

			if ( n_string_path_is_drivename( path ) ) { ret = n_true; }

			n_string_path_free( path );
		}

	}


	return ret;
}

#define n_oc_item_is_droppable( p ) n_oc_item_is_droppable_main( p, n_false )

n_bool
n_oc_item_is_droppable_main( n_oc_item *p, n_bool always_external )
{

	if ( n_oc_item_error( p ) ) { return n_false; }


//n_posix_debug_literal( " %d ", p->count ); return n_false;
	if ( p->count == 0 ) { return n_false; }


	n_posix_char *path = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( path, N_OC_LNK2PATH_CCH_MAX );
	n_posix_char *name = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( name, N_OC_LNK2PATH_CCH_MAX );
	n_posix_char *args = n_string_path_new( N_OC_LNK2PATH_CCH_MAX ); n_string_zero( args, N_OC_LNK2PATH_CCH_MAX );

	if ( p->hover == N_ORANGECAT_NOTHING )
	{

		n_bool find_onoff = (n_bool) n_win_message_send( oc.view_hwnd, oc.msg_find_onoff, 0,0 );
//n_game_hwndprintf_literal( " %d ", find_onoff );

		if ( ( find_onoff )||( item.find_onoff ) )
		{

			n_string_free( path );
			n_string_free( name );
			n_string_free( args );

			return n_false;

		}

		n_posix_sprintf_literal( path, "%s", oc.main );
		n_oc_lnk2path( path, name, args );

	} else
	if ( ( oc.is_external_dnd == n_false )&&( always_external == n_false ) )
	{

		// [x] : don't use oc.is_internal_dnd
		// [x] : oc.is_external_dnd will be n_false in WM_DROPFILES

//n_game_hwndprintf_literal( " Internal : %d %d ", p->hover, p->multifocus[ p->hover ] );
//n_posix_debug_literal( " %d ", p->hover );

		// [!] : self DnD is forbidden

		if ( p->multifocus[ p->hover ] )
		{

			n_string_free( path );
			n_string_free( name );
			n_string_free( args );

			return n_false;

		}

		n_oc_item_index2path( p, p->hover, path );
		n_oc_lnk2path( path, name, args );
//n_game_hwndprintf_literal( " %d : %s ", n_string_path_is_drivename( path ), path );

	} else {
//n_game_hwndprintf_literal( " External : %d %d ", p->hover, p->multifocus[ p->hover ] );

		n_oc_item_index2path( p, p->hover, path );
		n_oc_lnk2path( path, name, args );

	}


	n_bool ret = n_false;

	if ( oc.view_is_computer )
	{

		ret = n_string_path_is_drivename( path );

	} else
	if ( n_posix_stat_is_dir( name ) )
	{

		ret = n_true;

	} else {

		if ( n_sysinfo_version_nt() )
		{

			ret = n_oc_item_is_droppable_env( p, name );
//n_game_hwndprintf_literal( " Path %s : Name %s ", path, name );

		} else {

			// [!] : there is no good solution

			ret = n_true;

/*
			n_posix_char exe[ MAX_PATH ]; n_string_zero( exe, MAX_PATH );

			FindExecutable( name, NULL, exe );
			n_string_path_short2long( exe, exe );
//n_game_hwndprintf_literal( "%s : %s", name, exe );

			if ( n_string_is_same( name, exe ) )
			{

				ret = n_true;

			} else {

				n_posix_char *s = n_string_path_name_new( exe );

				if ( n_string_is_same_literal( "wscript.exe", s ) ) { ret = n_true; }

				n_string_path_free( s );

			}
*/

		}

	}


	n_string_free( path );
	n_string_free( name );
	n_string_free( args );


	return ret;
}

n_bool
n_oc_item_drag2scroll( n_oc_item *p, n_bool is_before )
{

	if (
		( p->drag == N_ORANGECAT_DRAG_BREADCRUMB )
		||
		( p->drag == N_ORANGECAT_DRAG_SCROLL     )
		||
		( p->drag == N_ORANGECAT_DRAG_NEUTRAL    )
	)
	{
		return n_false;
	}


	if ( p->margin_scroll_onoff == n_false )
	{

		p->margin_scroll_onoff = n_true;
		p->margin_scroll_timer = n_posix_tickcount();

	} else {

		if ( n_bmp_ui_timer( &p->margin_scroll_timer, N_ORANGECAT_INTERVAL_DRAG ) )
		{
			n_type_real delta = oc.scrollbar.pixel_step;
			if ( is_before ) { delta *= -1; } else { delta *= 1; }
			if ( n_win_scrollbar_scroll_pixel( &oc.scrollbar, delta, N_WIN_SCROLLBAR_SCROLL_AUTO ) )
			{

				if ( p->drag2select_onoff == n_false )
				{
					n_oc_event_redraw_fast();
				} else {
					n_oc_item_drag2select_loop( p );
				}

				return n_true;
			}
		}

	}


	return n_false;
}

n_bool
n_oc_item_comnputer_is_drive( n_oc_item *p, n_type_int index )
{

	if ( index < 0 ) { return n_false; }


	n_bool ret = n_false;


	n_posix_char *s = n_dir_name( &p->dir, index );

	if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, s ) )
	{
		//
	} else
	if ( n_string_is_same( N_ORANGECAT_SETTINGS,     s ) )
	{
		//
	} else
	if ( n_string_is_same( N_ORANGECAT_SHUTDOWN,     s ) )
	{
		//
	} else {
		ret = n_true;
	}


	return ret;
}

// internal
void
n_oc_item_select_add( n_oc_item *p, n_type_int index )
{

	//if ( oc.view_is_key_operation ) { return; }


	if ( index == N_ORANGECAT_NOTHING ) { return; }


	if ( oc.view_is_computer )
	{

		if (
			( n_oc_item_comnputer_is_drive( p, index ) )
			&&
			( n_oc_item_comnputer_is_drive( p, n_oc_item_multifocus_single( p ) ) )
		)
		{
			p->multifocus[ index ] = n_true;
			//n_bmp_fade_go( &p->fade[ index ], oc_color.item_focus );
		}

	} else {

		p->multifocus[ index ] = n_true;
		//n_bmp_fade_go( &p->fade[ index ], oc_color.item_focus );

	}

	n_oc_item_hover2tooltip_draw( p, n_true );


	return;
}

// internal
void
n_oc_item_on_keydown_shift( n_oc_item *p )
{

	if ( p->hover == N_ORANGECAT_NOTHING ) { return; }


	n_type_int f = 0;
	n_type_int t = p->hover;
	n_posix_loop
	{

		if ( f >= p->count ) { f = 0; break; }

		if ( p->multifocus[ f ] ) { break; }

		f++;

	}

	n_type_int minim = n_posix_min_n_type_int( f, t );
	n_type_int maxim = n_posix_max_n_type_int( f, t );

	f = minim;
	t = maxim + 1;
	n_posix_loop
	{

		if ( f >= t ) { break; }

		n_oc_item_select_add( p, f );

		f++;

	}


	return;
}

// internal
void
n_oc_item_select( n_oc_item *p )
{
//return;

	p->patch_forced_hover = N_ORANGECAT_NOTHING;
	n_memory_zero( p->patch_forced_focus, sizeof( n_bool ) * p->count );
//return;

	if ( n_win_is_input( VK_CONTROL ) )
	{

		if ( oc.is_lbutton == n_false ) { return; }

		n_oc_item_select_add( p, p->hover );

		return;

	} else
	if ( n_win_is_input( VK_SHIFT ) )
	{

		if ( oc.is_lbutton == n_false ) { return; }

		n_oc_item_on_keydown_shift( p );

		return;

	}


//n_game_debug_count();
//n_game_hwndprintf_literal( " %d %d %d ", p->hover, p->drag, p->drag2select_onoff );

	if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
	{
//n_game_hwndprintf_literal( " 1 " );

		// [!] : focus setter : #1 / 2


		// [!] : this means frame-only fade-out

		if ( p->hover == N_ORANGECAT_NOTHING )
		{

			// [!] : margin is clicked

			// [!] : delayed : oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

			p->patch_forced_frame_phase = N_OC_ITEM_FORCED_FRAME_ON_1;
/*
			if (n_true)
			{
				n_oc_item_multifocus_fade_off( p );
			} else {
				n_oc_subclass_on_keydown( VK_TAB, n_true );
				n_oc_key_operation_onoff( n_false );
			}
*/
		} else {

			// [!] : another item is clicked

			p->is_move_reserved = n_true;


			n_type_int *focus = n_memory_new_closed( sizeof( n_bool ) * p->count );
			n_memory_copy( p->multifocus, focus, sizeof( n_bool ) * p->count );

			n_bool onoff = n_false;
			if ( ( p->hover != N_ORANGECAT_NOTHING )&&( p->multifocus[ p->hover ] ) ) { onoff = n_true; }
			n_oc_subclass_on_keydown( VK_TAB, onoff );

			n_memory_copy( focus, p->multifocus, sizeof( n_bool ) * p->count );
			n_memory_free_closed( focus );


			n_oc_key_operation_onoff( n_false );

		}


		return;

	} else {
//n_game_hwndprintf_literal( " 2 " );

		p->is_move_reserved = n_false;

	}
//return;


//n_game_hwndprintf_literal( " %d ", oc.view_focus );
//n_game_hwndprintf_literal( " %d ", p->hover );

	if ( p->hover == N_ORANGECAT_NOTHING )
	{

		if ( oc.is_inner )
		{
			n_oc_item_multifocus_off( p );
		}

	} else
	//if ( p->hover != N_ORANGECAT_NOTHING )
	{

		n_oc_key_operation_onoff( n_false );

		if ( p->multifocus[ p->hover ] == n_false )
		{

			// [!] : focus setter : #2 / 2

			if ( p->is_move_reserved == n_false )
			{
				n_oc_item_multifocus_off( p );
				oc.view_is_key_operation_fade_out = n_false;

				p->multifocus[ p->hover ] = n_true;
			}

		}

	}


	n_oc_event_redraw_fast();


	return;
}

n_bool
n_oc_item_collision_roundrect( n_oc_item *p, n_type_int index, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_bool hover_onoff )
{

//n_game_hwndprintf_literal( " %d %d ", index, oc.is_round );
	if ( oc.is_round == n_false ) { return hover_onoff; }


	n_type_gfx tx = oc.cursor_x - x;
	n_type_gfx ty = oc.cursor_y - y;
	//n_type_gfx sx = n_oc_item_lineselection( p, 0 );
	//n_type_gfx sy = p->cell_sy_custom;

//n_game_hwndprintf_literal( " %d %d : %d %d ", tx,ty, sx,sy );


	n_type_gfx r = n_posix_min_n_type_gfx( sx, sy ) / 2;

	n_type_real percent = (n_type_real) oc.unit_rect * 0.01;
	percent = n_posix_min_n_type_real( 1.0, percent );

	if ( percent != 0.0 ) { r = (n_type_gfx) ( (n_type_real) r * percent ); }


	return n_bmp_roundrect_detect( tx,ty, sx,sy, r );
}

void
n_oc_item_collision( n_oc_item *p, n_type_int *ret_index, n_bool *ret_hover, n_bool large_area )
{

	if ( ret_index ) { (*ret_index) = N_ORANGECAT_NOTHING; }
	if ( ret_hover ) { (*ret_hover) =             n_false; }


	n_posix_bool hover_onoff = n_false;


	n_type_int index_f, index_t; n_oc_item_scan_index( p, &index_f, &index_t, n_false );
	n_posix_loop
	{//break;

		if ( index_f >= index_t ) { break; }

		n_bmp *t = &p->bmp[ index_f ];
		if ( NULL != N_BMP_PTR( t ) )
		{

			n_type_gfx  x = 0;
			n_type_gfx  y = 0;
			n_type_gfx sx = n_oc_item_lineselection( p, N_BMP_SX( t ) );
			n_type_gfx sy = N_BMP_SY( t ); 

			n_oc_item_position_calculate( p, index_f, &x, &y, n_true );

			n_type_gfx csx = (n_type_gfx) p->sx;
			n_type_gfx csy = (n_type_gfx) p->sy;
			if ( p->view_type != N_ORANGECAT_VIEW_TYPE_LOGO ) { csy += oc.unit_path; }

			n_type_gfx tx = x;
			n_type_gfx ty = y;
			if ( large_area )
			{
				tx += sx;
				ty += sy;
			}
//if ( i == 0 ) { n_game_hwndprintf_literal( " %d %d : %d %d ", x, y - oc.unit_path, x + sx, y - oc.unit_path + sy ); }

			if (
				( ( x >= -sx )&&( tx <= csx ) )
				&&
				( ( y >= -sy )&&( ty <= csy ) )
			)
			{

				hover_onoff = n_win_is_hovered_offset( game.hwnd, x, y, sx, sy );
				if ( hover_onoff )
				{
					hover_onoff = n_oc_item_collision_roundrect( p, index_f, x, y, sx, sy, hover_onoff );
					break;
				}

			}

		}


		index_f++;

	}


	if ( ret_index ) { (*ret_index) =     index_f; }
	if ( ret_hover ) { (*ret_hover) = hover_onoff; }


	return;
}

void
n_oc_item_on_click( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	if ( oc.view_drag_internal == N_ORANGECAT_DRAG_BREADCRUMB ) { return; }


	// [!] : Pager Dragging

	static n_bool scroll_drag_onoff = n_false;

	// [!] : for inactive window

	n_bool hovered_main  = n_win_scrollbar_rect_is_hovered( &oc.scrollbar.rect_main , game.hwnd );
	n_bool hovered_thumb = n_win_scrollbar_rect_is_hovered( &oc.scrollbar.rect_thumb, game.hwnd );
//n_game_hwndprintf_literal( " %d ", hovered_main );
//n_game_hwndprintf_literal( " %d %d ", oc.is_external_dnd, n_IDropTarget_is_running );

	if ( ( oc.scrollbar.enabled )&&( hovered_main ) )
	{

		if ( oc.is_input == n_false )
		{
			if ( p->drag >= N_ORANGECAT_DRAG_LBUTTON )
			{
				p->drag = N_ORANGECAT_DRAG_NEUTRAL;
				return;
			}
		}


		static u32 timer = 0;

		if (
			( p->drag >= N_ORANGECAT_DRAG_LBUTTON )
			||
			( oc.is_external_dnd )
		)
		{

			if ( scroll_drag_onoff == n_false )
			{
				scroll_drag_onoff = n_true;
				timer = n_posix_tickcount();
			}

			// [!] : Scroll Dragger : sync when drag onto scroll pager

			if (
				( scroll_drag_onoff )
				&&
				( n_bmp_ui_timer( &timer, N_ORANGECAT_INTERVAL_PBAR ) )
			)
			{
//return;
				if ( oc.scrollbar.drag_clamp )
				{

					oc.scrollbar.drag_clamp = n_false;

					if ( hovered_thumb == n_false )
					{
						n_win_scrollbar_event_shaft( &oc.scrollbar );
					}

					oc.scrollbar.drag_onoff     = n_true;
					n_win_scrollbar_hwnd_global = oc.scrollbar.hwnd;

					n_win_scrollbar_position_cursor( &oc.scrollbar, &oc.scrollbar.prv_cursor_x, &oc.scrollbar.prv_cursor_y );
					n_win_scrollbar_offset( &oc.scrollbar );

					n_bmp_fade_go( &oc.scrollbar.fade_thumb, oc.scrollbar.color_hvr_t );

				}

			}

			return;

		}

	}

	if ( scroll_drag_onoff )
	{
		scroll_drag_onoff = n_false;

		oc.scrollbar.drag_onoff     = n_false;
		oc.scrollbar.drag_clamp     = n_true;
		n_win_scrollbar_hwnd_global = NULL;
	}

	if ( oc.scrollbar.drag_onoff ) { return; }

//n_game_debug_count();
	if ( p->drag == N_ORANGECAT_DRAG_SCROLL ) { return; }


	if ( oc.focuskeeper_onoff ) { return; }


	// [!] : count zero is acceptable
	//if ( p->count <= 0 ) { return; }


//n_game_hwndprintf_literal( " %d ", oc.view_hover );
	if ( oc.view_hover != N_ORANGECAT_VIEW_HOVER_ITEM )
	{
//n_game_debug_count();

		p->hover = N_ORANGECAT_NOTHING;


		if ( p->drag2select_onoff == n_false )
		{
			n_oc_item_fade( p, n_true );
		}


		if (
			( oc.is_input )
			&&
			( p->drag >= N_ORANGECAT_DRAG_LBUTTON )
		)
		{
			n_oc_dnd_cursor();
		}


		if ( p->drag2select_onoff )
		{

			n_type_gfx ox = (n_type_gfx) ( p->ox                );
			n_type_gfx oy = (n_type_gfx) ( p->oy + oc.unit_path );
			n_type_gfx sx = game.sx;
			n_type_gfx sy = game.sy;

			if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
			{
				if ( oc.cursor_y < oy ) { n_oc_item_drag2scroll( p, n_true  ); }
				if ( oc.cursor_y > sy ) { n_oc_item_drag2scroll( p, n_false ); }
			} else {
				if ( oc.cursor_x < ox ) { n_oc_item_drag2scroll( p, n_true  ); }
				if ( oc.cursor_x > sx ) { n_oc_item_drag2scroll( p, n_false ); }
			}

		}


		return;
	}


	// Phase 1 : Collision

	n_type_int hover_index = N_ORANGECAT_NOTHING;
	n_bool     hover_onoff = n_false;

	n_oc_item_collision( p, &hover_index, &hover_onoff, n_false );


	// Phase 2 : Navigation #1

	// [!] : p->drag is sensitive
	//
	//	+ drag will be on when only clicked
	//	+ but a cursor is changed when moved some pixels

	n_bool is_hovered     = ( oc.view_hover == N_ORANGECAT_VIEW_HOVER_ITEM );
	n_bool is_dnd_started =
	(
		( is_hovered )
		&&
		( oc.is_draggable )
		&&
		( n_false == oc.view_is_computer )
		&&
		(
			( p->drag != N_ORANGECAT_DRAG_NEUTRAL    )
			&&
			( p->drag != N_ORANGECAT_DRAG_UNKNOWN    )
			&&
			( p->drag != N_ORANGECAT_DRAG_SCROLL     )
			&&
			( p->drag != N_ORANGECAT_DRAG_BREADCRUMB )
		)
	);
//n_game_hwndprintf_literal( "Input %d : DnD %d", oc.is_input, is_dnd_started );
//n_game_hwndprintf_literal( " %d ", oc.view_is_computer );


	if ( p->count == 0 )
	{
		hover_onoff = n_false;
	}


	if (
		( oc.view_is_computer )
		&&
		(
			( p->drag != N_ORANGECAT_DRAG_NEUTRAL )
			//||
			//( n_IDropTarget_is_running )
		)
		&&
		( n_oc_is_draggable() )
	)
	{
		hover_onoff = n_false;
	}

	if (
		( p->find_onoff )
		&&
		(
			( p->drag != N_ORANGECAT_DRAG_NEUTRAL )
			||
			( n_IDropTarget_is_running )
		)
		&&
		( n_oc_is_draggable() )
	)
	{
		//hover_onoff = n_false;
	}


	if ( n_oc_is_desktop_selection() )
	{
//n_game_hwndprintf_literal( " n_oc_is_desktop_selection() " );
		hover_onoff = n_false;
	}


	// [!] : dragging will be turned off when unknown DnD

	n_bool double_clicked = n_game_click_double( &oc.doubleclick_l );

	if (
		( p->drag == N_ORANGECAT_DRAG_UNKNOWN )
		&&
		( double_clicked == n_false )
		&&
		( 0 == n_oc_item_multifocus_count( p ) )
		&&
		( oc.is_external_dnd == n_false )
		&&
		( n_IDropTarget_is_running == n_false )
	)
	{
//n_game_debug_count();
//n_game_hwndprintf_literal( " unknown DnD " );
		hover_onoff = n_false;
	}


	if ( hover_onoff )
	{
		p->hover = hover_index;
	} else {
//n_game_debug_count();
		p->hover = N_ORANGECAT_NOTHING;
	}

//n_game_hwndprintf_literal( " %d %d ", p->hover, is_hovered );


//n_game_hwndprintf_literal( " %d %d ", n_oc_item_is_droppable( p ), p->hover );
	if (
		(
			( is_dnd_started )
			&&
			( n_false == n_oc_item_is_droppable( p ) )
		)
		||
		(
			( oc.is_external_dnd )
			&&
			( n_false == n_oc_item_is_droppable( p ) )
		)
	)
	{
		p->hover = N_ORANGECAT_NOTHING;
	}


	// Phase 3 : Navigation #2

/*
	if ( ( p->double_clicked )&&( oc.is_inner ) )
	{

		// [!] : double-click isn't accepted when loading is busy
		//
		//	see WM_LBUTTONDBLCLK @ n_oc_subclass() @ oc_subclass.c

	} else
*/
	if ( n_game_click_single( &oc.singleclick_m ) )
	{

		if ( n_win_is_input( VK_CONTROL ) )
		{

			n_oc_reset_stdsize();
//n_posix_debug_literal( " %d ", oc.unit_icon );

			n_oc_item_gallery_set( p, 32 );

		} else
		if ( n_win_is_input( VK_SHIFT ) )
		{

			n_oc_font_init( oc.font_smooth_auto, oc.font_smooth_onoff );
			n_oc_item_scroll_fontsize_redraw( p );

		} else {

			n_type_int i = 0;
			n_posix_loop
			{

				if ( p->multifocus[ i ] )
				{
					n_posix_char *name = n_oc_item_index2path_new( p, i );
//n_game_hwndprintf_literal( " %d : %s", p->hover, name );

					n_oc_newwindow( name, ( p->find_onoff == n_false ) );

					n_string_path_free( name );
				}


				i++;
				if ( i >= p->count ) { break; }
			}

		}

	} else
	if ( oc.is_input )
	{
//n_game_hwndprintf_literal( " %d ", p->drag );

		// [!] : to disappear : see WM_MOUSEMOVE @ n_oc_subclass() @ oc_subclass.c
/*
		if ( p->drag == N_ORANGECAT_DRAG_UNKNOWN )
		{

			if ( oc.is_internal_dnd )
			{
n_game_hwndprintf_literal( " %d ", oc.view_focus );
			}

		} else
*/
		if ( p->drag == N_ORANGECAT_DRAG_NEUTRAL )
		{
//n_game_hwndprintf_literal( " %d ", n_oc_is_desktop_selection() );
//n_game_hwndprintf_literal( " %d ", oc.is_internal_dnd );

			// [x] : when a cursor moves fastly into a client area : oc.is_internal_dnd will be n_true

			if ( oc.is_internal_dnd )
			{

				// [!] : focus remover

				n_oc_item_select( p );


				int drag = N_ORANGECAT_DRAG_UNKNOWN;
				if (
					( p->hover != N_ORANGECAT_NOTHING )
					&&
					( p->drag2select_onoff == n_posix_false )
				)
				{
//n_game_hwndprintf_literal( " %d ", p->drag2select_onoff );
					if ( oc.is_lbutton ) { drag = N_ORANGECAT_DRAG_LBUTTON; }
					if ( oc.is_mbutton ) { drag = N_ORANGECAT_DRAG_MBUTTON; }
					if ( oc.is_rbutton ) { drag = N_ORANGECAT_DRAG_RBUTTON; }
				}

//n_game_hwndprintf_literal( " %d %d ", p->hover, drag );

				n_oc_item_dnd_on( p, drag );

			} else {

				n_oc_item_dnd_off( p );

			}

		} else {

			if ( is_dnd_started )
			{
//n_game_debug_count();
				n_oc_dnd_cursor();
			}

		}

	} else
	if ( is_dnd_started )
	{
//n_game_debug_count();

		if ( p->drag >= N_ORANGECAT_DRAG_LBUTTON )
		{
//n_posix_debug_literal( "Dropped" );

			n_oc_item_autoscroll( p, p->hover, N_OC_ITEM_AUTOSCROLL_DEFAULT );

			n_posix_char *f = n_oc_item_multifocus_focus2path_new( p );
			n_posix_char *t = n_oc_item_index2path_new( p, p->hover );

			n_oc_item_scroll_restore( p );

//n_oc_item_multifocus_debug( f );


			n_bool is_cancelled = n_false;
			n_bool ret = n_oc_item_multifocus_dnd( f, t, p->drag, &is_cancelled );
			if ( ret ) { n_project_dialog_info( game.hwnd, n_project_string_error ); }

			if ( is_cancelled == n_false )
			{
				if ( n_posix_stat_is_dir( f ) )
				{
					if ( p->hover != N_ORANGECAT_NOTHING )
					{
						p->hover = N_ORANGECAT_NOTHING;
					}
				}

				if ( n_posix_stat_is_dir( t ) )
				{
					if ( p->hover != N_ORANGECAT_NOTHING )
					{
						n_oc_item_multifocus_off_all( p );
						p->multifocus[ p->hover ] = n_true;
					}
				}

			}

			n_string_path_free( f );
			n_string_path_free( t );

		}

		n_oc_item_dnd_off( p );

	} else {

		n_oc_item_drag2select_exit( p );

		if ( oc.activate_onoff == n_false )
		{
			n_oc_item_dnd_off( p );
		}

		if ( p->patch_forced_frame_phase == N_OC_ITEM_FORCED_FRAME_ON_1 )
		{
			p->patch_forced_frame_phase = N_OC_ITEM_FORCED_FRAME_NONE;

			n_oc_subclass_on_keydown( VK_TAB, n_true );
			n_oc_key_operation_onoff( n_false );
		}

	}


	// Phase 4 : Fade

	// [Needed] : this position is important

	if ( ( oc.is_inner )&&( p->drag2select_onoff == n_false ) )
	{
//n_game_hwndprintf_literal( " %d %d ", p->hover, p->patch_forced_hover );

		if ( p->hover != p->patch_forced_hover )
		{
			p->patch_forced_hover = N_ORANGECAT_NOTHING;
		}

		if ( p->is_move_reserved )
		{
			p->is_move_reserved = n_false;
			if ( p->hover == N_ORANGECAT_NOTHING )
			{
				n_oc_item_multifocus_move_on( p, p->hover );
			} else
			if ( ( p->hover != N_ORANGECAT_NOTHING )&&( p->multifocus[ p->hover ] == n_false ) )
			{
				n_oc_item_multifocus_move_on( p, p->hover );
				p->multifocus[ p->hover ] = n_true;
			}
		}

		n_oc_item_fade( p, n_true );

	}


//n_game_debug_count();
	return;
}

