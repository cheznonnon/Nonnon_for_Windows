// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_item_progressbar_reset( n_oc_item_progressbar *p, int mode )
{

	p->phase      = N_ORANGECAT_PROGRESS_NONE;
	p->onoff      = n_false;
	p->first      = n_true;

	p->redraw_lct = 0;
	p->redraw_prv = 0;
	p->redraw_cur = 0;
	p->redraw_pos = 0;


	n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );


	n_ITaskbarList_mode( oc.ITaskbarList3, game.hwnd, mode );

	if ( mode == N_ITASKBARLIST_MODE_GREEN  )
	{
		p->color = oc_color.item_gauge;
	} else
	if ( mode == N_ITASKBARLIST_MODE_YELLOW )
	{
		p->color = oc_color.item_copy;
	} else
	if ( mode == N_ITASKBARLIST_MODE_RED    )
	{
		p->color = oc_color.item_copy;
	}// else


	return;
}

void
n_oc_item_progressbar_main( n_oc_item_progressbar *p, n_type_int loaded, n_type_int count )
{
//return;

	if ( oc.exit_onoff ) { return; }


	if ( loaded <  0 ) { return; }
	if ( count  <= 0 ) { return; }


	// [!] : for 100%

//n_game_hwndprintf_literal( " %d : %d / %d ", p->phase, loaded, count );
//return;

	if ( loaded != count )
	{
		if ( p->phase == N_ORANGECAT_PROGRESS_NONE ) { p->phase = N_ORANGECAT_PROGRESS_INIT; }
	} else {
		if ( p->phase == N_ORANGECAT_PROGRESS_INIT ) { p->phase = N_ORANGECAT_PROGRESS_100P; }
	}

	if ( p->phase )
	{

		if ( p->onoff == n_false )
		{
			p->onoff = n_true;

			if ( p->first ) { p->first = n_false; p->redraw_lct = loaded; }

			p->redraw_prv = (n_type_real) p->redraw_lct / count;
			p->redraw_cur = (n_type_real)    loaded     / count;
			p->redraw_pos = 0;

			n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );
			n_ITaskbarList_loop( oc.ITaskbarList3, game.hwnd, loaded, count );

			//item.sync_progressbar_animation_onoff = n_true;
			//n_bmp_ui_progressbar_animation          = N_BMP_UI_PROGRESSBAR_ANIMATION_ON_UP;
		}

		if ( p->onoff )
		{

			n_type_gfx f = (n_type_gfx) ( (n_type_real) item.sx * p->redraw_prv );
			n_type_gfx t = (n_type_gfx) ( (n_type_real) item.sx * p->redraw_cur );

			n_type_gfx  x = 0;
			n_type_gfx  y = oc.unit_path;
			n_type_gfx sx = f;
			n_type_gfx sy = oc.unit_scal;

			n_bmp_box( &game.bmp, x,y,sx+p->redraw_pos,sy, p->color );

			p->redraw_pos += n_posix_max_n_type_gfx( 1, (n_type_gfx) ( item.sx / 100 ) );
			if ( ( f + p->redraw_pos ) > t )
			{
				p->onoff = n_false;

				p->redraw_lct = loaded;
				p->redraw_prv = 0;
				p->redraw_cur = 0;
				p->redraw_pos = 0;

				n_ITaskbarList_loop( oc.ITaskbarList3, game.hwnd, loaded, count );

				if ( p->phase == N_ORANGECAT_PROGRESS_100P )
				{

					p->phase = N_ORANGECAT_PROGRESS_LAST;
					p->timer = n_posix_tickcount();

				} else
				if ( p->phase == N_ORANGECAT_PROGRESS_LAST )
				{

					if ( n_bmp_ui_timer( &p->timer, N_ORANGECAT_INTERVAL_PBAR ) )
					{

						p->phase = N_ORANGECAT_PROGRESS_NONE;
						p->first = n_true;

						n_ITaskbarList_stop( oc.ITaskbarList3, game.hwnd );

						//item.sync_progressbar_animation_onoff = n_false;
						//n_bmp_ui_progressbar_animation          = N_BMP_UI_PROGRESSBAR_ANIMATION_OFF;

						n_bmp_box( &game.bmp, x, y, (n_type_gfx) item.sx, sy, oc_color.bg );

					} else {

						n_bmp_box( &game.bmp, x, y, (n_type_gfx) item.sx, sy, p->color );

					}

				}

			}

			// [x] : multi-thread : conflict
			//n_game_on_paint_partial( x,y,item.sx,sy );

			n_game_refresh_on();

		}


		// [x] : this process is very slow
/*
		if ( item.sync_progressbar_animation_onoff )
		{
			n_bmp_free( &oc.scrollbar.bmp_th );
			n_win_scrollbar_draw_always( &oc.scrollbar, n_true );

			//n_win_scrollbar_rect r = oc.scrollbar.rect_main;
			//n_game_on_paint_partial( r.x,r.y,r.sx,r.sy );
		}
*/
	}


	return;
}


