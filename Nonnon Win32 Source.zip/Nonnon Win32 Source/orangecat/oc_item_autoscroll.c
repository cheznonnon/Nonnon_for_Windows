// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static n_bool n_oc_item_autoscroll_debug_onoff = n_false;




// internal
void
n_oc_item_autoscroll_calculate( n_oc_item *p, n_type_int index, n_type_gfx *ret_unit_x, n_type_gfx *ret_unit_y )
{

	// [!] : unit based

	n_type_gfx unit_x = (n_type_gfx) ( index % (n_type_int) p->scroll_item_per_line );
	n_type_gfx unit_y = (n_type_gfx) ( index / (n_type_int) p->scroll_item_per_line );

	if ( ret_unit_x != NULL ) { (*ret_unit_x) = unit_x; }
	if ( ret_unit_y != NULL ) { (*ret_unit_y) = unit_y; }


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " %d %d ", unit_x, unit_y );
}

	return;
}

n_bool
n_oc_item_autoscroll_is_inner_by_pixelpos( n_oc_item *p, n_type_gfx pixel_x, n_type_gfx pixel_y )
{

	if ( n_oc_item_error( p ) ) { return n_false; }

	if ( p->count == 0 ) { return n_false; }


	n_bool ret = n_false;


	n_type_gfx cell = 0;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		cell = (n_type_gfx) ( p->cell_sx - ( p->ox * 2 ) );
	} else {
		cell = (n_type_gfx) ( p->cell_sy - ( p->oy * 2 ) );
	}


	n_type_gfx offset_f, offset_t;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		offset_f = pixel_x;
		offset_t = pixel_x + cell;
	} else {
		offset_f = pixel_y - oc.unit_path;
		offset_t = pixel_y + cell;
	}

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		//
	} else {
		//offset_f -= oc.unit_path;
		offset_t -= oc.unit_path + oc.unit_mrgn;
	}


	n_type_gfx size;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		size = (n_type_gfx) p->sx;
	} else {
		size = (n_type_gfx) p->sy;
	}


	if ( ( offset_f >= 0 )&&( offset_t < size ) ) { ret = n_true; }

	if ( oc.scrollbar.unit_pos == ( oc.scrollbar.unit_max - oc.scrollbar.unit_page ) )
	{
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			size += (n_type_gfx) p->cell_sx;
		} else {
			size += (n_type_gfx) p->cell_sy;
		}
		if ( ( offset_f >= 0 )&&( offset_t < size ) ) { ret = n_true; }
	}


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " is_inner() : From %d To %d : Client 0-%d : Ret %d ", offset_f,offset_t, size, ret );
}

	return ret;
}

n_bool
n_oc_item_autoscroll_is_inner( n_oc_item *p, n_type_int index )
{

	if ( ( index < 0 )||( index >= p->count ) ) { return n_false; }

	n_type_gfx x,y; n_oc_item_position_calculate( p, index, &x, &y, n_true );

	return n_oc_item_autoscroll_is_inner_by_pixelpos( p, x,y );
}

n_bool
n_oc_item_autoscroll_is_edge( n_oc_item *p, n_type_int index, n_bool *ret_before, n_bool *ret_after )
{

	// [!] : this module works for half-hidden items


	if ( n_oc_item_error( p ) ) { return n_false; }

	if ( p->count == 0 ) { return n_false; }

	if ( ( index < 0 )||( index >= p->count ) ) { return n_false; }


	n_bool before = n_false;
	n_bool after  = n_false;

	if ( n_false == n_oc_item_autoscroll_is_inner( p, index ) )
	{

		n_type_gfx offset = (n_type_gfx) p->scroll_item_per_line;

		before = n_oc_item_autoscroll_is_inner( p, index + offset );
		after  = n_oc_item_autoscroll_is_inner( p, index - offset );

	}


	if ( ret_before != NULL ) { (*ret_before) = before; }
	if ( ret_after  != NULL ) { (*ret_after ) = after ; }


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " is_edge() : %d %d : Index %d ", before, after, index );
}

	return before | after;
}

void
n_oc_item_autoscroll( n_oc_item *p, n_type_int index, int option )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }

	if ( ( index < 0 )||( index >= p->count ) ) { return; }


//n_oc_item_autoscroll_calculate( p, index, NULL, NULL ); return;
//n_oc_item_autoscroll_is_inner ( p, index             ); return;
//n_oc_item_autoscroll_is_edge  ( p, index, NULL, NULL ); return;


	if ( option == N_OC_ITEM_AUTOSCROLL_SMART )
	{

		n_type_gfx fx,fy; n_oc_item_position_calculate( p, index, &fx, &fy, n_true );

		n_type_gfx tx = (n_type_gfx) ( fx + p->cell_sx );
		n_type_gfx ty = (n_type_gfx) ( fy + p->cell_sy );
//n_game_hwndprintf_literal( " %d %d : %d %d : %g %g ", fx,fy, tx,ty, p->sx,p->sy );

		if (
			( fx < ( -p->cell_sx ) )
			||
			( fy < ( -p->cell_sy ) )
			||
			( tx >= ( p->sx + p->cell_sx ) )
			||
			( ty >= ( p->sy + p->cell_sy ) )
		)
		{
			n_oc_item_autoscroll( p, index, N_OC_ITEM_AUTOSCROLL_CENTERING );
		}

	} else
	if ( option == N_OC_ITEM_AUTOSCROLL_CENTERING )
	{

		n_type_gfx x,y; n_oc_item_autoscroll_calculate( p, index, &x, &y );

		n_type_gfx offset;
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			offset = (n_type_gfx) ( x * p->cell_sx );
		} else {
			offset = (n_type_gfx) ( y * p->cell_sy );
		}

		n_type_gfx pos = (n_type_gfx) ( offset - ( oc.scrollbar.unit_page / 2 ) );

		oc.scrollbar.unit_pos = 0;
		n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

	} else {

		n_bool before, after;
		n_oc_item_autoscroll_is_edge( p, index, &before, &after );
		if ( before )
		{

			n_type_gfx x,y; n_oc_item_position_calculate( p, index, &x, &y, n_true );

			n_type_gfx pos;
			if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
			{
				pos = (n_type_gfx) ( x - p->ox );
				if ( oc.cursor_x < ( oc.unit_path + p->ox ) ) { pos += (n_type_gfx) p->ox; }
			} else {
				pos = (n_type_gfx) ( y - p->oy - oc.unit_path );
				if ( oc.cursor_y < ( oc.unit_path + p->oy ) ) { pos += (n_type_gfx) p->oy; }
			}

			n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		} else
		if ( after )
		{
//n_game_debug_count();
			n_type_gfx x,y; n_oc_item_position_calculate( p, index, &x, &y, n_true );

			n_type_gfx pos;
			if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
			{
				pos = (n_type_gfx) ( ( x + p->cell_sx - p->sx                ) - p->ox );
				if ( ( oc.cursor_x                ) > ( p->sx - p->ox ) ) { pos -= (n_type_gfx) p->ox; }
			} else {
				pos = (n_type_gfx) ( ( y + p->cell_sy - p->sy - oc.unit_path ) - p->oy );
				if ( ( oc.cursor_y - oc.unit_path ) > ( p->sy - p->oy ) ) { pos -= (n_type_gfx) p->oy; }
//n_game_hwndprintf_literal( "%d %d", oc.cursor_y - oc.unit_path, (int) ( p->sy - p->oy ) );
			}

			n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		}

	}


	return;
}


