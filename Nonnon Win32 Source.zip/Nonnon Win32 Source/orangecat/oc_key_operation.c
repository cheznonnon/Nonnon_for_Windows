// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_oc_key_operation_path( n_oc_path *p, int vk )
{

	n_type_int p_focus = p->focus;


	if ( vk == VK_LEFT )
	{
		if ( p->focus == N_ORANGECAT_NOTHING )
		{
			p->focus = p->count - 1;
		} else {
			p->focus = n_posix_max_n_type_int( 0, p->focus - 1 );
		}
	} else
	if ( vk == VK_RIGHT )
	{
		if ( p->focus == N_ORANGECAT_NOTHING )
		{
			p->focus = p->count - 1;
		} else {
			p->focus = n_posix_min_n_type_int( p->count - 1, p->focus + 1 );
		}
	} else {
		return;
	}


	if ( ( p->focus != N_ORANGECAT_NOTHING )&&( p_focus != p->focus ) )
	{
		n_bmp_fade_go( &p->fade[ p->focus ], oc_color.path_hover );
		n_oc_path_draw( p );
	}


	return;
}

void
n_oc_key_operation_item( n_oc_item *p, int vk )
{

	if ( p->count == 0 ) { return; }


	// [Patch] : when multiple items are selected

	n_type_int count = n_oc_item_multifocus_count ( p );
	n_type_int focus = n_oc_item_multifocus_single( p );
//n_game_hwndprintf_literal( " Count %d : Curretnt %d ", count, focus );


	n_type_int index = focus;


	//p->patch_forced_hover          = N_ORANGECAT_NOTHING;
	//p->patch_forced_focus[ index ] = n_false;

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{

		if ( vk == VK_UP )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max_n_type_int( 0, focus - 1 );
			}
		} else
		if ( vk == VK_DOWN )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min_n_type_int( ( p->count - 1 ), focus + 1 );
			}
		} else
		if ( vk == VK_LEFT )
		{
			n_type_int ipl = (n_type_int) p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max_n_type_int( focus % ipl, focus - ipl );
			}
		} else
		if ( vk == VK_RIGHT )
		{
			n_type_int ipl = (n_type_int) p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				if ( ( focus + ipl ) < p->count )
				{
					index += ipl;
				} else
				if ( ( ( focus + ipl ) / ipl * ipl ) < p->count )
				{
					index = p->count - 1;
				}
			}
		} else {
			return;
		}

	} else
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_ICON )
	{

		if ( vk == VK_UP )
		{
			n_type_int ipl = (n_type_int) p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max_n_type_int( focus % ipl, focus - ipl );
			}
		} else
		if ( vk == VK_DOWN )
		{
			n_type_int ipl = (n_type_int) p->scroll_item_per_line;
			if ( count == 0 )
			{
				index = 0;
			} else {
				if ( ( focus + ipl ) < p->count )
				{
					index += ipl;
				} else
				if ( ( ( focus + ipl ) / ipl * ipl ) < p->count )
				{
					index = p->count - 1;
				}
			}
		} else
		if ( vk == VK_LEFT )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max_n_type_int( 0, focus - 1 );
			}
		} else
		if ( vk == VK_RIGHT )
		{
			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min_n_type_int( ( p->count - 1 ), focus + 1 );
			}
		} else {
			return;
		}

	} else {

		if ( vk == VK_UP )
		{
//n_game_hwndprintf_literal( " VK_UP " );

			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_max_n_type_int( 0, focus - 1 );
			}
		} else
		if ( vk == VK_DOWN )
		{
//n_game_hwndprintf_literal( " VK_DOWN " );

			if ( count == 0 )
			{
				index = 0;
			} else {
				index = n_posix_min_n_type_int( ( p->count - 1 ), focus + 1 );
			}
		} else {
			return;
		}

	}


	n_oc_item_multifocus_off( p );
	p->multifocus[ index ] = n_true;

	p->hover_prv = N_ORANGECAT_NOTHING;


	n_bool scroll_onoff = n_false;
	if (
		( n_false == n_oc_item_autoscroll_is_edge( p, index, NULL, NULL ) )
		&&
		( n_false == n_oc_item_autoscroll_is_inner( p, index ) )
	)
	{
		scroll_onoff = n_true;
	}
//n_game_hwndprintf_literal( " %d ", scroll_onoff );

	if ( scroll_onoff )
	{
		extern void n_oc_item_autoscroll_calculate( n_oc_item*, n_type_int, n_type_gfx*, n_type_gfx* );
		n_type_gfx x,y; n_oc_item_autoscroll_calculate( p, index, &x, &y );
//n_game_hwndprintf_literal( " %d %d ", x, y );

		n_type_int offset;
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			offset = (n_type_int) ( (n_type_real) x * p->cell_sx );
		} else {
			offset = (n_type_int) ( (n_type_real) y * p->cell_sy );
		}
//n_game_hwndprintf_literal( " %d %d %d ", y, offset, (int) p->sy );

		if ( offset > p->sy )
		{
			n_win_scrollbar_scroll_unit( &oc.scrollbar,  p->cell_sy, N_WIN_SCROLLBAR_SCROLL_AUTO );
		} else
		if ( offset < p->sy )
		{
			n_win_scrollbar_scroll_unit( &oc.scrollbar, -p->cell_sy, N_WIN_SCROLLBAR_SCROLL_AUTO );
		}

	}


	n_oc_item_autoscroll( p, index, N_OC_ITEM_AUTOSCROLL_DEFAULT );


	return;
}

void
n_oc_key_operation( int vk, n_bool forced_frame_onoff )
{

	if ( n_win_simplemenu_target != NULL ) { return; }


	if ( oc.view != N_ORANGECAT_VIEW_FILE ) { return; }


	if ( vk == VK_PRIOR   ) { return; }
	if ( vk == VK_NEXT    ) { return; }

	if ( vk == VK_CONTROL ) { return; }
	if ( vk == VK_SHIFT   ) { return; }

	if ( vk == VK_RETURN  ) { return; }

	if ( vk == VK_DELETE  ) { return; }

	if ( n_win_is_input( VK_CONTROL ) ) { return; }
	if ( n_win_is_input( VK_SHIFT   ) ) { return; }


	if (
		( vk == VK_TAB   )
		||
		( vk == VK_UP    )
		||
		( vk == VK_DOWN  )
		||
		( vk == VK_LEFT  )
		||
		( vk == VK_RIGHT )
	)
	{
		n_oc_key_operation_onoff( n_true );
		n_memory_zero( item.patch_forced_focus, sizeof( n_bool ) * item.count );

		n_type_int index = n_oc_item_multifocus_single( &item );
		if ( index == N_ORANGECAT_NOTHING ) { index = 0; }
		n_oc_item_autoscroll( &item, index, N_OC_ITEM_AUTOSCROLL_SMART );

		n_oc_event_redraw_fast();
	}


	if ( vk == VK_TAB )
	{


		// [Patch] : init code

		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
		{
			n_type_int count = n_oc_item_multifocus_count( &item );

			if ( count == 0 )
			{
				if ( item.count == 0 )
				{
					//
				} else {
					if ( item.multifocus[ 0 ] == n_false )
					{
						item.multifocus[ 0 ] = n_true;
					}
					oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;
				}
			}
		}


		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
		{

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;

			path.focus = path.count - 1;
			n_bmp_fade_go( &path.fade[ path.focus ], oc_color.path_hover );
			n_oc_path_draw( &path );

		} else
		if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
		{

			oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;

			path.focus = N_ORANGECAT_NOTHING;

		} else {

			return;
		}

		n_oc_event_redraw_fast();

	}


//oc.view_focus = N_ORANGECAT_VIEW_FOCUS_ITEM;
//oc.view_focus = N_ORANGECAT_VIEW_FOCUS_PATH;

	if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_ITEM )
	{
		n_oc_key_operation_item( &item, vk );
	} else
	if ( oc.view_focus == N_ORANGECAT_VIEW_FOCUS_PATH )
	{
		n_oc_key_operation_path( &path, vk );
	}


	return;
}

