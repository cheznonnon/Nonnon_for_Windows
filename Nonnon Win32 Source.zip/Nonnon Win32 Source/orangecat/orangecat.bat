
@echo off

set compile=..\nonnon\project\compile.bat
set    name=orangecat
set  window=-mwindows

%compile%

