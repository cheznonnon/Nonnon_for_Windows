// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_oc_item_drag2select_frame_1px( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 fg, u32 bg, n_bool is_dotted )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx fx  = x;
	n_type_gfx fy  = y;
	n_type_gfx tx  = x + sx - 1;
	n_type_gfx ty  = y + sy - 1;


	if ( is_dotted )
	{

		// Top
		n_bmp_line_dot( bmp, fx,fy,tx,fy, fg, 1 );
		n_bmp_line_dot( bmp, fx,fy,tx,fy, bg, 2 );

		// Bottom
		n_bmp_line_dot( bmp, fx,ty,tx,ty, fg, 1 );
		n_bmp_line_dot( bmp, fx,ty,tx,ty, bg, 2 );

		fy++;
		ty--;

		// Left
		n_bmp_line_dot( bmp, fx,fy,fx,ty, fg, 1 );
		n_bmp_line_dot( bmp, fx,fy,fx,ty, bg, 2 );

		// Right
		n_bmp_line_dot( bmp, tx,fy,tx,ty, fg, 1 );
		n_bmp_line_dot( bmp, tx,fy,tx,ty, bg, 2 );

	} else {

		// Top
		n_bmp_line( bmp, fx,fy,tx,fy, fg );

		// Bottom
		n_bmp_line( bmp, fx,ty,tx,ty, fg );

		fy++;
		ty--;

		// Left
		n_bmp_line( bmp, fx,fy,fx,ty, fg );

		// Right
		n_bmp_line( bmp, tx,fy,tx,ty, fg );

	}



	return;
}

void
n_oc_item_drag2select_frame( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 fg, u32 bg, n_bool is_dotted )
{

	// [x] : scaled frame : remainder is troublesome : see n_oc_lineframe() @ oc_core.c

	//const n_type_gfx unit = 10;
	const n_type_gfx unit = oc.unit_scal;

	if ( sx <= unit ) { return; }
	if ( sy <= unit ) { return; }


	n_type_gfx i = 0;
	n_posix_loop
	{

		n_oc_item_drag2select_frame_1px( bmp, x + i, y + i, sx - ( i * 2 ), sy - ( i * 2 ), fg, bg, is_dotted );

		i++;
		if ( i >= unit ) { break; }
	}


	return;
}

void
n_oc_item_drag2select_draw( n_oc_item *p )
{
//return;

	if ( n_oc_item_error( p ) ) { return; }


	if ( p->drag2select_onoff == n_false ) { return; }


	n_bool is_slowmode = n_false;


	if ( is_slowmode )
	{

		// [!] : slow mode

		p->is_blank = n_false;
		n_oc_item_erase( p );

	} else {

		// [!] : fast mode

		n_type_gfx  x = p->drag2select_px;
		n_type_gfx  y = p->drag2select_py;
		n_type_gfx sx = p->drag2select_psx;
		n_type_gfx sy = p->drag2select_psy;

		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			x -= (n_type_gfx) oc.scrollbar.unit_pos; 
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			y -= (n_type_gfx) oc.scrollbar.unit_pos;
		}

		u32 color = oc_color.bg;
//color = n_bmp_rgb( 255,0,0 );
		n_bmp_box( &game.bmp, x,y,sx,sy, color );

	}


	n_oc_item_fade_partial( p, n_false );


	n_type_int index_f, index_t; n_oc_item_scan_index( &item, &index_f, &index_t, n_false );
	n_posix_loop
	{//break;

		if ( index_f >= index_t ) { break; }

		n_bool redraw = n_false;

		if ( is_slowmode )
		{

			redraw = n_true;

		} else {

			if ( oc.view_is_computer )
			{

				redraw = n_true;

			} else {

				if ( ( p->multifocus[ index_f ] )||( n_false == p->fade[ index_f ].stop ) )
				{
					redraw = n_true;
//p->fade[ i ].color_fg = n_bmp_rgb( 255,0,0 );
				}

			}

		}

		if ( redraw )
		{
			//n_bmp_fade_redraw( &p->fade[ index_f ] );
			n_oc_item_draw_single( p, index_f, n_true );
		}

		index_f++;

	}


	{
//n_game_debug_count();

		n_type_gfx  x = p->drag2select_x;
		n_type_gfx  y = p->drag2select_y;
		n_type_gfx sx = p->drag2select_sx;
		n_type_gfx sy = p->drag2select_sy;


		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			x -= (n_type_gfx) oc.scrollbar.unit_pos;
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			y -= (n_type_gfx) oc.scrollbar.unit_pos;
		}

//n_game_hwndprintf_literal( " %d %d %d %d ", x,y,sx,sy );


		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			n_type_real pos  = oc.scrollbar.unit_pos;
			n_type_real last = oc.scrollbar.unit_max - oc.scrollbar.unit_page;
			if ( ( pos >= last )&&( ( x + sx ) >= game.sx ) ) { sx = game.sx - x + 1; }
		} else
		if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL   )
		{
			n_type_real pos  = oc.scrollbar.unit_pos;
			n_type_real last = oc.scrollbar.unit_max - oc.scrollbar.unit_page;
			if ( ( pos >= last )&&( ( y + sy ) >= game.sy ) ) { sy = game.sy - y + 1; }
		}

		if ( ( x + sx ) > (   p->sx                  ) ) { sx = (n_type_gfx) (   p->sx                  - x ); }
		if ( ( y + sy ) > ( ( p->sy + oc.unit_path ) ) ) { sy = (n_type_gfx) ( ( p->sy + oc.unit_path ) - y ); }


		if ( oc.dragselection_alpha_onoff )
		{

			n_bmp_mixer( &game.bmp, x,y,sx,sy, oc_color.item_select, 0.33 );

			u32 fg = oc_color.item_select;
			u32 bg = oc_color.item_select;

			n_oc_item_drag2select_frame( &game.bmp, x,y,sx,sy, fg, bg, n_true );

		} else {

			u32 fg = N_ORANGECAT_COLOR_BLACK;
			u32 bg = n_bmp_white;

			n_oc_item_drag2select_frame( &game.bmp, x,y,sx,sy, fg, bg, n_true );

		}


		p->drag2select_px  = p->drag2select_x;
		p->drag2select_py  = p->drag2select_y;
		p->drag2select_psx = p->drag2select_sx;
		p->drag2select_psy = p->drag2select_sy;

	}


	// [Needed] : when scrroll is not zero

	n_oc_path_draw( &path );


	p->is_blank = n_false;


	n_game_refresh_on();
	return;
}

void
n_oc_item_drag2select_focus( n_oc_item *p )
{

	if ( p->drag2select_onoff == n_false ) { return; }


	n_type_int index_min = p->count;
	n_type_int index_max = 0;


	n_type_int index_f, index_t; n_oc_item_scan_index( &item, &index_f, &index_t, n_false );
	n_posix_loop
	{

		if ( index_f >= index_t ) { break; }


		n_type_gfx fx = 0;
		n_type_gfx fy = 0;

		n_oc_item_position_calculate( p, index_f, &fx, &fy, n_false );


		n_type_gfx sx = N_BMP_SX( &p->bmp[ index_f ] );
		n_type_gfx sy = N_BMP_SY( &p->bmp[ index_f ] );
		n_type_gfx tx = fx + n_oc_item_lineselection( p, sx );
		n_type_gfx ty = fy + sy;


		n_type_gfx drag_fx = p->drag2select_x;
		n_type_gfx drag_fy = p->drag2select_y;
		n_type_gfx drag_tx = drag_fx + p->drag2select_sx;
		n_type_gfx drag_ty = drag_fy + p->drag2select_sy;

		if (
			( ( drag_fx < fx )||( drag_fx < tx ) )
			&&
			( ( drag_tx > fx )||( drag_tx > tx ) )
			&&
			( ( drag_fy < fy )||( drag_fy < ty ) )
			&&
			( ( drag_ty > fy )||( drag_ty > ty ) )
		)
		{

			n_bool hover_onoff = n_true;

			if ( oc.is_round )
			{
				hover_onoff = n_win_is_hovered_offset( game.hwnd, fx, fy, sx, sy );
				if ( hover_onoff )
				{
					hover_onoff = n_oc_item_collision_roundrect( p, index_f, fx, fy, sx, sy, n_true );
				} else {
					hover_onoff = n_true;
				}
			}

			if ( hover_onoff )
			{

				n_bool go = n_false;

				if ( oc.view_is_computer )
				{
					if ( n_oc_item_comnputer_is_drive( p, index_f ) ) { go = n_true; }
				} else {
					go = n_true;
				}

				if ( go )
				{
					p->multifocus[ index_f ] =  n_true;
					p->load_index = index_f;

					n_oc_item_preload_single( p, p->load_index, n_true );

					if ( index_min > index_f ) { index_min = index_f; }
					if ( index_max < index_f ) { index_max = index_f; }
				}

			} else {

				p->multifocus[ index_f ] = n_false;

			}

		} else {

			p->multifocus[ index_f ] = n_false;

		}


		index_f++;

	}


	if ( oc.debug_drag2select_onoff )
	{
		n_game_hwndprintf_literal( "%g : %d %d", p->scroll_item_per_line, index_min, index_max );
	}


	return;
}

void
n_oc_item_drag2select_init( n_oc_item *p )
{
//return;

//n_game_debug_count();


	// [!] : for Grab N Drag

	if ( oc.is_mbutton ) { return; }
	if ( oc.is_rbutton ) { return; }


	if ( p->drag2select_onoff ) { return; }


	n_type_gfx x = oc.cursor_x;
	n_type_gfx y = oc.cursor_y;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		x += (n_type_gfx) oc.scrollbar.unit_pos;
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		y += (n_type_gfx) oc.scrollbar.unit_pos;
	}

	p->drag2select_onoff = n_true;
	p->drag2select_fx    = x;
	p->drag2select_fy    = y;
	p->drag2select_x     = p->drag2select_fx;
	p->drag2select_y     = p->drag2select_fy;
	p->drag2select_sx    = 0;
	p->drag2select_sy    = 0;

	p->drag2select_px    = p->drag2select_x;
	p->drag2select_py    = p->drag2select_y;
	p->drag2select_psx   = p->drag2select_sx;
	p->drag2select_psy   = p->drag2select_sy;


	if ( oc.focuskeeper_onoff )
	{
		//
	} else
	if ( p->patch_forced_frame_phase == N_OC_ITEM_FORCED_FRAME_ON_1 )
	{

		p->patch_forced_frame_phase = N_OC_ITEM_FORCED_FRAME_ON_2;

		n_oc_item_multifocus_fade_off( p );

	} else {

		int *focus = n_memory_new_closed( sizeof( n_bool ) * p->count );
		if ( p->is_move_reserved )
		{
			n_memory_copy( p->multifocus, focus, sizeof( n_bool ) * p->count );
		}

		n_oc_item_multifocus_off( p );

		if ( p->is_move_reserved )
		{
			n_memory_copy( focus, p->multifocus_move, sizeof( n_bool ) * p->count );
		}
		n_memory_free_closed( focus );

	}


	return;
}

void
n_oc_item_drag2select_loop( n_oc_item *p )
{
//return;

	if ( p->drag2select_onoff == n_false ) { return; }


	//if ( oc.scrollbar.drag_onoff ) { return; }


	n_type_gfx cursor_x = oc.cursor_x;
	n_type_gfx cursor_y = oc.cursor_y;

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		cursor_x += (n_type_gfx) oc.scrollbar.unit_pos;
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		cursor_y += (n_type_gfx) oc.scrollbar.unit_pos;
	}

	if ( cursor_x <            0 ) { cursor_x =            0; }
	if ( cursor_y < oc.unit_path ) { cursor_y = oc.unit_path; }


	p->drag2select_sx = n_posix_max( oc.unit_scal * 2, abs( cursor_x - p->drag2select_fx ) );
	p->drag2select_x  = n_posix_min_n_type_gfx( cursor_x, p->drag2select_fx );

	p->drag2select_sy = n_posix_max( oc.unit_scal * 2, abs( cursor_y - p->drag2select_fy ) );
	p->drag2select_y  = n_posix_min_n_type_gfx( cursor_y, p->drag2select_fy );

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		if ( ( p->drag2select_y + p->drag2select_sy ) >= ( p->sy + oc.unit_path ) )
		{
			p->drag2select_sy = (n_type_gfx) ( ( p->sy + oc.unit_path ) - p->drag2select_y );
		}
	} else
	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		if ( ( p->drag2select_x + p->drag2select_sx ) >= ( p->sx                ) )
		{
			p->drag2select_sx = (n_type_gfx) ( ( p->sx                ) - p->drag2select_x );
		}
	}

/*
	p->drag2select_x  = 100;
	p->drag2select_sx = 100;
	p->drag2select_y  = 100;
	p->drag2select_sy = 100;
*/


	n_oc_item_drag2select_focus( p );


	n_oc_item_drag2select_draw( p );


	return;
}

void
n_oc_item_drag2select_exit( n_oc_item *p )
{
//return;

	if ( p->drag2select_onoff )
	{

		p->drag = N_ORANGECAT_DRAG_NEUTRAL;

		p->drag2select_onoff = n_false;
		p->drag2select_fx    = 0;
		p->drag2select_fy    = 0;
		p->drag2select_x     = 0;
		p->drag2select_y     = 0;
		p->drag2select_sx    = 0;
		p->drag2select_sy    = 0;

		p->drag2select_px    = 0;
		p->drag2select_py    = 0;
		p->drag2select_psx   = 0;
		p->drag2select_psy   = 0;

		p->is_blank = n_false;
		n_oc_item_erase( p );
		n_oc_item_draw( p );
		n_oc_path_draw( &path );
		//n_win_scrollbar_refresh( &oc.scrollbar );
		n_game_refresh_on();

	}


	return;
}


