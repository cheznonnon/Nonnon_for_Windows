
@echo off

set compile=..\nonnon\project\compile.bat
set    name=lm2
set  window=-mwindows

%compile%

