
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nspider
set  window=-mwindows

%compile%

