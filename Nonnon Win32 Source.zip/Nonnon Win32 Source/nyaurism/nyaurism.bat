
@echo off

set compile=..\nonnon\project\compile.bat
set    name=nyaurism
set  window=-mwindows

%compile%

