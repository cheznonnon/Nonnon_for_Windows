// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win64/ui/window.c"
#include "../nonnon/win64/ui/button.c"
#include "../nonnon/win64/ui/label.c"
#include "../nonnon/win64/ui/slider.c"




static HWND n_nyaursim_hwnd_eq = NULL;


static n_win64_ui_button n_eq_undo;
static n_win64_ui_button n_eq_analyze;
static n_win64_ui_button n_eq_reset;
static n_win64_ui_button n_eq_apply;

static n_win64_ui_slider n_eq_slider[ 10 ];
static n_win64_ui_label  n_eq_label [ 10 ];




void
n_nyaurism_equalizer_on_WM_PAINT( HWND hwnd, HDC hdc )
{

	RECT     rect; GetClientRect( hwnd, &rect );
	COLORREF colorref = n_win64_GetSysColor( COLOR_BTNFACE );

	HBRUSH br = CreateSolidBrush( colorref );

	FillRect( hdc, &rect, br );

	DeleteObject( br );


	int i = 0;
	n_posix_loop
	{

		n_win64_ui_slider_draw( &n_eq_slider[ i ], TRUE );
		n_win64_ui_label_draw ( &n_eq_label [ i ], TRUE );

		i++;
		if ( i >= 10 ) { break; }
	}

	n_win64_ui_button_draw( &n_eq_apply  , TRUE );
	n_win64_ui_button_draw( &n_eq_reset  , TRUE );
	n_win64_ui_button_draw( &n_eq_analyze, TRUE );
	n_win64_ui_button_draw( &n_eq_undo   , TRUE );


	i = 0;
	n_posix_loop
	{

		n_win64_doublebuffer_exit( &n_eq_slider[ i ].db );
		n_win64_doublebuffer_exit( &n_eq_label [ i ].db );

		i++;
		if ( i >= 10 ) { break; }
	}

	n_win64_doublebuffer_exit( &n_eq_apply  .db );
	n_win64_doublebuffer_exit( &n_eq_reset  .db );
	n_win64_doublebuffer_exit( &n_eq_analyze.db );
	n_win64_doublebuffer_exit( &n_eq_undo   .db );


	return;
}

LRESULT CALLBACK
n_nyaurism_equalizer_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static UINT darkmode_timer = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			darkmode_timer = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, darkmode_timer, 200 );
		}
	}
	break;


	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == darkmode_timer )
		{
			n_win64_timer_exit( hwnd, darkmode_timer );

			HDC hdc = GetDC( hwnd );
			n_nyaurism_equalizer_on_WM_PAINT( hwnd, hdc );
			ReleaseDC( hwnd, hdc );

			n_win64_darkmode_on_WM_SETTINGCHANGE( hwnd );
		}

	break;


	case WM_CREATE :

		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );


		// Window

		n_win64_ui_window_init( hwnd, L"Equalizer", N_STRING_EMPTY, N_STRING_EMPTY );

		n_win64_exstyle_add( hwnd, WS_EX_TOOLWINDOW );


		n_win64_ui_button_init( &n_eq_undo   , hwnd );
		n_win64_ui_button_init( &n_eq_analyze, hwnd );
		n_win64_ui_button_init( &n_eq_reset  , hwnd );
		n_win64_ui_button_init( &n_eq_apply  , hwnd );

		n_eq_undo   .label = n_posix_literal( "Undo" );
		n_eq_analyze.label = n_posix_literal( "Analyze" );
		n_eq_reset  .label = n_posix_literal( "Reset" );
		n_eq_apply  .label = n_posix_literal( "Apply" );

		n_eq_undo   .style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		n_eq_analyze.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		n_eq_reset  .style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		n_eq_apply  .style = N_WIN64_UI_BUTTON_STYLE_FLUENT;


		{
			int i = 0;
			n_posix_loop
			{
				n_win64_ui_slider_init( &n_eq_slider[ i ], hwnd, N_WIN64_UI_SLIDER_LAYOUT_VERT, 20 );
				n_eq_slider[ i ].pos = 10;
				n_eq_slider[ i ].tick_onoff = TRUE;

				n_win64_ui_label_init( &n_eq_label[ i ], hwnd, n_posix_literal( "0" ) );

				i++;
				if ( i >= 10 ) { break; }
			}
		}


		{
			const n_type_gfx unit    = n_win64_ui_stdsize( hwnd );
			const n_type_gfx padding = 16;
			const n_type_gfx margin  = 8;


			n_type_gfx desktop_sx, desktop_sy;
			n_win64_desktop_size( n_nyaurism->hwnd, &desktop_sx, &desktop_sy );

			RECT client_parent; GetClientRect( n_nyaurism->hwnd, &client_parent );

			n_type_gfx csx_parent = client_parent.right;
			n_type_gfx csy_parent = client_parent.bottom;

			n_type_gfx x = ( desktop_sx / 2 ) - ( csx_parent / 2 ) + csx_parent + 32;
			n_type_gfx y = ( desktop_sy / 2 ) - ( csy_parent / 2 );

			const n_type_gfx csx = 480;
			const n_type_gfx csy = 270;

			n_win64_ui_window_set( hwnd, x,y, csx,csy, FALSE );


			n_type_gfx sl_x = padding;
			n_type_gfx sl_y = padding;

			n_type_gfx lb_x = padding;
			n_type_gfx lb_y = csy - padding - unit;

			int i = 0;
			n_posix_loop
			{

				MoveWindow( n_eq_slider[ i ].hwnd, sl_x,sl_y,unit,csy-(padding*4), FALSE ); sl_x += unit + margin;
				MoveWindow( n_eq_label [ i ].hwnd, lb_x,lb_y,unit,unit           , FALSE ); lb_x += unit + margin;


				i++;
				if ( i >= 10 ) { break; }
			}


			n_type_gfx sx = 100;
			n_type_gfx sy = unit;

			x = csx - padding - sx;
			y = csy - padding - sy;

			n_win64_ui_button_move( &n_eq_apply  , x,y,sx,sy, FALSE ); y -= sy + margin;
			n_win64_ui_button_move( &n_eq_reset  , x,y,sx,sy, FALSE ); y -= sy + margin;
			n_win64_ui_button_move( &n_eq_analyze, x,y,sx,sy, FALSE ); y -= sy + margin;
			n_win64_ui_button_move( &n_eq_undo   , x,y,sx,sy, FALSE ); y -= sy + margin;
		}



		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		n_nyaurism_equalizer_on_WM_PAINT( hwnd, ps.hdc );

		EndPaint( hwnd, &ps );
	}
	break;


	case WM_COMMAND :

		if ( (HWND) lParam == n_eq_undo.hwnd )
		{
			if ( n_nyaurism->selection_shift_onoff ) { break; }

			n_nyaurism_plotter_undo( &n_nyaurism->wav );

			n_win64_refresh( GetParent( hwnd ), FALSE );
		} else
		if ( (HWND) lParam == n_eq_analyze.hwnd )
		{
			int    histogram_count = 10;
			double histogram[ histogram_count ];

			n_fft_histogram_main( &n_nyaurism->wav, histogram, histogram_count, N_NYAURISM_FFT_RESOLUTION, NO );

			for( int i = 0; i < histogram_count; i++ )
			{
				histogram[ i ]  = n_wav_sample_clamp_normalized( histogram[ i ] );
				histogram[ i ] -=  1.0;
				histogram[ i ] *= 10;
//n_posix_debug_literal( "%f", histogram[ i ] );

				n_eq_slider[ i ].pos = round( histogram[ i ] ) + 10;
				n_win64_ui_label_value_set( &n_eq_label[ i ], n_eq_slider[ i ].pos - 10 );

				n_win64_refresh( n_eq_slider[ i ].hwnd, FALSE );
				n_win64_refresh( n_eq_label [ i ].hwnd, FALSE );

			}
		} else
		if ( (HWND) lParam == n_eq_reset.hwnd )
		{

			int i = 0;
			n_posix_loop
			{

				n_eq_slider[ i ].pos = 10;
				n_win64_ui_label_value_set( &n_eq_label[ i ], n_eq_slider[ i ].pos - 10 );

				n_win64_refresh( n_eq_slider[ i ].hwnd, FALSE );
				n_win64_refresh( n_eq_label [ i ].hwnd, FALSE );

				i++;
				if ( i >= 10 ) { break; }
			}

		} else
		if ( (HWND) lParam == n_eq_apply.hwnd )
		{

			int num_bands = 10;

			double gains_db[ 10 ];

			int i = 0;
			n_posix_loop
			{

				gains_db[ i ] = n_eq_slider[ i ].pos - 10;

				i++;
				if ( i >= num_bands ) { break; }
			}


			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_undo );


			n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &n_nyaurism->wav, &x, &sx );
			if ( sx == 0 ) { sx = N_WAV_COUNT( &n_nyaurism->wav ); }
			if ( n_nyaurism_plotter_selection_line_only() ) { sx = 0; }

//NSLog( @"%d %d", x, sx );


			n_win64_busy_cursor( TRUE );

			if ( ( x == 0 )&&( sx == N_WAV_COUNT( &n_nyaurism->wav ) )&&( n_nyaurism->mix_onoff == FALSE ) )
			{
				n_fft_equalizer_apply( &n_nyaurism->wav, gains_db, num_bands, N_NYAURISM_FFT_RESOLUTION );
			} else {
				n_wav tmp; n_wav_carboncopy( &n_nyaurism->wav, &tmp );

				n_fft_equalizer_apply( &tmp, gains_db, num_bands, N_NYAURISM_FFT_RESOLUTION );


				n_type_real l = 1.0; if ( n_nyaurism->plotter_selection_channel == 1 ) { l = -1; }
				n_type_real r = 1.0; if ( n_nyaurism->plotter_selection_channel == 2 ) { r = -1; }

				if ( n_nyaurism->mix_onoff )
				{
					n_wav_copy( &tmp, &n_nyaurism->wav, x, sx, x, l, r, N_WAV_COPY_ADD );
				} else {
					n_wav_copy( &tmp, &n_nyaurism->wav, x, sx, x, l, r, N_WAV_COPY_SET );
				}


				n_wav_free( &tmp );
			}

			n_win64_busy_cursor( FALSE );

			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_base );

			n_nyaurism_slider_redraw( &n_nyaurism->wav );


			n_win64_refresh( GetParent( hwnd ), FALSE );


			//[self NonnonNyaurismEqualizerUIOnOff:TRUE];

		} else
		//
		{
			int i = 0;
			n_posix_loop
			{

				n_win64_ui_label_value_set( &n_eq_label[ i ], n_eq_slider[ i ].pos - 10 );

				i++;
				if ( i >= 10 ) { break; }
			}
		}

	break;


	case WM_CLOSE :

		{
			int i = 0;
			n_posix_loop
			{

				n_win64_ui_slider_exit( &n_eq_slider[ i ] );
				n_win64_ui_label_exit ( &n_eq_label [ i ] );

				i++;
				if ( i >= 10 ) { break; }
			}
		}

		n_win64_ui_button_exit( &n_eq_undo );
		n_win64_ui_button_exit( &n_eq_analyze );
		n_win64_ui_button_exit( &n_eq_reset );
		n_win64_ui_button_exit( &n_eq_apply );


		n_nyaursim_hwnd_eq = NULL;

		n_button_eq.fake_onoff = FALSE;
		n_win64_refresh( n_button_eq.hwnd, FALSE );

		DestroyWindow( hwnd );

	break;


	} // switch


	{
		int i = 0;
		n_posix_loop
		{

			n_win64_ui_slider_proc( hwnd, msg, wParam, lParam, &n_eq_slider[ i ] );
			n_win64_ui_label_proc ( hwnd, msg, wParam, lParam, &n_eq_label [ i ] );

			i++;
			if ( i >= 10 ) { break; }
		}
	}


	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_eq_undo );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_eq_analyze );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_eq_reset );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_eq_apply );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

