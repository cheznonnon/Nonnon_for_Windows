// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#define N_WAV_FORMAT_FLOAT_ON


#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/neutral/fft.c"

#include "../nonnon/win64/_windows.c"
#include "../nonnon/win64/resource.c"

#include "../nonnon/win64/ui/button.c"
#include "../nonnon/win64/ui/groupbox.c"
#include "../nonnon/win64/ui/menu.c"
#include "../nonnon/win64/ui/slider.c"
#include "../nonnon/win64/ui/txtbox.c"
#include "../nonnon/win64/ui/value.c"
#include "../nonnon/win64/ui/window.c"


#define NO  FALSE
#define YES  TRUE




BOOL
n_nyaurism_dialog_yesno( HWND hwnd, const n_posix_char *str )
{

	int mb = MB_TOPMOST | MB_ICONINFORMATION | MB_YESNO;
	int ret = MessageBox( hwnd, str, n_posix_literal( "Info" ), mb );

	return ( ret == IDYES );
}




n_posix_char*
n_win64_fork_rename( n_posix_char *path )
{

	n_posix_char *dir = n_string_path_upperfolder_new( path );
	n_posix_char *ext = n_string_path_ext_get_new( path );
	n_posix_char *nam = n_string_path_tmpname_new( ext );
	n_posix_char *ret = n_string_path_make_new( dir, nam );

	n_string_free( dir );
	n_string_free( ext );
	n_string_free( nam );


	return ret;
}




void
n_nyaurism_backup( n_wav *f, n_wav *t )
{

	n_wav_free( t );
	n_wav_carboncopy( f, t );

	return;
}




// [!] : Components

#define N_NYAURISM_FFT_RESOLUTION pow( 2, 14 ) // [!] : higher is better but heavy


#define N_NYAURISM_PLAYBACK_STOP    ( 0 )
#define N_NYAURISM_PLAYBACK_PLAYING ( 1 )
#define N_NYAURISM_PLAYBACK_PAUSE   ( 2 )




typedef struct {

	HWND          hwnd;

	n_posix_char *fname;

	//n_bmp        bmp;
	n_wav        wav;

	n_wav        wav_undo;
	n_wav        wav_base;
	n_wav        wav_clip;

	n_wav        wav_play;

	BOOL         mix_onoff;

	int          plotter_selection_channel;

	n_win64_ui_value  value_l;
	n_win64_ui_value  value_r;
	n_win64_ui_slider slider_l;
	n_win64_ui_slider slider_r;

	n_bmp        seekbar_bmp;
	float        seekbar_float_norm;

	HWAVEOUT     hwo;
	int          playback_status;
	u32          playback_timeout;
	float        playback_msec_x;
	float        playback_msec_sx;
	float        playback_prev_x;

	BOOL         selection_command_onoff;

	BOOL         selection_shift_onoff;
	n_type_gfx   selection_shift_pixel;

	BOOL         selection_reselect_onoff;
	n_type_gfx   selection_reselect_pixel;

	BOOL         selection_reverse;
	BOOL         selection_drag_onoff;
	BOOL         selection_select_all;

	n_type_gfx   selection_step;
	n_type_gfx   selection_size_pixel;
	n_type_gfx   selection_from_pixel;
	n_type_gfx   selection_loop_pixel;

} n_nyaurism_struct;

#define n_nyaurism_zero( p ) n_memory_zero( p, sizeof( n_nyaurism_struct ) )


static n_nyaurism_struct  n_nyaurism_instance;
static n_nyaurism_struct *n_nyaurism = &n_nyaurism_instance;




#define n_nyaurism_now_playing() ( n_nyaurism->seekbar_float_norm != -1 )




#include "./player.c"




// [!] : Constants

#define N_APPNAME "Nonnon Nyaurism"
#define N_ICONAME "NYAURISM_0_MAIN"

#define N_APPNAME_LITERAL n_posix_literal( "Nonnon Nyaurism" )
#define N_ICONAME_LITERAL n_posix_literal( "NYAURISM_0_MAIN" )




// internal
n_posix_char*
n_nyaurism_newname( void )
{

	n_posix_char *dir = n_string_path_folder_current_new();
	n_posix_char *tmp = n_string_path_tmpname_new_literal( ".wav" );
	n_posix_char *nam = n_string_path_make_new( dir, tmp );

	n_string_path_free( dir );
	n_string_path_free( tmp );
	//n_string_path_free( nam );


	return nam;
}

// internal
void
n_nyaurism_title( HWND hwnd )
{

	n_posix_char *s = n_string_carboncopy( n_nyaurism->fname );

	n_string_replace( s, s, N_STRING_BSLASH, N_STRING_SLASH );

	n_win64_hwndprintf_literal( hwnd, "%s - %s", s, N_APPNAME_LITERAL );

	n_memory_free( s );


	return;
}

// internal
void
n_nyaurism_newfile( HWND hwnd, const n_posix_char *name )
{

	if ( n_wav_load( &n_nyaurism->wav, name ) )
	{

		static BOOL is_first = TRUE;

		if ( is_first )
		{

			is_first = FALSE;

			n_wav_new_by_sample( &n_nyaurism->wav, 44100 * 5 );
			n_wav_martian( &n_nyaurism->wav, 0.25, 0.25 );

			n_string_path_free( n_nyaurism->fname );
			n_nyaurism->fname = n_nyaurism_newname();

		}

	} else {

		n_string_path_free( n_nyaurism->fname );
		n_nyaurism->fname = n_string_path_carboncopy( name );

	}

	n_nyaurism_title( hwnd );


	return;
}




#define n_button_setup_literal( p, r ) n_button_setup( p, n_posix_literal( r ) ) 

void
n_button_setup( n_win64_ui_button *p, n_posix_char *resource_name )
{

	//p->label         = label;
	p->resource_name = resource_name;

	p->style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

	n_win64_refresh( p->hwnd, FALSE );


	return;
}

void
n_button_setup_GDI( n_win64_ui_button *p, n_posix_char *text )
{

	p->style = N_WIN64_UI_BUTTON_STYLE_FLUENT;


	p->gdi_icon_onoff = TRUE;


	n_type_real scale_ui   = n_win64_scale_factor_ui  ( p->hwnd );
	//n_type_real scale_font = n_win64_scale_factor_font( p->hwnd );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = 40 * scale_ui;
	gdi.sy                  = 40 * scale_ui;

	gdi.text                = text;
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = 14 * scale_ui;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = n_bmp_rgb( 255,255,255 );

	u32 color_outline = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );
	if ( n_win64_darkmode_is_on() )
	{
		color_outline = n_bmp_blend_pixel( color_outline, n_bmp_black, 0.25 );
	} else {
		color_outline = n_bmp_blend_pixel( color_outline, n_bmp_black, 0.25 );
	}

	gdi.text_effect_style[ 0 ] = N_GDI_EFFECT_OUTLINE;
	gdi.text_effect_color[ 0 ] = color_outline;
	gdi.text_effect_param[ 0 ] = 1;

	p->gdi_icon = gdi;


	n_win64_refresh( p->hwnd, FALSE );


	return;
}




static n_win64_ui_button n_button_zero;
static n_win64_ui_button n_button_mix ;
static n_win64_ui_button n_button_stop;
static n_win64_ui_button n_button_play;
static n_win64_ui_button n_button_eq;
static n_win64_ui_button n_button_msec;
static n_win64_ui_button n_button_save;

static RECT n_win64_ui_vertical_separater;


#include "./plotter.c"

#include "./equalizer.c"




void
NonnonNyaurismUIContextPlayback( void )
{

	if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_STOP )
	{
		n_button_zero.gray_onoff = FALSE; n_win64_refresh( n_button_zero.hwnd, FALSE );
		n_button_mix .gray_onoff = FALSE; n_win64_refresh( n_button_mix .hwnd, FALSE );
		n_button_msec.gray_onoff = FALSE; n_win64_refresh( n_button_msec.hwnd, FALSE );
		n_button_save.gray_onoff = FALSE; n_win64_refresh( n_button_save.hwnd, FALSE );

		EnableWindow( n_nyaurism->value_l.hwnd, TRUE );
		EnableWindow( n_nyaurism->value_r.hwnd, TRUE );

		EnableWindow( n_nyaurism->slider_l.hwnd, TRUE );
		EnableWindow( n_nyaurism->slider_r.hwnd, TRUE );
	} else
	if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_PLAYING )
	{
		n_button_zero.gray_onoff = TRUE; n_win64_refresh( n_button_zero.hwnd, FALSE );
		n_button_mix .gray_onoff = TRUE; n_win64_refresh( n_button_mix .hwnd, FALSE );
		n_button_msec.gray_onoff = TRUE; n_win64_refresh( n_button_msec.hwnd, FALSE );
		n_button_save.gray_onoff = TRUE; n_win64_refresh( n_button_save.hwnd, FALSE );

		EnableWindow( n_nyaurism->value_l.hwnd, FALSE );
		EnableWindow( n_nyaurism->value_r.hwnd, FALSE );

		EnableWindow( n_nyaurism->slider_l.hwnd, FALSE );
		EnableWindow( n_nyaurism->slider_r.hwnd, FALSE );
	} else
	if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_PAUSE )
	{
		//
	}


	return;
}

void
NonnonNyaurismPlaybackReset( BOOL force_stop )
{
//return;

	if ( force_stop ) { n_nyaurism_player_stop( &n_nyaurism->hwo ); }

	n_button_setup_literal( &n_button_play, "NYAURISM_4_PLAY" );

	n_nyaurism->playback_status = N_NYAURISM_PLAYBACK_STOP;
	NonnonNyaurismUIContextPlayback();

	n_bmp_flush( &n_nyaurism->seekbar_bmp, n_bmp_black_invisible );
	n_nyaurism->seekbar_float_norm = -1;

	n_nyaurism_player_exit( &n_nyaurism->hwo, &n_nyaurism->wav_play );

	//n_mac_window_all_controls_onoff( [_n_eq_window contentView], YES );

	n_win64_refresh( n_plotter.hwnd, FALSE );


	return;
}




static n_win64_ui_groupbox n_config_group;
static n_win64_ui_value    n_config_label;
static n_txtbox            n_config_input;
static n_win64_ui_button   n_config_button_go;
static n_win64_ui_button   n_config_button_cancel;

void
NonnonNyaurismUIContextConfig( BOOL onoff )
{

	int sw_fr;
	int sw_to;

	if ( onoff )
	{
		sw_fr = SW_HIDE;
		sw_to = SW_NORMAL;
	} else {
		sw_fr = SW_NORMAL;
		sw_to = SW_HIDE;
	}

	ShowWindow( n_plotter    .hwnd, sw_fr );

	ShowWindow( n_button_zero.hwnd, sw_fr );
	ShowWindow( n_button_mix .hwnd, sw_fr );
	ShowWindow( n_button_stop.hwnd, sw_fr );
	ShowWindow( n_button_play.hwnd, sw_fr );
	ShowWindow( n_button_msec.hwnd, sw_fr );
	ShowWindow( n_button_save.hwnd, sw_fr );
	ShowWindow( n_button_eq  .hwnd, sw_fr );

	ShowWindow( n_nyaurism->value_l.hwnd, sw_fr );
	ShowWindow( n_nyaurism->value_r.hwnd, sw_fr );

	ShowWindow( n_nyaurism->slider_l.hwnd, sw_fr );
	ShowWindow( n_nyaurism->slider_r.hwnd, sw_fr );


	ShowWindow( n_config_group.hwnd, sw_to );
	ShowWindow( n_config_label.hwnd, sw_to );
	ShowWindow( n_config_input.hwnd, sw_to );

	ShowWindow( n_config_button_go    .hwnd, sw_to );
	ShowWindow( n_config_button_cancel.hwnd, sw_to );


	if ( onoff )
	{
		int msec = N_WAV_MSEC( &n_nyaurism->wav );

		n_posix_char *str = n_string_new( 1024 );
		n_posix_snprintf_literal( str, 1024+1, "%d", msec );
		n_txt_mod_fast( n_config_input.txt_data, 0, str );

		n_txtbox_caret_tail_set( &n_config_input );

		SetFocus( n_config_input.hwnd );
	}


	// [!] : for vertical line
	n_win64_refresh( GetParent( n_plotter.hwnd ), FALSE );


	return;
}




static n_win64_ui_groupbox n_formatter_group;
static n_txtbox            n_formatter_channel;
static n_txtbox            n_formatter_bit;
static n_txtbox            n_formatter_rate;
static n_win64_ui_button   n_formatter_button_go;
static n_win64_ui_button   n_formatter_button_cancel;

void
NonnonNyaurismFormatterApply( n_wav *wav )
{

	if ( wav->channel == 1 )
	{
		n_formatter_channel.focus = 0;
	} else {
		n_formatter_channel.focus = 1;
	}

	if ( wav->bit == 8 )
	{
		n_formatter_bit.focus = 0;
	} else
	if ( wav->bit == 16 )
	{
		n_formatter_bit.focus = 1;
	} else
	//if ( wav->bit == 32 )
	{
		n_formatter_bit.focus = 2;
	}

	if ( wav->rate == 11 )
	{
		n_formatter_rate.focus = 0;
	} else
	if ( wav->rate == 22 )
	{
		n_formatter_rate.focus = 1;
	} else
	//if ( wav->rate == 44 )
	{
		n_formatter_rate.focus = 2;
	}


	n_win64_refresh( n_formatter_channel.hwnd, FALSE );
	n_win64_refresh( n_formatter_bit    .hwnd, FALSE );
	n_win64_refresh( n_formatter_rate   .hwnd, FALSE );


	return;
}

void
NonnonNyaurismFormatterSave( HWND hwnd )
{

	n_wav *wav = &n_nyaurism->wav;

	if ( n_formatter_channel.focus == 0 )
	{
		wav->channel = 1;
	} else {
		wav->channel = 2;
	}

	if ( n_formatter_bit.focus == 0 )
	{
		wav->bit = 8;
		wav->format = N_WAV_FORMAT_PCM;
	} else
	if ( n_formatter_bit.focus == 1 )
	{
		wav->bit = 16;
		wav->format = N_WAV_FORMAT_PCM;
	} else {
		wav->bit = 32;
		wav->format = N_WAV_FORMAT_FLOAT;
	}

	if ( n_formatter_rate.focus == 0 )
	{
		wav->rate = 11;
	} else
	if ( n_formatter_rate.focus == 1 )
	{
		wav->rate = 22;
	} else {
		wav->rate = 44;
	}


	if ( n_posix_stat_is_exist( n_nyaurism->fname ) )
	{
		if ( FALSE == n_nyaurism_dialog_yesno( hwnd, n_posix_literal( "Overwrite?" ) ) )
		{
			return;
		}
	}

//n_win64_hwndprintf_literal( hwnd, "%d %d %d", wav->channel, wav->bit, wav->rate );

	n_wav_save( wav, n_nyaurism->fname );


	return;
}

void
NonnonNyaurismUIContextFormatter( BOOL onoff )
{

	int sw_fr;
	int sw_to;

	if ( onoff )
	{
		sw_fr = SW_HIDE;
		sw_to = SW_NORMAL;
	} else {
		sw_fr = SW_NORMAL;
		sw_to = SW_HIDE;
	}

	ShowWindow( n_plotter    .hwnd, sw_fr );

	ShowWindow( n_button_zero.hwnd, sw_fr );
	ShowWindow( n_button_mix .hwnd, sw_fr );
	ShowWindow( n_button_stop.hwnd, sw_fr );
	ShowWindow( n_button_play.hwnd, sw_fr );
	ShowWindow( n_button_msec.hwnd, sw_fr );
	ShowWindow( n_button_save.hwnd, sw_fr );
	ShowWindow( n_button_eq  .hwnd, sw_fr );

	ShowWindow( n_nyaurism->value_l.hwnd, sw_fr );
	ShowWindow( n_nyaurism->value_r.hwnd, sw_fr );

	ShowWindow( n_nyaurism->slider_l.hwnd, sw_fr );
	ShowWindow( n_nyaurism->slider_r.hwnd, sw_fr );


	ShowWindow( n_formatter_group.hwnd, sw_to );

	ShowWindow( n_formatter_channel.hwnd, sw_to );
	ShowWindow( n_formatter_bit    .hwnd, sw_to );
	ShowWindow( n_formatter_rate   .hwnd, sw_to );

	ShowWindow( n_formatter_button_go    .hwnd, sw_to );
	ShowWindow( n_formatter_button_cancel.hwnd, sw_to );


	if ( onoff )
	{
	}


	// [!] : for vertical line
	n_win64_refresh( GetParent( n_plotter.hwnd ), FALSE );


	return;
}




// internal
void
n_nyaurism_resize( HWND hwnd )
{

	const BOOL redraw = TRUE;


	const n_type_real scale_ui = n_win64_scale_factor_ui( hwnd );


	const n_type_gfx csx = 512 * scale_ui;
	const n_type_gfx csy = 400 * scale_ui;

	const n_type_gfx margin = 8 * scale_ui;

	const n_type_gfx btn_x = margin;
	const n_type_gfx btn_y = 256 * scale_ui;
	const n_type_gfx btn   = 40 * scale_ui;


	MoveWindow( n_plotter.hwnd, 0,0, csx, btn_y - margin, redraw );


	n_type_gfx x = btn_x;
	n_type_gfx y = btn_y;

	n_win64_ui_button_move( &n_button_zero, x,y,btn,btn, redraw ); x += btn + margin;
	n_win64_ui_button_move( &n_button_mix , x,y,btn,btn, redraw ); x += btn + margin;

	x = ( csx / 2 ) - ( btn / 2 );
	n_win64_ui_button_move( &n_button_play, x,y,btn,btn, redraw ); x -= btn + margin;
	n_win64_ui_button_move( &n_button_stop, x,y,btn,btn, redraw );

	x = csx - margin - btn;
	n_win64_ui_button_move( &n_button_save, x,y,btn,btn, redraw ); x -= btn + margin;
	n_win64_ui_button_move( &n_button_msec, x,y,btn,btn, redraw ); x -= btn + margin + margin;
	n_win64_ui_button_move( &n_button_eq  , x,y,btn,btn, redraw );

	x += btn + margin;
	n_win64_ui_vertical_separater = n_win64_rect_set( x,y,x+1,y+btn );

	const n_type_gfx lbl_sx = 100 * scale_ui;
	const n_type_gfx sld_sx = csx - lbl_sx - margin - margin - margin;
	const n_type_gfx ctl    = n_win64_ui_stdsize() * scale_ui;

	x = margin;
	y = btn_y + margin + btn + margin;

	MoveWindow( n_nyaurism->value_l.hwnd, x,y, lbl_sx, ctl, redraw ); y += ctl + margin;
	MoveWindow( n_nyaurism->value_r.hwnd, x,y, lbl_sx, ctl, redraw );

	x = x + lbl_sx + margin;
	y = btn_y + margin + btn + margin;

	MoveWindow( n_nyaurism->slider_l.hwnd, x,y, sld_sx, ctl, redraw ); y += ctl + margin;
	MoveWindow( n_nyaurism->slider_r.hwnd, x,y, sld_sx, ctl, redraw );


	// [!] : Config Msec.

	const n_type_gfx gsx = 256 * scale_ui;
	const n_type_gfx gsy = 256 * scale_ui;

	const n_type_gfx unit = 100 * scale_ui;

	x = ( csx - gsx ) / 2;
	y = ( csy - gsy ) / 2;

	MoveWindow( n_config_group.hwnd, x,y, gsx, gsy, redraw );

	n_type_gfx lx = ( csx / 2 ) - unit;
	n_type_gfx rx = ( csx / 2 );

	n_type_gfx yy = ( csy - ctl ) / 2;

	MoveWindow( n_config_label.hwnd, lx,yy, unit, ctl, redraw );
	MoveWindow( n_config_input.hwnd, rx,yy, unit, ctl, redraw );

	yy += ( ctl + margin ) * 2;
	rx += margin;

	MoveWindow( n_config_button_go    .hwnd, lx,yy, unit-margin/2, ctl, redraw );
	MoveWindow( n_config_button_cancel.hwnd, rx,yy, unit-margin/2, ctl, redraw );


	// [!] : Formatter Msec.

	const n_type_gfx fsx = csx / 5;
	const n_type_gfx fsy = csy / 3;

	x = fsx * 1;
	y = fsy * 1; y -= ctl / 2;

	MoveWindow( n_formatter_group.hwnd, x-margin,y-ctl, fsx*3+margin, fsy+ctl*2+margin*4, redraw );

	MoveWindow( n_formatter_channel.hwnd, x,y, fsx-margin, fsy, redraw ); x = fsx * 2;
	MoveWindow( n_formatter_bit    .hwnd, x,y, fsx-margin, fsy, redraw ); x = fsx * 3;
	MoveWindow( n_formatter_rate   .hwnd, x,y, fsx-margin, fsy, redraw );

	MoveWindow( n_formatter_button_go    .hwnd, lx,y+fsy+margin, unit-margin/2, ctl, redraw );
	MoveWindow( n_formatter_button_cancel.hwnd, rx,y+fsy+margin, unit-margin/2, ctl, redraw );


	static BOOL is_first = TRUE;

	if ( is_first )
	{
		is_first = FALSE;
		n_win64_ui_window_set( hwnd, 0,0,csx,csy, TRUE );
	}


	return;
}




void
n_nyaurism_on_WM_PAINT( HWND hwnd, HDC hdc )
{

	RECT rect; GetClientRect( hwnd, &rect );

	{
		COLORREF colorref = n_win64_GetSysColor( COLOR_BTNFACE );
		HBRUSH   br       = CreateSolidBrush( colorref );

		FillRect( hdc, &rect, br );

		DeleteObject( br );
	}

	if ( IsWindowVisible( n_plotter.hwnd ) )
	{
		COLORREF colorref = n_win64_GetSysColor( COLOR_BTNSHADOW );
		HBRUSH   br       = CreateSolidBrush( colorref );

		FillRect( hdc, &n_win64_ui_vertical_separater, br );

		DeleteObject( br );
	}


	return;
}




LRESULT CALLBACK
n_nyaurism_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static UINT playback_timer = 0;

	static UINT darkmode_timer = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			darkmode_timer = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, darkmode_timer, 200 );
		}
	}
	break;


	case WM_CREATE :


		// Global

		n_bmp_transparent_onoff_default = FALSE;

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );

		n_nyaurism_zero( n_nyaurism );

		n_nyaurism->seekbar_float_norm = -1;


		// UI

		n_nyaurism->hwnd = hwnd;

		n_win64_ui_window_init( hwnd, N_APPNAME_LITERAL, N_ICONAME_LITERAL, N_STRING_EMPTY );

		n_win64_ui_plotter_init( &n_plotter, hwnd );

		n_win64_ui_button_init( &n_button_zero, hwnd );
		n_win64_ui_button_init( &n_button_mix , hwnd );
		n_win64_ui_button_init( &n_button_stop, hwnd );
		n_win64_ui_button_init( &n_button_play, hwnd );
		n_win64_ui_button_init( &n_button_msec, hwnd );
		n_win64_ui_button_init( &n_button_save, hwnd );
		n_win64_ui_button_init( &n_button_eq  , hwnd );

		n_button_setup_literal( &n_button_zero, "NYAURISM_1_ZERO" );
		n_button_setup_GDI( &n_button_mix, n_posix_literal( "Mix" ) );
		n_button_setup_literal( &n_button_stop, "NYAURISM_3_STOP" );
		n_button_setup_literal( &n_button_play, "NYAURISM_4_PLAY" );
		n_button_setup_literal( &n_button_msec, "NYAURISM_5_MSEC" );
		n_button_setup_literal( &n_button_save, "NYAURISM_6_SAVE" );
		n_button_setup_literal( &n_button_eq  , "NYAURISM_8_EQ"   );

		n_win64_ui_value_init( &n_nyaurism->value_l, hwnd, n_posix_literal( "L" ) );
		n_win64_ui_value_init( &n_nyaurism->value_r, hwnd, n_posix_literal( "R" ) );

		n_win64_ui_slider_init( &n_nyaurism->slider_l, hwnd, N_WIN64_UI_SLIDER_LAYOUT_HORZ, 100 );
		n_win64_ui_slider_init( &n_nyaurism->slider_r, hwnd, N_WIN64_UI_SLIDER_LAYOUT_HORZ, 100 );


		// [!] : Config Msec

		n_win64_ui_value_init( &n_config_label, hwnd, n_posix_literal( "Msec" ) );

		n_txtbox_init( &n_config_input, hwnd, NULL );
		n_config_input.mode = N_MAC_TXTBOX_MODE_ONELINE;

		n_win64_ui_button_init( &n_config_button_go    , hwnd ); n_config_button_go    .label = n_posix_literal( "Go!" );
		n_win64_ui_button_init( &n_config_button_cancel, hwnd ); n_config_button_cancel.label = n_posix_literal( "Cancel" );

		n_config_button_go    .style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		n_config_button_cancel.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

		// [Needed] : after contents
		n_win64_ui_groupbox_init( &n_config_group, hwnd, NULL );

		NonnonNyaurismUIContextConfig( FALSE );


		// [!] : Formatter

		n_txtbox_init( &n_formatter_channel, hwnd, NULL );
		n_txtbox_init( &n_formatter_bit    , hwnd, NULL );
		n_txtbox_init( &n_formatter_rate   , hwnd, NULL );

		n_formatter_channel.mode = N_MAC_TXTBOX_MODE_LISTBOX;
		n_formatter_bit    .mode = N_MAC_TXTBOX_MODE_LISTBOX;
		n_formatter_rate   .mode = N_MAC_TXTBOX_MODE_LISTBOX;

		n_formatter_channel.listbox_whole_width_selection = TRUE;
		n_formatter_bit    .listbox_whole_width_selection = TRUE;
		n_formatter_rate   .listbox_whole_width_selection = TRUE;

		n_txt_set( n_formatter_channel.txt_data, 0, n_posix_literal( "Monaural" ) );
		n_txt_set( n_formatter_channel.txt_data, 1, n_posix_literal( "Stereo" ) );

		n_txtbox_reset( &n_formatter_channel );

		n_txt_set( n_formatter_bit.txt_data, 0, n_posix_literal( "8-bit" ) );
		n_txt_set( n_formatter_bit.txt_data, 1, n_posix_literal( "16-bit" ) );
		n_txt_set( n_formatter_bit.txt_data, 2, n_posix_literal( "32-bit" ) );

		n_txtbox_reset( &n_formatter_bit );

		n_txt_set( n_formatter_rate.txt_data, 0, n_posix_literal( "11k : 11025" ) );
		n_txt_set( n_formatter_rate.txt_data, 1, n_posix_literal( "22k : 22050" ) );
		n_txt_set( n_formatter_rate.txt_data, 2, n_posix_literal( "44k : 44100" ) );

		n_txtbox_reset( &n_formatter_rate );


		n_win64_ui_button_init( &n_formatter_button_go    , hwnd ); n_formatter_button_go    .label = n_posix_literal( "Go!" );
		n_win64_ui_button_init( &n_formatter_button_cancel, hwnd ); n_formatter_button_cancel.label = n_posix_literal( "Cancel" );

		n_formatter_button_go    .style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		n_formatter_button_cancel.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

		// [Needed] : after contents
		n_win64_ui_groupbox_init( &n_formatter_group, hwnd, n_posix_literal( "Formatter" ) );

		NonnonNyaurismUIContextFormatter( FALSE );


		if ( playback_timer == 0 ) { playback_timer = n_win64_timer_id_get(); }
		n_win64_timer_init( hwnd, playback_timer, 10 );


		// Instance

		{
			n_posix_char *cmdline = n_win64_commandline_new();
			n_nyaurism_newfile( hwnd, cmdline );

			NonnonNyaurismFormatterApply( &n_nyaurism->wav );
		}

		n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_undo );
		n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_base );

		n_nyaurism_slider_redraw( &n_nyaurism->wav );

		n_win64_refresh( n_plotter.hwnd, FALSE );


		// Display

		n_nyaurism_resize( hwnd );

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_DPICHANGED :

		n_button_setup_GDI( &n_button_mix, n_posix_literal( "Mix" ) );

	case WM_SIZE :

		n_nyaurism_plotter_draw_init = FALSE;

		n_nyaurism_resize( hwnd );

		if ( n_nyaursim_hwnd_eq != NULL )
		{
			n_nyaurism_equalizer_resize( n_nyaursim_hwnd_eq, FALSE );
			n_win64_refresh( n_nyaursim_hwnd_eq, FALSE );
		}

	break;


	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == darkmode_timer )
		{

			n_win64_timer_exit( hwnd, darkmode_timer );

			n_button_setup_GDI( &n_button_mix, n_posix_literal( "Mix" ) );

			HDC hdc = GetDC( hwnd );
			n_nyaurism_on_WM_PAINT( hwnd, hdc );
			ReleaseDC( hwnd, hdc );

			n_win64_darkmode_on_WM_SETTINGCHANGE( hwnd );

		} else
		if ( wParam == playback_timer )
		{

			if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_PLAYING )
			{
				if ( n_nyaurism->playback_timeout < n_posix_tickcount() )
				{
					NonnonNyaurismPlaybackReset( NO );
				} else {
					float  x;
					 x = (float) n_nyaurism->playback_msec_x;
					 x = (float)  x / N_WAV_MSEC( &n_nyaurism->wav );

					float sx;
					sx = (float) n_nyaurism->playback_msec_sx;
					sx = (float) sx / N_WAV_MSEC( &n_nyaurism->wav );

					float rest;
					rest = n_nyaurism->playback_timeout - n_posix_tickcount();
					rest = (float) rest / n_nyaurism->playback_msec_sx;
					rest = 1.0 - rest;
//NSLog( @"%f", rest );

					n_nyaurism->seekbar_float_norm = rest + x;
//NSLog( @"%f %f", n_nyaurism_seekbar_float_norm, x + sx );

					if ( n_nyaurism->seekbar_float_norm > 1.0 )
					{
						NonnonNyaurismPlaybackReset( NO );
					} else
					if ( n_nyaurism->seekbar_float_norm > ( x + sx ) )
					{
						NonnonNyaurismPlaybackReset( YES );
					} else {
						n_win64_refresh( n_plotter.hwnd, FALSE );
					}
				}
			}

		}

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		n_nyaurism_on_WM_PAINT( hwnd, ps.hdc );

		EndPaint( hwnd, &ps );
	}
	break;


	case WM_LBUTTONDOWN :

		n_nyaurism_plotter_selection_off();
		n_win64_refresh( n_plotter.hwnd, FALSE );

	break;


	case WM_DROPFILES :
	{

		n_posix_char *fname = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		n_wav wav_local; n_wav_zero( &wav_local );

		if ( n_wav_load( &wav_local, fname ) )
		{
			n_posix_debug_literal( "Not Supported" );
			n_string_free( fname );
		} else {
			if ( n_nyaurism->mix_onoff )
			{
				n_wav_free( &n_nyaurism->wav_clip );
				n_wav_alias( &wav_local, &n_nyaurism->wav_clip );

				//n_nyaurism_tooltip_calc( N_WAV_COUNT( &wav_local ) );

				n_nyaurism_plotter_overwrite( &n_nyaurism->wav );

				n_nyaurism_slider_redraw( &n_nyaurism->wav );

				n_win64_refresh( n_plotter.hwnd, FALSE );

				n_string_free( fname );
			} else {
				n_wav_free( &n_nyaurism->wav );
				n_wav_alias( &wav_local, &n_nyaurism->wav );

				NonnonNyaurismFormatterApply( &n_nyaurism->wav );

				n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_undo );
				n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_base );

				n_nyaurism_plotter_selection_off();

				n_nyaurism_slider_redraw( &n_nyaurism->wav );

				n_win64_refresh( n_plotter.hwnd, FALSE );

				n_string_path_free( n_nyaurism->fname );
				n_nyaurism->fname = fname;

				n_nyaurism_title( hwnd );
			}
		}

	}
	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lParam;

		if ( h == n_nyaurism->slider_l.hwnd )
		{
			n_nyaurism_slider_value_set( &n_nyaurism->value_l, n_nyaurism->slider_l.pos );

			n_nyaurism_slider_value_apply();
		} else
		if ( h == n_nyaurism->slider_r.hwnd )
		{
			n_nyaurism_slider_value_set( &n_nyaurism->value_r, n_nyaurism->slider_r.pos );

			n_nyaurism_slider_value_apply();
		} else

		if ( h == n_button_zero.hwnd )
		{
			n_nyaurism_plotter_mute( &n_nyaurism->wav );

			n_win64_refresh( n_plotter.hwnd, FALSE );
		} else
		if ( h == n_button_mix.hwnd )
		{
			if ( n_nyaurism->mix_onoff )
			{
				n_nyaurism->mix_onoff = FALSE;
			} else {
				n_nyaurism->mix_onoff =  TRUE;
			}

			n_button_mix.fake_onoff = n_nyaurism->mix_onoff;
			n_win64_refresh( n_button_mix.hwnd, FALSE );
		}// else

		if ( h == n_button_stop.hwnd )
		{

			NonnonNyaurismPlaybackReset( YES );

		} else
		if ( h == n_button_play.hwnd )
		{

			if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_STOP )
			{
				n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &n_nyaurism->wav, &x, &sx );
				if ( sx == 0 ) { sx = N_WAV_COUNT( &n_nyaurism->wav ); }

				const float sample_per_msec = (float) N_WAV_RATE( &n_nyaurism->wav ) / 1000;

				n_nyaurism->playback_msec_x  = (float)  x / sample_per_msec;
				n_nyaurism->playback_msec_sx = (float) sx / sample_per_msec;
//NSLog( @"playback msec : %f %f", n_nyaurism_playback_msec_x, n_nyaurism_playback_msec_sx );

				//n_mac_window_all_controls_onoff( [_n_eq_window contentView], NO );

				n_button_setup_literal( &n_button_play, "NYAURISM_7_PAUSE" );

				n_nyaurism->playback_prev_x = 0;

				n_wav_free( &n_nyaurism->wav_play );
				n_wav_carboncopy( &n_nyaurism->wav, &n_nyaurism->wav_play );
/*
				// [!] : for waveOutOpen() "not supported" error
				n_nyaurism->wav_play.format = N_WAV_FORMAT_PCM;
				n_nyaurism->wav_play.bit    = 16;
				n_wav_reducer( &n_nyaurism->wav_play );
*/
				n_nyaurism_player_init( &n_nyaurism->hwo, &n_nyaurism->wav_play );
				n_nyaurism_player_play( &n_nyaurism->hwo, &n_nyaurism->wav_play );


				n_nyaurism->playback_timeout = n_posix_tickcount() + n_nyaurism->playback_msec_sx;

				n_nyaurism->playback_status = N_NYAURISM_PLAYBACK_PLAYING;
				NonnonNyaurismUIContextPlayback();
			} else
			if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_PLAYING )
			{
				n_nyaurism->playback_status = N_NYAURISM_PLAYBACK_PAUSE;

				n_button_setup_literal( &n_button_play, "NYAURISM_4_PLAY" );
				n_nyaurism_player_pause( &n_nyaurism->hwo );

				n_nyaurism->playback_timeout -= n_posix_tickcount();
			} else
			if ( n_nyaurism->playback_status == N_NYAURISM_PLAYBACK_PAUSE )
			{
				n_nyaurism->playback_status = N_NYAURISM_PLAYBACK_PLAYING;

				n_button_setup_literal( &n_button_play, "NYAURISM_7_PAUSE" );
				n_nyaurism_player_resume( &n_nyaurism->hwo );

				n_nyaurism->playback_timeout += n_posix_tickcount();
			}

		} else

		if ( h == n_button_eq.hwnd )
		{

			if ( n_nyaursim_hwnd_eq == NULL )
			{
				n_nyaursim_hwnd_eq = n_win64_ui_window( hwnd, n_nyaurism_equalizer_wndproc );
			} else {
				n_win64_message_send( n_nyaursim_hwnd_eq, WM_CLOSE, 0, 0 );
			}

			n_button_eq.fake_onoff = ( n_nyaursim_hwnd_eq != NULL );
			n_win64_refresh( n_button_eq.hwnd, FALSE );

		} else

		if ( h == n_button_msec.hwnd )
		{

			NonnonNyaurismUIContextConfig( TRUE );

		} else
		if ( h == n_button_save.hwnd )
		{

			NonnonNyaurismUIContextFormatter( TRUE );

		} else

		if ( h == n_config_button_go.hwnd )
		{

			u32 msec = n_posix_atoi( n_txt_get( n_config_input.txt_data, 0 ) );

			n_wav_resizer( &n_nyaurism->wav, msec, N_WAV_RESIZER_NORMAL );

			NonnonNyaurismUIContextConfig( FALSE );

		} else
		if ( h == n_config_button_cancel.hwnd )
		{

			NonnonNyaurismUIContextConfig( FALSE );

		} //else

		if ( h == n_formatter_button_go.hwnd )
		{

			NonnonNyaurismFormatterSave( hwnd );

			NonnonNyaurismUIContextFormatter( FALSE );

		} else
		if ( h == n_formatter_button_cancel.hwnd )
		{

			NonnonNyaurismUIContextFormatter( FALSE );

		} //else

	}
	break;

	case WM_KEYDOWN :

		if ( wParam == VK_F2 )
		{
			n_nyaurism->fname = n_win64_fork_rename( n_nyaurism->fname );
			n_nyaurism_title( hwnd );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_win64_ui_plotter_exit( &n_plotter );

		n_win64_ui_button_exit( &n_button_zero );
		n_win64_ui_button_exit( &n_button_mix  );
		n_win64_ui_button_exit( &n_button_stop );
		n_win64_ui_button_exit( &n_button_play );
		n_win64_ui_button_exit( &n_button_msec );
		n_win64_ui_button_exit( &n_button_save );
		n_win64_ui_button_exit( &n_button_eq   );

		n_win64_ui_value_exit( &n_nyaurism->value_l );
		n_win64_ui_value_exit( &n_nyaurism->value_r );

		n_win64_ui_slider_exit( &n_nyaurism->slider_l );
		n_win64_ui_slider_exit( &n_nyaurism->slider_r );


		n_win64_ui_value_exit( &n_config_label );

		n_txtbox_exit( &n_config_input );

		n_win64_ui_groupbox_exit( &n_config_group );

		n_win64_ui_button_exit( &n_config_button_go );
		n_win64_ui_button_exit( &n_config_button_cancel );


		n_win64_ui_groupbox_exit( &n_formatter_group );

		n_txtbox_exit( &n_formatter_channel );
		n_txtbox_exit( &n_formatter_bit );
		n_txtbox_exit( &n_formatter_rate );

		n_win64_ui_button_exit( &n_formatter_button_go );
		n_win64_ui_button_exit( &n_formatter_button_cancel );


		n_wav_free( &n_nyaurism->wav );
		n_wav_free( &n_nyaurism->wav_play );
		n_wav_free( &n_nyaurism->wav_base );
		n_wav_free( &n_nyaurism->wav_undo );
		n_wav_free( &n_nyaurism->wav_clip );


		n_string_free( n_nyaurism->fname );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_ui_plotter_proc( hwnd, msg, wParam, lParam, &n_plotter );

	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_zero );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_mix  );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_stop );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_play );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_msec );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_save );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &n_button_eq   );

	n_win64_ui_value_proc( hwnd, msg, wParam, lParam, &n_nyaurism->value_l );
	n_win64_ui_value_proc( hwnd, msg, wParam, lParam, &n_nyaurism->value_r );

	n_win64_ui_slider_proc( hwnd, msg, wParam, lParam, &n_nyaurism->slider_l );
	n_win64_ui_slider_proc( hwnd, msg, wParam, lParam, &n_nyaurism->slider_r );

	n_win64_ui_value_proc   ( hwnd, msg, wParam, lParam, &n_config_label );
	n_win64_txtbox_proc     ( hwnd, msg, wParam, lParam, &n_config_input );
	n_win64_ui_groupbox_proc( hwnd, msg, wParam, lParam, &n_config_group );
	n_win64_ui_button_proc  ( hwnd, msg, wParam, lParam, &n_config_button_go );
	n_win64_ui_button_proc  ( hwnd, msg, wParam, lParam, &n_config_button_cancel );

	n_win64_ui_groupbox_proc( hwnd, msg, wParam, lParam, &n_formatter_group );
	n_win64_txtbox_proc     ( hwnd, msg, wParam, lParam, &n_formatter_channel );
	n_win64_txtbox_proc     ( hwnd, msg, wParam, lParam, &n_formatter_bit );
	n_win64_txtbox_proc     ( hwnd, msg, wParam, lParam, &n_formatter_rate );
	n_win64_ui_button_proc  ( hwnd, msg, wParam, lParam, &n_formatter_button_go );
	n_win64_ui_button_proc  ( hwnd, msg, wParam, lParam, &n_formatter_button_cancel );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_nyaurism_wndproc );
}

