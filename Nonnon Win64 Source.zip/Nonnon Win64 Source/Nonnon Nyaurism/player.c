// Nonnon Nyaurism
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




//#include <mmreg.h>
//#include <ks.h>
//#include <ksmedia.h>



/*
void CALLBACK
n_nyaurism_player_proc( HWAVEOUT hwo, UINT uMsg, DWORD_PTR dwInstance, DWORD_PTR dwParam1, DWORD_PTR dwParam2 )
{
	return;
}
*/
void
n_nyaurism_player_init( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h != NULL ) { return; }

//n_posix_debug_literal( "%d", N_WAV_FORMAT( wav ) );
//n_posix_debug_literal( "%d %d %d", N_WAV_STEREO( wav ), N_WAV_BIT( wav ), N_WAV_RATE( wav ) );
//n_posix_debug_literal( "%d %d %d", N_WAV_BYTELEN( wav ), N_WAV_BYTEPERSEC( wav ), N_WAV_CBSIZE( wav ) );

	// [Needed] : IEEE_FLOAT
	N_WAV_CBSIZE( wav ) = 0;

/*
	WAVEFORMATEXTENSIBLE w;

	GUID guid = { 0x00000003, 0x0000, 0x0010, {0x80,0x00,0x00,0xAA,0x00,0x38,0x9B,0x71} };

	w.Format            = N_WAV_FMT( wav );
	w.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
	w.Format.cbSize     = sizeof( WAVEFORMATEXTENSIBLE ) - sizeof( WAVEFORMATEX );
	w.SubFormat         = guid;//KSDATAFORMAT_SUBTYPE_IEEE_FLOAT;
	w.dwChannelMask     = 0x03;

	MMRESULT ret = waveOutOpen( h, WAVE_MAPPER, (void*) &w, (DWORD_PTR) n_nyaurism_player_proc, 0, CALLBACK_FUNCTION );
*/
	MMRESULT ret = waveOutOpen( h, WAVE_MAPPER, &N_WAV_FMT( wav ), 0, 0, CALLBACK_NULL );
	if ( ret != MMSYSERR_NOERROR )
	{
/*
		n_posix_char str[ 1024 ];
		waveOutGetErrorText( ret, str, 1024 );
		n_posix_debug_literal( "%s", str );
*/
	}


	N_WAV_LOOP( wav ) = 1;

	waveOutPrepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );
	waveOutReset( *h );


	return;
}

void
n_nyaurism_player_exit( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveOutReset( *h );
	waveOutUnprepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );

	waveOutClose( *h );

	(*h) = NULL;


	return;
}

void
n_nyaurism_player_play( HWAVEOUT *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }

	waveOutReset( *h );
	waveOutWrite( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );

	return;
}

void
n_nyaurism_player_stop( HWAVEOUT *h )
{

	waveOutReset( *h );

	return;
}

void
n_nyaurism_player_pause( HWAVEOUT *h )
{

	waveOutPause( *h );

	return;
}

void
n_nyaurism_player_resume( HWAVEOUT *h )
{

	waveOutRestart( *h );

	return;
}




void
n_nyaurism_recorder_init( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h != NULL ) { return; }


	waveInOpen( h, WAVE_MAPPER, &N_WAV_FMT( wav ), 0,0,CALLBACK_NULL );

	N_WAV_LOOP( wav ) = 1;

	waveInPrepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );
	waveInReset( *h );

	waveInAddBuffer( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );


	return;
}

void
n_nyaurism_recorder_go( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveInStart( *h );


	return;
}

void
n_nyaurism_recorder_exit( HWAVEIN *h, n_wav *wav )
{

	if (  h == NULL ) { return; }
	if ( *h == NULL ) { return; }


	waveInReset( *h );
	waveInUnprepareHeader( *h, &N_WAV_WH( wav ), sizeof( WAVEHDR ) );

	waveInClose( *h );

	(*h) = NULL;


	return;
}

