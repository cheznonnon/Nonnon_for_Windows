
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Nonnon Nyaurism"
set   debug=-DDEBUG

%compile%

