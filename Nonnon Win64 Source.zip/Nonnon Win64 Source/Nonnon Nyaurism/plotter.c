// Nonnon Nyaurism for Mac
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




typedef struct {

	HWND  hwnd;

	HMENU hmenu;

	n_win64_doublebuffer db;

} n_win64_ui_plotter;


#define n_win64_ui_plotter_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_plotter ) )


static n_win64_ui_plotter n_plotter;




static n_win64_ui_menu n_nyaurism_menu[] = {

	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Undo" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Select All" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Unselect"   ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Cut"   ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Copy"  ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Paste" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Overwrite/Mix" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Mute"               ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Monaural"           ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Copy Left to Right" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Copy Right to Left" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Fade-In"  ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Fade-Out" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Smoother"  ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Overdrive" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Tremolo" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "---" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "White Noise" ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, n_posix_literal( "Pink Noise"  ), 0 },
	{ N_WIN_MENU_NONE, FALSE, FALSE, NULL }

};




static n_posix_char n_nyaurism_tooltip_str[ 100 ] = n_posix_literal( "0 msec." );

void
n_nyaurism_tooltip_calc( HWND hwnd, n_type_real pixel_x )
{

	n_type_gfx csx; n_win64_control_size( hwnd, &csx, NULL );

	n_type_real norm = (n_type_real) pixel_x / csx;
//NSLog( @"%f %f", norm, norm * N_WAV_MSEC( &n_nyaurism->wav ) );

	n_posix_snprintf_literal( n_nyaurism_tooltip_str, 100, "%0.0f msec", norm * N_WAV_MSEC( &n_nyaurism->wav ) );


	return;
}

void
n_nyaurism_tooltip_draw( HWND hwnd, n_bmp *bmp_canvas, n_posix_char *str )
{

	n_type_real scale_ui   = n_win64_scale_factor_ui  ( hwnd );
	n_type_real scale_font = n_win64_scale_factor_font( hwnd );

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                 = 0;
	gdi.sy                 = 0;
	gdi.style              = N_GDI_AUTOMARGIN;

	gdi.base_color_bg      = n_bmp_rgb( 222,222,222 );
	gdi.base_color_fg      = n_bmp_rgb( 222,222,222 );
	gdi.base_style         = N_GDI_BASE_SOLID;

	gdi.frame_style        = N_GDI_FRAME_ROUND;//N_GDI_FRAME_SIMPLE;
	gdi.frame_round        = 3 * scale_ui;

	n_posix_char str2[ 1024 ]; n_posix_snprintf_literal( str2, 1024, " %s ", str );

	gdi.text               = str2;
	gdi.text_font          = n_posix_literal( "Trebuchet MS" );
	gdi.text_size          = 14 * scale_font;
	gdi.text_color_main    = n_bmp_rgb( 0,0,0 );
	gdi.text_style         = N_GDI_TEXT_MAC_NO_CROP | N_GDI_TEXT_SMOOTH  | N_GDI_TEXT_BOLD;
	gdi.text_fxsize2       = 0;


	n_bmp bmp; n_bmp_zero( &bmp ); n_gdi_bmp( &gdi, &bmp );
//n_bmp_save( &bmp, "/Users/nonnon/Desktop/ret.bmp" );


	// [!] : Centering

	n_type_gfx bmpsx = N_BMP_SX( bmp_canvas );
	n_type_gfx bmpsy = N_BMP_SY( bmp_canvas );

	n_type_gfx cx = ( ( bmpsx - gdi.sx ) / 2 );
	n_type_gfx cy = ( ( bmpsy - gdi.sy ) / 2 );


	n_bmp_transcopy( &bmp, bmp_canvas, 0,0,gdi.sx,gdi.sy, cx,cy );


	n_bmp_free_fast( &bmp );


	return;
}




void
n_nyaurism_plotter_selection_off( void )
{
//return;

	n_nyaurism->selection_reverse         = FALSE;
	n_nyaurism->plotter_selection_channel = 0;

	n_nyaurism->selection_from_pixel = 0;
	n_nyaurism->selection_loop_pixel = 0;
	n_nyaurism->selection_size_pixel = 0;

	//n_nyaurism_slider_redraw( &n_nyaurism->wav );


	return;
}

n_type_gfx
n_nyaurism_plotter_selection_left_edge( void )
{

	n_type_gfx ret;

	if ( n_nyaurism->selection_reverse )
	{
		ret = n_nyaurism->selection_loop_pixel;
	} else {
		ret = n_nyaurism->selection_from_pixel;
	}


	return ret;
}

BOOL
n_nyaurism_plotter_selection_line_only( void )
{

	BOOL ret = FALSE;


	if (
		( 0 != n_nyaurism_plotter_selection_left_edge() )
		&&
		( 0 == n_nyaurism->selection_size_pixel )
	)
	{
		ret = TRUE;
	}


	return ret;
}

void
n_nyaurism_plotter_selection_pixel2sample( n_wav *wav, n_type_gfx *ret_x, n_type_gfx *ret_sx )
{
//return;

	n_type_gfx st = n_nyaurism->selection_step;
	n_type_gfx  x = st * n_nyaurism_plotter_selection_left_edge();
	n_type_gfx sx = st * n_nyaurism->selection_size_pixel;

	if ( x < 0 ) { sx += x; x = 0; }


	n_type_gfx c = (n_type_gfx) N_WAV_COUNT( wav );
	if ( ( x + sx ) >= c ) { sx = c - x; }


	if ( ret_x  != NULL ) { (*ret_x ) =  x; }
	if ( ret_sx != NULL ) { (*ret_sx) = sx; }


	return;
}




void
n_nyaurism_slider_value_set( n_win64_ui_value *p, int v )
{

	n_posix_snprintf_literal( p->value, 100, "%d%%", v );

	n_win64_refresh( p->hwnd, FALSE );


	return;
}

void
n_nyaurism_slider_value_apply( void )
{

	n_type_real l = (n_type_real) n_nyaurism->slider_l.pos / 100.0;
	n_type_real r = (n_type_real) n_nyaurism->slider_r.pos / 100.0;

	n_nyaurism_backup( &n_nyaurism->wav_base, &n_nyaurism->wav );

	n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &n_nyaurism->wav, &x, &sx );
	if ( sx == 0 ) { sx = N_WAV_COUNT( &n_nyaurism->wav ); }
	if ( n_nyaurism_plotter_selection_line_only() ) { sx = 0; }

	n_wav_normalize_partial( &n_nyaurism->wav, x, sx, l, r );


	n_win64_refresh( n_plotter.hwnd, FALSE );

	return;
}

void
n_nyaurism_slider_redraw( n_wav *wav )
{

	n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( wav, &x, &sx );


	if ( sx == 0 ) { sx = N_WAV_COUNT( wav ); }

//x = 0; sx = N_WAV_COUNT( wav );


	n_type_real hi_l, hi_r;
	n_wav_peak_value( wav, x, sx, &hi_l, &hi_r );


	n_type_real l = hi_l / n_wav_sample_amp( wav ) * 100;
	n_type_real r = hi_r / n_wav_sample_amp( wav ) * 100;

	n_nyaurism->slider_l.pos = l; n_win64_refresh( n_nyaurism->slider_l.hwnd, FALSE );
	n_nyaurism->slider_r.pos = r; n_win64_refresh( n_nyaurism->slider_r.hwnd, FALSE );

	n_nyaurism_slider_value_set( &n_nyaurism->value_l, l );
	n_nyaurism_slider_value_set( &n_nyaurism->value_r, r );


	if ( n_nyaurism->plotter_selection_channel == 1 )
	{
		//[n_nyaurism->AppDelegate NonnonNyaurismSliderUIOnOff:nil L:FALSE R:TRUE];
	} else
	if ( n_nyaurism->plotter_selection_channel == 2 )
	{
		//[n_nyaurism->AppDelegate NonnonNyaurismSliderUIOnOff:nil L:TRUE R:FALSE];
	} else {
		//[n_nyaurism->AppDelegate NonnonNyaurismSliderUIOnOff:nil L:TRUE R:TRUE];
	}


	return;
}




#include "./plotter_verb.c"




static BOOL n_nyaurism_plotter_draw_init = FALSE;

void
n_nyaurism_plotter_draw( HWND hwnd, n_bmp *bmp, n_wav *wav, n_type_gfx sx, n_type_gfx sy )
{
//return;

	if ( n_wav_error_format( wav ) ) { return; }


	const u32  color_l = n_bmp_rgb(   0,200,255 );
	const u32  color_r = n_bmp_rgb(   0,255,200 );
	const u32  c_grid1 = n_bmp_rgb(  50, 50, 50 );
	const u32  c_grid2 = n_bmp_rgb(   0,100,100 );
	const u32  cselect = n_bmp_rgb( 255,255,255 );


	sx = n_posix_max_n_type_gfx( 1, sx );
	sy = n_posix_max_n_type_gfx( 1, sy );


	const n_type_gfx  count  = (n_type_gfx) N_WAV_COUNT( wav );
	const n_type_real per_ms = N_WAV_RATE ( wav ) / 1000;

	n_type_gfx  unit_x  = sx;
	n_type_gfx  unit_y  = sy / 4;
	n_type_gfx  line_l  = unit_y * 1;
	n_type_gfx  line_r  = unit_y * 3;
	n_type_real ratio_x = (n_type_real) unit_x / count;
	n_type_real ratio_y = (n_type_real) unit_y / n_wav_sample_amp( wav );
	n_type_gfx  step_x  = n_posix_max_n_type_gfx( 1, count / unit_x );
//NSLog( @"%d %d %d %d", sy, unit_y, line_l, line_r );

	n_nyaurism->selection_step = step_x;
//NSLog( @"Step %d", step_x );


	// [!] : Main Canvas

	if ( n_nyaurism_plotter_draw_init == FALSE )
	{
		n_nyaurism_plotter_draw_init = TRUE;
		//n_bmp_zero( bmp );

		n_bmp_new( &n_nyaurism->seekbar_bmp, sx, sy );
	}

	//n_bmp_new( bmp, sx,sy );


	// [!] : Grid

	n_type_gfx grid_1 = (n_type_gfx) ( (n_type_real) (   10 * per_ms ) * ratio_x );
	n_type_gfx grid_2 = (n_type_gfx) ( (n_type_real) ( 1000 * per_ms ) * ratio_x );


	n_type_gfx x = 0;
	n_posix_loop
	{//break;

		// [!] : Grid : threshold is 4px

		if ( ( grid_1 >= 4 )&&( 0 == ( x % grid_1 ) ) )
		{
			n_bmp_box( bmp, x,0, 1,sy, c_grid1 );
		} else
		if ( ( grid_2 >= 4 )&&( 0 == ( x % grid_2 ) ) )
		{
			n_bmp_box( bmp, x,0, 1,sy, c_grid2 );
		}


		u32 pos = x * step_x;
		if ( pos >= count ) { break; }


		// [x] : simple and fast but not-displayed data will be made

		n_type_real l,r;

		n_wav_sample_get( wav, pos, &l, &r );
/*
		// [x] : average : too much shrunk

		n_type_real l_avr = 0;
		n_type_real r_avr = 0;

		u32 z = 0;
		n_posix_loop
		{
			n_type_real l,r; n_wav_sample_get( wav, pos + z, &l, &r );

			l_avr += l;
			r_avr += r;

			z++;
			if ( z >= step_x ) { break; }
		}

		l = (n_type_real) l_avr / step_x;
		r = (n_type_real) r_avr / step_x;
*/

		// [!] : Main : ( n * -1 ) : up-side-down : WAV to BMP

		n_type_gfx ty_l = (n_type_gfx) ( line_l + trunc( l * ratio_y * -1 ) );
		n_type_gfx ty_r = (n_type_gfx) ( line_r + trunc( r * ratio_y * -1 ) );

		n_type_gfx fy_l = line_l;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_l, color_l );

			if ( fy_l == ty_l ) { break; }
			if ( fy_l > ty_l ) { fy_l--; } else { fy_l++; }
		}

		n_type_gfx fy_r = line_r;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_r, color_r );

			if ( fy_r == ty_r ) { break; }
			if ( fy_r > ty_r ) { fy_r--; } else { fy_r++; }
		}

/*
		// [x] : too much chunky

		n_type_real l_min = 0;
		n_type_real l_max = 0;
		n_type_real r_min = 0;
		n_type_real r_max = 0;

		u32 z = 0;
		n_posix_loop
		{
			n_type_real l,r; n_wav_sample_get( wav, pos + z, &l, &r );

			if ( l < l_min ) { l_min = l; }
			if ( l > l_max ) { l_max = l; }

			if ( r < r_min ) { r_min = r; }
			if ( r > r_max ) { r_max = r; }

			z++;
			if ( z >= step_x ) { break; }
		}


		// [!] : Main : ( n * -1 ) : up-side-down : WAV to BMP

		n_type_gfx ty_l_min = (n_type_gfx) ( line_l + trunc( l_min * ratio_y * -1 ) );
		n_type_gfx ty_l_max = (n_type_gfx) ( line_l + trunc( l_max * ratio_y * -1 ) );
		n_type_gfx ty_r_min = (n_type_gfx) ( line_r + trunc( r_min * ratio_y * -1 ) );
		n_type_gfx ty_r_max = (n_type_gfx) ( line_r + trunc( r_max * ratio_y * -1 ) );

		n_type_gfx fy_l = line_l;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_l, color_l );

			fy_l++;
			if ( fy_l > ty_l_min ) { break; }
		}

		fy_l = line_l;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_l, color_l );

			fy_l--;
			if ( fy_l < ty_l_max ) { break; }
		}

		n_type_gfx fy_r = line_r;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_r, color_r );

			fy_r++;
			if ( fy_r > ty_r_min ) { break; }
		}

		fy_r = line_r;
		n_posix_loop
		{//break;
			// [!] : don't use n_bmp_ptr_set_fast()
			n_bmp_ptr_set( bmp, x,fy_r, color_r );

			fy_r--;
			if ( fy_r < ty_r_max ) { break; }
		}
*/
/*
		// [!] : hard to recognize peak position

		u32 z = 0;
		n_posix_loop
		{
			n_type_real l,r; n_wav_sample_get( wav, pos + z, &l, &r );

			n_type_gfx ty_l = (n_type_gfx) ( line_l + trunc( l * ratio_y * -1 ) );
			n_type_gfx ty_r = (n_type_gfx) ( line_r + trunc( r * ratio_y * -1 ) );

			n_bmp_ptr_set( bmp, x, ty_l, color_l );
			n_bmp_ptr_set( bmp, x, ty_r, color_r );

			z++;
			if ( z >= step_x ) { break; }
		}
*/

		x++;
		if ( x >= N_WAV_COUNT( wav ) ) { break; }
	}


	// [!] : L/R separator

	n_bmp_line( bmp, 0, sy/2, sx, sy/2, n_bmp_rgb( 128,128,128 ) );


	// [!] : Indicator / Selector

	{
		n_type_gfx from = n_nyaurism_plotter_selection_left_edge();
		n_type_gfx size = n_nyaurism->selection_size_pixel;
//NSLog( @"%d %d", from, size );

		if ( n_nyaurism->selection_shift_onoff )
		{
			if ( size == 0 ) { size = sx; }
		}

		n_type_gfx ty  = 0;
		n_type_gfx tsy = sy;
		if ( n_nyaurism->plotter_selection_channel == 1 )
		{
			ty  = sy / 2;
			tsy = sy / 2;
		} else
		if ( n_nyaurism->plotter_selection_channel == 2 )
		{
			tsy = sy / 2;
		}

		n_bmp_mixer( bmp, from, ty, size, tsy, cselect, 0.2 );

		if ( size == 0 )
		{
			if ( from )
			{
//NSLog( @"indicator : %d", from );
				if ( n_nyaurism->plotter_selection_channel == 1 )
				{
					n_bmp_line( bmp, from, tsy, from, sy, cselect );
				} else
				if ( n_nyaurism->plotter_selection_channel == 2 )
				{
					n_bmp_line( bmp, from, 0, from, tsy, cselect );
				} else {
					n_bmp_line( bmp, from, 0, from, sy, cselect );
				}
			}
		} else
		if ( n_nyaurism->plotter_selection_channel == 1 )
		{
			n_bmp_line( bmp, from -    1, tsy, from -    1,  sy, cselect );
			n_bmp_line( bmp, from + size, tsy, from + size,  sy, cselect );
		} else
		if ( n_nyaurism->plotter_selection_channel == 2 )
		{
			n_bmp_line( bmp, from -    1,   0, from -    1, tsy, cselect );
			n_bmp_line( bmp, from + size,   0, from + size, tsy, cselect );
		} else {
			n_bmp_line( bmp, from -    1,   0, from -    1,  sy, cselect );
			n_bmp_line( bmp, from + size,   0, from + size,  sy, cselect );
		}
	}


	// Seek Bar
/*
	if ( n_nyaurism->seekbar_float_norm != -1 )
	{
		n_bmp_box( bmp, (float) sx * n_nyaurism->seekbar_float_norm, 0, 1, sy, n_bmp_rgb( 255,0,150 ) );
	}
*/

	if ( ( n_nyaurism->selection_size_pixel )||( n_nyaurism->selection_shift_onoff ) )
	{
		n_nyaurism_tooltip_draw( hwnd, bmp, n_nyaurism_tooltip_str );
	}


	return;
}




void
n_win64_ui_plotter_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_plotter *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );

		n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
		n_bmp *bmp = &p->db.bmp;
//n_bmp_flush( bmp, n_bmp_rgb( 0,200,255 ) );

		if ( n_nyaurism->seekbar_float_norm != -1 )
		{
//n_bmp_flush_fastcopy( &n_nyaurism->seekbar_bmp, bmp );

			n_win64_doublebuffer_presync( &p->db );

			float xx = n_nyaurism->playback_prev_x;
			n_bmp_fastcopy( &n_nyaurism->seekbar_bmp, bmp, xx,0,1,csy, xx,0 );

			float x = (float) csx * n_nyaurism->seekbar_float_norm;
			n_bmp_box( bmp, x, 0, 1, csy, n_bmp_rgb( 255,0,150 ) );

			n_nyaurism->playback_prev_x = x;
		} else {
			n_nyaurism_plotter_draw( hwnd, bmp, &n_nyaurism->wav, csx, csy );
			n_bmp_flush_fastcopy( bmp, &n_nyaurism->seekbar_bmp );
		}

		n_win64_doublebuffer_exit( &p->db );

	}
	break;


	} // switch


	return;
}




// internal
void
n_nyaurism_modifier_key( HWND hwnd )
{

	if ( FALSE == n_win64_is_input( VK_LBUTTON ) )
	{
		n_nyaurism->selection_shift_onoff   = FALSE;
		n_nyaurism->selection_command_onoff = FALSE;

		return;
	}

	if ( n_win64_is_input( VK_SHIFT ) )
	{
//NSLog( @"shift on" );

		n_type_gfx x,sx; n_nyaurism_plotter_selection_pixel2sample( &n_nyaurism->wav, &x, &sx );

		if ( ( x != 0 )&&( sx == 0 ) )
		{
			// [!] : indicator mode
		} else
		if ( n_nyaurism->selection_shift_onoff == FALSE )
		{
			n_nyaurism->selection_shift_onoff = TRUE;

			n_nyaurism_tooltip_calc( hwnd, 0 );
		}
	} else
	if ( n_nyaurism->selection_shift_onoff )
	{
//NSLog( @"shift off" );

		n_nyaurism->selection_shift_onoff = FALSE;

		n_nyaurism_tooltip_calc( hwnd, n_nyaurism->selection_size_pixel );

		n_type_gfx f = n_nyaurism->selection_from_pixel;
		n_type_gfx s = n_nyaurism->selection_size_pixel;

		// [!] : clipper

		n_type_gfx csx; n_win64_control_size( hwnd, &csx, NULL );

		if ( f < 0 )
		{
			s = s + f;
			f = 0;
		}

		if ( ( f + s ) > csx )
		{
			s -= ( f + s ) - csx;
		}

		n_nyaurism->selection_from_pixel = f;
		n_nyaurism->selection_loop_pixel = f;
		n_nyaurism->selection_size_pixel = s;

	}


	if ( n_win64_is_input( VK_CONTROL ) )
	{
		n_nyaurism->selection_command_onoff = TRUE;
	} else
	if ( n_nyaurism->selection_command_onoff )
	{
		n_nyaurism->selection_command_onoff = FALSE;
	}


	return;

}

// internal
LRESULT CALLBACK
n_win64_ui_plotter_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_plotter *p = (void*) dwRefData;
	if ( p == NULL ) { return DefSubclassProc( hwnd, msg, wParam, lParam ); }


	n_nyaurism_modifier_key( hwnd );


	switch( msg ) {


	case WM_KEYDOWN :
	{

		if ( n_nyaurism_now_playing() ) { break; }


		switch( wParam ) {

#ifdef DEBUG
		case VK_F1:
		{

			//n_fft_histogram_test( &n_nyaurism->wav );

			//n_wav_pinknoise( &n_nyaurism->wav, 0, 1.0, 1.0 );

			n_wav_tremolo( &n_nyaurism->wav, 3, 1.0, 1.0 );

			n_win64_refresh( p->hwnd, FALSE );
		}
		break;
#endif

		case VK_F2:
		{
			//n_nyaurism->fname = n_mac_fork_rename( n_nyaurism->fname );

			//NSString *title = [NSString stringWithFormat:@"%@ - Nyaurism", n_nyaurism->fname];
			//[n_mac_image_window setTitle:title];
		}
		break;

		case 'Z':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_undo( &n_nyaurism->wav );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case 'A':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_select_all( &n_nyaurism->wav, hwnd, TRUE );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case 'X':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_cut( &n_nyaurism->wav );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case 'C':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_copy( &n_nyaurism->wav, &n_nyaurism->wav_clip );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case 'V':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_paste( &n_nyaurism->wav );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case 'B':
		{
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( n_nyaurism->selection_shift_onoff ) { break; }

				n_nyaurism_plotter_overwrite( &n_nyaurism->wav );

				n_win64_refresh( p->hwnd, FALSE );
			}
		}
		break;

		case VK_BACK:
		{
			if ( n_nyaurism->selection_shift_onoff ) { break; }

			n_nyaurism_plotter_delete( &n_nyaurism->wav );

			n_win64_refresh( p->hwnd, FALSE );
		}
		break;

		} // switch( wParam )

	}
	break;


	case WM_LBUTTONDOWN :
	{

		n_nyaurism->selection_drag_onoff = FALSE;

		if ( n_nyaurism_now_playing() ) { break; }

		POINT pt = n_win64_cursor_position_relative_POINT( hwnd );

		if (0)//( [theEvent clickCount] >= 2 )
		{
//NSLog( @"double-click" );

			n_nyaurism->selection_select_all = TRUE;

			if ( n_win64_is_input( VK_SHIFT ) ) { break; }

			n_nyaurism->selection_reverse = FALSE;

			n_nyaurism->selection_from_pixel = 0;
			n_nyaurism->selection_loop_pixel = 0;
			n_nyaurism->selection_size_pixel = N_WAV_COUNT( &n_nyaurism->wav ) / n_nyaurism->selection_step;

			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_undo );
			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_base );

			n_nyaurism_tooltip_calc( hwnd, n_nyaurism->selection_size_pixel );

		} else
		if ( n_nyaurism->selection_shift_onoff )
		{

			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_undo );
			n_nyaurism_backup( &n_nyaurism->wav, &n_nyaurism->wav_base );

			n_nyaurism->selection_shift_pixel = pt.x;

			n_type_gfx f = n_nyaurism_plotter_selection_left_edge();
			n_nyaurism->selection_reselect_pixel = pt.x - f;

			if ( f )
			{
				n_nyaurism_plotter_copy( &n_nyaurism->wav, &n_nyaurism->wav_base );
			} else {
				n_nyaurism_plotter_select_all( &n_nyaurism->wav, hwnd, NO );
			}
		} else
		//
		{
			n_type_gfx csy; n_win64_control_size( p->hwnd, NULL, &csy );

			if ( n_nyaurism->selection_command_onoff )
			{
				if ( ( pt.y >   0 )&&( pt.y < ( csy / 2 ) ) )
				{
					if ( n_nyaurism->plotter_selection_channel == 1 )
					{
						n_nyaurism_plotter_selection_off();
					} else {
						n_nyaurism->plotter_selection_channel = 2;
					}
				} else
				if ( ( pt.y > ( csy / 2 ) )&&( pt.y < csy ) )
				{
					if ( n_nyaurism->plotter_selection_channel == 2 )
					{
						n_nyaurism_plotter_selection_off();
					} else {
						n_nyaurism->plotter_selection_channel = 1;
					}
				}
			} else {
				if ( ( pt.y >   0 )&&( pt.y < ( csy / 2 ) ) )
				{
					if ( n_nyaurism->plotter_selection_channel == 1 )
					{
						n_nyaurism_plotter_selection_off();
						break;
					}
				} else
				if ( ( pt.y > ( csy / 2 ) )&&( pt.y < csy ) )
				{
					if ( n_nyaurism->plotter_selection_channel == 2 )
					{
						n_nyaurism_plotter_selection_off();
						break;
					}
				}
			}


			n_type_gfx f = n_nyaurism_plotter_selection_left_edge();
			n_type_gfx s = n_nyaurism->selection_size_pixel;

			if ( n_nyaurism->selection_select_all )
			{
				n_nyaurism->selection_select_all = FALSE;
				n_nyaurism_plotter_selection_off();
			} else
			if ( ( f < pt.x )&&( ( f + s ) > pt.x ) )
			{
				n_nyaurism->selection_reselect_onoff = TRUE;
				n_nyaurism->selection_reselect_pixel = pt.x - f;
			} else
			if ( s != 0 )
			{
				n_nyaurism_plotter_selection_off();
			} else
			//
			{
				n_nyaurism->selection_reverse = FALSE;

				n_nyaurism->selection_from_pixel = pt.x;
				n_nyaurism->selection_loop_pixel = pt.x;
				n_nyaurism->selection_size_pixel = 0;

				if ( ( pt.x * n_nyaurism->selection_step ) < N_WAV_COUNT( &n_nyaurism->wav )  )
				{
					n_nyaurism->selection_drag_onoff = TRUE;
				}
			}
		}

		n_win64_refresh( p->hwnd, FALSE );

	}
	break;


	case WM_LBUTTONUP :

		if ( n_nyaurism_now_playing() ) { break; }

		if ( n_nyaurism->selection_reselect_onoff )
		{
			n_nyaurism->selection_reselect_onoff = FALSE;
		} else
		if ( n_nyaurism->selection_drag_onoff )
		{
			n_nyaurism->selection_drag_onoff = FALSE;

			POINT pt = n_win64_cursor_position_relative_POINT( hwnd );
			if ( pt.x < n_nyaurism->selection_from_pixel )
			{
				n_nyaurism->selection_from_pixel = n_nyaurism->selection_loop_pixel;
			}
		}

		n_nyaurism_slider_redraw( &n_nyaurism->wav );

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_MOUSEMOVE :
	{
		if ( n_nyaurism_now_playing() ) { break; }

		POINT pt = n_win64_cursor_position_relative_POINT( hwnd );

		if ( n_nyaurism->selection_reselect_onoff )
		{
			n_type_gfx f = pt.x - n_nyaurism->selection_reselect_pixel;
			n_type_gfx s = n_nyaurism->selection_size_pixel;

			n_type_gfx csx; n_win64_control_size( hwnd, &csx, NULL );

			// [!] : currently out-of-bound is not supported
			if ( f < 0 )
			{
				f = 0;
			} else
			if ( ( f + s ) > csx )
			{
				f = csx - s;
			}

			n_nyaurism->selection_from_pixel = f;
			n_nyaurism->selection_loop_pixel = n_nyaurism->selection_from_pixel;

			n_nyaurism_slider_redraw( &n_nyaurism->wav );

			n_nyaurism_tooltip_calc( hwnd, f );
		} else
		if ( n_nyaurism->selection_shift_onoff )
		{
			// [!] : don't use u32 here
			n_type_int f = pt.x - n_nyaurism->selection_reselect_pixel;
			n_type_int s = n_nyaurism->selection_size_pixel;
/*
			n_type_gfx csx; n_win64_control_size( hwnd, &csx, NULL );

			// [!] : out-of-bound is acceptable
			if ( f < 0 )
			{
				f = 0;
			} else
			if ( ( f + s ) > csx )
			{
				f = csx - s;
			}
*/
			n_nyaurism_tooltip_calc( hwnd, f );

			n_nyaurism->selection_from_pixel = (n_type_gfx) f;
			n_nyaurism->selection_loop_pixel = n_nyaurism->selection_from_pixel;

			n_type_int  x = f * n_nyaurism->selection_step;
			n_type_int sx = s * n_nyaurism->selection_step;

			n_type_real l = 1.0; if ( n_nyaurism->plotter_selection_channel == 1 ) { l = -1; }
			n_type_real r = 1.0; if ( n_nyaurism->plotter_selection_channel == 2 ) { r = -1; }

			n_nyaurism_backup( &n_nyaurism->wav_undo, &n_nyaurism->wav );

			if ( n_nyaurism->mix_onoff )
			{
				n_wav_copy( &n_nyaurism->wav_base, &n_nyaurism->wav, 0,sx, x, l,r, N_WAV_COPY_ADD );
			} else {
				n_wav_copy( &n_nyaurism->wav_base, &n_nyaurism->wav, 0,sx, x, l,r, N_WAV_COPY_SET );
			}

			n_nyaurism_slider_redraw( &n_nyaurism->wav );

			n_nyaurism_tooltip_calc( hwnd, f );
		} else
		if ( n_nyaurism->selection_drag_onoff )
		{
			if ( pt.x < 0 ) { pt.x = 0; }

			n_type_gfx s = N_WAV_COUNT( &n_nyaurism->wav ) / n_nyaurism->selection_step;

			if ( ( n_nyaurism->selection_step == 1 )&&( pt.x > s ) )
			{
				n_nyaurism->selection_size_pixel = s - n_nyaurism_plotter_selection_left_edge();
			} else
			if ( pt.x < n_nyaurism->selection_from_pixel )
			{
				n_nyaurism->selection_reverse =  TRUE;

				n_nyaurism->selection_size_pixel = n_nyaurism->selection_from_pixel - pt.x;
				n_nyaurism->selection_loop_pixel = pt.x;
			} else {
				n_nyaurism->selection_reverse = FALSE;

				n_type_gfx csx; n_win64_control_size( hwnd, &csx, NULL );

				n_type_gfx size = csx - n_nyaurism_plotter_selection_left_edge();

				n_nyaurism->selection_size_pixel = n_posix_min_n_type_gfx( size, pt.x - n_nyaurism_plotter_selection_left_edge() );
			}

			n_nyaurism_tooltip_calc( hwnd, n_nyaurism->selection_size_pixel );
		}

		n_win64_refresh( p->hwnd, FALSE );

	}
	break;


	case WM_RBUTTONUP :
//n_win64_hwndprintf_literal( GetParent( hwnd ), "WM_RBUTTONUP" );
//AppendMenu( p->hmenu, MF_STRING, 1001, L"test" );

		n_win64_ui_menu_popup_show( p->hmenu, p->hwnd );

	break;


	} // switch


	{ // Menu

	int i = n_win64_ui_menu_popup_proc( hwnd, msg, wParam, lParam, p->hmenu, n_nyaurism_menu, 0 );
//if ( i >= 0 ) { n_win64_hwndprintf_literal( hwnd, "%d", i ); }
	if ( i == 0 )
	{
		n_nyaurism_plotter_undo( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 1 )
	{
		// Separetor
	} else
	if ( i == 2 )
	{
		n_nyaurism_plotter_select_all( &n_nyaurism->wav, hwnd, YES );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 3 )
	{
		n_nyaurism_plotter_selection_off();
		n_win64_refresh( p->hwnd, FALSE );
	}
	if ( i == 4 )
	{
		// Separetor
	} else
	if ( i == 5 )
	{
		n_nyaurism_plotter_cut( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 6 )
	{
		n_nyaurism_plotter_copy( &n_nyaurism->wav, &n_nyaurism->wav_clip );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 7 )
	{
		n_nyaurism_plotter_paste( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 8 )
	{
		n_nyaurism_plotter_overwrite( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 9 )
	{
		// Separetor
	} else
	if ( i == 10 )
	{
		n_nyaurism_plotter_mute( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 11 )
	{
		n_nyaurism_plotter_monoaural( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 12 )
	{
		n_nyaurism_plotter_L2R( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 13 )
	{
		n_nyaurism_plotter_R2L( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 14 )
	{
		// Separetor
	} else
	if ( i == 15 )
	{
		n_nyaurism_plotter_fade_in( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 16 )
	{
		n_nyaurism_plotter_fade_out( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 17 )
	{
		// Separetor
	} else
	if ( i == 18 )
	{
		n_nyaurism_plotter_smoother( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 19 )
	{
		n_nyaurism_plotter_overdrive( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 20 )
	{
		// Separetor
	} else
	if ( i == 21 )
	{
		n_nyaurism_plotter_tremolo( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 22 )
	{
		// Separetor
	} else
	if ( i == 23 )
	{
		n_nyaurism_plotter_whitenoise( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	} else
	if ( i == 24 )
	{
		n_nyaurism_plotter_pinknoise( &n_nyaurism->wav );
		n_win64_refresh( p->hwnd, FALSE );
	}

	} // Menu


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_plotter_init( n_win64_ui_plotter *p, HWND hwnd_parent )
{

	n_win64_ui_plotter_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_plotter_subclass, 0, (DWORD_PTR) p );

	p->hmenu = n_win64_ui_menu_popup_hmenu_init();
	n_win64_ui_menu_popup_init( p->hmenu, p->hwnd, n_nyaurism_menu, 0 );


	return;
}

void
n_win64_ui_plotter_exit( n_win64_ui_plotter *p )
{

	n_win64_ui_menu_popup_hmenu_exit( p->hmenu );

	DestroyWindow( p->hwnd );

	n_win64_ui_plotter_zero( p );


	return;
}


