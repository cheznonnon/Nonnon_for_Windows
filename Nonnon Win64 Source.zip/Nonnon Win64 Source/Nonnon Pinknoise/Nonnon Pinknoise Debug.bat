
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Nonnon Pinknoise"
set   debug=-DDEBUG

%compile%

