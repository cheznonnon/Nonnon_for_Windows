// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : Partial File




#include <commdlg.h>




HFONT
n_catpad_fontchooser( HWND hwnd, HFONT hfont, LOGFONT *lf_ret )
{

	LOGFONT lf = n_win64_font_hfont2logfont( hfont );


	CHOOSEFONT cf; ZeroMemory( &cf, sizeof( CHOOSEFONT ) );

	cf.hwndOwner    = hwnd;
	cf.lpLogFont    = &lf;
	cf.lStructSize  = sizeof( CHOOSEFONT );
	cf.Flags        = CF_INITTOLOGFONTSTRUCT | CF_NOVERTFONTS;//CF_SCREENFONTS | CF_FIXEDPITCHONLY | 

	ChooseFont( &cf );


	n_win64_font_exit( hfont );
	hfont = n_win64_font_logfont2hfont( &lf );

	if ( lf_ret != NULL ) { (*lf_ret) = lf; }


	return hfont;
}


