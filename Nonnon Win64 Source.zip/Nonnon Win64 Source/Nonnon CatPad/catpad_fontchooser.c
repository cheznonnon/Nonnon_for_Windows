// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <commdlg.h>




HFONT
n_catpad_fontchooser( HWND hwnd, HFONT hfont )
{

	// [x] : buggy and useless

	CHOOSEFONT cf;
	LOGFONT    lf_i, lf_o;

	lf_i = n_win64_font_hfont2logfont( hfont );

	ZeroMemory( &cf, sizeof( CHOOSEFONT ) );

	cf.hwndOwner    = hwnd;
	cf.lpLogFont    = &lf_i;
	cf.lStructSize  = sizeof( CHOOSEFONT );
	cf.Flags        = CF_INITTOLOGFONTSTRUCT | CF_NOVERTFONTS;//CF_SCREENFONTS | CF_FIXEDPITCHONLY | 
	cf.lpLogFont    = &lf_o;

	ChooseFont( &cf );

	n_win64_font_exit( hfont );
	hfont = n_win64_font_logfont2hfont( &lf_o );


	return hfont;
}


