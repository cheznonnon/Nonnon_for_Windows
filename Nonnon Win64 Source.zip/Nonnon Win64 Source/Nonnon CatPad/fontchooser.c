



#include <commdlg.h>




HFONT
n_fontchooser( HWND hwnd, HFONT hfont )
{

	// [x] : buggy and useless

	CHOOSEFONT cf;
	LOGFONT    lf_i, lf_o;

	lf_i = n_win64_font_hfont2logfont( hfont );

	ZeroMemory( &cf, sizeof( CHOOSEFONT ) );

	cf.hwndOwner    = hwnd;
	cf.lpLogFont    = &lf_i;
	cf.lStructSize  = sizeof( CHOOSEFONT );
	cf.Flags        = CF_SCREENFONTS | CF_FIXEDPITCHONLY | CF_INITTOLOGFONTSTRUCT;
	cf.lpLogFont    = &lf_o;

	ChooseFont( &cf );

	n_win64_font_exit( hfont );
	hfont = n_win64_font_logfont2hfont( &lf_o );


	return hfont;
}

void
n_fontchooser_go( n_txtbox *txtbox, HWND hwnd, HFONT hfont )
{

	HFONT hfont = txtbox.font;
	hfont = n_fontchooser( hwnd, hfont );

	n_txtbox_font_change( txtbox, hfont );

	n_txtbox_reset( txtbox );

	return;
}

