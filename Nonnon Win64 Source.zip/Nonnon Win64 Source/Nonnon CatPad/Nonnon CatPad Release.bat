
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Nonnon CatPad"
set   debug=

%compile%

