// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_CATPAD_SYNC_CCH 1024




#ifdef UNICODE

#define n_catpad_sync_name n_posix_literal( "Nonnon.CatPad.Sync.W" )

#else  // #ifdef UNICODE

#define n_catpad_sync_name n_posix_literal( "Nonnon.CatPad.Sync.A" )

#endif // #ifdef UNICODE




static n_posix_char n_query[ N_CATPAD_SYNC_CCH ];

static UINT n_catpad_sync_msg = 0;

static HANDLE n_catpad_sync_hmutex = NULL;




#define n_catpad_sync_get() n_catpad_sync_getset(  TRUE )
#define n_catpad_sync_set() n_catpad_sync_getset( FALSE )

HANDLE
n_catpad_sync_getset( BOOL is_get )
{

	HANDLE        hmap;
	n_posix_char *s;
	DWORD         byte = N_CATPAD_SYNC_CCH * sizeof( n_posix_char );


	hmap = CreateFileMapping( INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0,byte, n_catpad_sync_name );
	s    = MapViewOfFile( hmap, FILE_MAP_ALL_ACCESS, 0,0, 0 );

	if ( s != NULL )
	{

		if ( is_get )
		{
//n_posix_debug_literal( "Get : %s\n%s", s, n_query );
			n_string_copy( s, n_query );
		} else {
//n_posix_debug_literal( "Set : %s\n%s", n_query, s );
			n_string_copy( n_query, s );
		}

	}


	UnmapViewOfFile( s );


	return hmap;
}

void
n_catpad_sync_init( n_txtbox *search, n_txt *search_txt_data )
{

	n_catpad_sync_msg = RegisterWindowMessage( n_catpad_sync_name );


	// [!] : try to load from another CatPad

	n_catpad_sync_hmutex = n_win64_mutex_init_literal( n_catpad_sync_hmutex, "Nonnon.CatPad" );
	if ( n_catpad_sync_hmutex == NULL )
	{
		n_catpad_sync_get();
	} else {
//n_posix_debug_literal( "!" );
		n_catpad_sync_set();
	}

	n_txt_mod( search_txt_data, 0, n_query );
	n_txtbox_redraw( search );


	return;
}

void
n_catpad_sync_exit( void )
{

	// [!] : simply fail when other processes exist

	CloseHandle( n_catpad_sync_set() );

	n_catpad_sync_hmutex = n_win64_mutex_exit( n_catpad_sync_hmutex );


	return;
}

void
n_catpad_sync_send( HWND hwnd, n_posix_char *query_new )
{

	// [Needed] : prevent memory-leak

	n_string_copy( query_new, n_query );

	CloseHandle( n_catpad_sync_set() );


	// [!] : don't use SendMessage() : hangup in some cases

	n_win64_message_post( HWND_BROADCAST, n_catpad_sync_msg, 0, (LPARAM) hwnd );


	return;
}

BOOL
n_catpad_sync_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_txtbox *search, n_txt *search_txt_data )
{

	if ( msg != n_catpad_sync_msg ) { return FALSE; }


#ifdef UNICODE

	if ( FALSE == IsWindowUnicode( (HWND) lparam ) ) { return FALSE; }

#else // #ifdef UNICODE

	if ( IsWindowUnicode( (HWND) lparam ) ) { return FALSE; }

#endif // #ifdef UNICODE


	// [Needed] : anti-memory-leak

	CloseHandle( n_catpad_sync_get() );


	n_txt_mod( search_txt_data, 0, n_query );
	n_txtbox_caret_tail_set( search );
	n_txtbox_redraw( search );


	return TRUE;
}

