﻿// Nonnon CatPad for Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win64/_windows.c"


#include "../nonnon/win64/ui/window.c"
#include "../nonnon/win64/ui/button.c"
#include "../nonnon/win64/ui/groupbox.c"
#include "../nonnon/win64/ui/txtbox.c"

#include "../nonnon/win64/resource.c"
#include "../nonnon/bridge/sound.c"

#include "../nonnon/win64/registry.c"


#include "catpad_filter.c"
#include "catpad_fontchooser.c"




void
n_catpad_font_change( n_txtbox *txtbox, HFONT font_new )
{

	// [x] : Windows : each fonts are uglier than macOS


	HDC hdc = GetDC( txtbox->hwnd );


	n_win64_font_exit( txtbox->font );
	txtbox->font = font_new;


	txtbox->linenumber_font = txtbox->font;
	txtbox->linenumber_size = n_win64_text_pixelsize( hdc, n_posix_literal( "000000" ), txtbox->font );


	txtbox->font_cjk = txtbox->font;


	txtbox->font_size = n_win64_text_pixelsize( hdc, n_posix_literal( " " ), txtbox->font );


	ReleaseDC( txtbox->hwnd, hdc );


	return;
}




#define N_APPNAME n_posix_literal( "Nonnon CatPad" )
#define N_ICONAME n_posix_literal( "MAIN_ICON" )


#define N_CATPAD_DEFAULT_SX ( 512 )
#define N_CATPAD_DEFAULT_SY ( 512 )


#define N_CATPAD_UNIT_SY ( 40 )




#define n_button_setup_literal( p, r ) n_button_setup( p, n_posix_literal( r ) ) 

void
n_button_setup( n_win64_ui_button *p, n_posix_char *resource_name )
{

	//p->label         = label;
	p->resource_name = resource_name;

	//n_win64_refresh( p->hwnd, FALSE );


	return;
}




void
n_catpad_registry( void )
{

	n_posix_char *exe = n_win64_exepath_new();
	DWORD         cch = n_posix_strlen( exe );


	DWORD         cch1 = cch + 10;
	n_posix_char *str1 = n_string_new( cch1 );

	n_posix_snprintf_literal( str1, cch1 + 1, "\"%s\",1", exe );

	n_win64_registry_write
	(
		HKEY_CURRENT_USER,
		n_posix_literal( "Software\\Classes\\Applications\\Nonnon CatPad.exe\\DefaultIcon" ),
		n_posix_literal( "" ),
		REG_SZ,
		str1,
		cch1 * sizeof( n_posix_char )
	);

	n_string_free( str1 );


	DWORD         cch2 = cch + 10;
	n_posix_char *str2 = n_string_new( cch2 );

	n_posix_snprintf_literal( str2, cch2 + 1, "\"%s\" \"%%1\"", exe );

	n_win64_registry_write
	(
		HKEY_CURRENT_USER,
		n_posix_literal( "Software\\Classes\\Applications\\Nonnon CatPad.exe\\shell\\open\\command" ),
		n_posix_literal( "" ),
		REG_SZ,
		str2,
		cch2 * sizeof( n_posix_char )
	);

	n_string_free( str2 );


	return;
}

static n_type_gfx n_x;
static n_type_gfx n_y;
static n_type_gfx n_w;
static n_type_gfx n_h;
static n_type_gfx n_w_max;
static n_type_gfx n_h_max;

static n_posix_char n_font_name[ LF_FACESIZE ] = n_posix_literal( "" );
static int          n_font_size                = 0;

#include "catpad_sync.c"

void
n_catpad_settings( BOOL is_read )
{

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_posix_literal( "nonnon.ini" ) );


	if ( is_read )
	{
		n_x = n_ini_value_int_literal( &ini, "[Nonnon CatPad]", "x", 0 );
		n_y = n_ini_value_int_literal( &ini, "[Nonnon CatPad]", "y", 0 );
		n_w = n_ini_value_int_literal( &ini, "[Nonnon CatPad]", "w", N_CATPAD_DEFAULT_SX );
		n_h = n_ini_value_int_literal( &ini, "[Nonnon CatPad]", "h", N_CATPAD_DEFAULT_SY );

		n_ini_value_str_literal( &ini, "[Nonnon CatPad]", "q", "", n_query, 1024 );

		              n_ini_value_str_literal( &ini, "[Nonnon CatPad]", "font_name", "", n_font_name, LF_FACESIZE );
		n_font_size = n_ini_value_int_literal( &ini, "[Nonnon CatPad]", "font_size", -18 );
	} else {
		n_ini_section_add_literal( &ini, "[Nonnon CatPad]" );

		n_ini_key_add_int_literal( &ini, "[Nonnon CatPad]", "x", n_x );
		n_ini_key_add_int_literal( &ini, "[Nonnon CatPad]", "y", n_y );
		n_ini_key_add_int_literal( &ini, "[Nonnon CatPad]", "w", n_w );
		n_ini_key_add_int_literal( &ini, "[Nonnon CatPad]", "h", n_h );
		n_ini_key_add_str_literal( &ini, "[Nonnon CatPad]", "q", n_query );

		n_ini_key_add_str_literal( &ini, "[Nonnon CatPad]", "font_name", n_font_name );
		n_ini_key_add_int_literal( &ini, "[Nonnon CatPad]", "font_size", n_font_size );

		n_ini_save( &ini, n_posix_literal( "nonnon.ini" ) );
	}

	n_ini_free( &ini );


	return;
}

BOOL
n_catpad_config( n_txt *data, n_txtbox *charset, n_txtbox *newline, BOOL is_read )
{

	static int charset_prv = 0;
	static int newline_prv = 0;

	BOOL ret = FALSE;

	if ( is_read )
	{

		charset_prv = data->unicode;

		if ( data->unicode == N_TXT_UNICODE_LIL )
		{
			charset->focus = 0;
		} else
		if ( data->unicode == N_TXT_UNICODE_BIG )
		{
			charset->focus = 1;
		} else
		if ( data->unicode == N_TXT_UNICODE_UTF8_NO_BOM )
		{
			charset->focus = 2;
		} else {
			charset->focus = 3;
		}


		newline_prv = data->newline;

		if ( data->newline == N_TXT_NEWLINE_CRLF )
		{
			newline->focus = 0;
		} else
		if ( data->newline == N_TXT_NEWLINE_CR )
		{
			newline->focus = 1;
		} else
		if ( data->newline == N_TXT_NEWLINE_LF )
		{
			newline->focus = 2;
		}

	} else {

		if ( charset->focus == 0 )
		{
			data->unicode = N_TXT_UNICODE_LIL;
		} else
		if ( charset->focus == 1 )
		{
			data->unicode = N_TXT_UNICODE_BIG;
		} else
		if ( charset->focus == 2 )
		{
			data->unicode = N_TXT_UNICODE_UTF8_NO_BOM;
		} else {
			data->unicode = N_TXT_UNICODE_UTF;
		}

		if ( newline->focus == 0 )
		{
			data->newline = N_TXT_NEWLINE_CRLF;
		} else
		if ( newline->focus == 1 )
		{
			data->newline = N_TXT_NEWLINE_CR;
		} else
		if ( newline->focus == 2 )
		{
			data->newline = N_TXT_NEWLINE_LF;
		}

		if ( charset_prv != data->unicode ) { ret = TRUE; }
		if ( newline_prv != data->newline ) { ret = TRUE; }
	}


	return ret;
}




void
n_catpad_blink_timer( n_win64_ui_button *button )
{

	if ( button->gray_onoff ) { return; }


	static int blink = 0;


	blink++;
	if ( blink == 47 )
	{
//NSLog( @"on" );
		n_button_setup_literal( button, "N_NEKO_2" );
		n_win64_refresh( button->hwnd, FALSE );
	} else
	if ( blink == 48 )
	{
//NSLog( @"on" );
		n_button_setup_literal( button, "N_NEKO_3" );
		n_win64_refresh( button->hwnd, FALSE );
	} else
	if ( blink == 49 )
	{
//NSLog( @"on" );
		n_button_setup_literal( button, "N_NEKO_2" );
		n_win64_refresh( button->hwnd, FALSE );
	} else
	if ( blink == 50 )
	{
//NSLog( @"off" );
		n_button_setup_literal( button, "N_NEKO_1" );
		n_win64_refresh( button->hwnd, FALSE );

		blink = 0;
	}


	return;
}




void
n_catpad_pos_size( HWND hwnd )
{

	if ( IsZoomed( hwnd ) )
	{
		RECT rect; GetClientRect( hwnd, &rect );
		n_win64_rect_expand_size( &rect, NULL, NULL, &n_w_max, &n_h_max );
	} else
	if ( IsIconic( hwnd ) )
	{
		//
	} else {
		RECT w; GetWindowRect( hwnd, &w );
		RECT c; GetClientRect( hwnd, &c );
		n_win64_rect_expand_size( &w, &n_x, &n_y, NULL, NULL );
		n_win64_rect_expand_size( &c, NULL, NULL, &n_w, &n_h );
	}


	return;
}

void
n_catpad_toolband_draw( HWND hwnd, HDC _hdc, BOOL config_onoff )
{

	HDC hdc = _hdc;
	if ( _hdc == NULL )
	{
		hdc = GetDC( hwnd );
	}

	RECT rect; GetClientRect( hwnd, &rect );
//n_win64_hwndprintf_literal( hwnd, "%d %d %d %d", rect.left, rect.top, rect.right, rect.bottom );

	if ( config_onoff == FALSE )
	{
		rect.bottom = N_CATPAD_UNIT_SY;
	}

	COLORREF colorref = n_win64_GetSysColor( COLOR_BTNFACE );

	HBRUSH br = CreateSolidBrush( colorref );

	FillRect( hdc, &rect, br );

	DeleteObject( br );

	if ( _hdc == NULL )
	{
		ReleaseDC( hwnd, hdc );
	}


	return;
}

void
n_catpad_title( HWND hwnd, n_posix_char *path, n_txt *txt )
{

	n_posix_char *title = n_string_path_cat( path, n_posix_literal( " - CatPad" ), NULL );


	// [!] : set readonly if the same titled window is running

	HWND h = NULL;
	n_posix_loop
	{
		h = FindWindowEx( NULL, h, NULL, title );
		if ( h == NULL ) { break; }
		if ( h != hwnd ) { break; }
	}

	if ( h != NULL )
	{
		txt->readonly = TRUE;

		n_posix_char *str = n_string_path_cat( path, n_posix_literal( " (Read Only)- CatPad" ), NULL );

		SetWindowText( hwnd, str );

		n_string_free( str );
	} else {
		SetWindowText( hwnd, title );
	}

	n_string_free( title );


	return;
}

void
n_catpad_resize
(
	HWND                 hwnd,
	BOOL                 window,
	n_txtbox            *txtbox,
	n_txtbox            *search,
	n_win64_ui_button   *button_0,
	n_win64_ui_button   *button_1,
	n_win64_ui_button   *button_2,
	n_win64_ui_button   *button_3,
	n_win64_ui_button   *button_4,
	n_win64_ui_button   *button_5,
	n_win64_ui_button   *button_6,
	n_win64_ui_groupbox *config_groupbox,
	n_txtbox            *config_charset,
	n_txtbox            *config_newline,
	BOOL                 config_onoff
)
{

	const n_type_gfx unit_sy = N_CATPAD_UNIT_SY;

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	n_type_gfx sx = unit_sy;
	n_type_gfx sy = unit_sy;

	n_win64_ui_button_move( button_0, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_1, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_2, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_3, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_4, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_5, x,y,sx,sy, FALSE ); x += sx;
	n_win64_ui_button_move( button_6, x,y,sx,sy, FALSE ); x += sx;


	n_type_gfx txtbox_sx, txtbox_sy;
	if ( IsZoomed( hwnd ) )
	{
		txtbox_sx = n_w_max;
		txtbox_sy = n_h_max;
	} else {
		txtbox_sx = n_w;
		txtbox_sy = n_h;
	}

	if ( config_onoff )
	{
		n_type_gfx half_sx = txtbox_sx / 2;
		n_type_gfx half_sy = txtbox_sy / 2;

		n_type_gfx cfg_sx = 128;
		n_type_gfx cfg_sy = 128;

		n_type_gfx cfg_y = half_sy - ( cfg_sy / 2 );

		MoveWindow( config_charset->hwnd, half_sx-cfg_sx-4,cfg_y, cfg_sx, cfg_sy, TRUE ); 
		MoveWindow( config_newline->hwnd, half_sx       +4,cfg_y, cfg_sx, cfg_sy, TRUE ); 

		{
			n_type_gfx x = half_sx - cfg_sx - 32;
			n_type_gfx y =            cfg_y - 32;

			n_type_gfx sx = ( cfg_sx * 2 ) + ( 32 * 2 );
			n_type_gfx sy = ( cfg_sy * 1 ) + ( 32 * 2 );

			MoveWindow( config_groupbox->hwnd, x,y, sx,sy, TRUE ); 
		}

	} else {
		MoveWindow( txtbox->hwnd, 0, unit_sy, txtbox_sx, txtbox_sy - unit_sy, TRUE ); 
	}

	{
		n_type_gfx ssx = n_posix_min( 333, ( txtbox_sx - x ) / 3 * 2 );
		n_type_gfx ssy = search->ui_stdsize + 8;

		n_type_gfx s_x = txtbox_sx - ssx;
		n_type_gfx s_y = ( unit_sy - ssy )  / 2;

		MoveWindow( search->hwnd, s_x, s_y, ssx-8, ssy, TRUE ); 
	}


	if ( window )
	{
		BOOL centering;
		if ( ( n_x == 0 )&&( n_y == 0 ) ) { centering = TRUE; } else { centering = FALSE; }

		if ( n_catpad_sync_hmutex == NULL )
		{
//n_win64_hwndprintf_literal( hwnd, "NULL" );

			n_type_gfx offset = GetSystemMetrics( SM_CYCAPTION );

			n_x += offset;
			n_y += offset;
		} else {
//n_win64_hwndprintf_literal( hwnd, "not NULL" );
		}

		n_win64_ui_window_set( hwnd, n_x, n_y, n_w, n_h, centering );
	}


	return;
}

LRESULT CALLBACK
n_catpad_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static n_wav wav;
	static n_directsound directsound;

	static n_win64_ui_button button_0;
	static n_win64_ui_button button_1;
	static n_win64_ui_button button_2;
	static n_win64_ui_button button_3;
	static n_win64_ui_button button_4;
	static n_win64_ui_button button_5;
	static n_win64_ui_button button_6;

	static n_txtbox txtbox;
	static n_txt    txt_data;

	static n_txtbox search;

	static BOOL     config_onoff = FALSE;

	static n_win64_ui_groupbox config_groupbox;

	static n_txtbox config_charset;
	static n_txtbox config_newline;

	static n_posix_char *path = NULL;

	static UINT neko_animation_timer = 0;

	static n_game_sound sound_meow;

	static UINT darkmode_timer = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			darkmode_timer = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, darkmode_timer, 200 );
		}
	}
	break;


	case WM_CREATE :


		// Global

		n_win64_exedir2curdir();

		n_catpad_settings( TRUE );

#ifndef DEBUG
		n_catpad_registry();
#endif

		// Window

		n_win64_ui_window_init( hwnd, N_APPNAME, N_ICONAME, N_STRING_EMPTY );

		n_win64_style_add( hwnd, WS_OVERLAPPEDWINDOW );

		//n_win64_exstyle_add( hwnd, WS_EX_COMPOSITED );


		n_win64_ui_button_init( &button_0, hwnd );
		n_win64_ui_button_init( &button_1, hwnd );
		n_win64_ui_button_init( &button_2, hwnd );
		n_win64_ui_button_init( &button_3, hwnd );
		n_win64_ui_button_init( &button_4, hwnd );
		n_win64_ui_button_init( &button_5, hwnd );
		n_win64_ui_button_init( &button_6, hwnd );

		n_button_setup_literal( &button_0, "N_TOPMOST" );
		n_button_setup_literal( &button_1, "N_NEKO_3" );
		n_button_setup_literal( &button_2, "N_CONFIG" );
		n_button_setup_literal( &button_3, "N_FONT" );
		n_button_setup_literal( &button_4, "N_CALC" );
		n_button_setup_literal( &button_5, "N_NDUMP" );
		n_button_setup_literal( &button_6, "N_HTML" );

		button_1.gray_onoff = TRUE; n_win64_refresh( button_1.hwnd, FALSE );

		button_0.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_1.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_2.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_3.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_4.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_5.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
		button_6.style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;


		path = n_win64_commandline_new();
		if ( n_string_is_empty( path ) )
		{
			path = n_string_carboncopy( n_posix_literal( "new.txt" ) );
		}

		n_txt_zero( &txt_data );

		if ( n_txt_load( &txt_data, path ) )
		{
			n_txt_new( &txt_data );
		} else {
			n_catpad_title( hwnd, path, &txt_data );
		}

		n_txtbox_init( &txtbox, hwnd, &txt_data );

		txtbox.option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;
		txtbox.border_separator_only = TRUE;
		txtbox.corner_size           = -1;
//if(0)
		{
			//AddFontResourceEx( n_posix_literal( "NotoSansMonoCJKjp-Regular.otf" ), FR_PRIVATE, 0 );

			HFONT hfont     = n_win64_font_name2hfont( n_font_name, n_font_size );
			HFONT hfont_cjk = hfont;

			if ( hfont == NULL )
			{
//n_posix_debug_literal( "NULL" );
				n_string_copy_literal( "MeiryoKe_Gothic", n_font_name );
				hfont = hfont_cjk = n_win64_font_name2hfont( n_font_name, n_font_size );
			}

			if ( hfont == NULL )
			{
//n_posix_debug_literal( "NULL" );
				n_string_copy_literal( "Noto Sans Mono CJK JP", n_font_name );
				hfont = hfont_cjk = n_win64_font_name2hfont( n_font_name, n_font_size );
			}

			if ( hfont == NULL )
			{
				n_string_copy_literal( "*", n_font_name );

				hfont     = n_win64_font_name2hfont_literal( "Consolas", n_font_size );
				hfont_cjk = n_win64_font_name2hfont_literal( "Meiryo"  , n_font_size );

				hfont     = n_win64_font_decoration( hfont    , CLEARTYPE_QUALITY, 0, FIXED_PITCH, FALSE, FALSE );
				hfont_cjk = n_win64_font_decoration( hfont_cjk, CLEARTYPE_QUALITY, 0, FIXED_PITCH, FALSE, FALSE );

				n_txtbox_font_change( &txtbox, hfont, hfont_cjk );

				txtbox.is_monospace = TRUE;
			} else {
				n_txtbox_font_change( &txtbox, hfont, hfont );
			}

		}

		n_txtbox_reset( &txtbox );


		n_txtbox_init( &search, hwnd, NULL );

		n_catpad_sync_init( &search, search.txt_data );

		search.mode = N_MAC_TXTBOX_MODE_FINDBOX;

		n_txtbox_reset( &search );


		n_txtbox_init( &config_charset, hwnd, NULL );

		n_txt_set( config_charset.txt_data, 0, n_posix_literal( "UTF-16 LE"      ) );
		n_txt_set( config_charset.txt_data, 1, n_posix_literal( "UTF-16 BE"      ) );
		n_txt_set( config_charset.txt_data, 2, n_posix_literal( "UTF-8 no BOM"   ) );
		n_txt_set( config_charset.txt_data, 3, n_posix_literal( "UTF-8 with BOM" ) );

		config_charset.mode = N_MAC_TXTBOX_MODE_LISTBOX;

		n_txtbox_reset( &config_charset );


		n_txtbox_init( &config_newline, hwnd, NULL );

		n_txt_set( config_newline.txt_data, 0, n_posix_literal( "CRLF" ) );
		n_txt_set( config_newline.txt_data, 1, n_posix_literal( "CR"   ) );
		n_txt_set( config_newline.txt_data, 2, n_posix_literal( "LF"   ) );

		config_newline.mode = N_MAC_TXTBOX_MODE_LISTBOX;

		n_txtbox_reset( &config_newline );


		// [Needed] : after Txtbox

		n_win64_ui_groupbox_init( &config_groupbox, hwnd, n_posix_literal( "Config" ) );


		if ( txt_data.newline == N_TXT_NEWLINE_BINARY )
		{
			n_catpad_ntxt_binary2text( &txt_data );
		}

		n_catpad_config( &txt_data, &config_charset, &config_newline, TRUE );

		if ( txt_data.readonly )
		{
			button_2.gray_onoff = TRUE; n_win64_refresh( button_2.hwnd, FALSE );
		}


		SetFocus( txtbox.hwnd );


		neko_animation_timer = n_win64_timer_id_get();
		n_win64_timer_init( hwnd, neko_animation_timer, 100 );

		n_game_sound_init_literal( &sound_meow, hwnd, "N_WAV_MEOW" );


		n_catpad_resize
		(
			hwnd,
			TRUE,
			&txtbox,
			&search,
			&button_0,
			&button_1,
			&button_2,
			&button_3,
			&button_4,
			&button_5,
			&button_6,
			&config_groupbox,
			&config_charset,
			&config_newline,
			config_onoff
		);


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );


		// [Needed] : system app-based volume control

		n_wav_zero( &wav );
		n_wav_new( &wav, 100 );

		n_directsound_zero( &directsound );
		n_directsound_init( &directsound, hwnd, &wav );
		n_directsound_loop( &directsound );

	break;


	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == neko_animation_timer )
		{
			n_catpad_blink_timer( &button_1 );
		} else
		if ( wParam == darkmode_timer )
		{
			n_win64_timer_exit( hwnd, darkmode_timer );

			n_win64_darkmode_titlebar_auto( hwnd );

			n_catpad_toolband_draw( hwnd, NULL, config_onoff );

			n_win64_refresh( button_0.hwnd, FALSE );
			n_win64_refresh( button_1.hwnd, FALSE );
			n_win64_refresh( button_2.hwnd, FALSE );
			n_win64_refresh( button_3.hwnd, FALSE );
			n_win64_refresh( button_4.hwnd, FALSE );
			n_win64_refresh( button_5.hwnd, FALSE );
			n_win64_refresh( button_6.hwnd, FALSE );

			n_txtbox_color_scheme( &txtbox );
			n_txtbox_color_scheme( &search );

			n_txtbox_redraw( &txtbox );
			n_txtbox_redraw( &search );

			n_win64_refresh( config_groupbox.hwnd, FALSE );

			n_txtbox_color_scheme( &config_charset );
			n_txtbox_color_scheme( &config_newline );

			n_txtbox_redraw( &config_charset );
			n_txtbox_redraw( &config_newline );
		}


	break;

	case WM_ERASEBKGND :

		return 1;

	break;

	case WM_PAINT :
	{

		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		n_catpad_toolband_draw( hwnd, ps.hdc, config_onoff );


		n_win64_ui_button_draw( &button_0, TRUE );
		n_win64_ui_button_draw( &button_1, TRUE );
		n_win64_ui_button_draw( &button_2, TRUE );
		n_win64_ui_button_draw( &button_3, TRUE );
		n_win64_ui_button_draw( &button_4, TRUE );
		n_win64_ui_button_draw( &button_5, TRUE );
		n_win64_ui_button_draw( &button_6, TRUE );

		NonnonTxtboxDraw( &txtbox, TRUE );
		NonnonTxtboxDraw( &search, TRUE );

		n_win64_ui_groupbox_draw( &config_groupbox, TRUE );

		NonnonTxtboxDraw( &config_charset, TRUE );
		NonnonTxtboxDraw( &config_newline, TRUE );


		n_win64_doublebuffer_exit( &button_0.db );
		n_win64_doublebuffer_exit( &button_1.db );
		n_win64_doublebuffer_exit( &button_2.db );
		n_win64_doublebuffer_exit( &button_3.db );
		n_win64_doublebuffer_exit( &button_4.db );
		n_win64_doublebuffer_exit( &button_5.db );
		n_win64_doublebuffer_exit( &button_6.db );

		n_win64_doublebuffer_exit( &txtbox.db );
		n_win64_doublebuffer_exit( &search.db );

		n_win64_doublebuffer_exit( &config_groupbox.db );

		n_win64_doublebuffer_exit( &config_charset.db );
		n_win64_doublebuffer_exit( &config_newline.db );


		EndPaint( hwnd, &ps );

	}
	break;


	case WM_SIZE :
//n_win64_titlebar_color_get( hwnd );

		n_catpad_pos_size( hwnd );

		n_catpad_resize
		(
			hwnd,
			FALSE,
			&txtbox,
			&search,
			&button_0,
			&button_1,
			&button_2,
			&button_3,
			&button_4,
			&button_5,
			&button_6,
			&config_groupbox,
			&config_charset,
			&config_newline,
			config_onoff
		);

		// [Needed] : when shrink
		n_win64_refresh( txtbox.hwnd, FALSE );
		n_win64_refresh( search.hwnd, FALSE );

	break;

	case WM_GETMINMAXINFO :

		n_win64_ui_window_on_WM_GETMINMAXINFO( hwnd,msg,wParam,lParam, N_CATPAD_DEFAULT_SX, N_CATPAD_DEFAULT_SY );

	break;


	case WM_DROPFILES :

		button_1.gray_onoff = TRUE; n_win64_refresh( button_1.hwnd, FALSE );

		n_string_free( path );
		path = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		n_txt_load( &txt_data, path );

		if ( txt_data.newline == N_TXT_NEWLINE_BINARY )
		{
			n_catpad_ntxt_binary2text( &txt_data );
			n_win64_message_send( hwnd, WM_COMMAND, 0, button_2.hwnd );
		}

		button_2.gray_onoff = txt_data.readonly; n_win64_refresh( button_2.hwnd, FALSE );

		n_catpad_config( &txt_data, &config_charset, &config_newline, TRUE );

		n_txtbox_reset( &txtbox );

		n_txtbox_redraw( &txtbox );

		n_txtbox_redraw( &config_charset );
		n_txtbox_redraw( &config_newline );

		n_catpad_title( hwnd, path, &txt_data );

	break;


	case WM_SETFOCUS :

		SetFocus( txtbox.hwnd );

	break;


	case WM_KEYDOWN :

		if ( wParam == VK_F2 )
		{
			// [!] : Test Only
/*
			LOGFONT lf_o;

			HFONT hfont = n_catpad_fontchooser( hwnd, txtbox.font, &lf_o );

			n_string_copy( lf_o.lfFaceName, n_font_name );
			n_font_size = lf_o.lfHeight;

			n_txtbox_font_change( &txtbox, hfont, hfont );

			txtbox.is_monospace = FALSE;

			n_txtbox_reset( &txtbox );
*/
		}

	break;

	case WM_COMMAND :

		if ( (HWND) lParam == button_0.hwnd )
		{
			static BOOL topmost = FALSE;

			if ( topmost ) { topmost = FALSE; } else { topmost = TRUE; }

			button_0.fake_onoff = topmost;
			n_win64_refresh( button_0.hwnd, FALSE );

			n_win64_topmost( hwnd, topmost );
		} else
		if ( (HWND) lParam == button_1.hwnd )
		{
			if ( button_1.gray_onoff ) { break; }

			if ( FALSE == n_txt_save( &txt_data, path ) )
			{
				n_game_sound_loop( &sound_meow );

				txtbox.edited = FALSE;

				n_button_setup_literal( &button_1, "N_NEKO_3" );
				button_1.gray_onoff = TRUE; n_win64_refresh( button_1.hwnd, FALSE );
			}
		} else
		if ( (HWND) lParam == button_2.hwnd )
		{
			if ( button_2.gray_onoff ) { break; }

			if ( config_onoff )
			{
				config_onoff = FALSE;

				BOOL ret = n_catpad_config( &txt_data, &config_charset, &config_newline, FALSE );
				if ( ret )
				{
					n_button_setup_literal( &button_1, "N_NEKO_1" );
					button_1.gray_onoff = FALSE; n_win64_refresh( button_1.hwnd, FALSE );
				}

				ShowWindow( txtbox.hwnd, SW_NORMAL );

				ShowWindow( config_charset.hwnd, SW_HIDE );
				ShowWindow( config_newline.hwnd, SW_HIDE );
			} else {
				config_onoff = TRUE;

				ShowWindow( txtbox.hwnd, SW_HIDE );

				ShowWindow( config_charset.hwnd, SW_NORMAL );
				ShowWindow( config_newline.hwnd, SW_NORMAL );
			}

			button_2.fake_onoff = config_onoff; n_win64_refresh( button_2.hwnd, FALSE );

			n_catpad_resize
			(
				hwnd,
				FALSE,
				&txtbox,
				&search,
				&button_0,
				&button_1,
				&button_2,
				&button_3,
				&button_4,
				&button_5,
				&button_6,
				&config_groupbox,
				&config_charset,
				&config_newline,
				config_onoff
			);
		} else
		if ( (HWND) lParam == button_3.hwnd )
		{
			LOGFONT lf_o;

			HFONT hfont = n_catpad_fontchooser( hwnd, txtbox.font, &lf_o );

			n_string_copy( lf_o.lfFaceName, n_font_name );
			n_font_size = lf_o.lfHeight;

			n_txtbox_font_change( &txtbox, hfont, hfont );

			txtbox.is_monospace = FALSE;

			n_txtbox_reset( &txtbox );

			return TRUE;
		} else
		if ( (HWND) lParam == button_4.hwnd )
		{
			n_win64_exec_literal( "calc.exe", SW_NORMAL );
		} else
		if ( (HWND) lParam == button_5.hwnd )
		{
			if ( button_5.gray_onoff ) { break; }

			static BOOL onoff = FALSE;

			if ( onoff )
			{
				onoff = FALSE;
			} else {
				onoff = TRUE;
			}

			n_button_setup_literal( &button_1, "N_NEKO_3" );
			button_1.gray_onoff =  TRUE; n_win64_refresh( button_1.hwnd, FALSE );
			button_2.gray_onoff = onoff; n_win64_refresh( button_2.hwnd, FALSE );
			button_6.gray_onoff = onoff; n_win64_refresh( button_6.hwnd, FALSE );

			button_5.fake_onoff = onoff; n_win64_refresh( button_5.hwnd, FALSE );

			if ( onoff )
			{
				n_catpad_ntxt_dump( &txt_data, path );
				txt_data.readonly = TRUE;
			} else {
				n_txt_load( &txt_data, path );
			}

			n_txtbox_redraw( &txtbox );
		} else
		if ( (HWND) lParam == button_6.hwnd )
		{
			if ( button_6.gray_onoff ) { break; }

			static BOOL onoff = FALSE;

			if ( onoff )
			{
				onoff = FALSE;
			} else {
				onoff = TRUE;
			}

			n_button_setup_literal( &button_1, "N_NEKO_3" );
			button_1.gray_onoff =  TRUE; n_win64_refresh( button_1.hwnd, FALSE );
			button_2.gray_onoff = onoff; n_win64_refresh( button_2.hwnd, FALSE );
			button_5.gray_onoff = onoff; n_win64_refresh( button_5.hwnd, FALSE );

			button_6.fake_onoff = onoff; n_win64_refresh( button_6.hwnd, FALSE );

			if ( onoff )
			{
				n_catpad_txt2html( &txt_data );
				txt_data.readonly = TRUE;
			} else {
				n_txt_load( &txt_data, path );
			}

			n_txtbox_redraw( &txtbox );
		} else
		if ( (HWND) lParam == txtbox.hwnd )
		{
//n_win64_hwndprintf_literal( hwnd, "%d", wParam );

			if ( wParam == N_MAC_TXTBOX_DELEGATE_EDITED )
			{
				n_button_setup_literal( &button_1, "N_NEKO_1" );
				button_1.gray_onoff = FALSE; n_win64_refresh( button_1.hwnd, FALSE );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_F3 )
			{
				n_posix_char *query = n_txt_get( search.txt_data, 0 );
				NonnonTxtboxSearch( &txtbox, query, n_win64_is_input( VK_SHIFT ) );
				n_catpad_sync_send( hwnd, query );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_FIND_FOCUS )
			{
				NonnonTxtboxTripleClickDetect( &search );
				SetFocus( search.hwnd );
			}
		} else
		if ( (HWND) lParam == search.hwnd )
		{
			if ( wParam == N_MAC_TXTBOX_DELEGATE_F3 )
			{
				n_posix_char *query = n_txt_get( search.txt_data, 0 );
				NonnonTxtboxSearch( &txtbox, query, n_win64_is_input( VK_SHIFT ) );
				n_catpad_sync_send( hwnd, query );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_FIND_FOCUS )
			{
				SetFocus( txtbox.hwnd );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT )
			{
				n_posix_char *query = n_txt_get( search.txt_data, 0 );
				NonnonTxtboxSearch( &txtbox, query, n_win64_is_input( VK_SHIFT ) );
				n_catpad_sync_send( hwnd, query );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT )
			{
				n_posix_char *query = n_txt_get( search.txt_data, 0 );
				NonnonTxtboxSearch( &txtbox, query, TRUE );
				n_catpad_sync_send( hwnd, query );
			}
		}

	break;


	case WM_CLOSE :

		n_string_free( path );

		n_win64_ui_button_exit( &button_0 );
		n_win64_ui_button_exit( &button_1 );
		n_win64_ui_button_exit( &button_2 );
		n_win64_ui_button_exit( &button_3 );
		n_win64_ui_button_exit( &button_4 );
		n_win64_ui_button_exit( &button_5 );
		n_win64_ui_button_exit( &button_6 );

		n_catpad_pos_size( hwnd );
		n_posix_snprintf_literal( n_query, 1024, "%s", n_txt_get( search.txt_data, 0 ) );
		n_catpad_settings( FALSE );

		n_txtbox_exit( &txtbox );
		n_txtbox_exit( &search );

		n_win64_ui_groupbox_exit( &config_groupbox );

		n_txtbox_exit( &config_charset );
		n_txtbox_exit( &config_newline );

		n_game_sound_exit( &sound_meow );

		n_wav_free( &wav );
		n_directsound_exit( &directsound );

		n_catpad_sync_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_catpad_sync_proc( hwnd, msg, wParam, lParam, &search, search.txt_data );


	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_0 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_1 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_2 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_3 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_4 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_5 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_6 );

	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &txtbox );
	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &search );

	n_win64_ui_groupbox_proc( hwnd, msg, wParam, lParam, &config_groupbox );

	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &config_charset );
	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &config_newline );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_catpad_wndproc );
}


