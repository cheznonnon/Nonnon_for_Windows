// Nonnon Project Checker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




BOOL
n_pc_is_file( const n_posix_char *f, const n_posix_char *t )
{

	if (
		( N_POSIX_STAT_TYPE_FILE == n_posix_stat_type( f ) )
		&&
		( N_POSIX_STAT_TYPE_FILE == n_posix_stat_type( t ) )
	)
	{
		return TRUE;
	}


	return FALSE;
}

BOOL
n_pc_is_folder( const n_posix_char *f, const n_posix_char *t )
{

	if (
		( N_POSIX_STAT_TYPE_DIRECTORY == n_posix_stat_type( f ) )
		&&
		( N_POSIX_STAT_TYPE_DIRECTORY == n_posix_stat_type( t ) )
	)
	{
		return TRUE;
	}


	return FALSE;
}

void
n_pc_go_file( n_txt *txt, const n_posix_char *f, const n_posix_char *t )
{

	if ( n_filer_is_same( f, t ) )
	{
		n_txt_mod( txt, 0, n_posix_literal(      "Same Binary" ) );
		return;
	} else {
		n_txt_mod( txt, 0, n_posix_literal( "Different Binary" ) );
	}


	n_type_int diff_line = -1;


	n_posix_bool ret = n_posix_false;

	n_txt txt_f; n_txt_zero( &txt_f ); ret |= n_txt_load( &txt_f, f );
	n_txt txt_t; n_txt_zero( &txt_t ); ret |= n_txt_load( &txt_t, t );

	if ( ret )
	{
		n_txt_free( &txt_f );
		n_txt_free( &txt_t );

		return;
	}

	if (
		( txt_f.newline == N_TXT_NEWLINE_BINARY )
		||
		( txt_t.newline == N_TXT_NEWLINE_BINARY )
	)
	{
		n_txt_free( &txt_f );
		n_txt_free( &txt_t );

		return;
	}

	n_type_int i = 0;
	n_posix_loop
	{
		if ( ( i >= txt_f.sy )&&( i >= txt_t.sy ) ) { break; }

		if ( i >= txt_f.sy ) { diff_line = i; break; }
		if ( i >= txt_t.sy ) { diff_line = i; break; }

		if ( n_string_is_same( n_txt_get( &txt_f, i ), n_txt_get( &txt_t, i ) ) )
		{
			//
		} else {
			diff_line = i;
			break;
		}

		i++;
	}


	if ( diff_line != -1 )
	{
		n_posix_char str_line[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line, 1 + diff_line );

		n_posix_char str[ 100 ];
		n_posix_snprintf_literal( str, 100, "Line #%s", str_line );

		n_txt_mod( txt, 1, str );
	}

	n_txt_free( &txt_f );
	n_txt_free( &txt_t );


	return;
}

// internal
void
n_pc_go_throbber( n_txtbox *txtbox, int phase )
{
//return;

	int           cch = 7;
	n_posix_char *str = n_string_alloccopy( cch + 3, n_posix_literal( "Working" ) );

	int i = 0;
	n_posix_loop
	{

		if ( i >= phase ) { break; }

		cch += n_posix_snprintf_literal( &str[ cch ], 7 + 3 + 1 - cch, "%s", N_STRING_DOT );

		i++;

	}

	n_txt_mod_fast( txtbox->txt_data, 0, str );
	n_win64_message_send( txtbox->hwnd, WM_PAINT, 0,0 );


	return;
}

// internal
n_type_int
n_pc_go_folder_count( n_txtbox *txtbox, const n_posix_char *folder, BOOL is_first )
{

	const  u32        msec  = 250;

	static n_type_int count = 0;
	static u32        timer = 0;
	static int        phase = 0;

	if ( is_first )
	{
		count = 0;
		timer = n_posix_tickcount() + msec;
		phase = 0;
		n_pc_go_throbber( txtbox, phase );
	}


	n_posix_DIR *dp = n_posix_opendir_nodot( folder );
	if ( dp == NULL ) { return 0; }


	n_posix_char *curdir = n_string_path_folder_current_new();
	n_string_path_folder_change_fast( folder );


	n_posix_loop
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		if ( FILE_ATTRIBUTE_DIRECTORY & dirent->dwFileAttributes )
		{
			n_pc_go_folder_count( txtbox, dirent->d_name, FALSE );
		}


		if ( timer < n_posix_tickcount() )
		{

			timer = n_posix_tickcount() + msec;

			phase++;
			if ( phase >= 4 ) { phase = 0; }

			n_pc_go_throbber( txtbox, phase );

		}


		count++;

#ifdef N_PC_DEBUG_SLOW
		n_posix_sleep( 1000 );
#endif // #ifdef N_PC_DEBUG_SLOW

	}


	n_string_path_folder_change_fast( curdir );
	n_string_path_free( curdir );


	n_posix_closedir( dp );


	return count;
}

void
n_pc_go_folder( n_txtbox *txtbox, const n_posix_char *f, const n_posix_char *t, BOOL complete_onoff, BOOL is_first )
{

	if ( n_string_is_same( f, t ) ) { return; }


	n_dir d; n_dir_zero( & d );
	if ( n_dir_load( &d, t ) ) { return; }

	if ( 0 >= n_dir_all( &d ) ) { n_dir_free( &d ); return; }


	n_dir_sort_path( &d );


	static n_posix_char *toplevel;
	static n_txt         txt;
	static n_type_real   step;
	static n_type_real   percent_prv;
	static n_type_real   percent_cur;

	if ( is_first )
	{
		toplevel = n_string_path_carboncopy( f );

		n_txt_zero( &txt ); n_txt_new( &txt );

		n_type_int count = n_pc_go_folder_count( txtbox, t, TRUE );

		step        = (n_type_real) 100 / count;
		percent_prv = -1;
		percent_cur =  0;
	}


	const n_type_int slash = n_posix_strlen( N_POSIX_SLASH );
	const n_type_int f_cch = n_posix_strlen( f ) + slash;
	const n_type_int t_cch = n_posix_strlen( t ) + slash;

	n_posix_structstat f_stat;
	n_posix_structstat t_stat;

	n_type_int i = 0;
	n_posix_loop
	{

		if ( i >= n_dir_all( &d ) ) { break; }


		n_type_int cch_name = n_posix_strlen( n_dir_name( &d, i ) );

		n_posix_char *f_name = n_string_path_new( f_cch + cch_name );
		n_posix_char *t_name = n_string_path_new( t_cch + cch_name );

		n_string_path_make( f, n_dir_name( &d, i ), f_name, f_cch + cch_name );
		n_string_path_make( t, n_dir_name( &d, i ), t_name, t_cch + cch_name );


		BOOL is_plus = FALSE;


		BOOL f_is_exist = ( 0 == n_posix_stat( f_name, &f_stat ) );
		BOOL t_is_exist = ( 0 == n_posix_stat( t_name, &t_stat ) );

		if ( ( t_is_exist )&&( FALSE == f_is_exist ) )
		{

			is_plus = TRUE;

			n_posix_char *str = n_string_path_cat( n_posix_literal( "+ : " ), t_name, NULL );

			n_txt_set( &txt, txt.sy, str );

			n_string_path_free( str );

		} else
		if (
			( t_is_exist )
			&&
			( FALSE == S_ISDIR( f_stat.st_mode ) )
			&&
			( FALSE == S_ISDIR( t_stat.st_mode ) )
		)
		{

			// [!] : modified time is different

			if ( ( complete_onoff )&&( FALSE == n_filer_is_same( f_name, t_name ) ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "? : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			} else
			if ( n_time_compare_mtime( f_name, t_name ) )
			{

				n_posix_char *str = n_string_path_cat( n_posix_literal( "! : " ), t_name, NULL );

				n_txt_set( &txt, txt.sy, str );

				n_string_path_free( str );

			}

		}


		if ( ( is_plus == FALSE )&&( S_ISDIR( f_stat.st_mode ) ) )
		{
			n_pc_go_folder( txtbox, f_name, t_name, complete_onoff, FALSE );
		}


		n_string_path_free( f_name );
		n_string_path_free( t_name );


		percent_cur += step;
		if ( trunc( percent_prv ) != trunc( percent_cur ) )
		{
			n_posix_char str[ 100 ];
			n_posix_snprintf_literal( str, 100, "Working (%d%%)", (int) trunc( percent_cur ) );
			n_txt_mod( txtbox->txt_data, 0, str );
			n_win64_message_send( txtbox->hwnd, WM_PAINT, 0,0 );
		}
		percent_prv = percent_cur;

		i++;

#ifdef N_PC_DEBUG_SLOW
		n_posix_sleep( 100 );
#endif // #ifdef N_PC_DEBUG_SLOW

	}

	n_dir_free( &d );


	if ( n_string_is_same( f, toplevel ) )
	{
		n_string_path_free( toplevel );

		n_txt_copy( &txt, txtbox->txt_data );
		n_txt_free( &txt );
	}


	return;
}

// internal
void
n_pc_sort( n_txt *txt )
{
//return;

	if ( txt->sy <= 1 ) { return; }


	n_type_int count_question    = 0;
	n_type_int count_exclamation = 0;
	n_type_int count_plus        = 0;

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *f = txt->line[ i ];

			if ( f[ 0 ] == n_posix_literal( '?' ) )
			{
				count_question++;
			} else
			if ( f[ 0 ] == n_posix_literal( '!' ) )
			{
				count_exclamation++;
			} else
			if ( f[ 0 ] == n_posix_literal( '+' ) )
			{
				count_plus++;
			}// else

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}


	n_type_int index_question    = 0;
	n_type_int index_exclamation = count_question;
	n_type_int index_plus        = count_question + count_exclamation;


	n_txt txt_t; n_txt_zero( &txt_t ); n_txt_new( &txt_t );

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '?' ) )
			{
				n_txt_set( &txt_t, index_question, s ); index_question++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '!' ) )
			{
				n_txt_set( &txt_t, index_exclamation, s ); index_exclamation++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	{

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char *s = txt->line[ i ];
			if ( s[ 0 ] == n_posix_literal( '+' ) )
			{
				n_txt_set( &txt_t, index_plus, s ); index_plus++;
			}

			i++;
			if ( i >= txt->sy ) { break; }
		}

	}

	n_txt_free( txt );
	n_txt_alias( &txt_t, txt );


	return;
}


