
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Project Checker"
set   debug=-DDEBUG

%compile%

