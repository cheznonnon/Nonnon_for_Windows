// Nonnon Project Checker
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/string_path.c"
#include "../nonnon/neutral/time.c"
#include "../nonnon/neutral/txt.c"

#include "../nonnon/win64/_windows.c"
#include "../nonnon/win64/resource.c"

#include "../nonnon/win64/ui/button.c"
#include "../nonnon/win64/ui/filer.c"
#include "../nonnon/win64/ui/menu.c"
#include "../nonnon/win64/ui/radio.c"
#include "../nonnon/win64/ui/txtbox.c"
#include "../nonnon/win64/ui/window.c"


#include "engine.c"




#define N_APPNAME "Nonnon Project Checker"


#define N_DEFAULT_SX ( 444 )
#define N_DEFAULT_SY ( 333 )




typedef struct {

	n_win64_ui_radio  radio_f;
	n_win64_ui_radio  radio_t;

	n_txtbox          label_f;
	n_txt             label_txt_f;

	n_txtbox          label_t;
	n_txt             label_txt_t;

	n_win64_ui_button button_rev;
	n_win64_ui_button button_go;

	n_txtbox          txtbox;
	n_txt             txtbox_data;

	BOOL              complete_onoff;

	UINT              timer_id;

} n_projectchecker;


static n_projectchecker pc;




// internal
void
n_pc_resize( HWND hwnd )
{

	const BOOL redraw = TRUE;


	const n_type_gfx m   = 4;
	const n_type_gfx pad = 8;
	      n_type_gfx ctl = n_win64_ui_stdsize( hwnd );
	const n_type_gfx ico = 40;

	n_type_gfx csx = N_DEFAULT_SX;
	n_type_gfx csy = N_DEFAULT_SY;

	static BOOL is_init = TRUE;
	if ( is_init )
	{
		//
	} else {
		RECT client; GetClientRect( hwnd, &client );

		csx = client.right;
		csy = client.bottom;
	}

	n_type_gfx csx_in = csx - ( pad * 2 );
	n_type_gfx csy_in = csy - ( pad * 2 );


	n_type_gfx radio = ctl + ico;
	n_type_gfx label = csx_in - radio - ico - ( m * 2 );
	n_type_gfx rsx   = ico;
	n_type_gfx rsy   = ( ctl * 2 ) - m;
	n_type_gfx list  = csy_in - ( ctl * 3 ) - ( m * 2 );

	n_type_gfx x = pad;
	n_type_gfx y = pad;

	n_type_gfx q  = m;
	n_type_gfx qq = q;

	MoveWindow            (  pc.radio_f.hwnd,                x,           y,   radio,    ctl, redraw );
	MoveWindow            (  pc.radio_t.hwnd,                x,       ctl+y,   radio,    ctl, redraw );
	MoveWindow            (  pc.label_f.hwnd,          radio+x,          +y,   label,    ctl, redraw );
	MoveWindow            (  pc.label_t.hwnd,          radio+x,       ctl+y,   label,    ctl, redraw );
	n_win64_ui_button_move( &pc.button_rev  , csx_in-ico-1+x-q,       m+y-q,  rsx+qq, rsy+qq, redraw );
	MoveWindow            (  pc.txtbox .hwnd,              1+x,   2*ctl+m+y,csx_in-2,   list, redraw );
	n_win64_ui_button_move( &pc.button_go   ,                x,csy_in-ctl+y,csx_in  ,    ctl, redraw );


	if ( is_init )
	{
		n_win64_ui_window_set( hwnd, 0, 0, csx, csy, TRUE );
	} else {
		//UINT swp = SWP_NOACTIVATE | SWP_DRAWFRAME | SWP_NOMOVE | SWO_NOSIZE;

		//SetWindowPos( hwnd, NULL, 0,0, 0,0, swp );
	}

	is_init = FALSE;


	return;
}

LRESULT CALLBACK
n_pc_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	switch( msg ) {


	case WM_CREATE :


		// Global

		n_bmp_safemode = n_bmp_safemode_base = FALSE;

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );


		n_memory_zero( &pc, sizeof( n_projectchecker ) );


		// Window

		n_win64_ui_window_init_literal( hwnd, N_APPNAME, "MAIN_ICON", "" );

		n_win64_style_add( hwnd, WS_OVERLAPPEDWINDOW );

		n_win64_ui_radio_init( &pc.radio_f, hwnd ); pc.radio_f.label = n_posix_literal( "From" );
		n_win64_ui_radio_init( &pc.radio_t, hwnd ); pc.radio_t.label = n_posix_literal( "To" );

		pc.radio_f.is_checked = TRUE;


		n_txt_zero( &pc.label_txt_f ); n_txt_new( &pc.label_txt_f );
		pc.label_txt_f.readonly = TRUE;

		n_txtbox_init( &pc.label_f, hwnd, &pc.label_txt_f );

		pc.label_f.mode                = N_MAC_TXTBOX_MODE_ONELINE;
		pc.label_f.path_ellipsis_onoff = TRUE;

		n_txtbox_reset( &pc.label_f );


		n_txt_zero( &pc.label_txt_t ); n_txt_new( &pc.label_txt_t );
		pc.label_txt_t.readonly = TRUE;

		n_txtbox_init( &pc.label_t, hwnd, &pc.label_txt_t );

		pc.label_t.mode                = N_MAC_TXTBOX_MODE_ONELINE;
		pc.label_t.path_ellipsis_onoff = TRUE;

		n_txtbox_reset( &pc.label_t );


		n_win64_ui_button_init( &pc.button_rev, hwnd );

		pc.button_rev.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

		pc.button_rev.resource_name = n_posix_literal( "N_REVERSE" );


		n_txt_zero( &pc.txtbox_data ); n_txt_new( &pc.txtbox_data );
		n_txt_mod( &pc.txtbox_data, 0, n_posix_literal( "Drop Here" ) );

		n_txtbox_init( &pc.txtbox, hwnd, &pc.txtbox_data );

		pc.txtbox.listbox_no_edit            = TRUE;
		pc.txtbox.mode                       = N_MAC_TXTBOX_MODE_LISTBOX;
		pc.txtbox.option_linenumber          = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;
		pc.txtbox.path_ellipsis_onoff        = TRUE;
		pc.txtbox.path_ellipsis_offset       = 4;
		pc.txtbox.listbox_no_selection_onoff = TRUE;

		n_txtbox_reset( &pc.txtbox );


		n_win64_ui_button_init( &pc.button_go, hwnd );

		pc.button_go.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		pc.button_go.label = n_posix_literal( "Go!" );


		// Display

		n_pc_resize( hwnd );

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;

	case WM_PAINT :

		n_win64_ui_radio_draw( &pc.radio_f, TRUE );
		n_win64_ui_radio_draw( &pc.radio_t, TRUE );

		NonnonTxtboxDraw( &pc.label_f, TRUE );
		NonnonTxtboxDraw( &pc.label_t, TRUE );

		NonnonTxtboxDraw( &pc.txtbox, TRUE );

		n_win64_ui_button_draw( &pc.button_rev, TRUE );
		n_win64_ui_button_draw( &pc.button_go , TRUE );


		n_win64_doublebuffer_exit( &pc.radio_f.db );
		n_win64_doublebuffer_exit( &pc.radio_t.db );

		n_win64_doublebuffer_exit( &pc.label_f.db );
		n_win64_doublebuffer_exit( &pc.label_t.db );

		n_win64_doublebuffer_exit( &pc.txtbox.db );

		n_win64_doublebuffer_exit( &pc.button_rev.db );
		n_win64_doublebuffer_exit( &pc.button_go .db );

	break;

	case WM_SIZE :

		n_pc_resize( hwnd );

		n_txtbox_redraw( &pc.label_f );
		n_txtbox_redraw( &pc.label_t );

		n_txtbox_redraw( &pc.txtbox );

	break;

	case WM_SETFOCUS :

		SetFocus( pc.txtbox.hwnd );

	break;

	case WM_DROPFILES :
	{

		n_posix_char *cmdline = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		if ( pc.radio_f.is_checked )
		{

			pc.radio_t.is_checked =  TRUE; n_win64_refresh( pc.radio_t.hwnd, FALSE );
			pc.radio_f.is_checked = FALSE; n_win64_refresh( pc.radio_f.hwnd, FALSE );

			n_txt_mod( &pc.label_txt_f, 0, cmdline );

			n_win64_refresh( pc.label_f.hwnd, FALSE );
			n_win64_refresh( pc.label_t.hwnd, FALSE );

		} else {

			pc.radio_t.is_checked = FALSE; n_win64_refresh( pc.radio_t.hwnd, FALSE );
			pc.radio_f.is_checked =  TRUE; n_win64_refresh( pc.radio_f.hwnd, FALSE );

			n_txt_mod( &pc.label_txt_t, 0, cmdline );

			n_win64_refresh( pc.label_f.hwnd, FALSE );
			n_win64_refresh( pc.label_t.hwnd, FALSE );

		}

		n_string_path_free( cmdline );

	}
	break;

	case WM_COMMAND :
	{
//break;

		HWND h = (HWND) lParam;

		if ( h == pc.txtbox.hwnd )
		{

			n_posix_char *item = n_string_path_carboncopy( n_txt_get( &pc.txtbox_data, pc.txtbox.focus ) );
//n_posix_debug( item ); n_string_path_free( item ); break;

			n_posix_char *f = n_string_path_carboncopy( n_txt_get( &pc.label_txt_f, 0 ) );
			n_posix_char *t = n_string_path_carboncopy( n_txt_get( &pc.label_txt_t, 0 ) );


			BOOL is_plus = FALSE;

			if (
				( item[ 0 ] == n_posix_literal( '!' ) )
				||
				( item[ 0 ] == n_posix_literal( '?' ) )
			)
			{
				is_plus = FALSE;
			} else
			if ( item[ 0 ] == n_posix_literal( '+' ) )
			{
				is_plus = TRUE;
			} else {

				n_string_path_free( item );

				n_string_path_free( f );
				n_string_path_free( t );

				break;
			}


			// [!] : don't use n_string_path_name()
			//
			//	this will be relative path

			n_posix_char *name = n_string_path_carboncopy( item );

			n_string_copy( &item[ 4 ], item );
			n_string_copy( &item[ n_posix_strlen( t ) ], name );


			n_posix_char *f2 = n_string_path_cat( f, name, NULL );
			n_posix_char *t2 = n_string_path_cat( t, name, NULL );

			n_string_path_free( f ); f = f2;
			n_string_path_free( t ); t = t2;

			if ( pc.txtbox.click_count >= 2 )
			{
//n_posix_debug_literal( "%s\n%s", f, t ); break;
//n_posix_debug_literal( "%d %d", n_posix_stat_is_exist( f ), n_posix_stat_is_exist( t ) );

				if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT )
				{
					BOOL is_cancelled = FALSE;
					BOOL is_break     = FALSE;

					if ( is_plus )
					{

						if ( n_win64_is_input( VK_CONTROL ) )
						{
							if ( n_win64_filer_delete ( hwnd, t, &is_cancelled ) ) { is_break = TRUE; }
						} else {
							n_win64_explorer_recyclebin( hwnd, t );
						}

					} else {

						if ( n_win64_filer_replace( hwnd, f, t, &is_cancelled ) ) { is_break = TRUE; }

					}


					if ( is_break )
					{
						n_string_path_free( f );
						n_string_path_free( t );
						break;
					}

					// [!] : succeeded

					if ( is_cancelled ) { break; }

					n_txt_del( &pc.txtbox_data, pc.txtbox.focus );

					n_win64_refresh( pc.txtbox.hwnd, FALSE );

				} else
				if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT )
				{
					// [!] : move to an upper folder when not exist

					n_posix_loop
					{

						if ( n_posix_stat_is_exist( f ) ) { break; }

						n_posix_char *f2 = n_string_path_upperfolder_new( f );
						n_string_path_free( f ); f = f2;

						if ( n_string_is_same( f, item ) ) { break; }

					}

					n_win64_explorer_open( f, SW_NORMAL );
					n_win64_explorer_open( t, SW_NORMAL );

					n_string_path_free( f );
					n_string_path_free( t );
				}

				if (
					( pc.txtbox.txt_data->sy == 1 )
					&&
					( n_string_is_empty( n_txt_get( pc.txtbox.txt_data, 0 ) ) )
				)
				{
					n_txtbox_caret_reset( &pc.txtbox );
				}
			}

		} else
		if ( h == pc.button_rev.hwnd )
		{

			n_posix_char *f = n_string_path_carboncopy( n_txt_get( &pc.label_txt_f, 0 ) );
			n_posix_char *t = n_string_path_carboncopy( n_txt_get( &pc.label_txt_t, 0 ) );

			n_txt_mod( &pc.label_txt_f, 0, t );
			n_txt_mod( &pc.label_txt_t, 0, f );

			n_txtbox_caret_tail_set( &pc.label_f );
			n_txtbox_caret_tail_set( &pc.label_t );

			n_win64_refresh( pc.label_f.hwnd, FALSE );
			n_win64_refresh( pc.label_t.hwnd, FALSE );

			n_string_path_free( f );
			n_string_path_free( t );

		} else
		if ( h == pc.radio_f.hwnd )
		{
//n_posix_debug_literal( " ! " );

			if ( pc.radio_f.is_checked == FALSE )
			{
				pc.radio_f.is_checked =  TRUE; n_win64_refresh( pc.radio_f.hwnd, FALSE );
				pc.radio_t.is_checked = FALSE; n_win64_refresh( pc.radio_t.hwnd, FALSE );
				
			}

		} else
		if ( h == pc.radio_t.hwnd )
		{
//n_posix_debug_literal( " ! " );

			if ( pc.radio_t.is_checked == FALSE )
			{
				pc.radio_f.is_checked = FALSE; n_win64_refresh( pc.radio_f.hwnd, FALSE );
				pc.radio_t.is_checked =  TRUE; n_win64_refresh( pc.radio_t.hwnd, FALSE );
				
			}

		} else
		if ( h == pc.button_go.hwnd )
		{

			n_txt_free( &pc.txtbox_data );
			n_txt_new ( &pc.txtbox_data );

			n_txtbox_caret_reset( &pc.txtbox );


			n_posix_char *f = n_string_path_carboncopy( n_txt_get( &pc.label_txt_f, 0 ) );
			n_posix_char *t = n_string_path_carboncopy( n_txt_get( &pc.label_txt_t, 0 ) );

			SetCursor( LoadCursor( NULL, IDC_WAIT ) );

			if ( n_pc_is_file( f, t ) )
			{

				n_pc_go_file( &pc.txtbox_data, f,t );

			} else
			if ( n_pc_is_folder( f, t ) )
			{

				n_pc_go_folder( &pc.txtbox, f,t, pc.complete_onoff, TRUE );
				n_pc_sort( &pc.txtbox_data );

			} else {

				n_txt_mod( &pc.txtbox_data, 0, n_posix_literal( "Please Check" ) );

			}

			SetCursor( LoadCursor( NULL, IDC_ARROW ) );

			n_string_path_free( f );
			n_string_path_free( t );


			n_win64_refresh( pc.txtbox.hwnd, FALSE );
		}
	}
	break;


	case WM_GETMINMAXINFO :

		n_win64_ui_window_on_WM_GETMINMAXINFO( hwnd,msg,wParam,lParam, N_DEFAULT_SX, N_DEFAULT_SY );

	break;



	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_win64_ui_radio_exit( &pc.radio_f );
		n_win64_ui_radio_exit( &pc.radio_t );

		n_txtbox_exit( &pc.label_f );
		n_txtbox_exit( &pc.label_t );

		n_txtbox_exit( &pc.txtbox );

		n_win64_ui_button_exit( &pc.button_rev );
		n_win64_ui_button_exit( &pc.button_go  );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch

	{
		static n_win64_ui_menu menu[] = {

			{ N_WIN_MENU_CHECK, FALSE, FALSE, n_posix_literal( "Complete Mode" ), 0 },
			{ N_WIN_MENU_NONE , FALSE, FALSE, n_posix_literal( "---"           ), 0 },
			{ N_WIN_MENU_NONE , FALSE, FALSE, NULL }

		};

		int i = n_win64_ui_menu_system_proc( hwnd, msg, wParam, lParam, menu, 0 );
//if ( i >= 0 ) { n_win64_hwndprintf_literal( hwnd, "%d", i ); }
		if ( i == 0 )
		{
			if ( menu[ 0 ].onoff )
			{
				menu[ 0 ].onoff = FALSE;
			} else {
				menu[ 0 ].onoff = TRUE;
			}
			pc.complete_onoff = menu[ 0 ].onoff;
		}
	}

	n_win64_ui_radio_proc( hwnd, msg, wParam, lParam, &pc.radio_f );
	n_win64_ui_radio_proc( hwnd, msg, wParam, lParam, &pc.radio_t );

	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &pc.label_f );
	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &pc.label_t );

	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &pc.button_rev );

	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &pc.txtbox );

	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &pc.button_go );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_pc_wndproc );
}

