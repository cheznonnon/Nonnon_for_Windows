
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Nonnon Marie"
set   debug=-DDEBUG

%compile%

