// Nonnon Marie for Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/win64/resource.c"

#include "../nonnon/neutral/png.c"

#include "../nonnon/bridge/gdi.c"

#include "../nonnon/win64/ui/window.c"

#include "../nonnon/win64/doublebuffer.c"

#include "../nonnon/win64/wic.c"


// [!] : bridge

#define CGFloat    n_type_real

#define NSRect     RECT
#define NSMakeRect n_win64_rect_set

#define n_bmp_argb_mac n_bmp_argb



	
#define N_MARIE_APPNAME "Marie"
#define N_MARIE_ICONAME "MAIN_ICON"




BOOL
n_marie_save_png( n_bmp *bmp, n_posix_char *path )
{

	BOOL ret = TRUE;


	n_bmp tmp; n_bmp_carboncopy( bmp, &tmp );


	n_png png = n_png_template;

	ret  = n_png_compress( &png, &tmp );
	ret += n_png_save( &png, path );

	n_png_free( &png );


	n_bmp_free_fast( &tmp );


	return ret;
}




#define N_MARIE_ROTATE_U ( 0 )
#define N_MARIE_ROTATE_L ( 1 )
#define N_MARIE_ROTATE_D ( 2 )
#define N_MARIE_ROTATE_R ( 3 )



static n_posix_char *n_path = NULL;
static n_bmp         n_bmp_drop_here;
static n_bmp         n_bmp_file;
static n_bmp         n_bmp_processed;
static n_bmp         n_bmp_clip;
static BOOL          n_error;
static BOOL          n_resample_onoff;
static int           n_rotate;
//static POINT         pt;
static CGFloat       n_ox;
static CGFloat       n_oy;
static BOOL          n_scrollbar_draw_stop;




BOOL
n_marie_load( void )
{

	if ( n_posix_stat_is_dir( n_path ) )
	{
		n_error = TRUE;
		return n_error;
	}

	if (
		( n_bmp_load( &n_bmp_file, n_path ) )
		&&
		( n_win64_wic_load( n_path, &n_bmp_file ) )
	)
	{
		n_error = TRUE;
	} else {
		n_error = FALSE;
	}


	return n_error;
}

void
n_marie_prepare_bitmap( HWND hwnd )
{

	const n_type_gfx min_size  = 256;


//NSLog( @"%d", n_error );
	n_bmp_free( &n_bmp_processed );
	if ( n_error )
	{
		n_bmp_carboncopy( &n_bmp_drop_here, &n_bmp_processed );
	} else {
		n_bmp_carboncopy( &n_bmp_file     , &n_bmp_processed );
	}

	if ( n_rotate == N_MARIE_ROTATE_U )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_R )
	{
		n_bmp_rotate( &n_bmp_processed, N_BMP_ROTATE_LEFT );
	} else
	if ( n_rotate == N_MARIE_ROTATE_D )
	{
		n_bmp_flush_mirror( &n_bmp_processed, N_BMP_MIRROR_UPSIDE_DOWN );
	} else
	if ( n_rotate == N_MARIE_ROTATE_L )
	{
		n_bmp_rotate( &n_bmp_processed, N_BMP_ROTATE_RIGHT );
	}

	n_type_gfx isx = N_BMP_SX( &n_bmp_processed );
	n_type_gfx isy = N_BMP_SY( &n_bmp_processed );

	n_type_gfx max_sx, max_sy; n_win64_desktop_size( hwnd, &max_sx, &max_sy );

	if ( n_resample_onoff )
	{
		double ratio_x = 1.0;
		double ratio_y = 1.0;

		if ( max_sx < isx )
		{
			ratio_x = (double) max_sx / isx;
		}

		if ( max_sy < isy )
		{
			ratio_y = (double) max_sy / isy;
		}
//n_win64_hwndprintf_literal( hwnd, "%d %d : %d %d", max_sx, isx, max_sy, isy );

		n_type_real ratio = n_posix_min_n_type_real( ratio_x, ratio_y );
//n_win64_hwndprintf_literal( hwnd, "%f", ratio );

		n_bmp_resampler( &n_bmp_processed, ratio, ratio );

	}


	{
		n_type_gfx rsx = n_posix_max_n_type_gfx( min_size, N_BMP_SX( &n_bmp_processed ) );
		n_type_gfx rsy = n_posix_max_n_type_gfx( min_size, N_BMP_SY( &n_bmp_processed ) );

		n_bmp_resizer( &n_bmp_processed, rsx, rsy, n_bmp_black, N_BMP_RESIZER_CENTER );
	}


	n_ox = 0;
	n_oy = 0;

	if ( n_rotate == N_MARIE_ROTATE_U )
	{
//NSLog( @"%d %f", N_BMP_SY( &n_bmp_processed ), max_sy );
		if ( N_BMP_SY( &n_bmp_processed ) > max_sy )
		{
			n_oy = N_BMP_SY( &n_bmp_processed ) - max_sy;
		}
	} else
	if ( n_rotate == N_MARIE_ROTATE_R )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_D )
	{
		//
	} else
	if ( n_rotate == N_MARIE_ROTATE_L )
	{
		//
	}

	n_scrollbar_draw_stop = TRUE;

}

void
n_marie_scrollbar_draw( HWND hwnd )
{

	n_type_gfx img_sx = N_BMP_SX( &n_bmp_processed );
	n_type_gfx img_sy = N_BMP_SY( &n_bmp_processed );

	n_type_gfx max_sx, max_sy; n_win64_desktop_size( hwnd, &max_sx, &max_sy );

	n_type_gfx csx = n_posix_min_n_type_real( max_sx, img_sx );
	n_type_gfx csy = n_posix_min_n_type_real( max_sy, img_sy );

	if ( ( img_sx > max_sx )||( img_sy > max_sy ) )
	{

		n_type_gfx sx = n_posix_min_n_type_gfx( img_sx, max_sx );
		n_type_gfx sy = n_posix_min_n_type_gfx( img_sy, max_sy );

		n_bmp_new( &n_bmp_clip, sx, sy );
		n_bmp_fastcopy( &n_bmp_processed, &n_bmp_clip, n_ox,n_oy,sx,sy, 0,0 );


		// [!] : Fake Scroller
		
		const CGFloat scroller_size = 12;


		{ // [!] : Fake Scroller : Horizontal

		NSRect scroller_x_rect_shaft;
		NSRect scroller_x_rect_thumb;

		CGFloat items_per_canvas = csx;
		CGFloat max_count        = img_sx;
//NSLog( @"%f %f", items_per_canvas, max_count );

		if (
			( n_scrollbar_draw_stop == FALSE )
			&&
			( trunc( items_per_canvas ) < max_count )
		)
		{

			CGFloat shaft = csx - scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsy = scroller_size;
			CGFloat scrsx = n_posix_max_n_type_real( scroller_size, ( items_per_canvas / page ) - scroller_size );
			CGFloat scr_y = csy - scrsy;
			CGFloat scr_x = ( n_ox / max_count ) * items_per_canvas;
//NSLog( @"%f %f", scr_y, n_oy );


			// [!] : for hit test

			scroller_x_rect_shaft = NSMakeRect(     0, scr_y, shaft, scrsy );
			scroller_x_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			// [!] : shaft

			n_bmp bmp_scroll; n_bmp_zero( &bmp_scroll );

			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_x_rect_shaft, &x, &y, &sx, &sy );

				u32 color_shaft = n_bmp_argb_mac( 64, 128,128,128 );

				n_bmp_new_fast( &bmp_scroll, sx,sy );
				n_bmp_flush( &bmp_scroll, n_bmp_white_invisible );

				n_bmp_roundrect( &bmp_scroll, 0,0,sx,sy, color_shaft, 50 );
			}


			// [!] : thumb / knob

			//if(0)
			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_x_rect_thumb, &x, &y, &sx, &sy );

				u32 color_thumb = n_bmp_argb_mac( 192, 128,128,128 );
				n_bmp_roundrect( &bmp_scroll, x,0,sx,sy, color_thumb, 50 );
			}

			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_x_rect_shaft, &x, &y, &sx, &sy );

				n_bmp_transcopy( &bmp_scroll, &n_bmp_clip, 0,0,sx,sy, x,y );
			}

			n_bmp_free_fast( &bmp_scroll );

		}

		} // [!] : Fake Scroller : Horizontal


		{ // [!] : Fake Scroller : Vertical

		NSRect scroller_y_rect_shaft;
		NSRect scroller_y_rect_thumb;

		CGFloat items_per_canvas = csy;
		CGFloat max_count        = img_sy;
//NSLog( @"%f %f", items_per_canvas, max_count );

		if (
			( n_scrollbar_draw_stop == FALSE )
			&&
			( trunc( items_per_canvas ) < max_count )
		)
		{

			CGFloat shaft = csy - scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = scroller_size;
			CGFloat scrsy = n_posix_max_n_type_real( scroller_size, ( items_per_canvas / page ) - scroller_size );
			CGFloat scr_x = csx - scrsx;
			CGFloat scr_y = ( ( ( max_count - items_per_canvas ) - n_oy ) / max_count ) * items_per_canvas;
//NSLog( @"%f %f", scr_y, n_oy );


			// [!] : for hit test

			scroller_y_rect_shaft = NSMakeRect( scr_x,     0, scrsx, shaft );
			scroller_y_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );


			// [!] : shaft

			n_bmp_flip_onoff = TRUE;

			n_bmp bmp_scroll; n_bmp_zero( &bmp_scroll );

			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_y_rect_shaft, &x, &y, &sx, &sy );

				u32 color_shaft = n_bmp_argb_mac( 64, 128,128,128 );

				n_bmp_new_fast( &bmp_scroll, sx,sy );
				n_bmp_flush( &bmp_scroll, n_bmp_white_invisible );

				n_bmp_roundrect( &bmp_scroll, 0,0,sx,sy, color_shaft, 50 );
			}


			// [!] : thumb / knob

			//if(0)
			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_y_rect_thumb, &x, &y, &sx, &sy );

				u32 color_thumb = n_bmp_argb_mac( 222, 128,128,128 );
				n_bmp_roundrect( &bmp_scroll, 0,y,sx,sy, color_thumb, 50 );
			}

			{
				n_type_gfx x,y,sx,sy;
				n_win64_rect_expand_simple( &scroller_y_rect_shaft, &x, &y, &sx, &sy );

				n_bmp_transcopy( &bmp_scroll, &n_bmp_clip, 0,0,sx,sy, x,y );
			}

			n_bmp_free_fast( &bmp_scroll );

		}

		} // [!] : Fake Scroller : Vertical

	}


	return;
}




void
n_marie_drophere( void )
{

	n_error = TRUE;


	u32 accent = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );

	u32 bg;
	if ( n_win64_darkmode_is_on() )
	{
		bg = n_bmp_black;
	} else {
		bg = n_bmp_white;
	}

	n_bmp_new( &n_bmp_drop_here, 256,256 );
	n_bmp_flush_gradient( &n_bmp_drop_here, bg, accent, N_BMP_GRADIENT_VERTICAL );


	n_bmp neko; n_bmp_zero( &neko );

	n_win64_resource_load_nbmp_literal( "N_NEKO", &neko );
	n_bmp_blendcopy( &neko, &n_bmp_drop_here, 0,0,256,256, 0,0, 0.5 );

	n_bmp_free( &neko );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = 256;
	gdi.sy                  = 256;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_color_bg       = n_bmp_argb( 0,255,255,255 );
	gdi.base_color_fg       = n_bmp_argb( 0,255,255,255 );
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_NOFRAME;
	gdi.frame_round         = 0;

	gdi.text                = n_posix_literal( "Drop Here" );
	gdi.text_font           = n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = 33;
	gdi.text_style          = N_GDI_TEXT_SINK;
	gdi.text_color_main     = n_bmp_rgb( 255,255,255 );
	gdi.text_color_sink_tl  = n_bmp_argb( 128, 10, 10, 10 );
	gdi.text_color_sink_br  = n_bmp_argb( 128,255,255,255 );
	gdi.text_fxsize1        = 1;
	gdi.text_fxsize2        = 1;

	n_bmp bmp_text; n_bmp_zero( &bmp_text );

	n_gdi_bmp( &gdi, &bmp_text );

	n_bmp_flush_transcopy( &bmp_text, &n_bmp_drop_here );

	n_bmp_free_fast( &bmp_text );

//n_bmp_save_literal( &n_bmp_drop_here, "ret.bmp" );


	return;
}




void
n_marie_init( void )
{

	n_bmp_transparent_onoff_default = FALSE;

	n_bmp_zero( &n_bmp_drop_here );
	n_bmp_zero( &n_bmp_file      );
	n_bmp_zero( &n_bmp_processed );
	n_bmp_zero( &n_bmp_clip      );

	n_resample_onoff = TRUE;

}




LRESULT CALLBACK
n_marie_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_win64_darkmode_titlebar_auto( hwnd );

		n_win64_refresh( hwnd, TRUE );

	break;


	case WM_CREATE :

		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );

		n_path = n_win64_commandline_new();

		n_marie_init();


		// Window

		n_win64_ui_window_init_literal( hwnd, N_MARIE_APPNAME, N_MARIE_ICONAME, "" );

		n_win64_darkmode_titlebar_auto( hwnd );


		// Marie

		n_marie_drophere();
		n_marie_load();

		n_marie_prepare_bitmap( hwnd );

		{
			n_type_gfx sx = N_BMP_SX( &n_bmp_processed );
			n_type_gfx sy = N_BMP_SY( &n_bmp_processed );

			n_win64_ui_window_set( hwnd, 0,0,sx,sy, TRUE );
		}


		// Display

		//ShowWindow( hwnd, SW_HIDE );
		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		//PAINTSTRUCT ps;
		//BeginPaint( hwnd, &ps );


		RECT rect; GetClientRect( hwnd, &rect );
		n_type_gfx sx = rect.right;
		n_type_gfx sy = rect.bottom;

		n_win64_doublebuffer_simple_init( hwnd, sx,sy );

		n_bmp *bmp = &n_win64_doublebuffer_instance.bmp;

		n_bmp_flush_fastcopy( &n_bmp_processed, bmp );

		n_win64_doublebuffer_simple_exit();


		//EndPaint( hwnd, &ps );

		return 0;
	}
	break;


	case WM_DROPFILES :

		// [!] : currently, shortcut support is omitted

		n_string_free( n_path );
		n_path = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		n_marie_load();
		n_marie_prepare_bitmap( hwnd );

		n_type_gfx sx = N_BMP_SX( &n_bmp_processed );
		n_type_gfx sy = N_BMP_SY( &n_bmp_processed );

		n_win64_ui_window_set( hwnd, 0,0,sx,sy, TRUE );

		n_win64_refresh( hwnd, FALSE );

	break;


	case WM_KEYDOWN :

		if ( wParam == VK_LEFT )
		{
			if ( n_rotate == N_MARIE_ROTATE_U )
			{
				n_rotate = N_MARIE_ROTATE_R;
			} else
			if ( n_rotate == N_MARIE_ROTATE_R )
			{
				n_rotate = N_MARIE_ROTATE_D;
			} else
			if ( n_rotate == N_MARIE_ROTATE_D )
			{
				n_rotate = N_MARIE_ROTATE_L;
			} else
			if ( n_rotate == N_MARIE_ROTATE_L )
			{
				n_rotate = N_MARIE_ROTATE_U;
			}
		} else
		if ( wParam == VK_RIGHT )
		{
			if ( n_rotate == N_MARIE_ROTATE_U )
			{
				n_rotate = N_MARIE_ROTATE_L;
			} else
			if ( n_rotate == N_MARIE_ROTATE_L )
			{
				n_rotate = N_MARIE_ROTATE_D;
			} else
			if ( n_rotate == N_MARIE_ROTATE_D )
			{
				n_rotate = N_MARIE_ROTATE_R;
			} else
			if ( n_rotate == N_MARIE_ROTATE_R )
			{
				n_rotate = N_MARIE_ROTATE_U;
			}
		}

		{
			n_marie_prepare_bitmap( hwnd );

			n_type_gfx sx = N_BMP_SX( &n_bmp_processed );
			n_type_gfx sy = N_BMP_SY( &n_bmp_processed );

			n_win64_ui_window_set( hwnd, 0,0,sx,sy, TRUE );

			n_win64_refresh( hwnd, FALSE );
		}

	break;


	case WM_LBUTTONDOWN :

		//pt = n_win64_cursor_position_relative_POINT( hwnd );

	break;


	case WM_LBUTTONDBLCLK :
	{
		n_type_gfx sx = N_BMP_SX( &n_bmp_processed );
		n_type_gfx sy = N_BMP_SY( &n_bmp_processed );

		n_win64_ui_window_set( hwnd, 0,0,sx,sy, TRUE );
	}
	break;


	case WM_CLOSE :
	
		n_string_free( n_path );

		n_bmp_free( &n_bmp_drop_here );
		n_bmp_free( &n_bmp_file );
		n_bmp_free( &n_bmp_processed );
		n_bmp_free( &n_bmp_clip );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;

	} // switch


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_marie_wndproc );
}

