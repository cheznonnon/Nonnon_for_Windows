// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_poker_settings( n_poker *p, BOOL is_read )
{

	n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, n_posix_literal( "nonnon.ini" ) );


	if ( is_read )
	{
		n_posix_char str[ 100 ];
		n_ini_value_str_literal( &ini, "[Nonnon Poker]", "coin", "500", str , 100 );

		p->coin = n_posix_atoi( str );
	} else {
		n_posix_char str[ 100 ];
		n_posix_snprintf_literal( str, 100, "%d", p->coin );

		n_ini_section_add_literal( &ini, "[Nonnon Poker]" );
		n_ini_key_add_int_literal( &ini, "[Nonnon Poker]", "coin", p->coin );

		n_ini_save( &ini, n_posix_literal( "nonnon.ini" ) );
	}

	n_ini_free( &ini );


	return;
}




void
n_game_init( void )
{

	n_poker *p = &poker;


	n_poker_zero( p );
	n_poker_init( p );

	if ( 0 )
	{
		poker.game_mode = N_POKER_GAME_MODE_ENDLESS;
	} else {
		poker.game_mode = N_POKER_GAME_MODE_BET;
	}

	n_poker_settings( p, TRUE );

	p->coin_dif = p->coin;


	game.sx = p->sx;
	game.sy = p->sy;

	n_game_bmp_init();

	p->canvas = &game.bmp;


	n_win64_ui_window_init_literal( game.hwnd, "Nonnon Poker", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	n_win64_darkmode_titlebar_auto( game.hwnd );

	p->hwnd = game.hwnd;


	n_poker_reset( p );


	return;
}

void
n_game_loop( void )
{

	n_poker *p = &poker;

	n_poker_coin_animation( p );

	n_poker_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_poker *p = &poker;

	n_poker_settings( p, FALSE );

	n_poker_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	n_poker *p = &poker;


	static BOOL drag_onoff = FALSE;

	static UINT timer_id = 1;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
//n_game_hwndprintf_literal( "WM_SETTINGCHANGE : %d", n_win64_darkmode_is_on() );

		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			// [x] : not working accurately
			//n_win64_timer_init( hwnd, timer_id, 200 );
		}

	}
	break;

	case WM_TIMER :
	{
//n_game_hwndprintf_literal( "WM_TIMER : %d", wParam );

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wParam == 0 ) { break; }

		if ( wParam != timer_id ) { break; }

		n_win64_timer_exit( hwnd, timer_id );

//n_game_debug_count();

		n_win64_darkmode_titlebar_auto( hwnd );

/*
		static BOOL is_first = TRUE;

		BOOL cur = n_win64_darkmode_is_on();

		static BOOL prv = FALSE;
		if ( is_first ) { is_first = FALSE; prv = cur; }

		if ( cur != prv )
		{
//n_game_hwndprintf_literal( "!" );
			n_poker_cardgenerator( p );
		}
		prv = cur;
*/

		n_poker_cardgenerator( p );

		n_poker_counter_exit( p );
		n_poker_counter_init( p );


		n_poker_table_draw( p );


		//InvalidateRect( hwnd, NULL, TRUE );
		//UpdateWindow( hwnd );
		//n_win64_message_send( hwnd, WM_PAINT, 0,0 );

	}
	break;


	case WM_LBUTTONDOWN :
	{

		drag_onoff = TRUE;


		n_poker *p = &poker;

		n_poker_on_click( p );
		p->draw_center = N_POKER_DRAW_CENTER_ALL;

		if ( n_poker_button_is_hovered( p, 0 ) )
		{
			p->click_onoff[ 0 ] = TRUE;

			p->draw_center = N_POKER_DRAW_CENTER_ALL;
			n_poker_draw_button( p );
		}

		if ( n_poker_button_is_hovered( p, 1 ) )
		{
			p->click_onoff[ 1 ] = TRUE;

			p->draw_center = N_POKER_DRAW_CENTER_ALL;
			n_poker_draw_button( p );
		}

	}
	break;

	case WM_LBUTTONUP :
	{
		drag_onoff = FALSE;


		n_poker *p = &poker;

		BOOL draw = FALSE;

		if ( p->click_onoff[ 0 ] )
		{
			if ( n_poker_button_is_hovered( p, 0 ) )
			{
				p->button_is_clicked[ 0 ] = TRUE;
			}

			draw = TRUE;
		}

		if ( p->click_onoff[ 1 ] )
		{
			if ( n_poker_button_is_hovered( p, 1 ) )
			{
				p->button_is_clicked[ 1 ] = TRUE;
			}

			draw = TRUE;
		}

		p->click_onoff[ 0 ] = FALSE;
		p->click_onoff[ 1 ] = FALSE;

		if ( draw )
		{
			p->draw_center = N_POKER_DRAW_CENTER_ALL;
			n_poker_draw_button( p );
		}

//NSLog( @"Button %d %d", p->button_is_clicked[ 0 ], p->button_is_clicked[ 1 ] );

//NSLog( @"Button %d %d", n_poker_button_is_hovered( p, 0 ), n_poker_button_is_hovered( p, 1 ) );
	}
	break;

	case WM_MOUSEMOVE :
	{

		if ( drag_onoff == FALSE ) { break; }


		n_poker *p = &poker;

		BOOL draw = FALSE;

		if ( FALSE == n_poker_button_is_hovered( p, 0 ) )
		{
			if ( p->click_onoff[ 0 ] )
			{
				p->click_onoff[ 0 ] = FALSE;
				draw = TRUE;
			}
		}

		if ( FALSE == n_poker_button_is_hovered( p, 1 ) )
		{
			if ( p->click_onoff[ 1 ] )
			{
				p->click_onoff[ 1 ] = FALSE;
				draw = TRUE;
			}
		}

		if ( draw )
		{
			p->draw_center = N_POKER_DRAW_CENTER_ALL;
			n_poker_draw_button( p );
		}

	}
	break;

	} // switch


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

