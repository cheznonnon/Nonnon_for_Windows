﻿// Nonnon Freecell
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_POKER_CARDGENERATOR
#define _H_NONNON_POKER_CARDGENERATOR




#define N_CARDGENERATOR_DIGIT_PATCH

#include "../nonnon/bridge/cardgenerator.c"




void
n_cardgenerator_init( n_cardgenerator *p, n_type_real scale, HWND hwnd )
{

	// Init

	p->is_init = TRUE;


	// Size

	p->unit_sx  = 1920 / 17 * scale;
	p->unit_sy  = (n_type_gfx) ( (n_type_real) p->unit_sx * 1.5 );
	p->resample = 1.0;

//NSLog( @"%f", p->unit_sx * p->resample );

	p->border = 1;
	p->halo   = 6;


	// Blank Card Maker

	if ( n_cardgenerator_darkmode_is_on() )
	{
		p->color_card_main = n_bmp_rgb(  96, 96, 96 );
	} else {
		p->color_card_main = n_bmp_white;
	}

	{

		const int blend   = 0;// p->option_blend;
		const u32 lighter = n_bmp_rgb( 222,222,222 );

		if ( n_cardgenerator_darkmode_is_on() )
		{
			p->color_frame = n_bmp_rgb( 111,111,111 );
		} else {
			p->color_frame = lighter;
		}

		n_cardgenerator_base( p, &p->bmp_blank, p->color_card_main, blend );
	}

	if ( n_cardgenerator_darkmode_is_on() )
	{
		p->color_margin = n_bmp_alpha_invisible_pixel( p->color_frame );
	} else {
		p->color_margin = n_bmp_white_invisible;
	}


	// Resampling Test

	{
		n_bmp b; n_bmp_carboncopy( &p->bmp_blank, &b );
		n_cardgenerator_resampler( p, &b, p->color_frame );

		p->card_sx = N_BMP_SX( &b );
		p->card_sy = N_BMP_SY( &b );
//n_posix_debug_literal( " %d : %f ", p->card_sx, p->unit_sx * p->resample );

		n_bmp_free_fast( &b );
	}

	p->csx_min = p->csx = p->card_sx * 10;
	p->csy_min = p->csy = p->card_sy * 4;
	p->osy     = (n_type_gfx) ( p->card_sy * 0.18 );


	return;
}

void
n_cardgenerator_loop( n_cardgenerator *p )
{

	// Debug Center

	u32 tick = 0;//n_posix_tickcount();


	if ( p->is_init )
	{
		p->is_init = FALSE;
	} else {
		return;
	}


	// Load

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.2;

		n_cardgenerator_gdi_literal( &p->digit_1[  0 ], "A" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  1 ], "2" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  2 ], "3" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  3 ], "4" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  4 ], "5" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  5 ], "6" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  6 ], "7" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  7 ], "8" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  8 ], "9" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[  9 ], "10", size );
		n_cardgenerator_gdi_literal( &p->digit_1[ 10 ], "J" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[ 11 ], "Q" , size );
		n_cardgenerator_gdi_literal( &p->digit_1[ 12 ], "K" , size );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.2;

		n_cardgenerator_gdi_literal( &p->suit__1[ 0 ], "♥", size );
		n_cardgenerator_gdi_literal( &p->suit__1[ 1 ], "♦", size );
		n_cardgenerator_gdi_literal( &p->suit__1[ 2 ], "♠", size );
		n_cardgenerator_gdi_literal( &p->suit__1[ 3 ], "♣", size );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.5;

		n_cardgenerator_gdi_literal( &p->suitbig[ 0 ], "♥", size );
		n_cardgenerator_gdi_literal( &p->suitbig[ 1 ], "♦", size );
		n_cardgenerator_gdi_literal( &p->suitbig[ 2 ], "♠", size );
		n_cardgenerator_gdi_literal( &p->suitbig[ 3 ], "♣", size );

		n_bmp_ui_search_icon_crop( &p->suitbig[ 0 ], n_bmp_black );
		n_bmp_ui_search_icon_crop( &p->suitbig[ 1 ], n_bmp_black );
		n_bmp_ui_search_icon_crop( &p->suitbig[ 2 ], n_bmp_black );
		n_bmp_ui_search_icon_crop( &p->suitbig[ 3 ], n_bmp_black );
//n_bmp_save_literal( &p->suitbig[ 0 ], "ret.bmp" );
	}

	{
		n_type_gfx size = (n_type_real) p->unit_sx * 0.8;

		u32 fg, bg;
		if ( n_cardgenerator_darkmode_is_on() )
		{
			bg = p->color_card_main;
			fg = n_bmp_blend_pixel( bg, n_bmp_white, 0.5 );
		} else {
			bg = p->color_card_main;
			fg = n_bmp_blend_pixel( bg, n_bmp_black, 0.5 );
		}

		n_cardgenerator_gdi_bg_literal( &p->suit_bg[ 0 ], "♥", size, bg, fg );
		n_cardgenerator_gdi_bg_literal( &p->suit_bg[ 1 ], "♦", size, bg, fg );
		n_cardgenerator_gdi_bg_literal( &p->suit_bg[ 2 ], "♠", size, bg, fg );
		n_cardgenerator_gdi_bg_literal( &p->suit_bg[ 3 ], "♣", size, bg, fg );

		n_bmp_ui_search_icon_crop( &p->suit_bg[ 0 ], n_bmp_white );
		n_bmp_ui_search_icon_crop( &p->suit_bg[ 1 ], n_bmp_white );
		n_bmp_ui_search_icon_crop( &p->suit_bg[ 2 ], n_bmp_white );
		n_bmp_ui_search_icon_crop( &p->suit_bg[ 3 ], n_bmp_white );
//n_bmp_save_literal( &p->suit_bg[ 0 ], "ret.bmp" );
	}

	{
		n_win64_resource_load_nbmp_literal( "POKER_NEKO"   , &p->bmp_logo    );
		n_win64_resource_load_nbmp_literal( "POKER_CROWN_K", &p->bmp_crown_k );
		n_win64_resource_load_nbmp_literal( "POKER_CROWN_Q", &p->bmp_crown_q );
//n_bmp_save( &p->bmp_logo, "/Users/nonnon2/Desktop/ret.bmp" );

		n_type_real ratio = (n_type_real) p->unit_sx / N_BMP_SX( &p->bmp_logo ) * 0.5;

		if ( ratio < 0.5 )
		{
			int i = 0;
			int c = 1.0 / ratio;
			n_posix_loop
			{
				n_bmp_flush_antialias( &p->bmp_logo   , 1.0 );
				n_bmp_flush_antialias( &p->bmp_crown_k, 1.0 );
				n_bmp_flush_antialias( &p->bmp_crown_q, 1.0 );

				i++;
				if ( i >= c ) { break; }
			}
		}

		n_bmp_resampler( &p->bmp_logo   , ratio, ratio );
		n_bmp_resampler( &p->bmp_crown_k, ratio, ratio );
		n_bmp_resampler( &p->bmp_crown_q, ratio, ratio );

//n_bmp_save_literal( &p->bmp_logo, "ret.bmp" );
	}


	// Cat

	if ( 0 )
	{
		//
	} else
	if ( n_cardgenerator_darkmode_is_on() )
	{
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb(  64, 10, 10, 10 ), n_bmp_argb(  64, 10, 10, 10 ) );
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb( 128, 10, 10, 10 ), n_bmp_argb( 128, 10, 10, 10 ) );
	} else {
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb(  64,128,128,128 ), n_bmp_argb(  64,255,255,255 ) );
		n_bmp_flush_replacer( &p->bmp_logo, n_bmp_argb( 128,128,128,128 ), n_bmp_argb( 128,255,255,255 ) );
	}


	// Suit Mark and Digit Maker

//if(0)
	{

		n_type_gfx i = 0;
		n_posix_loop
		{
			n_bmp_carboncopy( &p->digit_1[ i ], &p->digit_2[ i ] );

			n_bmp_flush_mirror( &p->digit_2[ i ], N_BMP_COPY_MIRROR_ROTATE180 );

			i++;
			if ( i >= N_CARDGENERATOR_CARD_UNIT ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_bmp_carboncopy( &p->suit__1[ i ], &p->suit__2[ i ] );

			n_bmp_flush_mirror( &p->suit__2[ i ], N_BMP_COPY_MIRROR_ROTATE180 );

			i++;
			if ( i >= N_CARDGENERATOR_SUIT_MAX ) { break; }
		}

	}


	// Halo Maker : new card size is needed

	n_cardgenerator_dropshadow( &p->bmp_halo, p->card_sx, p->card_sy, p->halo, 1 );


	// Preload

#ifdef N_POSIX_PLATFORM_MAC

	{

		BOOL p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = TRUE;

/*
		// [x] : broken image will be made

		dispatch_group_t group = dispatch_group_create();
		dispatch_queue_t queue = dispatch_get_main_queue();

		dispatch_async( queue, ^{ n_cardgenerator_card( p, 0 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 1 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 2 ); } );
		dispatch_async( queue, ^{ n_cardgenerator_card( p, 3 ); } );

		dispatch_group_notify( group, queue, ^{ ; } );
		dispatch_group_wait( group, DISPATCH_TIME_FOREVER );
*/

		NSOperationQueue *q = [[NSOperationQueue alloc] init];

		int i = 0;
		n_posix_loop
		{
			NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{
				n_cardgenerator_card( p, i );
			}];

			[q addOperation:o];

			i++;
			if ( i >= 4 ) { break; }
		}

		[q waitUntilAllOperationsAreFinished];


		n_bmp_is_multithread = p_multithread;

	}

#else  // #ifdef N_POSIX_PLATFORM_MAC

	{

		// [x] : Win9x : can run but not working

		if ( n_thread_onoff() )
		{

			BOOL p_multithread = n_bmp_is_multithread;
			n_bmp_is_multithread = TRUE;

			n_thread thread_0 = n_thread_init( n_cardgenerator_thread_0, p );
			n_thread thread_1 = n_thread_init( n_cardgenerator_thread_1, p );
			n_thread thread_2 = n_thread_init( n_cardgenerator_thread_2, p );
			n_thread thread_3 = n_thread_init( n_cardgenerator_thread_3, p );

			n_thread_wait( thread_0 ); n_thread_exit( thread_0 );
			n_thread_wait( thread_1 ); n_thread_exit( thread_1 );
			n_thread_wait( thread_2 ); n_thread_exit( thread_2 );
			n_thread_wait( thread_3 ); n_thread_exit( thread_3 );

			n_bmp_is_multithread = p_multithread;

		} else {

			n_cardgenerator_card( p, 0 );
			n_cardgenerator_card( p, 1 );
			n_cardgenerator_card( p, 2 );
			n_cardgenerator_card( p, 3 );

		}

	}

#endif // #ifdef N_POSIX_PLATFORM_MAC


	if ( tick ) { n_posix_debug_literal( "%d", (int) n_posix_tickcount() - tick ); }


	return;
}


#endif // _H_NONNON_PROJECT_CARDGENERATOR

