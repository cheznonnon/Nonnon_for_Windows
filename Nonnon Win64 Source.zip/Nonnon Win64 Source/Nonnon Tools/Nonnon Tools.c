// Nonnon Tools for Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win64/_windows.c"


#include "../nonnon/win64/ui/window.c"
#include "../nonnon/win64/ui/button.c"


#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/neutral/curico.c"
#include "../nonnon/neutral/midi.c"
#include "../nonnon/neutral/zip.c"


#include "dotfiles_remover.c"
#include "favorites2html.c"
#include "timestamp.c"




#define N_PINKNOISE_APPNAME n_posix_literal( "Nonnon Tools" )
#define N_PINKNOISE_ICONAME n_posix_literal( "MAIN_ICON" )




#define n_tools_button_setup_literal( p, l, r ) n_tools_button_setup( p, n_posix_literal( l ), n_posix_literal( r ) ) 

void
n_tools_button_setup( n_win64_ui_button *p, n_posix_char *label, n_posix_char *resource_name )
{

	p->label         = label;
	p->resource_name = resource_name;

	n_win64_refresh( p->hwnd, FALSE );


	return;
}




static n_win64_ui_button button_0;
static n_win64_ui_button button_1;
static n_win64_ui_button button_2;
static n_win64_ui_button button_3;
static n_win64_ui_button button_4;
static n_win64_ui_button button_5;

void
n_tools_resize( HWND hwnd, BOOL is_first )
{

	n_type_real scale_ui = n_win64_scale_factor_ui( hwnd );

	const n_type_gfx csx     = 333 * scale_ui;
	const n_type_gfx unit_sy = n_win64_ui_stdsize() * scale_ui;
	const n_type_gfx padding = 16 * scale_ui;
	const n_type_gfx margin  = 8 * scale_ui;

	n_type_gfx x = padding;
	n_type_gfx y = padding;

	n_type_gfx sx = csx - ( padding * 2 );
	n_type_gfx sy = unit_sy;

	n_win64_ui_button_move( &button_0, x,y,sx,sy, FALSE ); y += sy + margin;
	n_win64_ui_button_move( &button_1, x,y,sx,sy, FALSE ); y += sy + margin;
	n_win64_ui_button_move( &button_2, x,y,sx,sy, FALSE ); y += sy + margin;
	n_win64_ui_button_move( &button_3, x,y,sx,sy, FALSE ); y += sy + margin;
	n_win64_ui_button_move( &button_4, x,y,sx,sy, FALSE ); y += sy + margin;
	n_win64_ui_button_move( &button_5, x,y,sx,sy, FALSE ); y += sy + margin;


	n_type_gfx wx = 0;
	n_type_gfx wy = 0;

	if ( is_first == FALSE )
	{
		RECT rect; GetWindowRect( hwnd, &rect );
		wx = rect.left;
		wy = rect.top;
	}

	n_win64_ui_window_set( hwnd, wx, wy, csx, y + margin, is_first );


	return;
}




LRESULT CALLBACK
n_tools_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static n_posix_char *path = NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_win64_darkmode_on_WM_SETTINGCHANGE( hwnd );

	break;


	case WM_CREATE :


		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );


		// Window

		n_win64_ui_window_init( hwnd, N_PINKNOISE_APPNAME, N_PINKNOISE_ICONAME, N_STRING_EMPTY );


		n_win64_ui_button_init( &button_0, hwnd );
		n_win64_ui_button_init( &button_1, hwnd );
		n_win64_ui_button_init( &button_2, hwnd );
		n_win64_ui_button_init( &button_3, hwnd );
		n_win64_ui_button_init( &button_4, hwnd );
		n_win64_ui_button_init( &button_5, hwnd );

		n_tools_button_setup_literal( &button_0, "Zero Timestamp"   , "" );
		n_tools_button_setup_literal( &button_1, "Remove Dot Files" , "" );
		n_tools_button_setup_literal( &button_2, "Pack/Unpack Icons", "" );
		n_tools_button_setup_literal( &button_3, "ArcDrop"          , "" );
		n_tools_button_setup_literal( &button_4, "Favorites2HTML"   , "" );
		n_tools_button_setup_literal( &button_5, "Nonnon MIDI"      , "" );


		// Display

		n_tools_resize( hwnd, TRUE );

		//ShowWindow( hwnd, SW_HIDE );
		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_DPICHANGED :
	case WM_SIZE :

		n_tools_resize( hwnd, FALSE );

	break;

	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		RECT rect; GetClientRect( hwnd, &rect );

		COLORREF colorref = n_win64_GetSysColor( COLOR_BTNFACE );

		HBRUSH br = CreateSolidBrush( colorref );

		FillRect( ps.hdc, &rect, br );

		DeleteObject( br );


		n_win64_ui_button_draw( &button_0, TRUE );
		n_win64_ui_button_draw( &button_1, TRUE );
		n_win64_ui_button_draw( &button_2, TRUE );
		n_win64_ui_button_draw( &button_3, TRUE );
		n_win64_ui_button_draw( &button_4, TRUE );
		n_win64_ui_button_draw( &button_5, TRUE );

		n_win64_doublebuffer_exit( &button_0.db );
		n_win64_doublebuffer_exit( &button_1.db );
		n_win64_doublebuffer_exit( &button_2.db );
		n_win64_doublebuffer_exit( &button_3.db );
		n_win64_doublebuffer_exit( &button_4.db );
		n_win64_doublebuffer_exit( &button_5.db );


		EndPaint( hwnd, &ps );
	}
	break;


	case WM_DROPFILES :

		n_string_free( path );
		path = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		SetWindowText( hwnd, path );

	break;


	case WM_COMMAND :

		if ( n_string_is_empty( path ) ) { break; }

		if ( (HWND) lParam == button_0.hwnd )
		{
			n_timestamp_directory( path );
		} else
		if ( (HWND) lParam == button_1.hwnd )
		{
			n_mac_tools_dotfiles_remover( path );
		} else
		if ( (HWND) lParam == button_2.hwnd )
		{
			if ( n_posix_stat_is_dir( path ) )
			{
				n_curico_multi_pack( path );
			} else {
				n_curico_multi_unpack( path );
			}
		} else
		if ( (HWND) lParam == button_3.hwnd )
		{
			n_zip_main( path );
		} else
		if ( (HWND) lParam == button_4.hwnd )
		{
			n_favorites2html_main( path );
		} else
		if ( (HWND) lParam == button_5.hwnd )
		{
//n_posix_debug_literal( "" );
			n_midi_encode( path, FALSE );
		}// else

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_string_free( path );

		n_win64_ui_button_exit( &button_0 );
		n_win64_ui_button_exit( &button_1 );
		n_win64_ui_button_exit( &button_2 );
		n_win64_ui_button_exit( &button_3 );
		n_win64_ui_button_exit( &button_4 );
		n_win64_ui_button_exit( &button_5 );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_0 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_1 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_2 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_3 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_4 );
	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button_5 );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_tools_wndproc );
}


