// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_timestamp_file( const n_posix_char *fname )
{

	// [Mechanism]
	//
	//	access : set by any actions
	//	create : set by local system
	//	modify : set by file overwriting
	//
	//	"modify" will be kept over archive formats like .ZIP


	time_t a = n_posix_stat_atime( fname );
	//time_t c = n_posix_stat_ctime( fname );
	time_t m = n_posix_stat_mtime( fname );


	// [!] : set 00:00AM

	struct tm *tm = localtime( &m );
	if ( tm == NULL ) { return; }

	tm->tm_hour = tm->tm_min = tm->tm_sec = 0;


	n_posix_utimbuf ut;

	ut.actime  = a;
	ut.modtime = mktime( tm );

	n_posix_utime( fname, &ut );


	return;
}

BOOL
n_timestamp_directory( const n_posix_char *path )
{

	n_timestamp_file( path );


	n_posix_DIR *dp = n_posix_opendir_nodot( path );
	if ( dp == NULL ) { return TRUE; }

	while( 1 )
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }

		n_posix_char *name = n_string_path_make_new( path, dirent->d_name );

		n_timestamp_directory( name );

		n_string_free( name );

	}

	n_posix_closedir( dp );


	return FALSE;
}

