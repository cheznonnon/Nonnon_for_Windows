// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_game_init( void )
{
//return;

	n_freecell *p = &freecell;

	n_freecell_zero( p );
	n_freecell_init( p );

	game.sx = p->sx;
	game.sy = p->sy;

	n_game_bmp_init();

	n_freecell_sound_init( p, game.hwnd );


	n_win64_ui_window_init( game.hwnd, "Nonnon Freecell", "MAIN_ICON", N_STRING_EMPTY );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	p->hwnd   =  game.hwnd;
	p->canvas = &game.bmp;


	n_freecell_reset( p, TRUE );


	return;
}

void
n_game_loop( void )
{

	n_freecell *p = &freecell;

	n_freecell_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_freecell *p = &freecell;

	n_freecell_exit( p );

	n_freecell_sound_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	extern void n_freecell_input( n_freecell* );

	switch( msg ) {


	case WM_LBUTTONUP :

		ReleaseCapture();

		n_freecell_input( &freecell );

	break;

	case WM_LBUTTONDOWN :

		SetCapture( game.hwnd );

		n_freecell_input( &freecell );

	break;

	case WM_MOUSEMOVE :

		n_freecell_input( &freecell );

	break;


	case WM_LBUTTONDBLCLK :

		freecell.doubleclick = TRUE;

		n_freecell_loop( &freecell );

		freecell.doubleclick = FALSE;

	break;


	case WM_RBUTTONDOWN :

	break;


	case WM_MOUSEWHEEL :

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

