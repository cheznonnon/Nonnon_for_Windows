// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




static BOOL n_game_WM_SIZE_skip = TRUE;




void
n_game_init( void )
{
//return;

	n_freecell *p = &freecell;

	n_freecell_zero( p );
	n_freecell_init( p );

	game.sx = p->sx;
	game.sy = p->sy;

	n_game_bmp_init();

	n_freecell_sound_init( p, game.hwnd );


	n_win64_style_new( game.hwnd, WS_OVERLAPPEDWINDOW );

	n_win64_ui_window_init_literal( game.hwnd, "Nonnon Freecell", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	n_win64_darkmode_titlebar_auto( game.hwnd );

	p->hwnd   =  game.hwnd;
	p->canvas = &game.bmp;


	n_freecell_reset( p, TRUE );


	n_game_WM_SIZE_skip = FALSE;


	return;
}

void
n_game_loop( void )
{

	n_freecell *p = &freecell;

	n_freecell_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_freecell *p = &freecell;

	n_freecell_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	extern void n_freecell_input( n_freecell* );


	n_freecell *p = &freecell;


	static UINT timer_id = 1;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
//n_game_hwndprintf_literal( "WM_SETTINGCHANGE : %d", n_win64_darkmode_is_on() );

		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			n_win64_timer_init( hwnd, timer_id, 200 );
		}

	}
	break;


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wParam == 0 ) { break; }

		if ( wParam != timer_id ) { break; }

		n_win64_timer_exit( hwnd, timer_id );

//n_game_debug_count();

		n_freecell_style_change_color( p );
		n_freecell_flush_background( p );


		static BOOL is_first = TRUE;

		BOOL cur = n_win64_darkmode_is_on();

		static BOOL prv = FALSE;
		if ( is_first ) { is_first = FALSE; prv = cur; }

		if ( cur != prv )
		{
//n_game_hwndprintf_literal( "!" );
			n_cardgenerator_exit( &p->cardgen     );
			n_cardgenerator_init( &p->cardgen, 10 );
			n_cardgenerator_loop( &p->cardgen     );
		}
		prv = cur;


		n_freecell_placeholder_free( p );
		n_freecell_placeholder_make( p );

		n_freecell_redraw( p );

		p->refresh = TRUE;
		n_freecell_loop( p );

		// [Needed] : not game.refresh = TRUE;
		n_win64_refresh( hwnd, FALSE );

	}
	break;


	case WM_LBUTTONUP :

		ReleaseCapture();

		n_freecell_input( p );

	break;

	case WM_LBUTTONDOWN :

		SetCapture( game.hwnd );

		n_freecell_input( p );

	break;

	case WM_MOUSEMOVE :

		n_freecell_input( p );

	break;


	case WM_LBUTTONDBLCLK :

		p->doubleclick = TRUE;

		n_freecell_loop( p );

		p->doubleclick = FALSE;

	break;


	case WM_SIZE :
	{

		if ( n_game_WM_SIZE_skip ) { break; }
//n_game_debug_count();
//n_game_hwndprintf_literal( "%d %d", LOWORD( lParam ), HIWORD( lParam ) );

		game.sx = p->sx = p->cardgen.csx = LOWORD( lParam );
		game.sy = p->sy = p->cardgen.csy = HIWORD( lParam );

		n_game_bmp_exit();
		n_game_bmp_init();

		n_freecell_flush_background( p );

		n_freecell_reposition( p );
		n_freecell_redraw( p );

		p->refresh = TRUE;
		n_freecell_loop( p );

		// [Needed] : not game.refresh = TRUE;
		n_win64_refresh( game.hwnd, FALSE );

	}
	break;

	case WM_GETMINMAXINFO :

		n_win64_ui_window_on_WM_GETMINMAXINFO( hwnd,msg,wParam,lParam, freecell.cardgen.csx_min, freecell.cardgen.csy_min );

	break;


	} // switch

	{
		static n_win64_ui_menu menu[] = {

			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "Replay"   ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "New Game" ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "---"      ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, NULL }

		};

		int i = n_win64_ui_menu_system_proc( hwnd, msg, wParam, lParam, menu, 0 );
//if ( i >= 0 ) { n_win64_hwndprintf_literal( hwnd, "%d", i ); }
		if ( i == 0 )
		{
			n_freecell_replay( p );
		} else
		if ( i == 1 )
		{
			n_freecell_newgame( p );
		}
	}


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

