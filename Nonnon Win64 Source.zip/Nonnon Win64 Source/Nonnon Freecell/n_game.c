// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_game_init( void )
{
//return;

	n_freecell *p = &freecell;

	n_freecell_zero( p );
	n_freecell_init( p );

	game.sx = p->sx;
	game.sy = p->sy;

	n_game_bmp_init();

	n_freecell_sound_init( p, game.hwnd );


	n_win64_ui_window_init_literal( game.hwnd, "Nonnon Freecell", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	n_win64_darkmode_titlebar_auto( game.hwnd );

	p->hwnd   =  game.hwnd;
	p->canvas = &game.bmp;


	n_freecell_reset( p, TRUE );


	return;
}

void
n_game_loop( void )
{

	n_freecell *p = &freecell;

	n_freecell_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_freecell *p = &freecell;

	n_freecell_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	extern void n_freecell_input( n_freecell* );


	n_freecell *p = &freecell;


	switch( msg ) {


	case WM_SETTINGCHANGE :
//n_game_hwndprintf_literal( "WM_SETTINGCHANGE : %d", n_win64_color_scheme_darkmode_is_on() );

		// [x] : currently not working
/*
		n_win64_darkmode_titlebar_auto( hwnd );

		n_freecell_style_change( p );

		n_freecell_flush_background( p );

		n_freecell_placeholder_free( p );
		n_freecell_placeholder_make( p ); // [x] : placeholder will be NULL

		n_freecell_redraw( p );

		p->refresh = TRUE;
		n_freecell_loop( p );

		game.refresh = TRUE;
*/
	break;


	case WM_LBUTTONUP :

		ReleaseCapture();

		n_freecell_input( p );

	break;

	case WM_LBUTTONDOWN :

		SetCapture( game.hwnd );

		n_freecell_input( p );

	break;

	case WM_MOUSEMOVE :

		n_freecell_input( p );

	break;


	case WM_LBUTTONDBLCLK :

		p->doubleclick = TRUE;

		n_freecell_loop( p );

		p->doubleclick = FALSE;

	break;


	case WM_SIZE :
	{
break;
		game.sx = LOWORD( lParam );
		game.sy = HIWORD( lParam );

		n_game_bmp_init();

		n_freecell_reposition( p );

	}
	break;


	} // switch

	{
		static n_win64_ui_menu menu[] = {

			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "Replay"   ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "New Game" ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, n_posix_literal( "---"      ), 0 },
			{ N_WIN_MENU_NONE,  FALSE, FALSE, NULL }

		};

		int i = n_win64_ui_menu_system_proc( hwnd, msg, wParam, lParam, menu, 0 );
//if ( i >= 0 ) { n_win64_hwndprintf_literal( hwnd, "%d", i ); }
		if ( i == 0 )
		{
			n_freecell_replay( p );
		} else
		if ( i == 1 )
		{
			n_freecell_newgame( p );
		}
	}


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

