
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="LINE MASHER 2"

%compile%

