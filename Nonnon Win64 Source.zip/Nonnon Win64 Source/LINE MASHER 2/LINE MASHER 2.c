// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/bridge/app/LINE MASHER 2/LINE MASHER 2.c"


static n_lm2 lm2;




void
n_game_init( void )
{
//return;

	n_lm2 *p = &lm2;

	n_lm2_zero( p );


	game.fps = 60;


	p->hwnd = game.hwnd;

	n_lm2_init( p );


	game.sx = p->csx;
	game.sy = p->csy;


	n_game_bmp_init();


	// Init

	p->canvas = &game.bmp;


	n_lm2_reset( p );


	n_win64_ui_window_init_literal( game.hwnd, "LINE MASHER 2", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );


	return;
}

void
n_game_loop( void )
{

	n_lm2 *p = &lm2;

	if ( p->transition_phase != N_LM2_TRANSITION_NONE )
	{
		if ( p->transition_phase == N_LM2_TRANSITION_FADE_IN )
		{
			n_lm2_chara_draw_blend -= 0.05;

			if ( n_lm2_chara_draw_blend <= 0.0 )
			{
				p->transition_phase = N_LM2_TRANSITION_NONE;
			}
		} else
		if ( p->transition_phase == N_LM2_TRANSITION_FADE_OUT )
		{
			n_lm2_chara_draw_blend += 0.05;

			if ( n_lm2_chara_draw_blend >= 1.0 )
			{
				p->transition_phase = N_LM2_TRANSITION_FADE_IN;

				n_lm2_vibrate_off( p );

				n_lm2_reset( p );
				n_bmp_flush_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], p->canvas );
			}
		}

		p->refresh = TRUE;
	}

	n_lm2_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_lm2 *p = &lm2;


	n_lm2_settings( p, FALSE );

	n_lm2_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	n_lm2 *p = &lm2;


	static int  click_count          = 0;
	static u32  click_count_timeout  = 0;
	static UINT click_count_timer_id = 2;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
//n_game_hwndprintf_literal( "WM_SETTINGCHANGE : %d", n_win64_darkmode_is_on() );

		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
			n_win64_darkmode_titlebar_auto( hwnd );

			n_game_on_paint();
		}

	}
	break;



	case WM_DPICHANGED :
	case WM_SIZE :

		n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	break;


	case WM_CREATE :

		click_count_timer_id = n_win64_timer_id_get();
		n_win64_timer_init( hwnd, click_count_timer_id, 100 );

	break;


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wParam == 0 ) { break; }

		if ( wParam == click_count_timer_id )
		{
			if ( click_count_timeout < n_posix_tickcount() )
			{
				click_count = 0;
			}
			break;
		}

	}
	break;


	case WM_KEYDOWN :

		p->input_any_keys_onoff = TRUE;

	break;


	case WM_LBUTTONDOWN :


		if ( click_count_timeout > n_posix_tickcount() )
		{
			click_count++;
		} else {
			click_count = 1;
		}

		click_count_timeout = n_posix_tickcount() + GetDoubleClickTime();


		if ( click_count >= 2 )
		{
			n_win64_ui_window_set( hwnd, 0,0,game.sx,game.sy, TRUE );
		}


		n_win64_message_send( hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

