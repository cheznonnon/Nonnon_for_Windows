
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="hunyapiyo3"

%compile%

