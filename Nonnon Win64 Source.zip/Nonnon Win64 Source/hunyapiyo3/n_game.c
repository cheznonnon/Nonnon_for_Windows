// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_game_init( void )
{
//return;

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_zero( p );


	n_hunyapiyo3_init( p );
//n_posix_debug_literal( "%d %d", p->sx, p->sy );
//return;


	game.sx = p->sx;
	game.sy = p->sy + p->bar;
/*
Size            393 419 
GetClientRect   0 0 387 390 
*/
//n_posix_debug_literal( "%d %d", game.sx, game.sy );

	n_game_bmp_init();


	// Init

	p->canvas = &game.bmp;

	n_hunyapiyo3_gdi_background( p, &p->bmp_bg );

	n_bmp_flush_fastcopy( &p->bmp_bg, p->canvas );

	n_bmp_carboncopy( &p->bmp_bg, &p->bmp_result );


	n_hunyapiyo3_sound_init( p, game.hwnd );


	n_hunyapiyo3_reset( p );


	n_win64_ui_window_init_literal( game.hwnd, "hunyapiyo3", "MAIN_ICON", "" );
	n_win64_ui_window_set( game.hwnd, 0,0,game.sx,game.sy, TRUE );

	n_win64_darkmode_titlebar_auto( game.hwnd );


	return;
}

void
n_game_loop( void )
{

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_loop( p );

	game.refresh = p->refresh; p->refresh = FALSE;


	return;
}

void
n_game_exit( void )
{

	n_hunyapiyo3 *p = &hunyapiyo3;

	n_hunyapiyo3_exit( p );


	n_game_bmp_exit();


	return;
}

LRESULT CALLBACK
n_game_DefWindowProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_hunyapiyo3 *p = &hunyapiyo3;


	switch( msg ) {


	case WM_SETTINGCHANGE :
//n_game_hwndprintf_literal( "WM_SETTINGCHANGE : %d", n_win64_color_scheme_darkmode_is_on() );

		n_win64_darkmode_titlebar_auto( hwnd );

		n_hunyapiyo3_metrics( p );

		n_hunyapiyo3_gdi_background( p, &p->bmp_bg );
		n_bmp_flush_fastcopy( &p->bmp_bg, p->canvas );

		n_bmp_free( &p->bmp_button );

		p->refresh = TRUE;

		game.force_redraw = TRUE;

	break;


	case WM_MOUSEMOVE :

		p->pt = n_win64_cursor_position_relative_POINT( hwnd );

		n_win64_on_mousemove( hwnd );

	break;

	case WM_MOUSELEAVE :

		p->pt = n_win64_cursor_position_relative_POINT( hwnd );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "WM_LBUTTONDOWN" );

		if ( p->animation_onoff ) { break; }

		if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			p->button_press_offset = p->button_press_offset_default;

			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_main( p );
		} else
		if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			p->button_press_offset = p->button_press_offset_default;

			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_last( p );
		}

		game.refresh = p->refresh;

	break;

	case WM_LBUTTONUP :

		if ( p->animation_onoff ) { break; }

		p->click = TRUE;

		if ( p->phase == N_HUNYAPIYO3_PHASE_CLCK )
		{
			p->phase = N_HUNYAPIYO3_PHASE_STRT;
		} else
		if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_main( p );
		} else
		if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_last( p );
		}

		p->click = FALSE;

		game.refresh = p->refresh;

	break;


	case WM_RBUTTONDOWN :

		if ( p->animation_onoff ) { break; }

		p->click_menu = TRUE;

		if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_main( p );
		} else
		if ( p->phase == N_HUNYAPIYO3_PHASE_PERC )
		{
			if ( p->answer_check_onoff )
			{
				n_hunyapiyo3_sound_play( p, N_HUNYAPIYO3_SOUND_CLICK );
				p->answer_check_onoff = FALSE;
			} else {
				n_hunyapiyo3_sound_play( p, N_HUNYAPIYO3_SOUND_CLICK );
				p->answer_check_onoff = TRUE;
			}

			p->pt = n_win64_cursor_position_relative_POINT( hwnd );
			n_hunyapiyo3_last( p );
		}

		p->click_menu = FALSE;

		game.refresh = p->refresh;

	break;


	case WM_MOUSEWHEEL :

		if ( p->animation_onoff ) { break; }

		if ( p->phase == N_HUNYAPIYO3_PHASE_MAIN )
		{
//n_posix_debug_literal( "%d", n_win64_scroll_wheeldelta( wparam, 1 ) );

			if ( 0 < n_win64_scroll_wheeldelta( wparam, 1 ) )
			{
				p->click      = TRUE;	
			} else {
				p->click_menu = TRUE;
			}
			n_hunyapiyo3_main( p );

			p->click = p->click_menu = n_posix_false;
		}

		game.refresh = p->refresh;

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

