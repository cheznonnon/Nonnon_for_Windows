
@echo off

set compile=..\nonnon\project\compile64.bat
set    name="Nonnon Nyaagle"
set   debug=-DDEBUG

%compile%

