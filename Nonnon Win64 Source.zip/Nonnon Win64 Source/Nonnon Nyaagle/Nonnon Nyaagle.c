// Nonnon Nyaagle for Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [x] : swprintf() requires as snwprintf (cch parameter is added)

#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win64/_windows.c"
#include "../nonnon/win64/resource.c"

#include "../nonnon/win64/ui/window.c"
#include "../nonnon/win64/ui/button.c"
#include "../nonnon/win64/ui/txtbox.c"




void
n_nyaagle_explorer_open( const n_posix_char *filename )
{

	SHELLEXECUTEINFO sei; ZeroMemory( &sei, sizeof( SHELLEXECUTEINFO ) );

	sei.cbSize = sizeof( SHELLEXECUTEINFO );
	sei.fMask  = SEE_MASK_INVOKEIDLIST;
	sei.lpVerb = n_posix_literal( "open" );
	sei.lpFile = filename;
	sei.nShow  = SW_SHOWNORMAL;

	ShellExecuteEx( &sei );


	return;
}




#include "engine.c"

static n_posix_char *n_path = NULL;

void
NyaagleGo( n_posix_char *query, n_txtbox *txtbox_list )
{

	txtbox_list->focus = -1;


	n_win64_busy_cursor( TRUE );


	if ( FALSE == n_string_is_empty( query ) )
	{
		n_clipboard_text_set( GetParent( txtbox_list->hwnd ), query );
	}


	//BOOL prv_search = n_nyaagle_is_text_search;
/*
	if ( n_is_option_pressed )
	{
		n_nyaagle_is_text_search = FALSE;
	}
*/
	n_txtbox_reset( txtbox_list );

	if ( ( txtbox_list->txt_data->sy == 1 )&&( n_string_is_empty( n_txt_get( txtbox_list->txt_data, 0 ) ) ) )
	{
		n_nyaagle_directory         ( txtbox_list->txt_data, n_path, query );
	} else {
		n_nyaagle_directory_narrowed( txtbox_list->txt_data,         query );
	}


	//n_nyaagle_is_text_search = prv_search;


	n_txt_sort_up( txtbox_list->txt_data );


	n_win64_refresh( txtbox_list->hwnd, FALSE );


	n_win64_busy_cursor( FALSE );


	return;
}




#define N_APPNAME n_posix_literal( "Nonnon Nyaagle" )
#define N_ICONAME n_posix_literal( "MAIN_ICON" )




#define n_button_setup_literal( p, l, r ) n_button_setup( p, n_posix_literal( l ), n_posix_literal( r ) ) 

void
n_button_setup( n_win64_ui_button *p, n_posix_char *label, n_posix_char *resource_name )
{

	p->label         = label;
	p->resource_name = resource_name;

	n_win64_refresh( p->hwnd, FALSE );


	return;
}




void
n_nyaagle_draw( HWND hwnd, n_bmp *logo )
{

	RECT client; GetClientRect( hwnd, &client );

	n_win64_doublebuffer_simple_init( hwnd, client.right, client.bottom );
	n_bmp *bmp = &n_win64_doublebuffer_instance.bmp;

	u32 color_bg;
	if (1)//( n_win64_darkmode_is_on() )
	{
		color_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	} else {
		color_bg = n_bmp_white;
	}

	n_bmp_flush( bmp, color_bg );

	n_bmp_transcopy( logo, bmp, 0,0,N_BMP_SX( logo ),N_BMP_SY( logo ), 0,0 );


	n_win64_doublebuffer_simple_exit();


	return;
}




static n_bmp logo;

static n_txtbox txtbox_path;
static n_txtbox txtbox_find;
static n_txtbox txtbox_list;

static n_win64_ui_button button;

void
n_nyaagle_resize( HWND hwnd, BOOL is_first )
{

	n_type_real scale_ui = n_win64_scale_factor_ui( hwnd );

	n_bmp_scaler_big( &logo, scale_ui );

	const n_type_gfx csx     = N_BMP_SX( &logo );
	const n_type_gfx csy     = 512 * scale_ui;

	const n_type_gfx unit_sy = n_win64_ui_stdsize() * scale_ui;
	const n_type_gfx padding = 16 * scale_ui;
	const n_type_gfx gap     =  8 * scale_ui;

	n_type_gfx x = padding;
	n_type_gfx y = padding + N_BMP_SY( &logo );

	n_type_gfx sx = csx - ( padding * 2 );

	n_type_gfx psy = unit_sy + 2;
	n_type_gfx fsy = unit_sy + 4;
	n_type_gfx lsy = csy;
	n_type_gfx bsy = unit_sy;

	MoveWindow( txtbox_path.hwnd, x,y,sx,psy, FALSE ); y += unit_sy + gap;
	MoveWindow( txtbox_find.hwnd, x,y,sx,fsy, FALSE ); y += unit_sy + gap; lsy -= y + unit_sy + gap + gap;
	MoveWindow( txtbox_list.hwnd, x,y,sx,lsy, FALSE );

	n_win64_ui_button_move( &button, x,csy - unit_sy - gap,sx,bsy, FALSE );


	n_type_gfx wx = 0;
	n_type_gfx wy = 0;

	n_type_gfx wsx = csx;
	n_type_gfx wsy = csy;

	if ( is_first == false )
	{
		RECT rect; GetWindowRect( hwnd, &rect );

		wx = rect.left;
		wy = rect.top;

		//wsx = rect.right - rect.left;
		//wsy = rect.bottom - rect.top;
	}

	n_win64_ui_window_set( hwnd, wx, wy, wsx, wsy, is_first );


	return;
}




LRESULT CALLBACK
n_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static UINT darkmode_timer = 0;


	switch( msg ) {


	case WM_DPICHANGED :

		n_txtbox_on_WM_DPICHANGED( &txtbox_path );
		n_txtbox_on_WM_DPICHANGED( &txtbox_find );
		n_txtbox_on_WM_DPICHANGED( &txtbox_list );

	case WM_SIZE :

		n_nyaagle_resize( hwnd, FALSE );

	break;

	case WM_SETTINGCHANGE :
	{
		n_posix_char *str = (n_posix_char*) lParam;
//n_game_hwndprintf_literal( "%s", str );

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
//n_game_debug_count(); // [!] : come 4 times

			darkmode_timer = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, darkmode_timer, 200 );
		}
	}
	break;

	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == darkmode_timer )
		{
			n_win64_timer_exit( hwnd, darkmode_timer );

			n_nyaagle_draw( hwnd, &logo );

			n_txtbox_color_scheme( &txtbox_path );
			n_txtbox_color_scheme( &txtbox_find );
			n_txtbox_color_scheme( &txtbox_list );

			n_win64_darkmode_on_WM_SETTINGCHANGE( hwnd );

		}


	break;

	case WM_CREATE :


		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );

		n_win64_resource_load_nbmp( n_posix_literal( "N_NYAAGLE_LOGO" ), &logo );

/*
		// [!] : main icons maker
		{
			n_bmp bmp; n_bmp_zero( &bmp );

			//n_bmp_ui_search_icon_make( &bmp, 256, n_bmp_black, n_bmp_white );
			//n_bmp_ui_search_icon_png_save( &bmp, L"icon_main.png" );

			n_bmp_ui_search_icon_make( &bmp, 64, 0, n_bmp_rgb( 128,128,128 ) );
			n_bmp_ui_search_icon_png_save( &bmp, L"icon_small.png" );

			n_bmp_free_fast( &bmp );
		}
*/

		// Window

		n_win64_ui_window_init( hwnd, N_APPNAME, N_ICONAME, N_STRING_EMPTY );


		n_txtbox_init( &txtbox_path, hwnd, NULL );

		txtbox_path.txt_data->readonly = TRUE;

		txtbox_path.mode                = N_MAC_TXTBOX_MODE_ONELINE;
		txtbox_path.path_ellipsis_onoff = TRUE;

		n_txt_mod( txtbox_path.txt_data, 0, n_posix_literal( "Drop Here" ) );

		n_txtbox_reset( &txtbox_path );


		n_txtbox_init( &txtbox_find, hwnd, NULL );

		txtbox_find.mode = N_MAC_TXTBOX_MODE_FINDBOX;

		n_txtbox_reset( &txtbox_find );


		n_txtbox_init( &txtbox_list, hwnd, NULL );

		txtbox_list.mode                       = N_MAC_TXTBOX_MODE_LISTBOX;
		txtbox_list.path_ellipsis_onoff        = TRUE;
		txtbox_list.listbox_no_selection_onoff = TRUE;
		txtbox_list.scrollbar_patch            = TRUE;

		n_txtbox_reset( &txtbox_list );


		n_win64_ui_button_init( &button, hwnd );

		button.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

		n_button_setup_literal( &button, "Go!", "" );


		// Display

		SetFocus( txtbox_find.hwnd );

		n_nyaagle_resize( hwnd, TRUE );

		//ShowWindow( hwnd, SW_HIDE );
		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	{
		//PAINTSTRUCT ps;
		//BeginPaint( hwnd, &ps );

		n_nyaagle_draw( hwnd, &logo );

		NonnonTxtboxDraw( &txtbox_path, TRUE );
		NonnonTxtboxDraw( &txtbox_find, TRUE );
		NonnonTxtboxDraw( &txtbox_list, TRUE );

		n_win64_ui_button_draw( &button, TRUE );

		n_win64_doublebuffer_exit( &txtbox_path.db );
		n_win64_doublebuffer_exit( &txtbox_find.db );
		n_win64_doublebuffer_exit( &txtbox_list.db );

		n_win64_doublebuffer_exit( &button.db );

		//EndPaint( hwnd, &ps );
	}
	break;


	case WM_DROPFILES :

		n_string_free( n_path );
		n_path = n_win64_ui_window_on_WM_DROPFILES( hwnd, wParam );

		if ( n_posix_stat_is_file( n_path ) )
		{
			n_posix_char *upper = n_string_path_upperfolder_new( n_path );
			n_string_free( n_path );
			n_path = upper;
		}

		n_txt_mod( txtbox_path.txt_data, 0, n_path );
		n_win64_refresh( txtbox_path.hwnd, FALSE );

		n_txt_new( txtbox_list.txt_data );
		n_txtbox_reset( &txtbox_list );
		n_txtbox_redraw( &txtbox_list );

		SetFocus( txtbox_find.hwnd );

		//SetWindowText( hwnd, path );

	break;


	case WM_COMMAND :

		if ( n_string_is_empty( n_path ) ) { break; }

		if ( (HWND) lParam == txtbox_find.hwnd )
		{
			if ( wParam == N_MAC_TXTBOX_DELEGATE_F3 )
			{
				NyaagleGo( n_txt_get( txtbox_find.txt_data, 0 ), &txtbox_list );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT )
			{
				NyaagleGo( n_txt_get( txtbox_find.txt_data, 0 ), &txtbox_list );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT )
			{
				NyaagleGo( n_txt_get( txtbox_find.txt_data, 0 ), &txtbox_list );
			} else
			if ( wParam == N_MAC_TXTBOX_DELEGATE_DELETE_BUTTON )
			{
				n_txt_new( txtbox_list.txt_data );
				n_txtbox_reset( &txtbox_list );

				n_txtbox_redraw( &txtbox_list );
			}
		} else
		if ( (HWND) lParam == txtbox_list.hwnd )
		{
			if ( wParam == N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT )
			{
				if ( txtbox_list.click_count == 2 )
				{
					n_nyaagle_explorer_open( n_txt_get( txtbox_list.txt_data, txtbox_list.focus ) );
				}
			}
		} else
		if ( (HWND) lParam == button.hwnd )
		{
			NyaagleGo( n_txt_get( txtbox_find.txt_data, 0 ), &txtbox_list );
		}

	break;


	case WM_LBUTTONDOWN :
	{

		POINT pt = n_win64_cursor_position_relative_POINT( hwnd );

		RECT rect = { 0,0,N_BMP_SX( &logo ),N_BMP_SY( &logo ) };

		if ( PtInRect( &rect, pt ) )
		{
			n_win64_message_send( hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0 );
		}

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_string_free( n_path );

		n_txtbox_exit( &txtbox_path );
		n_txtbox_exit( &txtbox_find );
		n_txtbox_exit( &txtbox_list );

		n_win64_ui_button_exit( &button );

		n_bmp_free( &logo );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &txtbox_path );
	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &txtbox_find );
	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &txtbox_list );

	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &button );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win64_ui_window_main( NULL, n_wndproc );
}


