// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_BUTTON
#define _H_NONNON_WIN64_UI_BUTTON




#include <commctrl.h>




#include "../../neutral/bmp/all.c"


#include "../_windows.c"
#include "../doublebuffer.c"
#include "../font.c"

#include "../resource.c"
#include "../../bridge/gdi.c"




void
n_bmp_specialcopy( n_bmp *bmp_f, n_bmp *bmp_t, n_type_gfx fx, n_type_gfx fy, n_type_gfx fsx, n_type_gfx fsy, n_type_gfx tx, n_type_gfx ty, u32 fg, u32 bg )
{

	if ( n_bmp_error_clipping( bmp_f,bmp_t, &fx,&fy,&fsx,&fsy, &tx,&ty ) ) { return; }


	n_type_gfx xx = 0;
	n_type_gfx yy = 0;
	n_posix_loop
	{

		u32 color_f; n_bmp_ptr_get_fast( bmp_f, fx + xx, fy + yy, &color_f );
		u32 color_t; n_bmp_ptr_get_fast( bmp_t, tx + xx, ty + yy, &color_t );

		int a = n_bmp_a( color_f );

		u32 color;
		if ( 0 == a )
		{
			color = color_t;
		} else {
			if ( 255 == a )
			{
				color = color_f;
			} else {
				color = n_bmp_blend_pixel( fg, bg, n_bmp_blend_alpha2ratio( a ) );
			}
		}

		n_bmp_ptr_set_fast( bmp_t, tx + xx, ty + yy, color );


		xx++;
		if ( xx >= fsx )
		{

			xx = 0;

			yy++;
			if ( yy >= fsy ) { break; }
		}
	}


	return;
}




#define N_WIN64_UI_BUTTON_STYLE_CLASSIC ( 0 )
#define N_WIN64_UI_BUTTON_STYLE_TOOLBAR ( 1 )
#define N_WIN64_UI_BUTTON_STYLE_FLUENT  ( 2 )




typedef struct {

	HWND hwnd;

	int  style;

	n_posix_char *label;
	n_posix_char *resource_name;

	BOOL   hot_onoff;
	BOOL press_onoff;
	BOOL  gray_onoff;
	BOOL  fake_onoff;
	BOOL frame_onoff;

} n_win64_ui_button;


#define n_win64_ui_button_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_button ) )




void
n_win64_ui_button_move( n_win64_ui_button *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL redraw )
{

	MoveWindow( p->hwnd, x,y,sx,sy, redraw );

	return;
}




void
n_win64_ui_button_gdi_frame( n_win64_ui_button *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 bg, int frame )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = bg;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = frame;
	gdi.frame_round         = 0;

	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_button_gdi_contents( n_win64_ui_button *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 bg, int label_color )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_alpha_replace_pixel( bg, 0 );
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size;

	n_win64_font_hfont2name( hfont, font_name, &font_size );

	n_win64_font_exit( hfont );


	gdi.text                = p->label;
	gdi.text_font           = font_name;//n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = font_size;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;
	gdi.text_color_main     = label_color;

	gdi.icon                = p->resource_name;
	gdi.icon_style          = N_GDI_ICON_UI;

	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_button_draw( n_win64_ui_button *p )
{

	RECT rect; GetClientRect( p->hwnd, &rect );

	n_type_gfx sx,sy; n_win64_rect_expand_size( &rect, NULL, NULL, &sx, &sy );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d", sx, sy );


	// [!] : Metrics

	n_type_gfx offset_sink = 1;


	// Main

	n_win64_doublebuffer_simple_init( p->hwnd, sx,sy );

	n_bmp *bmp = &n_win64_doublebuffer_instance.bmp;


	u32 darkmode_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 darkmode_lb = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );
	u32 darkmode_ac = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );


	u32 lb, bg;
	if ( p->fake_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, n_bmp_black, 0.2 );
		lb = darkmode_lb;
	} else
	if ( p->hot_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, darkmode_ac, 0.2 );
		lb = darkmode_lb;
	} else
	if ( p->gray_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, n_bmp_black, 0.05 );
		lb = darkmode_lb;
	} else
	if ( p->press_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, n_bmp_black, 0.2 );
		lb = darkmode_lb;
	} else {
		bg = darkmode_bg;
		lb = darkmode_lb;
	}


	n_bmp_flush( bmp, darkmode_bg );


	n_bmp icon_contents; n_bmp_zero( &icon_contents );
	n_win64_ui_button_gdi_contents( p, &icon_contents, sx, sy, n_bmp_white_invisible, lb );
	if ( p->gray_onoff )
	{
		n_bmp_flush_grayscale( &icon_contents );
	}


	n_bmp icon_frame; n_bmp_zero( &icon_frame );
	n_bmp_new_fast( &icon_frame, sx, sy ); n_bmp_flush( &icon_frame, darkmode_bg );

	const n_type_gfx round = 6;


//p->style = N_WIN64_UI_BUTTON_STYLE_CLASSIC;
//p->style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
//p->style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

	if ( p->style == N_WIN64_UI_BUTTON_STYLE_CLASSIC )
	{
		int frame = N_GDI_FRAME_TRANS;

		if ( p->fake_onoff )
		{
			frame = N_GDI_FRAME_PUSH;
		} else
		if ( p->gray_onoff )
		{
			frame = N_GDI_FRAME_TRANS;
		} else
		if ( p->press_onoff )
		{
			frame = N_GDI_FRAME_PUSH;
		} else {
			frame = N_GDI_FRAME_BUTTON;
		}
//frame = N_GDI_FRAME_ETCH;

		n_win64_ui_button_gdi_frame( p, &icon_frame, sx, sy, bg, frame );
	} else
	if ( p->style == N_WIN64_UI_BUTTON_STYLE_TOOLBAR )
	{
		n_bmp_roundrect_pixel( &icon_frame, 0,0,sx,sy, bg, round );
	} else
	if ( p->style == N_WIN64_UI_BUTTON_STYLE_FLUENT )
	{
		n_type_gfx b  = 0;
		n_type_gfx bb = b * 2;

		if ( p->hot_onoff )
		{
			n_bmp_roundrect_pixel( &icon_frame, b,b,sx-bb,sy-bb, bg, round );
		}

		b += 2;
		bb = b * 2;

		u32 fr;
		if ( n_win64_darkmode_is_on() )
		{
			fr = n_bmp_blend_pixel( bg, n_bmp_white, 0.2 );
		} else {
			fr = n_bmp_blend_pixel( bg, n_bmp_black, 0.2 );
		}

		n_bmp_roundrect_pixel( &icon_frame, b,b,sx-bb,sy-bb, fr, round );

		b++;
		bb = b * 2;

		n_bmp_roundrect_pixel( &icon_frame, b,b,sx-bb,sy-bb, bg, round );
	}


	{
		n_type_gfx bmpsx = N_BMP_SX( &icon_frame );
		n_type_gfx bmpsy = N_BMP_SY( &icon_frame );

		n_type_gfx x = ( sx / 2 ) - ( bmpsx / 2 );
		n_type_gfx y = ( sy / 2 ) - ( bmpsy / 2 );

		n_bmp_transcopy( &icon_frame, bmp, 0,0,bmpsx,bmpsy, x,y );

		if ( p->press_onoff )
		{
			x += offset_sink;
			y += offset_sink;
		}

		n_bmp_transcopy( &icon_contents, bmp, 0,0,bmpsx,bmpsy, x,y );
	}

	n_bmp_free_fast( &icon_frame    );
	n_bmp_free_fast( &icon_contents );


	// Done!

	n_win64_doublebuffer_simple_exit();


	return;
}




// internal
LRESULT CALLBACK
n_win64_ui_button_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_button *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_MOUSEMOVE :

		// [!] : this code depends on SetCapture()/ReleaseCapture()

		n_win64_on_WM_MOUSEMOVE( hwnd );

	break;

	case WM_MOUSEHOVER :

		if ( p->fake_onoff )
		{
			//
		} else
		if ( p->gray_onoff )
		{
			//
		} else
		if ( p->press_onoff )
		{
			//
		} else
		if ( p->hot_onoff == FALSE )
		{
			p->hot_onoff = TRUE;
			n_win64_refresh( p->hwnd, FALSE );
		}

	break;

	case WM_MOUSELEAVE :
n_win64_hwndprintf_literal( hwnd, "WM_MOUSELEAVE" );

		if ( p->gray_onoff ) { break; }

		p->  hot_onoff = FALSE;
		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_ERASEBKGND :

		return 1;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		SetCapture( p->hwnd );

		p->  hot_onoff = FALSE;
		p->press_onoff = TRUE;

		n_win64_refresh( p->hwnd, FALSE );

	break;

	case WM_LBUTTONUP :
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		ReleaseCapture();

		n_win64_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );

		if ( p->fake_onoff )
		{
			//
		} else
		if ( p->gray_onoff )
		{
			//
		} else
		//
		{
			p->hot_onoff = TRUE;
		}

		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_RBUTTONDOWN :

	break;

	case WM_RBUTTONUP :

	break;

	} // switch


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_button_init( n_win64_ui_button *p, HWND hwnd_parent )
{

	n_win64_ui_button_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_button_subclass, 0, (DWORD_PTR) p );


	return;
}

void
n_win64_ui_button_exit( n_win64_ui_button *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_button_zero( p );


	return;
}




void
n_win64_ui_button_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_button *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win64_ui_button_draw( p );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN64_UI_BUTTON


