// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_BUTTON
#define _H_NONNON_WIN64_UI_BUTTON




#include <commctrl.h>




#include "../../neutral/bmp/all.c"


#include "../_windows.c"
#include "../doublebuffer.c"
#include "../font.c"

#include "../resource.c"
#include "../../bridge/gdi.c"




#define N_WIN64_UI_BUTTON_STYLE_CLASSIC ( 0 )
#define N_WIN64_UI_BUTTON_STYLE_TOOLBAR ( 1 )
#define N_WIN64_UI_BUTTON_STYLE_FLUENT  ( 2 )




typedef struct {

	HWND hwnd;

	int  style;

	n_posix_char *label;
	n_posix_char *resource_name;

	BOOL   hot_onoff;
	BOOL press_onoff;
	BOOL  gray_onoff;
	BOOL  fake_onoff;
	BOOL frame_onoff;

	BOOL  gdi_icon_onoff;
	n_gdi gdi_icon;

	BOOL  halo_onoff;

	n_win64_doublebuffer db;

} n_win64_ui_button;


#define n_win64_ui_button_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_button ) )




void
n_win64_ui_button_move( n_win64_ui_button *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL redraw )
{

	MoveWindow( p->hwnd, x,y,sx,sy, redraw );

	return;
}




void
n_win64_ui_button_gdi_halo( n_gdi *gdi, n_type_real scale )
{

	u32 color_outline;
	if ( n_win64_darkmode_is_on() )
	{
		color_outline = n_bmp_rgb(  96, 96, 96 );
	} else {
		color_outline = n_bmp_rgb( 192,192,192 );
	}

	gdi->icon_effect_style[ 0 ] = N_GDI_EFFECT_OUTLINE_FOG;
	gdi->icon_effect_color[ 0 ] = color_outline;
	gdi->icon_effect_param[ 0 ] = 3;// * scale;


	return;
}




void
n_win64_ui_button_gdi_frame( n_win64_ui_button *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 bg, int frame )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = bg;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = frame;
	gdi.frame_round         = 0;

	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_button_gdi_contents( n_win64_ui_button *p, n_bmp *bmp, n_type_gfx sx, n_type_gfx sy, u32 bg, int label_color )
{

	n_type_real scale      = n_win64_scale_factor_ui( p->hwnd );
	n_type_real scale_font = n_win64_scale_factor_font( p->hwnd );
//n_log( "%f", scale );

	if ( p->gdi_icon_onoff )
	{
		if ( p->halo_onoff )
		{

			n_gdi_bmp( &p->gdi_icon, bmp );


			n_gdi gdi; n_gdi_zero( &gdi );

			gdi.scale   = scale;

			gdi.icon_sx = N_BMP_SX( bmp );
			gdi.icon_sy = N_BMP_SY( bmp );

			gdi.icon_in = bmp;

			gdi.base_color_bg = n_bmp_alpha_replace_pixel( bg, 0 );
			gdi.base_style    = N_GDI_BASE_SOLID;

			n_win64_ui_button_gdi_halo( &gdi, scale );

			n_gdi_bmp( &gdi, bmp );

//n_bmp_save_literal( bmp, "ret.bmp" );
		} else {
			n_gdi_bmp( &p->gdi_icon, bmp );
		}

		return;
	}

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.hwnd                = p->hwnd;

	gdi.scale               = scale;

	gdi.sx                  = sx;
	gdi.sy                  = sy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_alpha_replace_pixel( bg, 0 );
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size = n_win64_font_hfont2size( hfont );

	n_win64_font_hfont2name( hfont, font_name );

	n_win64_font_exit( hfont );


	gdi.text                = p->label;
	gdi.text_font           = font_name;//n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = (n_type_real) font_size * scale_font;
	gdi.text_style          = N_GDI_TEXT_SYS_SMOOTH | N_GDI_TEXT_BOLD;
	gdi.text_color_main     = label_color;

	gdi.icon                = p->resource_name;
	gdi.icon_style          = N_GDI_ICON_RESOURCE | N_GDI_ICON_UI;


	if ( p->halo_onoff )
	{
		n_win64_ui_button_gdi_halo( &gdi, scale );
	}


	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_button_draw( n_win64_ui_button *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d", sx, sy );


	// [!] : Metrics

	BOOL dakmode_onoff = n_win64_darkmode_is_on();

	n_type_gfx offset_sink = 1;


	// Main

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/

	u32 color_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 color_lb = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );
	u32 color_ac = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );


	u32 lb, bg;
	if ( p->fake_onoff )
	{
		if ( dakmode_onoff )
		{
			bg = n_bmp_blend_pixel( color_bg, n_bmp_white, 0.2 );
		} else {
			bg = n_bmp_blend_pixel( color_bg, n_bmp_black, 0.2 );
		}
		lb = color_lb;
	} else
	if ( p->hot_onoff )
	{
		if ( dakmode_onoff )
		{
			bg = n_bmp_blend_pixel( color_bg, color_ac, 0.8 );
		} else {
			bg = n_bmp_blend_pixel( color_bg, color_ac, 0.2 );
		}
		lb = color_lb;
	} else
	if ( p->gray_onoff )
	{
		bg = n_bmp_blend_pixel( color_bg, n_bmp_black, 0.05 );
		lb = color_lb;
	} else
	if ( p->press_onoff )
	{
		if ( dakmode_onoff )
		{
			bg = n_bmp_blend_pixel( color_bg, n_bmp_white, 0.2 );
		} else {
			bg = n_bmp_blend_pixel( color_bg, n_bmp_black, 0.2 );
		}
		lb = color_lb;
	} else {
		bg = color_bg;
		lb = color_lb;
	}


	//if ( db_parent == NULL )
	{
		n_bmp_flush( bmp, color_bg );
	}


	n_type_real blend = 0.0;

	n_bmp icon_contents; n_bmp_zero( &icon_contents );
	n_win64_ui_button_gdi_contents( p, &icon_contents, csx, csy, bg, lb );
	if ( p->gray_onoff )
	{
		blend = 0.5;
		n_bmp_flush_grayscale( &icon_contents );
	}


	n_bmp icon_frame; n_bmp_zero( &icon_frame );
	n_bmp_new_fast( &icon_frame, csx, csy ); n_bmp_flush( &icon_frame, color_bg );

	const n_type_gfx round = 6 * n_win64_scale_factor_ui( p->hwnd );


//p->style = N_WIN64_UI_BUTTON_STYLE_CLASSIC;
//p->style = N_WIN64_UI_BUTTON_STYLE_TOOLBAR;
//p->style = N_WIN64_UI_BUTTON_STYLE_FLUENT;

	if ( p->style == N_WIN64_UI_BUTTON_STYLE_CLASSIC )
	{
		int frame = N_GDI_FRAME_TRANS;

		if ( p->fake_onoff )
		{
			frame = N_GDI_FRAME_PUSH;
		} else
		if ( p->gray_onoff )
		{
			frame = N_GDI_FRAME_TRANS;
		} else
		if ( p->press_onoff )
		{
			frame = N_GDI_FRAME_PUSH;
		} else {
			frame = N_GDI_FRAME_BUTTON;
		}
//frame = N_GDI_FRAME_ETCH;

		n_win64_ui_button_gdi_frame( p, &icon_frame, csx, csy, bg, frame );
	} else
	if ( p->style == N_WIN64_UI_BUTTON_STYLE_TOOLBAR )
	{
		n_bmp_roundrect_pixel( &icon_frame, 0,0,csx,csy, bg, round );
	} else
	if ( p->style == N_WIN64_UI_BUTTON_STYLE_FLUENT )
	{
		n_type_gfx b  = 0;
		n_type_gfx bb = b * 2;

		if ( p->hot_onoff )
		{
			u32 bg_blend = n_bmp_blend_pixel( color_bg, color_ac, 0.11 );
			n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, bg_blend, round );
		}

		b++;
		bb = b * 2;

		if ( p->hot_onoff )
		{
			u32 bg_blend = n_bmp_blend_pixel( color_bg, color_ac, 0.22 );
			n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, bg_blend, round );
		}

		b++;
		bb = b * 2;

		if ( p->hot_onoff )
		{
			u32 bg_blend = n_bmp_blend_pixel( color_bg, color_ac, 0.33 );
			n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, bg_blend, round );
		}

		u32 fr;
		if ( dakmode_onoff )
		{
			fr = n_bmp_blend_pixel( bg, n_bmp_white, 0.2 );
		} else {
			fr = n_bmp_blend_pixel( bg, n_bmp_black, 0.2 );
		}

		n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, fr, round );

		b++;
		bb = b * 2;

		if ( p->hot_onoff )
		{
			u32 bg_blend = n_bmp_blend_pixel( color_bg, color_ac, 0.44 );
			n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, bg_blend, round );
		}

		n_bmp_roundrect_pixel( &icon_frame, b,b,csx-bb,csy-bb, bg, round );
	}


	{
		n_type_gfx bmpsx = N_BMP_SX( &icon_frame );
		n_type_gfx bmpsy = N_BMP_SY( &icon_frame );

		n_type_gfx xx = x + ( csx / 2 ) - ( bmpsx / 2 );
		n_type_gfx yy = y + ( csy / 2 ) - ( bmpsy / 2 );

		n_bmp_transcopy( &icon_frame, bmp, 0,0,bmpsx,bmpsy, xx,yy );

		if ( p->press_onoff )
		{
			xx += offset_sink;
			yy += offset_sink;
		}

		n_bmp_blendcopy( &icon_contents, bmp, 0,0,bmpsx,bmpsy, xx,yy, blend );
	}

	n_bmp_free_fast( &icon_frame    );
	n_bmp_free_fast( &icon_contents );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}




// internal
LRESULT CALLBACK
n_win64_ui_button_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_button *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_MOUSEMOVE :

		// [!] : this code depends on SetCapture()/ReleaseCapture()

		n_win64_on_WM_MOUSEMOVE( hwnd );

	break;

	case WM_MOUSEHOVER :

		if ( p->fake_onoff )
		{
			//
		} else
		if ( p->gray_onoff )
		{
			//
		} else
		if ( p->press_onoff )
		{
			//
		} else
		if ( p->hot_onoff == FALSE )
		{
			p->hot_onoff = TRUE;
			n_win64_refresh( p->hwnd, FALSE );
		}

	break;

	case WM_MOUSELEAVE :
//n_win64_hwndprintf_literal( hwnd, "WM_MOUSELEAVE" );

		if ( p->gray_onoff ) { break; }

		p->  hot_onoff = FALSE;
		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_ERASEBKGND :

		return 1;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		SetCapture( p->hwnd );

		p->  hot_onoff = FALSE;
		p->press_onoff = TRUE;

		n_win64_refresh( p->hwnd, FALSE );

	break;

	case WM_LBUTTONUP :
	{
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		ReleaseCapture();

		if ( FALSE == p->press_onoff ) { break; }

		LRESULT lret = n_win64_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );
		if ( lret )
		{
			p->hot_onoff = p->press_onoff = FALSE;
			n_win64_refresh( p->hwnd, FALSE );
			break;
		}

		if ( p->fake_onoff )
		{
			//
		} else
		if ( p->gray_onoff )
		{
			//
		} else
		//
		{
			p->hot_onoff = TRUE;
		}

		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	}
	break;


	case WM_RBUTTONDOWN :

	break;

	case WM_RBUTTONUP :

	break;

	} // switch


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_button_init( n_win64_ui_button *p, HWND hwnd_parent )
{

	n_win64_ui_button_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_button_subclass, 0, (DWORD_PTR) p );


	p->halo_onoff = TRUE;


	return;
}

void
n_win64_ui_button_exit( n_win64_ui_button *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_button_zero( p );


	return;
}




void
n_win64_ui_button_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_button *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win64_ui_button_draw( p, NULL );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN64_UI_BUTTON


