// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_VALUE
#define _H_NONNON_WIN64_UI_VALUE





#include "../_windows.c"
#include "../doublebuffer.c"




typedef struct {

	HWND         hwnd;

	n_posix_char label[ 100 ];
	n_posix_char value[ 100 ];

	n_win64_doublebuffer db;

} n_win64_ui_value;


#define n_win64_ui_value_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_value ) )




// internal
void
n_win64_ui_value_gdi( n_win64_ui_value *p, n_bmp *bmp, n_posix_char *str, u32 color_bg, u32 color_text )
{

	n_type_real scale_font = n_win64_scale_factor_font( p->hwnd );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.base_color_bg       = color_bg;
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size = n_win64_font_hfont2size( hfont );

	n_win64_font_hfont2name( hfont, font_name );

	n_win64_font_exit( hfont );


	gdi.text                = str;
	gdi.text_font           = font_name;
	gdi.text_size           = font_size * scale_font;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = color_text;

	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_win64_ui_value_draw( n_win64_ui_value *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );


	// Main

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/


	u32 color_back = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 color_text = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );

	if ( FALSE == IsWindowEnabled( p->hwnd ) )
	{
		color_text = n_bmp_blend_pixel( color_back, color_text, 0.5 );
	}


	// Draw

	n_bmp_flush( bmp, color_back );


	//n_type_gfx text_sy = n_win64_ui_stdsize( p->hwnd );


	n_bmp label; n_bmp_zero( &label );
	n_win64_ui_value_gdi( p, &label, p->label, color_back, color_text );

	y = ( csy - N_BMP_SY( &label ) ) / 2;

	n_bmp_transcopy( &label, bmp, 0,0,N_BMP_SX( &label ),N_BMP_SY( &label ), x, y );

	n_bmp_free_fast( &label );


	n_bmp value; n_bmp_zero( &value );
	n_win64_ui_value_gdi( p, &value, p->value, color_back, color_text );

	y = ( csy - N_BMP_SY( &value ) ) / 2;

	n_bmp_transcopy( &value, bmp, 0,0,N_BMP_SX( &value ),N_BMP_SY( &value ), x + csx - N_BMP_SX( &value ), y );

	n_bmp_free_fast( &value );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}

void
n_win64_ui_value_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_value *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_value_draw( p, NULL );

	}
	break;


	} // switch


	return;
}




void
n_win64_ui_value_init( n_win64_ui_value *p, HWND hwnd_parent, n_posix_char *label )
{

	n_win64_ui_value_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | SS_OWNERDRAW,// | WS_BORDER,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	//SetWindowSubclass( p->hwnd, n_win64_ui_value_subclass, 0, (DWORD_PTR) p );


	n_posix_snprintf_literal( p->label, 100, "%s", label );


	return;
}

void
n_win64_ui_value_exit( n_win64_ui_value *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_value_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_VALUE


