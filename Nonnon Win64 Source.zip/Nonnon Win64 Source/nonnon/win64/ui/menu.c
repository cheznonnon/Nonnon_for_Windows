// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Limitation] : customized system menu
//
//	WS_OVERLAPPEDWINDOW only supported


// [Limitation] : submenu support
//
//	you cannot use ID number zero
//	+ see sample code below




#ifndef _H_NONNON_WIN64_UI_MENU
#define _H_NONNON_WIN64_UI_MENU




#define N_WIN_MENU_NONE  0
#define N_WIN_MENU_RADIO 1
#define N_WIN_MENU_CHECK 2




typedef struct {

	// .style
	//
	//	N_WIN_MENU_NONE  : none         : "  Menu Item"
	//	N_WIN_MENU_RADIO : radio button : "o Menu Item"
	//	N_WIN_MENU_CHECK : checkbox     : "v Menu Item"

	// .onoff
	//
	//	FALSE : unchecked
	//	TRUE  :   checked

	// .gray
	//
	//	FALSE :  enable
	//	TRUE  : disable

	// .string
	//
	//	"---" : will be separator
	//	NULL  : means end of array

	int           style;
	BOOL          onoff;
	BOOL          gray;
	n_posix_char *string;


	// .id_offset
	//
	//	needed for submenu detection

	// .hmenu_sub
	//
	//	submenu handle if needed

	int           id_offset;
	HMENU         hmenu_sub;


	// .hmenu_prev
	//
	//	internal
	//	for multiple instance when popup

	HMENU         hmenu_prev;

} n_win64_ui_menu;




static BOOL n_win64_ui_menu_stop_onoff = FALSE;




HMENU
n_win64_ui_menu_popup_hmenu_init( void )
{
	return CreatePopupMenu();
}

void
n_win64_ui_menu_popup_hmenu_exit( HMENU hmenu )
{

	DestroyMenu( hmenu );

	return;
}

void
n_win64_ui_menu_popup_show( HMENU hmenu, HWND hwnd )
{

	POINT p; GetCursorPos( &p );
	TrackPopupMenu( hmenu, 0, p.x,p.y, 0, hwnd, NULL );

	return;
}

void
n_win64_ui_menu_system_show( HMENU hmenu, HWND hwnd )
{

	// [!] : when you modify the system menu : don't use zero as menu ID

	POINT p; GetCursorPos( &p );
	int index = TrackPopupMenu( hmenu, TPM_RETURNCMD, p.x,p.y, 0, hwnd, NULL );

	if ( index > 0 )
	{
		n_win64_message_send( hwnd, WM_SYSCOMMAND, index, 0 );
	}


	return;
}

#define n_win64_ui_menu_popup_init(   a,b,c,d ) n_win64_ui_menu_popup_set( a,b,c,d, TRUE  )
#define n_win64_ui_menu_popup_modify( a,b,c,d ) n_win64_ui_menu_popup_set( a,b,c,d, FALSE )

#define n_win64_ui_menu_system_init(   a,b,c ) n_win64_ui_menu_system_set( a,b,c, TRUE  )
#define n_win64_ui_menu_system_modify( a,b,c ) n_win64_ui_menu_system_set( a,b,c, FALSE )

#define n_win64_ui_menu_system_set( a,b,c,d ) n_win64_ui_menu_popup_set( NULL, a,b,c,d )

// internal
void
n_win64_ui_menu_popup_set
(
                    HMENU hmenu,
	             HWND hwnd,
	  n_win64_ui_menu menu[],
	              int offset,
	             BOOL init
)
{

	if ( hmenu == NULL )
	{
		hmenu = GetSystemMenu( hwnd, FALSE );
	}


	MENUITEMINFO mii; ZeroMemory( &mii, sizeof( MENUITEMINFO ) );

	mii.cbSize = sizeof( MENUITEMINFO );
	mii.fMask  = MIIM_ID | MIIM_TYPE | MIIM_STATE;


	int i = 0;
	n_posix_loop
	{

		mii.wID = i + menu[ i ].id_offset;


		if ( menu[ i ].style == N_WIN_MENU_NONE )
		{

			mii.fType  = 0;
			mii.fState = MF_UNCHECKED;

		} else {

			if ( menu[ i ].style == N_WIN_MENU_RADIO )
			{
				mii.fType = MFT_RADIOCHECK;
			} else
			if ( menu[ i ].style == N_WIN_MENU_CHECK )
			{
				mii.fType = 0;
			}


			if ( menu[ i ].onoff )
			{
				mii.fState = MF_CHECKED;
			} else {
				mii.fState = MF_UNCHECKED;
			}

		}


		if ( n_string_is_same_literal( "---", menu[ i ].string ) )
		{
			mii.dwTypeData = (void*) NULL;
		} else {
			mii.dwTypeData = (void*) menu[ i ].string;
		}


		if ( menu[ i ].gray )
		{
			mii.fState |= MFS_GRAYED;
		}


		if ( menu[ i ].hmenu_sub != NULL )
		{
			mii.fMask    |=  MIIM_SUBMENU;
			mii.hSubMenu  =  menu[ i ].hmenu_sub;
		} else {
			mii.fMask    &= ~MIIM_SUBMENU;
			mii.hSubMenu  =  NULL;
		}


		if ( init )
		{
			InsertMenuItem ( hmenu, offset + i, TRUE, &mii );
		} else {
			SetMenuItemInfo( hmenu, offset + i, TRUE, &mii );
		}


		i++;
		if ( menu[ i ].string == NULL ) { break; }
	}

/*
	// [x] : not working
	{

		MENUINFO mi; n_memory_zero( &mi, sizeof( MENUINFO ) );

		mi.cbSize  = sizeof( MENUINFO );
		mi.fMask   = 16;//MIM_STYLE;
		mi.dwStyle = 0x08000000;//MNS_NOTIFYBYPOS;

		SetMenuInfo( hmenu, &mi );

	}
*/

	DrawMenuBar( hwnd );


	return;
}

#define n_win64_ui_menu_is_on( menu, i ) ( menu[ i ].onoff )

#define n_win64_ui_menu_on(  menu, i ) menu[ i ].onoff = TRUE
#define n_win64_ui_menu_off( menu, i ) menu[ i ].onoff = FALSE

void
n_win64_ui_menu_radiobutton( n_win64_ui_menu menu[], int check, int start, int end )
{

	if ( start < 0 ) { return; }
	if ( end   < 0 ) { return; }

	if ( start == end ) { return; }
	if ( start >= end ) { return; }


	int i = start;
	n_posix_loop
	{

		if ( i == check )
		{
			n_win64_ui_menu_on ( menu, i );
		} else {
			n_win64_ui_menu_off( menu, i );
		}

		i++;
		if ( i > end ) { break; }
	}


	return;
}

void
n_win64_ui_menu_checkbox( n_win64_ui_menu menu[], int index )
{

	if ( index < 0 ) { return; }

	if ( menu[ index ].style != N_WIN_MENU_CHECK ) { return; }

	if ( n_win64_ui_menu_is_on( menu, index ) )
	{
		n_win64_ui_menu_off( menu, index );
	} else {
		n_win64_ui_menu_on ( menu, index );
	}


	return;
}

void
n_win64_ui_menu_system_reset( HWND hwnd )
{

	GetSystemMenu( hwnd, TRUE );


	return;
}

int
n_win64_ui_menu_system_proc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	n_win64_ui_menu menu[],
	UINT            offset
)
{

	// [Limitation]
	//
	//	don't call twice or more

	// [!] : return value
	//
	//	-1   : not selected
	//	else : zero based index


	switch( msg ) {


	case WM_CREATE :

		n_win64_ui_menu_system_init( hwnd, menu, offset );

	break;


	case WM_SYSCOMMAND :
	{
		int index = LOWORD( wparam );

		if ( index >= 0xf000 ) { break; }

		return index;
	}
	break;


	case WM_INITMENU :
//n_win64_hwndprintf_literal( hwnd, "WM_INITMENU" );

	break;


	case WM_INITMENUPOPUP :
//n_win64_hwndprintf_literal( hwnd, " HMENU %d : Offset %d : Is System %d ", (int) wparam, LOWORD( lparam ), HIWORD( lparam ) );

		// [!] : this HIWORD( lparam ) will be TRUE when system menu

		if ( FALSE == HIWORD( lparam ) ) { break; }

		if ( (HMENU) wparam == GetSystemMenu( hwnd, FALSE ) )
		{
			n_win64_ui_menu_system_modify( hwnd, menu, offset );
		}

	break;


	} // switch


	return -1;
}

int
n_win64_ui_menu_popup_proc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	HMENU           hmenu,
	n_win64_ui_menu menu[],
	UINT            offset
)
{

	// [Limitation]
	//
	//	don't call twice or more

	// [!] : return value
	//
	//	-1   : not selected
	//	else : zero based index


	static u32 timer_id = 0;


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == 0 ) { break; }

		if ( timer_id == wparam )
		{
			n_win64_ui_menu_stop_onoff = FALSE;
			//n_win_timer_exit( hwnd, timer_id );
		}

	break;


	case WM_CREATE :

		n_win64_ui_menu_popup_init( hmenu, hwnd, menu, offset );

	break;


	case WM_INITMENU :

	break;


	case WM_INITMENUPOPUP :

		// [!] : this HIWORD( lparam ) will be TRUE when system menu

		if ( FALSE != HIWORD( lparam ) ) { break; }

		if ( hmenu == (HMENU) wparam )
		{
			n_win64_ui_menu_stop_onoff = TRUE;

			n_win64_ui_menu_popup_modify( hmenu, hwnd, menu, offset );
			menu->hmenu_prev = (HMENU) wparam;
		}

	break;


	case WM_EXITMENULOOP :

		//if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		//n_win_timer_init( hwnd, timer_id, 200 );

	break;


	case WM_COMMAND :
	{
		if (         lparam   != 0 ) { break; }
		if ( HIWORD( wparam ) != 0 ) { break; }


		if ( menu->hmenu_prev != hmenu ) { break; }

		menu->hmenu_prev = NULL;

		int index = LOWORD( wparam );

		return index;
	}
	break;


	} // switch


	return -1;
}


#endif // _H_NONNON_WIN64_UI_MENU


