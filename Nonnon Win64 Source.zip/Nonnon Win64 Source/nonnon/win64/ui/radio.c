// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_RADIO
#define _H_NONNON_WIN64_UI_RADIO




#include "../../neutral/bmp/all.c"


#include "../../win64/doublebuffer.c"
#include "../../win64/font.c"


#include "../../bridge/gdi.c"




typedef struct {

	HWND hwnd;

	BOOL is_checked;

	n_posix_char *label;

	BOOL   hot_onoff;
	BOOL press_onoff;
	BOOL  gray_onoff;

} n_win64_ui_radio;


#define n_win64_ui_radio_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_radio ) )




void
n_win64_ui_radio_move( n_win64_ui_radio *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, BOOL redraw )
{

	MoveWindow( p->hwnd, x,y,sx,sy, redraw );

	return;
}




void
n_win64_ui_radio_gdi_text( n_win64_ui_radio *p, n_bmp *bmp, u32 bg, int label_color )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_VERTICAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = n_bmp_alpha_replace_pixel( bg, 0 );
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size = n_win64_font_hfont2size( hfont );

	n_win64_font_hfont2name( hfont, font_name );

	n_win64_font_exit( hfont );


	gdi.text                = p->label;
	gdi.text_font           = font_name;//n_posix_literal( "Trebuchet MS" );
	gdi.text_size           = font_size;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;
	gdi.text_color_main     = label_color;

	n_gdi_bmp( &gdi, bmp );


	return;
}

void
n_win64_ui_radio_draw( n_win64_ui_radio *p )
{

	RECT rect; GetClientRect( p->hwnd, &rect );

	n_type_gfx sx,sy; n_win64_rect_expand_size( &rect, NULL, NULL, &sx, &sy );

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hwnd ), "%d %d", sx, sy );


	// Main

	n_win64_doublebuffer_simple_init( p->hwnd, sx,sy );

	n_bmp *bmp = &n_win64_doublebuffer_instance.bmp;


	u32 darkmode_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 darkmode_lb = n_win64_GetSysColor_nbmp( COLOR_GRAYTEXT );
	u32 darkmode_ac = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );


	u32 lb, bg;
	if ( p->hot_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, darkmode_ac, 0.2 );
		lb = darkmode_lb;
	} else
	if ( p->gray_onoff )
	{
		bg = n_bmp_blend_pixel( darkmode_bg, n_bmp_black, 0.05 );
		lb = darkmode_lb;
	} else {
		bg = darkmode_bg;
		lb = darkmode_lb;
	}
//if(bg){}


	n_bmp_flush( bmp, darkmode_bg );


	// Radio Button

	const n_type_gfx m   = 4;
	      n_type_gfx ctl = n_win64_ui_stdsize( p->hwnd ) - 8;

	n_type_gfx  xx = m;
	n_type_gfx  yy = abs( sy - ctl ) / 2;
	n_type_gfx sxx = ctl;
	n_type_gfx syy = ctl;

	n_bmp_circle( bmp, xx,yy,sxx,syy, lb );

	n_type_gfx n = 1;

	 xx += n * 1;
	 yy += n * 1;
	sxx -= n * 2;
	syy -= n * 2;

	n_bmp_circle( bmp, xx,yy,sxx,syy, bg );

	if ( p->is_checked )
	{
		 xx += n * 3;
		 yy += n * 3;
		sxx -= n * 6;
		syy -= n * 6;

		n_bmp_circle( bmp, xx,yy,sxx,syy, darkmode_ac );
	}


	// Text

	lb = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );

	n_bmp bmp_text; n_bmp_zero( &bmp_text );
	n_win64_ui_radio_gdi_text( p, &bmp_text, n_bmp_white_invisible, lb );

	if ( p->gray_onoff )
	{
		n_bmp_flush_grayscale( &bmp_text );
	}

	{
		n_type_gfx bmpsx = N_BMP_SX( &bmp_text );
		n_type_gfx bmpsy = N_BMP_SY( &bmp_text );

		n_type_gfx x = ( sy / 2 ) - ( bmpsy / 2 ) + ctl + m;
		n_type_gfx y = ( sy / 2 ) - ( bmpsy / 2 );

		n_bmp_transcopy( &bmp_text, bmp, 0,0,bmpsx,bmpsy, x, y );
	}

	n_bmp_free_fast( &bmp_text );


	// Done!

	n_win64_doublebuffer_simple_exit();


	return;
}




// internal
LRESULT CALLBACK
n_win64_ui_radio_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_radio *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_MOUSEMOVE :

		// [!] : this code depends on SetCapture()/ReleaseCapture()

		n_win64_on_WM_MOUSEMOVE( hwnd );

	break;

	case WM_MOUSEHOVER :

		if ( p->gray_onoff )
		{
			//
		} else
		if ( p->press_onoff )
		{
			//
		} else
		if ( p->hot_onoff == FALSE )
		{
			p->hot_onoff = TRUE;
			n_win64_refresh( p->hwnd, FALSE );
		}

	break;

	case WM_MOUSELEAVE :
//n_win64_hwndprintf_literal( hwnd, "WM_MOUSELEAVE" );

		if ( p->gray_onoff ) { break; }

		p->  hot_onoff = FALSE;
		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_ERASEBKGND :

		return 1;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/


	case WM_SETFOCUS :

		SetFocus( GetParent( hwnd ) );

	break;


	case WM_LBUTTONDOWN :
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		SetCapture( p->hwnd );

		p->  hot_onoff = FALSE;
		p->press_onoff = TRUE;

		n_win64_refresh( p->hwnd, FALSE );

	break;

	case WM_LBUTTONUP :
//n_posix_debug_literal( "!" );

		if ( p->gray_onoff ) { break; }

		ReleaseCapture();

		n_win64_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );

		if ( p->gray_onoff )
		{
			//
		} else
		//
		{
			p->hot_onoff = TRUE;
		}

		if ( p->is_checked )
		{
			//p->is_checked = FALSE;
		} else {
			p->is_checked = TRUE;
		}

		p->press_onoff = FALSE;

		n_win64_refresh( p->hwnd, FALSE );

	break;


	case WM_RBUTTONDOWN :

	break;

	case WM_RBUTTONUP :

	break;

	} // switch


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_radio_init( n_win64_ui_radio *p, HWND hwnd_parent )
{

	n_win64_ui_radio_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_radio_subclass, 0, (DWORD_PTR) p );


	p->label = L"Test";


	return;
}

void
n_win64_ui_radio_exit( n_win64_ui_radio *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_radio_zero( p );


	return;
}




void
n_win64_ui_radio_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_radio *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }

		n_win64_ui_radio_draw( p );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN64_UI_RADIO


