// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_GROUPBOX
#define _H_NONNON_WIN64_UI_GROUPBOX





#include "../_windows.c"
#include "../doublebuffer.c"


#include "../../neutral/bmp/ui/roundframe.c"




typedef struct {

	HWND          hwnd;

	n_posix_char *label;

	n_win64_doublebuffer db;

} n_win64_ui_groupbox;


#define n_win64_ui_groupbox_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_groupbox ) )




// internal
void
n_win64_ui_groupbox_gdi_label( n_win64_ui_groupbox *p, n_bmp *bmp, u32 color_bg, u32 color_text )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.base_color_bg       = color_bg;
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size = n_win64_font_hfont2size( hfont );

	n_win64_font_hfont2name( hfont, font_name );

	n_win64_font_exit( hfont );


	const n_type_real scale_font = n_win64_scale_factor_font( p->hwnd );

	gdi.text                = p->label;
	gdi.text_font           = font_name;
	gdi.text_size           = font_size * scale_font;
	gdi.text_style          = N_GDI_TEXT_SYS_SMOOTH;
	gdi.text_color_main     = color_text;

	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_win64_ui_groupbox_draw( n_win64_ui_groupbox *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );


	// Main

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/

	u32 color_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 color_ln = n_win64_GetSysColor_nbmp( COLOR_BTNSHADOW );
	u32 color_tx = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );


	// Draw

	const n_type_real scale_ui = n_win64_scale_factor_ui( p->hwnd );


	n_bmp_flush( bmp, color_bg );

	n_type_gfx text_sy = n_win64_ui_stdsize() * scale_ui;

	n_type_gfx round = 8;
	n_type_gfx frame = 1;


	n_bmp_ui_roundframe( bmp, x,y+(text_sy/2),csx,csy-(text_sy), round, frame, color_ln, color_bg );


	n_bmp label; n_bmp_zero( &label );
	n_win64_ui_groupbox_gdi_label( p, &label, color_bg, color_tx );

	n_bmp_transcopy( &label, bmp, 0,0,N_BMP_SX( &label ),N_BMP_SY( &label ), x + ( round * 2 ), y );

	n_bmp_free_fast( &label );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}

void
n_win64_ui_groupbox_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_groupbox *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_groupbox_draw( p, NULL );

	}
	break;


	} // switch


	return;
}




void
n_win64_ui_groupbox_init( n_win64_ui_groupbox *p, HWND hwnd_parent, n_posix_char *label )
{

	n_win64_ui_groupbox_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | SS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	//SetWindowSubclass( p->hwnd, n_win64_ui_groupbox_subclass, 0, (DWORD_PTR) p );


	if ( FALSE == n_string_is_empty( label ) )
	{
		n_type_int cch = n_posix_strlen( label ) + 2;

		p->label = n_string_new( cch );

		n_posix_snprintf_literal( p->label, cch + 1, " %s ", label );
	}


	return;
}

void
n_win64_ui_groupbox_exit( n_win64_ui_groupbox *p )
{

	n_string_free( p->label );

	DestroyWindow( p->hwnd );

	n_win64_ui_groupbox_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_GROUPBOX


