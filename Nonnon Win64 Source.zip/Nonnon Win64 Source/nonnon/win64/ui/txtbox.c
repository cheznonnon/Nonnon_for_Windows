﻿// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : these component files use mixed name convention by its history




#ifndef _H_NONNON_WIN64_UI_TXTBOX
#define _H_NONNON_WIN64_UI_TXTBOX





#include "../_windows.c"
#include "../clipboard.c"
#include "../doublebuffer.c"
#include "../font.c"

#include "./window.c"


#include "../../neutral/bmp/ui/rectframe.c"
#include "../../neutral/bmp/ui/roundframe.c"
#include "../../neutral/bmp/ui/search_icon.c"
#include "../../neutral/bmp/ui/timer.c"

#include "../../neutral/txt.c"

#include "../../bridge/gdi.c"




//static HWND n_hwnd;

BOOL
n_txtbox_PtInRect( RECT *r, POINT pt )
{

	RECT rect = (*r);

	rect.right  += rect.left;
	rect.bottom += rect.top;

//n_win64_hwndprintf_literal( n_hwnd, "%d %d : %d %d %d %d", pt.x, pt.y, rect.left, rect.top, rect.right, rect.bottom );

	return PtInRect( &rect, pt );
}




#include "txtbox/00_codec.c"
#include "txtbox/01_character.c"
#include "txtbox/02_caret.c"
#include "txtbox/03_selection.c"
#include "txtbox/04_edit.c"
#include "txtbox/05_date.c"
#include "txtbox/06_undo.c"




#define N_MAC_TXTBOX_MODE_EDITBOX ( 0 )
#define N_MAC_TXTBOX_MODE_LISTBOX ( 1 )
#define N_MAC_TXTBOX_MODE_FINDBOX ( 2 )
#define N_MAC_TXTBOX_MODE_ONELINE ( 3 )


#define N_MAC_TXTBOX_CARET_SIZE   ( 2 )


#define N_MAC_TXTBOX_DRAW_LINENUMBER_NONE            ( 0 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX  ( 1 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX ( 1 << 1 )


#define N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT  ( 1 <<  0 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT    ( 1 <<  1 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT ( 1 <<  2 )
#define N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT   ( 1 <<  3 )
#define N_MAC_TXTBOX_DELEGATE_LISTBOX_EDITED  ( 1 <<  4 )
#define N_MAC_TXTBOX_DELEGATE_LISTBOX_MOVED   ( 1 <<  5 )
#define N_MAC_TXTBOX_DELEGATE_EDITED          ( 1 <<  6 )
#define N_MAC_TXTBOX_DELEGATE_FIND_FOCUS      ( 1 <<  7 )
#define N_MAC_TXTBOX_DELEGATE_SWAP            ( 1 <<  8 )
#define N_MAC_TXTBOX_DELEGATE_F3              ( 1 <<  9 )
#define N_MAC_TXTBOX_DELEGATE_DELETE          ( 1 << 10 )
#define N_MAC_TXTBOX_DELEGATE_SHIFT           ( 1 << 11 )
#define N_MAC_TXTBOX_DELEGATE_UNDO            ( 1 << 12 )
#define N_MAC_TXTBOX_DELEGATE_ALL             0xffff




typedef struct {

	// Public

	n_type_int  focus;

	int         mode;

	int         is_monospace;

	n_type_gfx  ui_stdsize;

	n_posix_char *path;

	n_txt      *txt_data;
	n_txt      *txt_deco;

	BOOL        direct_click_onoff;
	int         option_linenumber;
	BOOL        edited;

	BOOL        is_enter_pressed;

	n_type_real corner_size;
	BOOL        border_separator_only;

	BOOL        listbox_no_selection_onoff;
	BOOL        listbox_edit_onoff;
	BOOL        listbox_no_edit;

	BOOL        path_ellipsis_onoff;
	n_type_int  path_ellipsis_offset;

	BOOL       *search_marker;
	n_type_int  search_marker_count;


	// Private

	HWND        hwnd;
	HDC         hdc;
	n_bmp      *canvas;

	n_win64_doublebuffer doublebuffer;
	n_type_gfx           doublebuffer_psx;
	n_type_gfx           doublebuffer_psy;

	n_type_real offset, offset_x, offset_y;
	n_type_real margin;
	n_type_real padding;

	HFONT       font;
	HFONT       font_cjk;
	HFONT       font_crlf;
	SIZE        font_size;

	n_type_real scroll;
	n_type_real scroll_step;
	n_type_real scroll_page;

	POINT       pt;

	n_type_int  redraw_fy;
	n_type_int  redraw_ty;

	BOOL        is_key_input;

	BOOL        shift_selection_is_tail;

	n_undo      undo;

	BOOL        drag_timer_queue;

	n_bmp_fade  scrollbar_fade;
	BOOL        scrollbar_fade_hovered_onoff;
	BOOL        scrollbar_fade_captured_onoff;
	RECT        scrollbar_thumb_rect;
	BOOL        scrollbar_thumb_is_captured;
	BOOL        scrollbar_thumb_is_hovered;
	n_type_real scrollbar_thumb_offset;
	RECT        scrollbar_shaft_rect;
	BOOL        scrollbar_shaft_is_hovered;

	HFONT       linenumber_font;
	SIZE        linenumber_size;

	POINT       caret_pt;
	n_caret     caret_fr;
	n_caret     caret_to;
	BOOL        caret_blink_onoff;
	BOOL        caret_blink_force_onoff;
	n_bmp_fade  caret_blink_fade;
	u32         caret_blink_interval;
	n_type_real caret_centered_offset;

	n_bmp       find_icon;
	RECT        find_icon_rect;
	BOOL        find_icon_is_pressed;
	BOOL        find_icon_focus_prev;
	BOOL        find_icon_press_prev;
	n_bmp_fade  find_icon_fade;

	BOOL        delete_circle_onoff;
	RECT        delete_circle_rect;

	n_type_int  listbox_edit_index;

	u32         nscolor_white;
	u32         nscolor_black;
	u32         nscolor_gray;
	u32         nscolor_text;
	u32         nscolor_back;
	u32         nscolor_text_highlight;
	u32         nscolor_crlf;
	u32         nscolor_accent;
	u32         nscolor_ime;
	u32         nscolor_stripe;
	u32         nscolor_frame;
	u32         nscolor_text_normal;

	UINT        timer_id_caret_blink;
	UINT        timer_id_scrollbar_fade;
	UINT        timer_id_drag;

	RECT        debug_rect;

	BOOL        ime_composition_onoff;
	BOOL        ime_processed;
	POINT       ime_pt;

} n_txtbox;


#define n_txtbox_zero( p ) n_memory_zero( p, sizeof( n_txtbox ) )




#define n_txtbox_delegate_message( t, w ) n_win64_message_send( GetParent( (t)->hwnd ), WM_COMMAND, w, (t)->hwnd )

void
n_txtbox_edited_notify( n_txtbox *txtbox )
{

	if ( txtbox->edited == FALSE )
	{
		txtbox->edited = TRUE;
		n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_EDITED );
	}


	return;
}

BOOL
n_txtbox_is_hovered( n_txtbox *txtbox, RECT *r )
{
	POINT pt = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

	return n_txtbox_PtInRect( r, pt );
}

void
n_txtbox_reset( n_txtbox *txtbox )
{

	 if ( txtbox->border_separator_only ) { txtbox->offset_x = 4; }


	if ( txtbox->option_linenumber == N_MAC_TXTBOX_DRAW_LINENUMBER_NONE )
	{
		txtbox->padding = txtbox->offset_x;
	} else {
		txtbox->padding = txtbox->offset_x + txtbox->linenumber_size.cx + txtbox->margin;
	}


	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		txtbox->padding += txtbox->ui_stdsize - 3;

		n_type_gfx sz = txtbox->ui_stdsize - 10;
		n_type_gfx  x = txtbox->offset_x + 2;
		n_type_gfx  y = ( txtbox->ui_stdsize - sz ) / 2;

		txtbox->find_icon_rect = n_win64_rect_set( x, y, sz, sz );

		// [!] : X : later moved
		n_type_gfx ds = ( sz - 4 ) + ( ( sz % 2 ) == 0 ); // [!] : odd number
		n_type_gfx dy = ( txtbox->ui_stdsize - ds ) / 2;
		txtbox->delete_circle_rect = n_win64_rect_set( -1, dy, ds, ds );


		n_bmp_ui_search_icon_make( &txtbox->find_icon, 1024, 0, n_bmp_white );

		n_posix_loop
		{
			n_bmp_flush_antialias( &txtbox->find_icon, 1.0 );
			n_bmp_scaler_lil( &txtbox->find_icon, 2 );

			if ( 24 > N_BMP_SX( &txtbox->find_icon ) ) { break; }
		}
	}


	txtbox->scroll = 0;

	if ( txtbox->listbox_no_selection_onoff )
	{
		txtbox->focus = -1;
	} else {
		txtbox->focus = 0;
	}

	txtbox->scrollbar_thumb_rect = n_win64_rect_set( 0,0,0,0 );
	txtbox->scrollbar_shaft_rect = n_win64_rect_set( 0,0,0,0 );


	n_bmp_fade_init( &txtbox->scrollbar_fade, n_bmp_black );

	txtbox->scrollbar_thumb_is_hovered  = txtbox->scrollbar_fade_hovered_onoff  = FALSE;
	txtbox->scrollbar_thumb_is_captured = txtbox->scrollbar_fade_captured_onoff = FALSE;


	POINT point_zero = { 0,0 }; txtbox->caret_pt = point_zero;

	txtbox->caret_fr = NonnonMakeCaret( 0,0,0,0 );
	txtbox->caret_to = NonnonMakeCaret( 0,0,0,0 );

	txtbox->caret_blink_onoff       = TRUE;
	txtbox->caret_blink_force_onoff = FALSE;

	n_bmp_fade_init( &txtbox->caret_blink_fade, n_bmp_black );

	txtbox->shift_selection_is_tail = TRUE;


	txtbox->edited = FALSE;


	txtbox->redraw_fy = -1;
	txtbox->redraw_ty = -1;


	return;
}

void
n_txtbox_color_scheme( n_txtbox *txtbox )
{

	BOOL is_darkmode = n_win64_darkmode_is_on();


	txtbox->nscolor_gray = n_bmp_argb( 255,128,128,128 );
	txtbox->nscolor_text = n_win64_GetSysColor_nbmp( COLOR_WINDOWTEXT );
	txtbox->nscolor_back = n_win64_GetSysColor_nbmp( COLOR_WINDOW );

	txtbox->nscolor_text_normal = txtbox->nscolor_text;

	if ( is_darkmode )
	{
		txtbox->nscolor_text_highlight = txtbox->nscolor_text;
	} else {
		txtbox->nscolor_text_highlight = txtbox->nscolor_back;
	}

	txtbox->nscolor_accent = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );


	return;
}

void
n_txtbox_font_change( n_txtbox *txtbox, HFONT font_new, HFONT font_new_cjk )
{

	// [x] : Windows : each fonts are uglier than macOS


	HDC hdc = GetDC( txtbox->hwnd );


	n_win64_font_exit( txtbox->font );
	txtbox->font = font_new;

	n_win64_font_exit( txtbox->font_cjk );
	txtbox->font_cjk = font_new_cjk;

	txtbox->font_size = n_win64_text_pixelsize( hdc, n_posix_literal( " " ), txtbox->font );


	n_win64_font_exit( txtbox->font_crlf );
	txtbox->font_crlf = n_win64_font_ui();

	txtbox->linenumber_font = font_new;
	txtbox->linenumber_size = n_win64_text_pixelsize( hdc, n_posix_literal( "000000" ), txtbox->linenumber_font );


	ReleaseDC( txtbox->hwnd, hdc );


	return;
}

void
n_txtbox_init( n_txtbox *txtbox, HWND hwnd_parent, n_txt *txt_data )
{

	n_txtbox_zero( txtbox );


	n_bmp_safemode = FALSE;

	n_bmp_transparent_onoff_default = FALSE;


	{
		n_posix_char str_tmp[ 100 ]; n_string_path_tmpname( str_tmp );
		n_string_path_ext_add_literal( ".txt", str_tmp );

    		txtbox->path = n_string_carboncopy( str_tmp );
//NSLog( @"%@", path );
	}


	txtbox->txt_data = txt_data;


	const HINSTANCE hinst = GetModuleHandle( NULL );

	txtbox->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		NULL,
		WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | SS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);


	txtbox->offset = 6;
	txtbox->margin = 3;

	txtbox->offset_x = txtbox->offset_y = txtbox->offset;


	// [!] : FINDBOX uses this

	txtbox->ui_stdsize = 24 + 4;


	n_txtbox_font_change( txtbox, n_win64_font_ui(), n_win64_font_ui() );


	n_txtbox_reset( txtbox );

	n_txtbox_color_scheme( txtbox );


	n_bmp_fade_init( &txtbox->scrollbar_fade, n_bmp_black );


	n_undo_zero( &txtbox->undo ); n_txt_zero( &txtbox->undo.txt ); n_txt_new( &txtbox->undo.txt );


	txtbox->edited = FALSE;


	txtbox->timer_id_caret_blink = n_win64_timer_id_get();
	n_win64_timer_init( hwnd_parent, txtbox->timer_id_caret_blink, 66 );

	txtbox->timer_id_scrollbar_fade = n_win64_timer_id_get();
	n_win64_timer_init( hwnd_parent, txtbox->timer_id_scrollbar_fade, 33 );

	txtbox->timer_id_drag = n_win64_timer_id_get();
	n_win64_timer_init( hwnd_parent, txtbox->timer_id_drag, 33 );

	
	return;
}

void
n_txtbox_exit( n_txtbox *txtbox )
{

	n_string_free( txtbox->path );

	n_txt_free( txtbox->txt_data );
	n_txt_free( txtbox->txt_deco );

	n_bmp_free_fast( &txtbox->find_icon );

	n_win64_font_exit( txtbox->font );
	n_win64_font_exit( txtbox->font_cjk );
	n_win64_font_exit( txtbox->font_crlf );
	//n_win64_font_exit( txtbox->linenumber_font );

	DestroyWindow( txtbox->hwnd );


	n_txtbox_zero( txtbox );


	return;
}




void
n_txtbox_redraw( n_txtbox *txtbox )
{

	n_win64_refresh( txtbox->hwnd, FALSE );

	return;
}

void
n_txtbox_redraw_partial( n_txtbox *txtbox )
{

	n_win64_refresh( txtbox->hwnd, FALSE );

	return;
}




void
NonnonTxtboxSearchMarkerReset( n_txtbox *txtbox, BOOL redraw )
{

	if ( txtbox->search_marker != NULL )
	{
		n_memory_free( txtbox->search_marker );

		txtbox->search_marker       = NULL;
		txtbox->search_marker_count = 0;

		if ( redraw ) { n_txtbox_redraw( txtbox ); }
	}


	return;
}




void
n_txtbox_caret_reset( n_txtbox *txtbox )
{

	txtbox->focus = -1;

	txtbox->caret_fr = NonnonMakeCaret( 0,0,0,0 );
	txtbox->caret_to = NonnonMakeCaret( 0,0,0,0 );


	return;
}

void
n_txtbox_caret_calculate( n_txtbox *txtbox )
{

	// [!] : caret on the current screen

	n_caret pt = txtbox->caret_fr;

	if ( txtbox->caret_fr.cch.y == txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_fr.cch.y == txtbox->focus )
		{
			if ( txtbox->caret_fr.pxl.x == txtbox->caret_to.pxl.x )
			{
//NSLog( @"==" );
				//
			} else
			if ( txtbox->caret_fr.pxl.x < txtbox->caret_to.pxl.x )
			{
//NSLog( @"< : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = txtbox->caret_to;
			} else {
//NSLog( @"> : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = txtbox->caret_to;
			}
		}
	} else
	if ( txtbox->caret_fr.cch.y < txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { pt = txtbox->caret_to; }
	} else
	if ( txtbox->caret_fr.cch.y > txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { pt = txtbox->caret_to; }
	}

	txtbox->caret_pt.x = txtbox->padding + pt.pxl.x - 1;
	txtbox->caret_pt.y = txtbox->offset_y + ( ( pt.cch.y - trunc( txtbox->scroll ) ) * txtbox->font_size.cy );


	return;
}

BOOL
NonnonTxtboxCaretIsOnScreen( n_txtbox *txtbox )
{

	n_txtbox_caret_calculate( txtbox );


	if ( txtbox->focus < ( txtbox->scroll - 1 ) ) { return FALSE; }


	BOOL ret = FALSE;

	if ( txtbox->caret_fr.cch.y == txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_fr.cch.y == txtbox->focus ) { ret = TRUE; }
	} else
	if ( txtbox->caret_fr.cch.y < txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { ret = TRUE; }
	} else
	if ( txtbox->caret_fr.cch.y > txtbox->caret_to.cch.y )
	{
		if ( txtbox->caret_to.cch.y == txtbox->focus ) { ret = TRUE; }
	}


//NSLog( @"%lld : %d", txtbox->focus, ret );


	return ret;
}

void
n_txtbox_caret_tail_set( n_txtbox *txtbox )
{

	txtbox->hdc = GetDC( txtbox->hwnd );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_tail
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		&txtbox->shift_selection_is_tail,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	return;
}




void
n_txtbox_focus2caret( n_txtbox *txtbox )
{

	txtbox->hdc = GetDC( txtbox->hwnd );

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
	n_type_int    cch  = n_posix_strlen( line );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		cch,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	return;
}

n_type_real
n_txtbox_focus_calculate( n_txtbox *txtbox, POINT local_point )
{
	return trunc( txtbox->scroll ) + trunc( ( local_point.y - txtbox->offset_y ) / txtbox->font_size.cy );
}

n_caret
n_txtbox_mouse_cursor_detect( n_txtbox *txtbox )
{

	POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

	txtbox->focus = n_txtbox_focus_calculate( txtbox, local_point );
	if ( txtbox->focus < 0 ) { txtbox->focus = 0; }
	if ( txtbox->focus >= txtbox->txt_data->sy ) { txtbox->focus = txtbox->txt_data->sy - 1; }
//NSLog( @"%f", txtbox->focus );

	RECT c; GetClientRect( txtbox->hwnd, &c );
	RECT r = n_win64_rect_set( txtbox->padding, txtbox->offset_y, c.right - ( txtbox->offset_x * 2 ), txtbox->font_size.cy );

	txtbox->hdc = GetDC( txtbox->hwnd );

	n_caret caret = n_txtbox_caret_detect_pixel2caret
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		r,
		txtbox->font,
		txtbox->font_size,
		local_point,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );

//RECT rct = { txtbox->padding+caret.pxl.x, txtbox->offset_y+caret.pxl.y, txtbox->font_size.cx, txtbox->font_size.cy };
//txtbox->debug_rect = rct;

//NSLog( @"%lld %lld", caret.cch.x, caret.cch.y );


	return caret;
}




void
NonnonTxtboxUndo( n_txtbox *txtbox, int action )
{

	if ( action == N_TXTBOX_UNDO_RESTORE )
	{
		n_txt_copy( &txtbox->undo.txt, txtbox->txt_data );

		txtbox->scroll   = txtbox->undo.scroll;
		txtbox->focus    = txtbox->undo.focus;
		txtbox->caret_fr = txtbox->undo.caret_fr;
		txtbox->caret_to = txtbox->undo.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_REGISTER )
	{
		n_txt_copy( txtbox->txt_data, &txtbox->undo.txt );

		txtbox->undo.scroll   = txtbox->scroll;
		txtbox->undo.focus    = txtbox->focus;
		txtbox->undo.caret_fr = txtbox->caret_fr;
		txtbox->undo.caret_to = txtbox->caret_to;
	}


	return;
}




void
_NonnonTxtboxScrollbarFadeTimer( n_txtbox *txtbox )
{

	if ( txtbox->scrollbar_fade_captured_onoff )
	{
		n_bmp_fade_engine( &txtbox->scrollbar_fade, TRUE );
//NSLog( @"%d", scrollbar_fade.percent );
		if ( txtbox->scrollbar_fade.stop == FALSE )
		{
			n_txtbox_redraw( txtbox );
		} else {
			txtbox->scrollbar_fade_captured_onoff = FALSE;
		}

		return;
	}


//return;

	static BOOL prv = FALSE;

	POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

	BOOL cur = n_txtbox_PtInRect( &txtbox->scrollbar_thumb_rect, local_point );

//NSLog( @"fade %d %d %d", prv, cur, thumb_is_hovered );

	if ( ( prv == FALSE )&&( cur )&&( txtbox->scrollbar_thumb_is_hovered == FALSE ) )
	{
//NSLog( @"fade in" );
		txtbox->scrollbar_thumb_is_hovered = TRUE;

		txtbox->scrollbar_fade_hovered_onoff = TRUE;
		n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
	} else
	if ( ( cur == FALSE )&&( txtbox->scrollbar_thumb_is_hovered ) )
	{
//NSLog( @"fade out" );
		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->scrollbar_fade_hovered_onoff = TRUE;
		n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
	} 

	n_bmp_fade_engine( &txtbox->scrollbar_fade, TRUE );
//NSLog( @"%d", scrollbar_fade.percent );

	if ( txtbox->scrollbar_fade.stop == FALSE )
	{
		n_txtbox_redraw( txtbox );
	} else {
		txtbox->scrollbar_fade_hovered_onoff = FALSE;
	}

	prv = txtbox->scrollbar_thumb_is_hovered;


	return;
}

void
_NonnonTxtboxCaretBlinkTimer( n_txtbox *txtbox )
{
//return;

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		if ( txtbox->listbox_edit_onoff == FALSE ) { return; }
	}


	if ( n_bmp_ui_timer( &txtbox->caret_blink_interval, 500 ) )
	{
		n_bmp_fade_init( &txtbox->caret_blink_fade, n_bmp_black );
		if ( txtbox->caret_blink_onoff )
		{
			n_bmp_fade_go( &txtbox->caret_blink_fade, n_bmp_white );
			txtbox->caret_blink_onoff = txtbox->caret_blink_force_onoff = FALSE;
		} else {
			n_bmp_fade_go( &txtbox->caret_blink_fade, n_bmp_white );
			txtbox->caret_blink_onoff =  TRUE;
		}
	}

	n_bmp_fade_engine( &txtbox->caret_blink_fade, TRUE );


//return;

//NSLog( @"!" );
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
//NSLog( @"N_MAC_TXTBOX_MODE_FINDBOX" );
		n_txtbox_redraw( txtbox );
	} else
	if ( txtbox->is_key_input )
	{
//NSLog( @"is_key_input" );
		n_txtbox_redraw( txtbox );
	} else
	if ( NonnonTxtboxCaretIsOnScreen( txtbox ) )
	{
//NSLog( @"caret" );
		n_txtbox_redraw_partial( txtbox );
	} else
	//
	{
//NSLog( @"N/A" );
	}

}

void
_NonnonTxtboxDragTimer( n_txtbox *txtbox )
{

	if ( txtbox->drag_timer_queue )
	{
		if ( n_win64_is_input( VK_LBUTTON ) )
		{
			POINT pt = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

			RECT client; GetClientRect( txtbox->hwnd, &client );

			if ( pt.y <= 0 )
			{
				n_type_real boost = 1 + ( fabs( pt.y ) / 100 );
				txtbox->scroll -= boost;
			} else
			if ( pt.y >= client.bottom )
			{
				n_type_real boost = 1 + ( fabs( pt.y - client.bottom ) / 100 );
				txtbox->scroll += boost;
			}

			txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );

			n_txtbox_redraw( txtbox );
		} else {
			txtbox->drag_timer_queue = FALSE;
		}
	} else
	if ( txtbox->scrollbar_thumb_is_captured )
	{
		if ( n_win64_is_input( VK_LBUTTON ) )
		{
			POINT pt_cur = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

			n_type_real dy = pt_cur.y - txtbox->pt.y;

			txtbox->pt = pt_cur;

			RECT client; GetClientRect( txtbox->hwnd, &client );

			n_type_real scroll_csy = (n_type_real) client.bottom - ( txtbox->offset_y * 2 );

			n_type_real max_c = (n_type_real) txtbox->txt_data->sy;
			n_type_real step  = scroll_csy / ( max_c * txtbox->font_size.cy );


			txtbox->scroll += dy / ( txtbox->font_size.cy * step );

			n_txtbox_redraw( txtbox );
		} else {
			txtbox->scrollbar_thumb_is_captured = FALSE;
		}
	}

}




void
NonnonTxtboxKeyboardInputMethod( n_txtbox *txtbox, n_posix_char *str )
{
//return;

	// [x] : don't make undo buffer : NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );


	if ( txtbox->txt_data->readonly ) { return; }


	n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );
//return;

	extern void n_txtbox_edit_insert( n_txtbox *txtbox, n_posix_char *text );
	n_txtbox_edit_insert( txtbox, str );


	n_txtbox_edited_notify( txtbox );


	extern void NonnonTxtboxCaretOutOfCanvasUpDown( n_txtbox *txtbox );
	NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );

	n_txtbox_redraw( txtbox );


	return;
}




void
NonnonTxtboxTripleClickDetect( n_txtbox *txtbox )
{
//NSLog( @"%f", txtbox->focus );

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
	n_type_int    cch  = n_posix_strlen( line );

	txtbox->hdc = GetDC( txtbox->hwnd );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		cch,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	txtbox->caret_fr = NonnonMakeCaret
	(
		0, txtbox->focus * txtbox->font_size.cy,
		0, txtbox->focus
	);

	txtbox->caret_to = NonnonMakeCaret
	(
		caret.pxl.x, txtbox->focus * txtbox->font_size.cy,
		cch, txtbox->focus
	);

	txtbox->shift_selection_is_tail = TRUE;


	return;
}

void
NonnonTxtboxDoubleClickDetect( n_txtbox *txtbox, BOOL smart_selection_onoff, BOOL tab_patch )
{
//return;

	// [x] : Xcode : bug : japanese characters are not output

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
//NSLog( @"%lld : %s", txtbox->focus, line ); return;
//NSLog( @"%c", line[ caret_fr.cch.x ] );


	// [x] : Win64 : not working accurately

//smart_selection_onoff = TRUE;


	txtbox->hdc = GetDC( txtbox->hwnd );

	if (
		( line[ txtbox->caret_fr.cch.x ] == N_STRING_CHAR_SPACE )
		||
		( line[ txtbox->caret_fr.cch.x ] == N_STRING_CHAR_TAB )
		||
		(
			( tab_patch )
			&&
			( ( txtbox->caret_fr.cch.x > 0 )&&( line[ txtbox->caret_fr.cch.x - 1 ] == N_STRING_CHAR_TAB ) )
		)
	)
	{
//NSLog( @"blank" );

		if (
			( tab_patch )
			&&
			( ( txtbox->caret_fr.cch.x > 0 )&&( line[ txtbox->caret_fr.cch.x - 1 ] == N_STRING_CHAR_TAB ) )
		)
		{
			txtbox->caret_fr.cch.x--;
		}

		{

			n_type_int cch_fr = txtbox->caret_fr.cch.x;
			n_posix_loop
			{
				if ( cch_fr <= 0 ) { break; }

//NSLog( @"%c", line[ cch_fr ] );

				if (
					( line[ cch_fr ] != N_STRING_CHAR_SPACE )
					&&
					( line[ cch_fr ] != N_STRING_CHAR_TAB )
				)
				{
					cch_fr++;
					break;
				}

				cch_fr--;
			}


			txtbox->caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->hdc,
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_fr,
				txtbox->is_monospace
			);

		}

		{

			n_type_int cch_to = txtbox->caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == N_STRING_CHAR_NUL ) { break; }

				if (
					( line[ cch_to ] != N_STRING_CHAR_SPACE )
					&&
					( line[ cch_to ] != N_STRING_CHAR_TAB )
				)
				{
					break;
				}

				cch_to++;
			}


			txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->hdc,
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_to,
				txtbox->is_monospace
			);

		}

	} else {
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "non-blank : %s : %c", line, line[ txtbox->caret_fr.cch.x ] );

		n_posix_char *starting_char = &line[ txtbox->caret_fr.cch.x ];

		{
			const n_type_int step = 1;

			n_type_int cch_fr = txtbox->caret_fr.cch.x;
//NSLog( @"start %c", line[ cch_fr ] );

			n_posix_loop
			{
				if ( cch_fr < 0 ) { cch_fr = 0; break; }

				if (
					( line[ cch_fr ] == N_STRING_CHAR_SPACE )
					||
					( line[ cch_fr ] == N_STRING_CHAR_TAB )
					||
					(
						( smart_selection_onoff )
						&&
						(
							( n_mac_txtbox_selection_is_stop_char_utf16( starting_char, &line[ cch_fr ] ) )
							||
							( n_mac_txtbox_digit_detect( starting_char, line, cch_fr ) )
						)
					)
				)
				{
					cch_fr += step;
					break;
				}

				cch_fr--;
			}

			txtbox->caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->hdc,
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_fr,
				txtbox->is_monospace
			);

//NSLog( @"%c", line[ cch_fr ] );

		}

		{
			const n_type_int step = 1;

			n_type_int cch_to = txtbox->caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == N_STRING_CHAR_NUL ) { break; }

				if (
					( line[ cch_to ] == N_STRING_CHAR_SPACE )
					||
					( line[ cch_to ] == N_STRING_CHAR_TAB )
					||
					(
						( smart_selection_onoff )
						&&
						(
							( n_mac_txtbox_selection_is_stop_char_utf16( starting_char, &line[ cch_to ] ) )
							||
							( n_mac_txtbox_digit_detect( starting_char, line, cch_to ) )
						)
					)
				)
				{
//NSLog( @"To : found %@", n_mac_str2nsstring( &line[ cch_to ] ) );
					break;
				}

				cch_to += step;
			}


			txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
			(
				txtbox->hdc,
				txtbox->txt_data,
				txtbox->focus,
				txtbox->font,
				txtbox->font_size,
				cch_to,
				txtbox->is_monospace
			);

		}

	}

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	txtbox->shift_selection_is_tail = TRUE;


//n_caret_debug_cch( caret_fr, caret_to );
	return;	
}




void
NonnonTxtboxCaretOutOfCanvasUpDown( n_txtbox *txtbox )
{
//NSLog( @"NonnonTxtboxCaretOutOfCanvasUpDown" );

	RECT frame; GetClientRect( txtbox->hwnd, &frame );

	n_type_real csy              = frame.bottom - ( txtbox->offset_y * 2 );
	n_type_real items_per_canvas = trunc( csy / txtbox->font_size.cy );


	n_type_real minim = n_posix_min_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
	n_type_real maxim = n_posix_max_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
//NSLog( @"%f %f %f %f", minim, maxim, scroll, items_per_canvas );

	// [!] : out of bound : centering

	if ( minim < ( trunc( txtbox->scroll ) - 1 ) )
	{
//NSLog( @"minim" );
		txtbox->scroll = minim - ( items_per_canvas / 2 );
		return;
	} else
	if ( maxim >= ( trunc( txtbox->scroll ) + items_per_canvas + 1 ) )
	{
//NSLog( @"maxim" );
		txtbox->scroll = maxim - ( items_per_canvas / 2 );
		return;
	} else {
//NSLog( @"others" );
	}

	// [!] : scroll per one line

	if ( minim < trunc( txtbox->scroll ) )
	{
		txtbox->scroll--;
	} else
	if ( maxim >= ( trunc( txtbox->scroll ) + items_per_canvas ) )
	{
		txtbox->scroll++;
	}


	return;
}

void
NonnonTxtboxCaretOutOfCanvasUpDownListbox( n_txtbox *txtbox )
{
//NSLog( @"NonnonTxtboxCaretOutOfCanvasUpDownListbox" );

	RECT frame; GetClientRect( txtbox->hwnd, &frame );

	n_type_real csy              = frame.bottom - ( txtbox->offset_y * 2 );
	n_type_real items_per_canvas = trunc( csy / txtbox->font_size.cy );


	n_type_real minim = txtbox->focus;//MIN( caret_fr.cch.y, caret_to.cch.y );
	n_type_real maxim = txtbox->focus;//MAX( caret_fr.cch.y, caret_to.cch.y );
//NSLog( @"%f %f %f %f", minim, maxim, scroll, items_per_canvas );

	// [!] : out of bound : centering

	if ( minim < ( trunc( txtbox->scroll ) - 1 ) )
	{
//NSLog( @"minim" );
		txtbox->scroll = minim - ( items_per_canvas / 2 );
		return;
	} else
	if ( maxim >= ( trunc( txtbox->scroll ) + items_per_canvas + 1 ) )
	{
//NSLog( @"maxim" );
		txtbox->scroll = maxim - ( items_per_canvas / 2 );
		return;
	} else {
//NSLog( @"others" );
	}

	// [!] : scroll per one line

	if ( minim < trunc( txtbox->scroll ) )
	{
		txtbox->scroll--;
	} else
	if ( maxim >= ( trunc( txtbox->scroll ) + items_per_canvas ) )
	{
		txtbox->scroll++;
	}


	return;
}

void
NonnonTxtboxCaretOutOfCanvasUpDownSearch( n_txtbox *txtbox )
{
//NSLog( @"NonnonTxtboxCaretOutOfCanvasUpDown" );

	RECT frame; GetClientRect( txtbox->hwnd, &frame );

	n_type_real csy              = frame.bottom - ( txtbox->offset_y * 2 );
	n_type_real items_per_canvas = csy / txtbox->font_size.cy;


	n_type_real minim = n_posix_min_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
	n_type_real maxim = n_posix_max_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
//NSLog( @"%f %f %f", minim, maxim, scroll );

	if ( minim < txtbox->scroll )
	{
//NSLog( @"up" );
		txtbox->scroll = minim - ( items_per_canvas / 2 );
	} else
	if ( maxim >= ( txtbox->scroll + items_per_canvas - 1 ) )
	{
//NSLog( @"down : %f %f", maxim, ( scroll + items_per_canvas - 1 ) );
		txtbox->scroll = maxim - ( items_per_canvas / 2 );
	}


	return;
}




void
NonnonTxtboxInsert( n_txtbox *txtbox, n_posix_char *string )
{
//return;

	if ( txtbox->txt_data->readonly ) { return; }


	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		if ( txtbox->listbox_edit_onoff == FALSE ) { return; }
	}


	n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );


//n_caret_debug_cch( caret_fr, caret_to );

	n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );

	n_posix_char *line_f = n_string_carboncopy( line );
	n_posix_char *line_m = string;
	n_posix_char *line_t = n_string_carboncopy( line );

//NSLog( @"modified : %s : %@", line_f, n_mac_str2nsstring( line_t ) );


	n_type_int cch_f = n_posix_strlen( line_f );
	n_type_int cch_m = n_posix_strlen( line_m );
	n_type_int cch_t = n_posix_strlen( line_t );


	n_posix_char *mod = n_string_new( cch_f + cch_m + cch_t );

	n_posix_snprintf_literal( mod, cch_f + cch_m + cch_t + 1, "%s%s%s", line_f, line_m, line_t );
//NSLog( @"%s : %s : %s", line_f, line_m, line_t );

	n_txt_mod_fast( txtbox->txt_data, txtbox->focus, mod );


	n_string_free( line_f );
	//n_string_free( line_m );
	n_string_free( line_t );


	txtbox->hdc = GetDC( txtbox->hwnd );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->caret_fr.cch.x + cch_m,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	n_txtbox_edited_notify( txtbox );


	return;
}

void
NonnonTxtboxSelectAll( n_txtbox *txtbox, BOOL redraw )
{

	txtbox->caret_fr = NonnonMakeCaret( 0, 0, 0, 0 );
	
	txtbox->hdc = GetDC( txtbox->hwnd );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->txt_data->sy - 1,
		txtbox->font,
		txtbox->font_size,
		n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->txt_data->sy - 1 ) ),
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );

	txtbox->caret_to = NonnonMakeCaret
	(
		caret.pxl.x,
		( (n_type_real) txtbox->txt_data->sy - 1 ) * txtbox->font_size.cy,
		caret.cch.x,
		txtbox->txt_data->sy - 1
	);

	if ( redraw )
	{
		n_txtbox_redraw( txtbox );
	}


	return;
}






#include "txtbox/07_dnd.c"
#include "txtbox/08_draw.c"
#include "txtbox/09_search.c"
#include "txtbox/10_keyboard.c"
#include "txtbox/11_mouse.c"




LRESULT CALLBACK
n_win64_txtbox_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_txtbox *txtbox = (void*) dwRefData;
	if ( txtbox == NULL ) { return 0; }


	switch( msg ) {

	case WM_IME_REQUEST :
	{
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), " WM_IME_REQUEST : %d %x ", wParam, lParam );
//n_posix_debug_literal( " WM_IME_REQUEST " );

		if ( txtbox->txt_data->readonly ) { break; }

		if ( wParam == IMR_RECONVERTSTRING )
		{

			//n_posix_char *line = n_txt_get( &txtbox->txt_data, txtbox->focus );
			//n_posix_char *word = n_string_carboncopy( &line[ p->select_cch_x ] );

			n_posix_char *word = n_mac_txtbox_copy( txtbox->txt_data, txtbox->caret_fr.cch.x, txtbox->caret_fr.cch.y, txtbox->caret_to.cch.x, txtbox->caret_to.cch.y );

			n_type_int    word_cch = n_posix_strlen( word ) + 1;
			n_type_int    word_cb  = sizeof( n_posix_char    ) * word_cch;
			n_type_int    rcnv_cb  = sizeof( RECONVERTSTRING );
			u8           *data     = (void*) lParam;
			LRESULT       lret     = rcnv_cb + word_cb;

			if ( data != NULL )
			{

				RECONVERTSTRING rcs = { (DWORD) rcnv_cb, 0, (DWORD) word_cch, (DWORD) rcnv_cb, (DWORD) word_cch, 0, (DWORD) word_cch, 0, };
				n_type_int      i   = 0;

				n_memory_copy( &rcs, &data[ i ], rcnv_cb ); i += rcnv_cb;
				n_memory_copy( word, &data[ i ], word_cb ); i += word_cb;

				n_win64_message_send( hwnd, WM_IME_COMPOSITION, 0,0 );

				lret = (LRESULT) data;

			}

			n_memory_free( word );

			return lret;

		} else
		if ( wParam == IMR_CONFIRMRECONVERTSTRING )
		{

			// [!] : never sent

		} else
		if ( wParam == IMR_QUERYCHARPOSITION )
		{
//n_posix_debug_literal( " ! " );

			IMECHARPOSITION *icp = (void*) lParam;
			if ( icp == NULL ) { break; }

			RECT            rect = n_win64_rect_set( 0,0,0,0 );
			POINT           pt   = txtbox->ime_pt; ClientToScreen( hwnd, &pt );
			IMECHARPOSITION ret  = { sizeof( IMECHARPOSITION ), 0, pt, 24, rect };

			(*icp) = ret;

			return TRUE;
		}

	}
	break;

	case WM_IME_STARTCOMPOSITION :
	{
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), " WM_IME_STARTCOMPOSITION " );
//n_posix_debug_literal( " WM_IME_STARTCOMPOSITION " );

		if ( txtbox->txt_data->readonly ) { break; }


		txtbox->ime_composition_onoff = TRUE;


		HIMC himc = ImmGetContext( hwnd );

		LOGFONT lf = n_win64_font_hfont2logfont( txtbox->font_cjk );
		ImmSetCompositionFont( himc, &lf );

		COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, txtbox->ime_pt, { 0,0,0,0 } };
		ImmSetCompositionWindow( himc, &cf );

	}
	break;

	case WM_IME_COMPOSITION :
	{
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), " WM_IME_COMPOSITION : %d %x ", wParam, lParam );
//n_posix_debug_literal( " WM_IME_COMPOSITION " );

		if ( txtbox->txt_data->readonly ) { break; }

		// [!] : this message can replace WM_IME_STARTCOMPOSITION and WM_IME_ENDCOMPOSITION

		// [ Mechanism ]
		//
		//	0x01b9 : Start
		//	0x1e00 : End
		//	0x1fb9 : Auto-Confirmation : End + Start

		const int start = GCS_DELTASTART | GCS_CURSORPOS | GCS_COMPCLAUSE | GCS_COMPATTR | GCS_COMPSTR | GCS_COMPREADSTR;
		const int end   = GCS_RESULTCLAUSE | GCS_RESULTSTR | GCS_RESULTREADCLAUSE | GCS_RESULTREADSTR;

		HIMC himc = ImmGetContext( hwnd );

		if ( lParam & end )
		{

			// [ Mechanism ] : ImmGetCompositionString()
			//
			//	this API doesn't write "\0"
			//
			//	return value will always be DBCS unit
			//	an ASCII character will be 1
			//	a  kanji character will be 2

			n_type_int n = (n_type_int) ImmGetCompositionString( himc, GCS_RESULTSTR, NULL, 0 );
			if ( n > ULONG_MAX ) { break; }

			n_posix_char *s = n_string_new( n * 4 );
			if ( s == NULL ) { break; }

			ImmGetCompositionString( himc, GCS_RESULTSTR, s, (DWORD) n );

			n_txtbox_edit_insert( txtbox, s );
			n_txtbox_redraw( txtbox );

			n_memory_free( s );

		}

		if ( lParam & start )
		{

			LOGFONT lf = n_win64_font_hfont2logfont( txtbox->font_cjk );
			ImmSetCompositionFont( himc, &lf );

			COMPOSITIONFORM cf = { CFS_FORCE_POSITION | CFS_POINT, txtbox->ime_pt, { 0,0,0,0 } };
			ImmSetCompositionWindow( himc, &cf );

//HWND h = ImmGetDefaultIMEWnd( hwnd );
//ShowWindow( h, SW_HIDE );
		}

		ImmReleaseContext( hwnd, himc );

	}
	break;

	case WM_IME_ENDCOMPOSITION :
//n_posix_debug_literal( " WM_IME_ENDCOMPOSITION " );

		txtbox->ime_composition_onoff = FALSE;

	break;

	case WM_IME_NOTIFY :

		//

	break;


	case WM_ERASEBKGND :

		return 1;

	break;
/*
	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );

		EndPaint( hwnd, &ps );

		return 0;
	}
	break;
*/

	} // switch


	n_win64_txtbox_proc_keyboard( hwnd, msg, wParam, lParam, txtbox );


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_txtbox_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_txtbox *txtbox )
{

	switch( msg ) {


	case WM_CREATE :

		SetWindowSubclass( txtbox->hwnd, n_win64_txtbox_subclass, 0, (DWORD_PTR) txtbox );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( txtbox->hwnd != di->hwndItem ) { break; }

		NonnonTxtboxDraw( txtbox );

	}
	break;


	case WM_TIMER :

		if ( wParam == txtbox->timer_id_caret_blink )
		{
			_NonnonTxtboxCaretBlinkTimer( txtbox );
		} else
		if ( wParam == txtbox->timer_id_scrollbar_fade )
		{
			_NonnonTxtboxScrollbarFadeTimer( txtbox );
		} else
		if ( wParam == txtbox->timer_id_drag )
		{
			_NonnonTxtboxDragTimer( txtbox );
		}

	break;

	} // switch


	n_win64_txtbox_proc_mouse( hwnd, msg, wParam, lParam, txtbox );


	return;
}




#endif // _H_NONNON_WIN64_UI_TXTBOX


