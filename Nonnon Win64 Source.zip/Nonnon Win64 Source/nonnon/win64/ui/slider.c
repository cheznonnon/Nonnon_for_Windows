// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_SLIDER
#define _H_NONNON_WIN64_UI_SLIDER





#include "../_windows.c"
#include "../doublebuffer.c"




#define N_WIN64_UI_SLIDER_LAYOUT_HORZ ( 0 )
#define N_WIN64_UI_SLIDER_LAYOUT_VERT ( 1 )




typedef struct {

	HWND hwnd;

	int  layout;
	BOOL tick_onoff;

	int  pos;
	int  maxim;

	RECT rect_shaft;
	RECT rect_knob;

	BOOL  drag_onoff;
	POINT drag_pt;

	n_win64_doublebuffer db;

} n_win64_ui_slider;


#define n_win64_ui_slider_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_slider ) )




// internal
void
n_win64_ui_slider_draw( n_win64_ui_slider *p, BOOL delayed_render )
{

	// Metrics

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );

	n_type_gfx sz = n_win64_ui_stdsize( p->hwnd ) / 4 * 3; sz += ( 0 == ( sz % 2 ) ); // [!] : odd number

	const n_type_gfx padding = sz / 2;


	// Main

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );

	n_bmp *bmp = &p->db.bmp;


	u32 color_bg = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 color_ln = n_win64_GetSysColor_nbmp( COLOR_BTNSHADOW );
	u32 color_kn = n_win64_GetSysColor_nbmp( COLOR_ACTIVECAPTION );


	// Draw

	n_bmp_flush( bmp, color_bg );


	// Shaft

	n_type_gfx shaft_size;

	{
		const n_type_gfx thickness = 3;

		n_type_gfx tx, ty, tsx, tsy;

		if ( p->layout == N_WIN64_UI_SLIDER_LAYOUT_HORZ )
		{
			tx  = padding;
			ty  = ( csy / 2 ) - ( thickness / 2 );
			tsx = csx - ( padding * 2 );
			tsy = thickness;

			shaft_size = tsx;
		} else {
			tx  = ( csx / 2 ) - ( thickness / 2 );
			ty  = padding;
			tsx = thickness;
			tsy = csy - ( padding * 2 );

			shaft_size = tsy;
		}

		n_bmp_box( bmp, tx,ty,tsx,tsy, color_ln );

		p->rect_shaft = n_win64_rect_set( tx,ty, tx+tsx,ty+tsy );
	}


	// Tick

	if ( p->tick_onoff )
	{
		n_type_real step = (n_type_real) shaft_size / p->maxim;
		n_type_real tick = sz / 2;

		if ( p->layout == N_WIN64_UI_SLIDER_LAYOUT_HORZ )
		{
			n_type_real center = csy / 2;

			n_bmp_box( bmp,       padding, center-tick, 1, tick*2+1, color_ln ); // [!] :  left edge
			n_bmp_box( bmp, csx - padding, center-tick, 1, tick*2+1, color_ln ); // [!] : right edge

			n_type_gfx  i  = 1;
			n_type_real tx = padding + ( step * i );
			n_posix_loop
			{//break;

				n_bmp_box( bmp, tx, center-tick/2, 1, tick+2, color_ln );

				tx += step;

				i++;
				if ( i >= p->maxim ) { break; }
			}
		} else {
			n_type_real center = csx / 2;

			n_bmp_box( bmp, center-tick,       padding, tick*2+1, 1, color_ln ); // [!] :    top edge
			n_bmp_box( bmp, center-tick, csy - padding, tick*2+1, 1, color_ln ); // [!] : bottom edge

			n_type_gfx  i  = 1;
			n_type_real ty = padding + ( step * i );
			n_posix_loop
			{//break;

				n_bmp_box( bmp, center-tick/2, ty, tick+2, 1, color_ln );

				ty += step;

				i++;
				if ( i >= p->maxim ) { break; }
			}
		}
	}


	// Knob

	if ( IsWindowEnabled( p->hwnd ) )
	{
//p->pos = 5;

		n_type_gfx tx,ty;

		if ( p->layout == N_WIN64_UI_SLIDER_LAYOUT_HORZ )
		{
			const n_type_real norm   = (n_type_real) p->pos / p->maxim;
			const n_type_real offset = padding + ( norm * shaft_size ); 
			const n_type_real half   = sz / 2;

			tx = offset - half;
			ty = ( csy / 2 ) - half;
		} else {
			const n_type_real norm   = (n_type_real) ( p->maxim - p->pos ) / p->maxim;
			const n_type_real offset = padding + ( norm * shaft_size ); 
			const n_type_real half   = sz / 2;

			tx = ( csx / 2 ) - half;
			ty = offset - half;
		}

		p->rect_knob = n_win64_rect_set( tx,ty, tx+sz,ty+sz );


		n_bmp_circle( bmp, tx,ty,sz,sz, color_kn );


		n_type_gfx border = 2;

		tx += border;
		ty += border;
		sz -= border * 2;

		n_bmp_circle( bmp, tx,ty,sz,sz, n_bmp_white );

	}


	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}


	return;
}

void
n_win64_ui_slider_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_slider *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_slider_draw( p, FALSE );

	}
	break;


	} // switch


	return;
}

// internal
LRESULT CALLBACK
n_win64_ui_slider_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_slider *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_LBUTTONUP :
	{
		ReleaseCapture();

		p->drag_onoff = FALSE;
	}
	break;

	case WM_LBUTTONDOWN :
	{
		p->drag_pt = n_win64_cursor_position_relative_POINT( hwnd );
/*
n_win64_hwndprintf_literal
(
	GetParent( hwnd ),
	"%d %d : %d %d %d %d : %d",
	p->drag_pt.x, p->drag_pt.y,
	p->rect_knob.left, p->rect_knob.top, p->rect_knob.right, p->rect_knob.bottom,
	PtInRect( &p->rect_knob, p->drag_pt )
);
*/
		if ( PtInRect( &p->rect_knob, p->drag_pt ) )
		{
			SetCapture( p->hwnd );
			p->drag_onoff = TRUE;
		}
	}
	break;

	case WM_MOUSEMOVE :
	{
		if ( p->drag_onoff )
		{
			p->drag_pt = n_win64_cursor_position_relative_POINT( hwnd );
			if ( p->layout == N_WIN64_UI_SLIDER_LAYOUT_HORZ )
			{
				n_type_real size = p->rect_shaft.right - p->rect_shaft.left;
				n_type_real norm = (n_type_real) p->drag_pt.x / size;

				p->pos = (n_type_real) p->maxim * norm;

				if ( p->pos < 0 ) { p->pos = 0; } else if ( p->pos > p->maxim ) { p->pos = p->maxim; }

				n_win64_refresh( p->hwnd, FALSE );
			} else {
				n_type_real size = p->rect_shaft.bottom - p->rect_shaft.top;
				n_type_real norm = (n_type_real) p->drag_pt.y / size;

				p->pos = (n_type_real) p->maxim * norm;
				p->pos = p->maxim - p->pos;

				if ( p->pos < 0 ) { p->pos = 0; } else if ( p->pos > p->maxim ) { p->pos = p->maxim; }

				n_win64_refresh( p->hwnd, FALSE );
			}

			n_win64_message_send( GetParent( p->hwnd ), WM_COMMAND, 0, p->hwnd );
		}
	}
	break;


	} // switch


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_slider_init( n_win64_ui_slider *p, HWND hwnd_parent, int layout, int maxim )
{

	n_win64_ui_slider_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_slider_subclass, 0, (DWORD_PTR) p );


	p->layout = layout;
	p->maxim  = maxim;


	return;
}

void
n_win64_ui_slider_exit( n_win64_ui_slider *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_slider_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_SLIDER


