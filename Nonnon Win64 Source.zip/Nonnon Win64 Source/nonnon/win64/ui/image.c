// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_IMAGE
#define _H_NONNON_WIN64_UI_IMAGE





#include "../_windows.c"
#include "../doublebuffer.c"




typedef struct {

	HWND         hwnd;

	n_bmp        bmp;

	n_win64_doublebuffer db;

} n_win64_ui_image;


#define n_win64_ui_image_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_image ) )




// internal
void
n_win64_ui_image_draw( n_win64_ui_image *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );


	// Main

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/


	// Draw

	n_bmp_flush_fastcopy( &p->bmp, bmp );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}

void
n_win64_ui_image_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_image *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_image_draw( p, FALSE );

	}
	break;


	} // switch


	return;
}




void
n_win64_ui_image_init( n_win64_ui_image *p, HWND hwnd_parent )
{

	n_win64_ui_image_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | SS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	//SetWindowSubclass( p->hwnd, n_win64_ui_image_subclass, 0, (DWORD_PTR) p );


	return;
}

void
n_win64_ui_image_exit( n_win64_ui_image *p )
{

	n_bmp_free_fast( &p->bmp );

	DestroyWindow( p->hwnd );

	n_win64_ui_image_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_IMAGE


