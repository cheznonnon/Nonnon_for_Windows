// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_PREVIEW
#define _H_NONNON_WIN64_UI_PREVIEW




#include "../../_windows.c"
#include "../../doublebuffer.c"


#include "../../../neutral/bmp/ui/roundframe.c"




typedef struct {

	HWND         hwnd;

	HFONT        font;
	n_posix_char text[ 100 ];

	n_win64_doublebuffer db;

} n_win64_ui_preview;


#define n_win64_ui_preview_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_preview ) )




// internal
void
n_win64_ui_preview_draw( n_win64_ui_preview *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );


	// Main

	HDC hdc = n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/


	// Draw

	RECT rect = { 0,0,csx,csy };

	u32      color_bg;
	COLORREF colorref_text;

	color_bg      = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	colorref_text = RGB( 0,0,0 );


	n_type_gfx round = 8;
	n_type_gfx frame = 1;

	n_bmp_flush( bmp, color_bg );
	n_bmp_ui_roundframe( bmp, 0,0,csx,csy, round, frame, n_bmp_rgb( 222,222,222 ), n_bmp_white );


	SetBkMode   ( hdc, TRANSPARENT );
	SetTextColor( hdc, colorref_text );


	HFONT hf = SelectObject( hdc, p->font );

	const int dt = DT_NOPREFIX | DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );// | DT_NOCLIP;
	DrawText( hdc, p->text, -1, &rect, dt );

	SelectObject( hdc, hf );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}

void
n_win64_ui_preview_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_preview *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_preview_draw( p, FALSE );

	}
	break;


	} // switch


	return;
}




void
n_win64_ui_preview_init( n_win64_ui_preview *p, HWND hwnd_parent )
{

	n_win64_ui_preview_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | SS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	//SetWindowSubclass( p->hwnd, n_win64_ui_preview_subclass, 0, (DWORD_PTR) p );


	return;
}

void
n_win64_ui_preview_exit( n_win64_ui_preview *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_preview_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_PREVIEW


