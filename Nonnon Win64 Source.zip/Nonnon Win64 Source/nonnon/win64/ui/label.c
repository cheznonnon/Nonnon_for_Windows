// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_LABEL
#define _H_NONNON_WIN64_UI_LABEL





#include "../_windows.c"
#include "../doublebuffer.c"




typedef struct {

	HWND         hwnd;

	n_posix_char label[ 100 ];

	n_win64_doublebuffer db;

} n_win64_ui_label;


#define n_win64_ui_label_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_label ) )




// internal
void
n_win64_ui_label_gdi( n_win64_ui_label *p, n_bmp *bmp, n_posix_char *str, u32 color_bg, u32 color_text )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.base_color_bg       = color_bg;
	gdi.base_style          = N_GDI_BASE_SOLID;


	HFONT hfont = n_win64_font_ui();

	n_posix_char font_name[ LF_FACESIZE ];
	n_type_gfx   font_size = n_win64_font_hfont2size( hfont );

	n_win64_font_hfont2name( hfont, font_name );

	n_win64_font_exit( hfont );


	gdi.text                = str;
	gdi.text_font           = font_name;
	gdi.text_size           = font_size;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = color_text;

	n_gdi_bmp( &gdi, bmp );


	return;
}

// internal
void
n_win64_ui_label_draw( n_win64_ui_label *p, BOOL delayed_render )
{

	n_type_gfx csx,csy; n_win64_control_size( p->hwnd, &csx, &csy );


	// Main

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	n_win64_doublebuffer_init( &p->db, p->hwnd, NULL, csx,csy );
	n_bmp *bmp = &p->db.bmp;

/*
	n_win64_doublebuffer db;

	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_init( &db, p->hwnd, NULL, csx,csy );
	} else {
		db = *db_parent;
		n_win64_control_position_on_parent( p->hwnd, &x, &y );
	}

	n_bmp *bmp = &db.bmp;
*/


	u32 color_back = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	u32 color_text = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );

	if ( FALSE == IsWindowEnabled( p->hwnd ) )
	{
		color_text = n_bmp_blend_pixel( color_back, color_text, 0.5 );
	}


	// Draw

	n_bmp_flush( bmp, color_back );


	//n_type_gfx text_sy = n_win64_ui_stdsize( p->hwnd );


	n_bmp label; n_bmp_zero( &label );
	n_win64_ui_label_gdi( p, &label, p->label, color_back, color_text );

	n_type_gfx xx = ( csx - N_BMP_SX( &label ) ) / 2;
	n_type_gfx yy = ( csy - N_BMP_SY( &label ) ) / 2;

	n_bmp_transcopy( &label, bmp, 0,0,N_BMP_SX( &label ),N_BMP_SY( &label ), x+xx, y+yy );

	n_bmp_free_fast( &label );


	// Done!

	if ( delayed_render == FALSE )
	{
		n_win64_doublebuffer_exit( &p->db );
	}
/*
	if ( db_parent == NULL )
	{
		n_win64_doublebuffer_exit( &db );
	}
*/

	return;
}

void
n_win64_ui_label_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_label *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }

		if ( p->hwnd != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win64_ui_label_draw( p, NULL );

	}
	break;


	} // switch


	return;
}




void
n_win64_ui_label_value_set( n_win64_ui_label *p, int value )
{

	n_posix_snprintf_literal( p->label, 100, "%d", value );

	n_win64_refresh( p->hwnd, FALSE );

	return;
}




void
n_win64_ui_label_init( n_win64_ui_label *p, HWND hwnd_parent, n_posix_char *label )
{

	n_win64_ui_label_zero( p );


	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "STATIC" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | SS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	//SetWindowSubclass( p->hwnd, n_win64_ui_label_subclass, 0, (DWORD_PTR) p );

	n_posix_snprintf_literal( p->label, 100, "%s", label );


	return;
}

void
n_win64_ui_label_exit( n_win64_ui_label *p )
{

	DestroyWindow( p->hwnd );

	n_win64_ui_label_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_LABEL


