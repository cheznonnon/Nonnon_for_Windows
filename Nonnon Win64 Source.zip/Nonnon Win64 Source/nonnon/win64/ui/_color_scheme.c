// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Needed] : Link : -ldwmapi




#ifndef _H_NONNON_WIN64_UI_COLOR_SCHEME
#define _H_NONNON_WIN64_UI_COLOR_SCHEME




#include "../../neutral/bmp.c"


#include "../registry.c"


#include <dwmapi.h>




BOOL
n_win64_color_scheme_darkmode_is_on( void )
{

	u32 light_onoff = 1;


	n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" );
	n_posix_char *section = n_posix_literal( "AppsUseLightTheme" );

	n_win64_registry_read( HKEY_CURRENT_USER, subkey, section, &light_onoff, sizeof( u32 ) );


	return ( light_onoff == 0 );
}

#define n_win64_darkmode_titlebar_auto( hwnd ) n_win64_darkmode_titlebar( hwnd, n_win64_color_scheme_darkmode_is_on() )

void
n_win64_darkmode_titlebar( HWND hwnd, BOOL onoff )
{

	// [x] : currently not working

	// [!] : enum DWMWINDOWATTRIBUTE
	//const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

//onoff = TRUE;
	DwmSetWindowAttribute( hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &onoff, sizeof( onoff ) );

	//InvalidateRect( hwnd, NULL, TRUE );


	return;
}




#define n_win64_color_scheme_accent_color_COLORREF GetSysColor( COLOR_HIGHLIGHT )

u32
n_win64_color_scheme_accent_color_get( void )
{

	COLORREF color = GetSysColor( COLOR_HIGHLIGHT );

	int r = GetRValue( color );
	int g = GetGValue( color );
	int b = GetBValue( color );

	return n_bmp_rgb( r, g, b );
}

COLORREF
n_win64_color_scheme_base_color_COLORREF( void )
{

	// [x] : currently not supported

	if ( n_win64_color_scheme_darkmode_is_on() )
	{
		return RGB(  66, 66, 66 );
	} else {
		return RGB( 222,222,222 );
	}
}

u32
n_win64_color_scheme_base_color_get( void )
{

	// [x] : currently not supported

	if ( n_win64_color_scheme_darkmode_is_on() )
	{
		return n_bmp_rgb(  66, 66, 66 );
	} else {
		return n_bmp_rgb( 222,222,222 );
	}
}

COLORREF
n_win64_color_scheme_text_color_COLORREF( void )
{

	// [x] : currently not supported

	if ( n_win64_color_scheme_darkmode_is_on() )
	{
		return RGB( 255,255,255 );
	} else {
		return RGB(   0,  0,  0 );
	}
}

u32
n_win64_color_scheme_text_color_get( void )
{

	// [x] : currently not supported

	if ( n_win64_color_scheme_darkmode_is_on() )
	{
		return n_bmp_rgb( 255,255,255 );
	} else {
		return n_bmp_rgb(   0,  0,  0 );
	}
}


#endif // _H_NONNON_WIN64_UI_COLOR_SCHEME
