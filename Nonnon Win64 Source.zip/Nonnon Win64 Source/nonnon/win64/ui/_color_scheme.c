// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Needed] : Link : -ldwmapi -luxtheme




#ifndef _H_NONNON_WIN64_UI_COLOR_SCHEME
#define _H_NONNON_WIN64_UI_COLOR_SCHEME




#include "../../neutral/bmp.c"


#include "../font.c"
#include "../registry.c"


#include <dwmapi.h>




n_type_gfx
n_win64_ui_stdsize( HWND hwnd )
{

	HFONT      hfont = n_win64_font_ui();
	n_type_gfx size  = n_win64_font_hfont2size( hfont );


	return abs( size ) + ( 6 * 2 );
}




BOOL
n_win64_darkmode_is_on( void )
{

	u32 light_onoff = 1;


	n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" );
	n_posix_char *section = n_posix_literal( "AppsUseLightTheme" );

	n_win64_registry_read( HKEY_CURRENT_USER, subkey, section, &light_onoff, sizeof( u32 ) );


	return ( light_onoff == 0 );
}




#define n_win64_darkmode_titlebar_auto( hwnd ) n_win64_darkmode_titlebar( hwnd, n_win64_darkmode_is_on() )

void
n_win64_darkmode_titlebar( HWND hwnd, BOOL onoff )
{

	// [!] : enum DWMWINDOWATTRIBUTE
	//const int n_DWMWA_USE_IMMERSIVE_DARK_MODE = 20;

//onoff = TRUE;

	// [!] : I'm a genious programmer lol

	DWORD d = onoff;

	DwmSetWindowAttribute( hwnd, 19, &d, sizeof( DWORD ) );
	DwmSetWindowAttribute( hwnd, 20, &d, sizeof( DWORD ) );

	if ( onoff )
	{
		//SetWindowTheme( hwnd, n_posix_literal( "DarkMode_Explorer" ), NULL );
	}

	//n_win64_message_send( hwnd, WM_NCACTIVATE, FALSE, 0 );
	//n_win64_message_send( hwnd, WM_NCACTIVATE, TRUE , 0 );


	return;
}




COLORREF
n_win64_accent_color( void )
{

	COLORREF fallback = GetSysColor( COLOR_ACTIVECAPTION );
	COLORREF color    = fallback;


	// [x] : DwmGetColorizationColor() returns a how-to-use-this value

	n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
	n_posix_char *section = n_posix_literal( "ColorPrevalence" );
	u32           onoff   = 0;

	DWORD ret = n_win64_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );
	if ( ( ret != ERROR_SUCCESS )||( onoff == 0 ) )
	{

		u32 abgr = 0;

		section = n_posix_literal( "ColorizationColor" );

		DWORD ret = n_win64_registry_read( HKEY_CURRENT_USER, subkey, section, &abgr, sizeof( u32 ) );
		if ( ret != ERROR_SUCCESS )
		{
			section = n_posix_literal( "AccentColor" );

			ret = n_win64_registry_read( HKEY_CURRENT_USER, subkey, section, &abgr, sizeof( u32 ) );
		}

		if ( ret == ERROR_SUCCESS )
		{
			// [!] : format : ABGR

			//int a = n_bmp_a( abgr );
			int r = n_bmp_r( abgr );
			int g = n_bmp_g( abgr );
			int b = n_bmp_b( abgr );

			color = RGB( b,g,r );
		}

	}


	return color;
}
/*
static COLORREF n_win64_titlebar_color = RGB( 255,255,255 );

void
n_win64_titlebar_color_get( HWND hWnd )
{

	// [x] : initialize will fail

	RECT rect; GetWindowRect( hWnd, &rect );

	int width  = 100;//rect.right - rect.left;
	int height = 100;//rect.bottom - rect.top;


	HDC hdcScreen = GetDC( NULL );
	HDC hdcMem    = CreateCompatibleDC( hdcScreen );

	HBITMAP hBitmap = CreateCompatibleBitmap( hdcScreen, width, height );
	HGDIOBJ hOld    = SelectObject( hdcMem, hBitmap );


	PrintWindow( hWnd, hdcMem, PW_RENDERFULLCONTENT );

	int x = 2; if ( IsZoomed( hWnd ) ) { x = 6; }
	int titleBarHeight = GetSystemMetrics( SM_CYCAPTION );

	n_win64_titlebar_color = GetPixel( hdcMem, x, titleBarHeight / 2 );

COLORREF c = n_win64_titlebar_color;
n_win64_hwndprintf_literal( hWnd, "%d %d %d", GetRValue( c ), GetGValue( c ), GetBValue( c ) );


	SelectObject( hdcMem, hOld );

	DeleteObject( hBitmap );

	DeleteDC( hdcMem );

	ReleaseDC( NULL, hdcScreen );


	return;
}
*//*
static COLORREF n_win64_titlebar_color = RGB( 255,255,255 );

void
n_win64_titlebar_color_on_WM_NCPAINT( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	// [x] : not working

	// [!] : return 0; after this function is called

	if ( msg != WM_NCPAINT ) { return; }

	DefWindowProc( hwnd, msg, wParam, lParam );


	//RECT rect; GetClientRect( hwnd, &rect );

	int x = GetSystemMetrics( SM_CXSIZEFRAME );
	int y = GetSystemMetrics( SM_CYSIZEFRAME );


	HDC hdc = GetWindowDC( hwnd );

	n_win64_titlebar_color = GetPixel( hdc, x, y );

	ReleaseDC( hwnd, hdc );

COLORREF c = n_win64_titlebar_color;
n_win64_hwndprintf_literal( hwnd, "%d %d %d", GetRValue( c ), GetGValue( c ), GetBValue( c ) );


	return;
}
*/
COLORREF
n_win64_GetSysColor( int color_id )
{

	COLORREF ret;


	if ( n_win64_darkmode_is_on() )
	{

		if ( color_id == COLOR_ACTIVECAPTION ) { ret = n_win64_accent_color(); } else
		if ( color_id == COLOR_WINDOW        ) { ret = RGB(  66, 66, 66 ); } else
		if ( color_id == COLOR_WINDOWTEXT    ) { ret = RGB( 240,240,240 ); } else
		if ( color_id == COLOR_HIGHLIGHT     ) { ret = RGB( 200,200,200 ); } else
		if ( color_id == COLOR_HIGHLIGHTTEXT ) { ret = RGB( 255,255,255 ); } else
		if ( color_id == COLOR_BTNFACE       ) { ret = RGB(  32, 32, 32 ); } else
		if ( color_id == COLOR_BTNSHADOW     ) { ret = RGB( 111,111,111 ); } else
		if ( color_id == COLOR_GRAYTEXT      ) { ret = RGB( 200,200,200 ); } else
		if ( color_id == COLOR_BTNTEXT       ) { ret = RGB( 240,240,240 ); } else
		if ( color_id == COLOR_BTNHIGHLIGHT  ) { ret = RGB( 111,111,111 ); } else
		if ( color_id == COLOR_3DLIGHT       ) { ret = RGB( 222,222,222 ); } else
		if ( color_id == COLOR_3DDKSHADOW    ) { ret = RGB(  50, 50, 50 ); } else
		if ( color_id == COLOR_INFOBK        ) { ret = RGB(  50, 50, 50 ); } else
		if ( color_id == COLOR_INFOTEXT      ) { ret = RGB( 240,240,240 ); } else
		{
			ret = GetSysColor( color_id );
		}

	} else {

		if ( color_id == COLOR_ACTIVECAPTION ) { ret = n_win64_accent_color(); } else
		if ( color_id == COLOR_BTNFACE       ) { ret = RGB( 243,243,243 );     } else
		{
			ret = GetSysColor( color_id );
		}

	}


	return ret;
}

u32
n_win64_GetSysColor_nbmp( int color_id )
{

	// [x] : don't use n_bmp_colorref2argb() : maybe something different

	COLORREF color = n_win64_GetSysColor( color_id );

	int r = GetRValue( color );
	int g = GetGValue( color );
	int b = GetBValue( color );


	return n_bmp_rgb( b, g, r );
}


#endif // _H_NONNON_WIN64_UI_COLOR_SCHEME
