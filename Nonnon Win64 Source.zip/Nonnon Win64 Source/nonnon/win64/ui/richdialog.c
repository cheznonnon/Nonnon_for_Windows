// Nonnon Win64
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Techniques : How to adjust padding ]
//
//	use a space or tab character


// [!] : gdi.icon, gdi.text : auto-free()
//
//	don't set these members by string literals
//	use n_string_carboncopy() for simple use




#ifndef _H_NONNON_WIN64_UI_RICHDIALOG
#define _H_NONNON_WIN64_UI_RICHDIALOG




#include "../../bridge/gdi.c"

#include "../_windows.c"
#include "../font.c"

#include "./button.c"
#include "./window.c"




#define N_WIN64_RICHDIALOG_MAX ( 32 )


typedef struct {

	n_posix_char *title;
	n_posix_char *label;
	n_gdi        *gdi;
	n_bmp        *bmp;
	int           gdi_used;

	n_type_gfx    sx, sy;
	n_type_gfx    padding;
	n_type_gfx    header_sy;
	n_type_gfx    margin_sy;
	n_type_gfx    button_sy;

	HWND              hwnd;
	n_win64_ui_button hbtn;

	BOOL          is_ok;

	u32           tick;

} n_win64_richdialog;


static n_win64_richdialog n_win64_richdialog_instance;




n_gdi
n_win64_richdialog_template( void )
{

	static n_posix_char text_font[ LF_FACESIZE ];


	HFONT hfont = n_win64_font_ui();

	n_win64_font_hfont2name( hfont, text_font );
	n_type_gfx text_size = n_win64_font_hfont2size( hfont );

	n_win64_font_exit( hfont );


	static n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx              = 0;
	gdi.sy              = 0;
	gdi.scale           = N_GDI_SCALE_AUTO;
	gdi.style           = 0;//N_GDI_AUTOMARGIN;
	gdi.layout          = 0;
	gdi.align           = 0;

	gdi.base_color_bg   = n_win64_GetSysColor_nbmp( COLOR_WINDOW );
	gdi.base_color_fg   = n_bmp_trans;
	gdi.base_style      = N_GDI_BASE_DEFAULT;

	gdi.frame_style     = N_GDI_FRAME_NOFRAME;

	gdi.icon            = NULL;//n_posix_literal( "" );
	gdi.icon_index      = 0;
	gdi.icon_style      = N_GDI_ICON_DEFAULT;

	gdi.text            = NULL;//n_posix_literal( "" );
	gdi.text_font       = text_font;
	gdi.text_size       = text_size;
	gdi.text_color_main = n_win64_GetSysColor_nbmp( COLOR_WINDOWTEXT );
	gdi.text_style      = N_GDI_TEXT_SMOOTH;


	return gdi;
}

BOOL
n_win64_richdialog_exit( n_win64_richdialog *p )
{

	if ( p == NULL ) { return FALSE; }


	BOOL ret = p->is_ok;


	int i = 0;
	n_posix_loop
	{//break;

		if ( i >= p->gdi_used ) { break; }

		n_bmp_free( &p->bmp[ i ] );

		n_string_free( p->gdi[ i ].icon );
		n_string_free( p->gdi[ i ].text );

		i++;

	}

	n_memory_free( p->title );
	n_memory_free( p->gdi   );
	n_memory_free( p->bmp   );


	n_memory_zero( p, sizeof( n_win64_richdialog ) );


	return ret;
}

void
n_win64_richdialog_init( n_win64_richdialog *p, int needed_ngdi_count, const n_posix_char *title )
{

	if ( p == NULL ) { return; }


	n_memory_zero( p, sizeof( n_win64_richdialog ) );


	p->title    = n_string_carboncopy( title );
	p->gdi_used = needed_ngdi_count;
	p->gdi      = n_memory_new( sizeof( n_gdi ) * p->gdi_used );
	p->bmp      = n_memory_new( sizeof( n_bmp ) * p->gdi_used );
	p->gdi[ 0 ] = n_win64_richdialog_template();

	n_bmp_zero( &p->bmp[ 0 ] );

	int i = 1;
	n_posix_loop
	{

		n_gdi_alias( &p->gdi[ 0 ], &p->gdi[ i ] );
		n_bmp_alias( &p->bmp[ 0 ], &p->bmp[ i ] );

		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win64_richdialog_autosize( n_win64_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	p->button_sy = n_win64_ui_stdsize( p->hwnd );
	p->margin_sy = p->button_sy * 2;
	p->padding   = p->button_sy / 4;


	n_type_gfx csx = ( p->padding * 2 );
	n_type_gfx csy = ( p->padding * 2 );

	n_type_gfx dsx; n_win64_desktop_size( p->hwnd, &dsx, NULL );

	csx = n_posix_max_n_type_gfx( csx, (n_type_gfx) ( (n_type_real) dsx * 0.1 ) );
	csx = n_posix_max_n_type_gfx( csx, 200 );

	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];

		g->style = g->style | N_GDI_CALCONLY;
		g->sx    = 0;
		g->sy    = 0;

		n_gdi_bmp( g, NULL );

		g->style = g->style & ~N_GDI_CALCONLY;


		csx = n_posix_max_n_type_gfx( csx, g->sx + ( p->padding * 2 ) );
		csy = csy + ( g->sy + p->padding );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}

	p->header_sy = csy;


	p->sx = csx;
	p->sy = csy + p->margin_sy;


	return;
}

void
n_win64_richdialog_bmp( n_win64_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];

		g->sx = 0;
		g->sy = 0;

		n_gdi_bmp( g, b );


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	return;
}

void
n_win64_richdialog_draw( n_win64_richdialog *p )
{
//return;

	if ( p == NULL ) { return; }


	// Init

	n_win64_doublebuffer_simple_init( p->hwnd, p->sx,p->sy );

	n_bmp *bmp_canvas = &n_win64_doublebuffer_instance.bmp;


	// Background

	u32 color_margin = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );

	n_bmp_box( bmp_canvas, 0,0,p->sx,p->sy, color_margin );

	n_bmp_box( bmp_canvas, 0,0,p->sx,p->header_sy, p->gdi[ 0 ].base_color_bg );


	// Draw

	n_type_gfx y = p->padding;

	int i = 0;
	n_posix_loop
	{//break;

		n_gdi *g = &p->gdi[ i ];
		n_bmp *b = &p->bmp[ i ];


		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );
		n_type_gfx  x = 0;

		if ( g->align == N_GDI_ALIGN_LEFT   ) { x = p->padding;                      } else
		if ( g->align == N_GDI_ALIGN_CENTER ) { x = ( p->sx - sx ) / 2;              } else
		if ( g->align == N_GDI_ALIGN_RIGHT  ) { x = p->sx - ( p->padding * 2 ) - sx; }

		n_bmp_fastcopy( b, bmp_canvas, 0,0,sx,sy, x,y );

		y += sy + p->padding;


		i++;
		if ( i >= p->gdi_used ) { break; }
	}


	// Exit

	n_win64_doublebuffer_simple_exit();


	return;
}

void
n_win64_richdialog_resize( n_win64_richdialog *p, BOOL is_first )
{

	if ( p == NULL ) { return; }


	n_win64_richdialog_draw( p );

	n_win64_ui_window_set( p->hwnd, 0,0,p->sx,p->sy, TRUE );


	n_type_gfx btn_sy = p->button_sy;
	n_type_gfx btn_sx = (n_type_gfx) ( (n_type_real) p->sx * 0.5 );
	n_type_gfx btn_x  = ( p->sx - btn_sx ) / 2;
	n_type_gfx btn_y  = p->header_sy + ( ( p->margin_sy - btn_sy ) / 2 );

	n_win64_ui_button_move( &p->hbtn, btn_x, btn_y, btn_sx, btn_sy, FALSE );


	return;
}

#define n_win64_richdialog_is_locked( p ) ( ( n_posix_tickcount() - ( p )->tick ) < 333 )

LRESULT CALLBACK
n_win64_richdialog_WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	static n_win64_richdialog *p = &n_win64_richdialog_instance;


	switch( msg ) {


	case WM_CREATE :
//return -1;

		// Global

		//n_bmp_safemode = FALSE;

		n_win64_ime_onoff( hwnd, FALSE );

		p->hwnd = hwnd;


		// Window

		n_win64_ui_window_init_literal( hwnd, "", "", "" );


		n_win64_ui_button_init( &p->hbtn, hwnd );

		if ( n_string_is_empty( p->label ) )
		{
			p->label = n_posix_literal( "OK" );
		}

		p->hbtn.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		p->hbtn.label = p->label;


		SetWindowText( p->hwnd, p->title );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win64_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win64_style_new  ( hwnd, WS_POPUP | WS_CAPTION | WS_SYSMENU );

		//n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// Size

		n_win64_richdialog_autosize( p );
		n_win64_richdialog_bmp( p );

		n_win64_richdialog_resize( p, TRUE );


		// Display

		// [Needed] : Async only
		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( n_win64_hwnd_toplevel( hwnd ), FALSE );


		// [!] : prevent accidental clicking

		p->tick = n_posix_tickcount();


	break;


	case WM_ERASEBKGND :

		// [x] : UxTheme : margin will be black

		//return 1;

	break;

	case WM_PAINT :

		n_win64_richdialog_draw( p );

	break;


	case WM_SIZE :

		//n_win64_richdialog_resize( p, FALSE );

	break;


	case WM_COMMAND :

		if ( n_win64_richdialog_is_locked( p ) ) { break; }

		if ( (HWND) lParam == p->hbtn.hwnd )
		{
			p->hbtn.fake_onoff = TRUE;
			n_win64_refresh( p->hbtn.hwnd, FALSE );

			p->is_ok = TRUE;
			n_win64_message_post( hwnd, WM_CLOSE, 0,0 );
		}

	break;

	case WM_KEYDOWN :

		if ( n_win64_richdialog_is_locked( p ) ) { break; }

		if ( ( wParam == VK_SPACE )||( wParam == VK_RETURN ) )
		{
			p->hbtn.fake_onoff = TRUE;
			n_win64_refresh( p->hbtn.hwnd, FALSE );
		} else
		if ( wParam == VK_ESCAPE )
		{
			n_win64_message_post( hwnd, WM_CLOSE, 0,0 );
		}// else

	break;

	case WM_KEYUP :

		if ( n_win64_richdialog_is_locked( p ) ) { break; }

		if ( ( wParam == VK_SPACE )||( wParam == VK_RETURN ) )
		{
			p->is_ok = TRUE;
			n_win64_message_post( hwnd, WM_CLOSE, 0,0 );
		}// else

	break;


	case WM_CLOSE :

		EnableWindow( n_win64_hwnd_toplevel( hwnd ), TRUE );
		ShowWindow( hwnd, SW_HIDE );

		n_win64_ui_button_exit( &p->hbtn );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &p->hbtn );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}

BOOL
n_win64_richdialog_go( n_win64_richdialog *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return FALSE; }

	if ( hwnd_parent == NULL ) { return FALSE; }


	p->hwnd = n_win64_ui_window( hwnd_parent, n_win64_richdialog_WndProc );

//return FALSE;

	// [!] : don't use GetMessage() : a closed process will remain in background

	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );
	n_posix_loop
	{

		if ( n_win64_message_peek( &msg ) )
		{

			if ( msg.message == WM_QUIT ) { break; }

			if ( FALSE == IsWindow( p->hwnd ) ) { break; }

			TranslateMessage( &msg );
			DispatchMessage ( &msg );

		} else {

			// [!] ; "else" is important with performance

			n_posix_sleep( 1 );

		}

	}


//n_win_hwndprintf_literal( hwnd_parent, "%d", p->is_ok );


	return n_win64_richdialog_exit( p );
}




#endif // _H_NONNON_WIN64_UI_RICHDIALOG

