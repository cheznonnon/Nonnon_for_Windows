// Nonnon CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_FONTCHOOSER
#define _H_NONNON_WIN64_UI_FONTCHOOSER




#include "../_windows.c"


#include "./button.c"
#include "./slider.c"
#include "./txtbox.c"
#include "./value.c"
#include "./window.c"

#include "./fontchooser/preview.c"




typedef struct {

	HWND               hwnd;

	n_win64_ui_value   value;
	n_win64_ui_slider  slider;
	n_win64_ui_preview preview;
	n_txtbox           txtbox;
	n_win64_ui_button  button;

	BOOL               window_init;
	BOOL               apply;

	// [!] : remember original spec : for cancel

	int                font_size;
	n_posix_char       font_name[ LF_FACESIZE ];

} n_win64_ui_fontchooser;


static n_win64_ui_fontchooser n_win64_ui_fontchooser_instance;


static HFONT n_win64_ui_fontchooser_hfont = NULL;




// internal
void
n_win64_ui_fontchooser_live_sync( HWND hwnd )
{

	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;


	n_posix_char *name = n_txt_get( p->txtbox.txt_data, p->txtbox.focus );
	int           size = p->slider.pos;

	n_win64_font_exit( n_win64_ui_fontchooser_hfont );
	n_win64_ui_fontchooser_hfont = n_win64_font_name2hfont( name, size );


	n_win64_message_send( GetParent( hwnd ), WM_COMMAND, 0, hwnd );


	return;
}

// internal
void
n_win64_ui_fontchooser_cancel( HWND hwnd )
{

	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;


	n_posix_char *name = p->font_name;
	int           size = p->font_size;

	n_win64_font_exit( n_win64_ui_fontchooser_hfont );
	n_win64_ui_fontchooser_hfont = n_win64_font_name2hfont( name, size );


	n_win64_message_send( GetParent( hwnd ), WM_COMMAND, 0, hwnd );


	return;
}

// internal
int CALLBACK
n_win64_ui_fontchooser_FONTENUMPROC( const LOGFONT *lf, const TEXTMETRIC *tm, u32 type, LPARAM lparam )
{

	const int mask = 15;


	if (
		( type != DEVICE_FONTTYPE )
		&&
		( ( lf->lfPitchAndFamily & mask ) == FIXED_PITCH )
		&&
		( lf->lfFaceName[ 0 ] != n_posix_literal( '@' ) )
	)
	{

		n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;

		n_txt_set( p->txtbox.txt_data, 0, lf->lfFaceName );

	}


	return TRUE;
}

// internal
void
n_win64_ui_fontchooser_gdi( HWND hwnd )
{

	// [!] : for cleartype

	n_type_real scale = n_win64_scale_factor_ui( hwnd );

	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;

	n_posix_char *name = n_txt_get( p->txtbox.txt_data, p->txtbox.focus );
	int           size = p->slider.pos * scale;

	p->preview.font = n_win64_font_name2hfont( name, size );
	n_posix_snprintf_literal( p->preview.text, 100, "Jumped Over A Sleepy Cat" );

	n_win64_refresh( p->preview.hwnd, FALSE );

/*
	n_type_gfx csx,csy; n_win64_control_size( p->preview.hwnd, &csx, &csy );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = csx;
	gdi.sy                  = csy;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base                = n_posix_literal( "" );
	gdi.base_index          = 0;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.frame_style         = N_GDI_FRAME_SIMPLE;
	gdi.frame_round         = 0;

	gdi.text                = n_posix_literal( "Jumped Over A Sleepy Cat" );
	gdi.text_font           = n_txt_get( p->txtbox.txt_data, p->txtbox.focus );
	gdi.text_size           = p->slider.pos;
	gdi.text_style          = N_GDI_TEXT_SMOOTH;

	//if ( n_win64_darkmode_is_on() )

	gdi.base_color_bg   = p->txtbox.nscolor_back;
	gdi.text_color_main = p->txtbox.nscolor_text;


	n_gdi_bmp( &gdi, &p->image.bmp );

//n_bmp_new( &p->image.bmp, csx, csy ); n_bmp_flush( &p->image.bmp, n_bmp_white );

	n_win64_refresh( p->image.hwnd, FALSE );
*/

	return;
}

// internal
void
n_win64_ui_fontchooser_resize( HWND hwnd )
{

	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;


	const BOOL redraw = TRUE;


	n_type_real scale = n_win64_scale_factor_ui( hwnd );


	const n_type_gfx m   = 4 * scale;
	const n_type_gfx pad = 8 * scale;
	      n_type_gfx ctl = n_win64_ui_stdsize() * scale;

	n_type_gfx csx = 512 * scale;
	n_type_gfx csy = 512 * scale;

	if ( p->window_init == FALSE )
	{
		//
	} else {
		RECT client; GetClientRect( hwnd, &client );

		csx = client.right;
		csy = client.bottom;
	}

	n_type_gfx csx_in = csx - ( pad * 2 );
	n_type_gfx csy_in = csy - ( pad * 2 );


	n_type_gfx value  = 77 * scale;
	n_type_gfx slider = csx_in - value;
	n_type_gfx text   = ctl * 2;
	n_type_gfx list   = csy_in - ( ctl * 4 ) - ( m * 3 );


	n_type_gfx x = pad;
	n_type_gfx y = pad;

	MoveWindow( p->value .hwnd, x,y,  value, ctl, redraw ); x += value + m;
	MoveWindow( p->slider.hwnd, x,y, slider, ctl, redraw );

	x = pad;
	y = y + ctl + m;

	MoveWindow( p->preview.hwnd, x,y,csx_in, text, redraw );

	y += text + m;

	MoveWindow( p->txtbox .hwnd, x,y,csx_in, list, redraw );

	y = csy - pad - ctl;

	MoveWindow( p->button .hwnd, x,y,csx_in,  ctl, redraw );


	if ( p->window_init == FALSE )
	{
		n_win64_ui_window_set( hwnd, 0, 0, csx, csy, TRUE );
	}

	p->window_init = TRUE;


	return;
}

void
n_win64_ui_fontchooser_bg_draw( HWND hwnd, HDC hdc )
{

	RECT rect; GetClientRect( hwnd, &rect );

	COLORREF colorref = n_win64_GetSysColor( COLOR_BTNFACE );
	HBRUSH   br       = CreateSolidBrush( colorref );

	FillRect( hdc, &rect, br );

	DeleteObject( br );


	return;
}

LRESULT CALLBACK
n_win64_ui_fontchooser_wndproc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{

	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;


	static UINT darkmode_timer = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :
	{
		n_posix_char *str = (n_posix_char*) lParam;

		if ( n_string_is_same_literal( "ImmersiveColorSet", str ) )
		{
			n_win64_timer_init( hwnd, darkmode_timer, 200 );
		}
	}
	break;

	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == darkmode_timer )
		{
			n_win64_timer_exit( hwnd, darkmode_timer );

			n_txtbox_color_scheme( &p->txtbox );

			n_win64_ui_fontchooser_gdi( hwnd );

			n_win64_darkmode_on_WM_SETTINGCHANGE( hwnd );
		}

	break;


	case WM_CREATE :


		// Global

		n_win64_exedir2curdir();

		n_win64_ime_onoff( hwnd, FALSE );

		darkmode_timer = n_win64_timer_id_get();


		// Window

		n_win64_ui_window_init_literal( hwnd, "Font Chooser", "", "" ); 

		n_win64_exstyle_add( hwnd, WS_EX_TOOLWINDOW );


		n_win64_ui_value_init( &p->value, hwnd, n_posix_literal( "Size" ) );

		n_win64_ui_slider_init( &p->slider, hwnd, N_WIN64_UI_SLIDER_LAYOUT_HORZ, 100 );

		n_win64_ui_preview_init( &p->preview, hwnd );

		n_txtbox_init( &p->txtbox, hwnd, NULL );

		p->txtbox.listbox_no_edit = TRUE;
		p->txtbox.mode            = N_MAC_TXTBOX_MODE_LISTBOX;

		n_txtbox_reset( &p->txtbox );

		{
			HDC hdc = GetDC( hwnd );

			EnumFonts( hdc, NULL, n_win64_ui_fontchooser_FONTENUMPROC, (LPARAM) 0 );

			n_txt_sort_up( p->txtbox.txt_data );

			ReleaseDC( hwnd, hdc );
		}

		n_win64_ui_button_init( &p->button, hwnd );

		p->button.style = N_WIN64_UI_BUTTON_STYLE_FLUENT;
		p->button.label = n_posix_literal( "Go!" );


		// Display

		n_win64_ui_fontchooser_resize( hwnd );


		// [!] : after resize()

		if ( n_win64_ui_fontchooser_hfont == NULL )
		{
			n_win64_ui_fontchooser_hfont = n_win64_font_name2hfont_literal( "Consolas", 18 );
		}

		p->font_size  = n_win64_font_hfont2size( n_win64_ui_fontchooser_hfont );
		p->slider.pos = p->font_size;
		n_posix_snprintf_literal( p->value.value, 100, "%d", p->font_size );

		{
			n_win64_font_hfont2name( n_win64_ui_fontchooser_hfont, p->font_name );

			NonnonTxtboxDraw( &p->txtbox, FALSE );

			NonnonTxtboxSearch( &p->txtbox, p->font_name, FALSE );

			NonnonTxtboxDraw( &p->txtbox, FALSE );

//n_win64_hwndprintf_literal( hwnd, "%lld %f", p->txtbox.focus, p->txtbox.scroll );
		}

		n_win64_ui_fontchooser_gdi( hwnd );


		ShowWindowAsync( hwnd, SW_NORMAL );

	break;

	case WM_PAINT :
	{
		PAINTSTRUCT ps;
		BeginPaint( hwnd, &ps );


		n_win64_ui_fontchooser_bg_draw( hwnd, ps.hdc );


		n_win64_ui_value_draw  ( &p->value  , TRUE );
		n_win64_ui_slider_draw ( &p->slider , TRUE );
		n_win64_ui_preview_draw( &p->preview, TRUE );
		NonnonTxtboxDraw       ( &p->txtbox , TRUE );
		n_win64_ui_button_draw ( &p->button , TRUE );


		n_win64_doublebuffer_exit( &p->value  .db );
		n_win64_doublebuffer_exit( &p->slider .db );
		n_win64_doublebuffer_exit( &p->preview.db );
		n_win64_doublebuffer_exit( &p->txtbox .db );
		n_win64_doublebuffer_exit( &p->button .db );


		EndPaint( hwnd, &ps );
	}
	break;


	case WM_COMMAND :

		if ( (HWND) lParam == p->slider.hwnd )
		{
			if ( p->slider.pos == 0 ) { p->slider.pos = 18; }

			n_posix_snprintf_literal( p->value.value, 100, "%d", p->slider.pos );
			n_win64_refresh( p->value.hwnd, FALSE );

			n_win64_ui_fontchooser_gdi( hwnd );

			n_win64_ui_fontchooser_live_sync( hwnd );
		} else
		if ( (HWND) lParam == p->txtbox.hwnd )
		{
			n_win64_ui_fontchooser_gdi( hwnd );

			n_win64_ui_fontchooser_live_sync( hwnd );
		} else
		if ( (HWND) lParam == p->button.hwnd )
		{
			n_win64_ui_fontchooser_live_sync( hwnd );

			p->apply = TRUE;

			n_win64_message_post( hwnd, WM_CLOSE, 0, 0 );
		}


	break;

	case WM_CLOSE :

		n_win64_ui_value_exit( &p->value );

		n_win64_ui_slider_exit( &p->slider );

		n_win64_ui_preview_exit( &p->preview );

		n_txtbox_exit( &p->txtbox );

		n_win64_ui_button_exit( &p->button );

		if ( p->apply == FALSE )
		{
			n_win64_ui_fontchooser_cancel( hwnd );
		}

		n_memory_zero( p, sizeof( n_win64_ui_fontchooser ) );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win64_ui_value_proc( hwnd, msg, wParam, lParam, &p->value );

	n_win64_ui_slider_proc( hwnd, msg, wParam, lParam, &p->slider );

	n_win64_ui_preview_proc( hwnd, msg, wParam, lParam, &p->preview );

	n_win64_txtbox_proc( hwnd, msg, wParam, lParam, &p->txtbox );

	n_win64_ui_button_proc( hwnd, msg, wParam, lParam, &p->button );


	return DefWindowProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_fontchooser_go( HWND hwnd_parent, HFONT hfont )
{

	if ( hwnd_parent == NULL ) { return; }


	n_win64_ui_fontchooser *p = &n_win64_ui_fontchooser_instance;


	if ( p->hwnd != NULL ) { return; }

	n_memory_zero( p, sizeof( n_win64_ui_fontchooser ) );

	n_win64_ui_fontchooser_hfont = hfont;

	p->hwnd = n_win64_ui_window( hwnd_parent, n_win64_ui_fontchooser_wndproc );

//return FALSE;


//n_win_hwndprintf_literal( hwnd_parent, "%d", p->is_ok );


	return;
}


#endif // _H_NONNON_WIN64_UI_FONTCHOOSER


