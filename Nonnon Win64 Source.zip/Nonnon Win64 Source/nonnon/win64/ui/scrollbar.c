// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Version 10.0 ]
//
//	 1.0 : initial release
//	 2.0 : scroll_pixel()/unit() have three modes
//	 3.0 : thumb calculation is removed
//	 4.0 : OrangeCat Mode is implemented
//	 5.0 : redraw count is reduced
//	 6.0 : mainbuffer is implemented, rapid fire is re-tuned, fade_go() is made
//	 7.0 : scroll_pixel()/unit() will not accept when delta is zero
//	 8.0 : n_win_scrollbar_on_drag() behavior is changed
//	 9.0 : option-ify "n_win64_ui_scrollbar_direct_render"
//	10.0 : slimmed down for Win64 Version




// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//		n_win64_ui_scrollbar_init()
//
//	[ WM_CLOSE ]
//
//		n_win64_ui_scrollbar_exit()
//
//	[ WM_COMMAND ]
//
//		+ WPARAM : scroll position by unit
//		+ LPARAM : HWND to check
//
//	[ WM_SETTINGCHANGE ]
//
//		n_win64_ui_scrollbar_on_WM_SETTINGCHANGE()
//
//		+ this module is also used by .style and .option are manually set
//
//	[ WndProc() ]
//
//		n_win64_ui_scrollbar_proc()
//
//	[ Scrollbar Initialization ]
//
//		n_win64_ui_scrollbar_parameter()
//
//		+ call n_win64_ui_scrollbar_metrics() after set
//
//	[ .style ]
//
//		select style by N_WIN_SCROLLBAR_STYLE_*
//
//	[ .option ]
//
//		N_WIN_SCROLLBAR_OPTION_NONE
//
//		+ zero, nothing uses
//
//		N_WIN_SCROLLBAR_OPTION_NO_ARROWS
//
//		+ arrow buttons are not used
//
//		N_WIN_SCROLLBAR_OPTION_PAGER
//
//		+ jump when shaft is clicked
//
//		N_WIN_SCROLLBAR_OPTION_BIG_ARROWS
//
//		+ for IE11 like arrow buttons
//
//		N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR
//
//		+ .color_sh_fg/bg are used
//
//	[ Tips ]
//
//		[ the system has three modes ]
//
//		1 :  unit_* : user defined unit
//		2 : pixel_* : shaft based pixel
//		3 : re-calculation when a thumb has minimal size




#ifndef _H_NONNON_WIN64_UI_SCROLLBAR
#define _H_NONNON_WIN64_UI_SCROLLBAR




#include "../../neutral/bmp/all.c"

#include "../../bridge/gdi.c"

#include "../_windows.c"


#define n_win64_fluent_ui_round_param() ( 8 )




void
n_win64_ui_scrollbar_bmp_checker( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 color )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx xx = 0;
	n_type_gfx yy = 0;
	n_posix_loop
	{

		if ( n_bmp_moire_detect( xx, yy, 1 ) )
		{
			n_bmp_ptr_set( bmp, xx + x, yy + y, color );
		}

		xx++;
		if ( xx >= sx )
		{
			xx = 0;
			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}




typedef struct {

	n_type_real x,y,sx,sy;

} n_win64_ui_scrollbar_rect;


n_win64_ui_scrollbar_rect
n_win64_ui_scrollbar_rect_set_range( n_type_real x, n_type_real y, n_type_real sx, n_type_real sy )
{

	n_win64_ui_scrollbar_rect ret = { x, y, x + sx, y + sy };

	return ret;
}

BOOL
n_win64_ui_scrollbar_rect_is_hovered( HWND hwnd, n_win64_ui_scrollbar_rect n_rect )
{

	RECT rect = { n_rect.x, n_rect.y, n_rect.sx, n_rect.sy };

	POINT pt = n_win64_cursor_position_relative_POINT( hwnd );

	return PtInRect( &rect, pt );
}




#define  N_WIN_SCROLLBAR_RECT_NONE ( -11 ) // [!] : for debugging




#define N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL      ( 0 )
#define N_WIN_SCROLLBAR_LAYOUT_VERTICAL        ( 1 )

#define N_WIN_SCROLLBAR_STYLE_CLASSIC          ( 0 )
#define N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT     ( 1 )
#define N_WIN_SCROLLBAR_STYLE_FLUENT_UI        ( 2 )

#define N_WIN_SCROLLBAR_OPTION_NONE            ( 0 <<  0 )
#define N_WIN_SCROLLBAR_OPTION_NO_ARROWS       ( 1 <<  0 )
#define N_WIN_SCROLLBAR_OPTION_PAGER           ( 1 <<  1 )
#define N_WIN_SCROLLBAR_OPTION_BIG_ARROWS      ( 1 <<  2 )
#define N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR     ( 1 <<  3 )

#define N_WIN_SCROLLBAR_SCROLL_NONE            ( 0 )
#define N_WIN_SCROLLBAR_SCROLL_SEND            ( 1 )
#define N_WIN_SCROLLBAR_SCROLL_AUTO            ( 2 )




typedef struct {

	HWND        hwnd;
	HWND        hwnd_parent;

	int         layout;
	int         style;
	int         option;

	n_type_gfx  csx,csy;

	u32         color_trans;
	u32         color__back;
	u32         color_thumb;
	u32         color_shaft;
	u32         color_press;
	u32         color_hvr_t;
	u32         color_hvr_s;
	u32         color_arbtn;
	u32         color_arrow;
	u32         color_sh_fg;
	u32         color_sh_bg;

	u32         color_edge_ul;
	u32         color_edge_ur;
	u32         color_edge_dl;
	u32         color_edge_dr;

	n_type_real unit_pos , pixel_pos;
	n_type_real unit_max , pixel_max;
	n_type_real unit_page, pixel_page;
	n_type_real unit_step, pixel_step;
	n_type_real unit_pos_prev;
	n_type_real pixel_thumb_original;
	n_type_real pixel_thumb;
	n_type_real pixel_minim;
	n_type_real pixel_arrow_sx, pixel_arrow_sy;
	n_type_real pixel_shaft;
	n_type_real pixel_offset;
	n_type_real pixel_offset_prv;
	n_type_real pixel_patch;

	BOOL        enabled;
	BOOL        enabled_ul;
	BOOL        enabled_dr;

	n_type_gfx  prv_cursor_x;
	n_type_gfx  prv_cursor_y;
	n_type_gfx  cur_cursor_x;
	n_type_gfx  cur_cursor_y;

	BOOL        drag_onoff;

	BOOL        pressed_thumb;
	BOOL        pressed_shaft;
	BOOL        pressed_arrow_ul;
	BOOL        pressed_arrow_dr;

	BOOL        hovered_main;
	BOOL        hovered_thumb;
	BOOL        hovered_shaft;
	BOOL        hovered_arrow_ul;
	BOOL        hovered_arrow_dr;

	n_bmp       bmp_sh;
	n_bmp       bmp_ul;
	n_bmp       bmp_dr;
	n_bmp       bmp_th;
	n_bmp       bmp_gr;

	n_win64_ui_scrollbar_rect rect_main;
	n_win64_ui_scrollbar_rect rect_shaft;
	n_win64_ui_scrollbar_rect rect_thumb;
	n_win64_ui_scrollbar_rect rect_arrow_ul;
	n_win64_ui_scrollbar_rect rect_arrow_dr;

} n_win64_ui_scrollbar;


#define n_win64_ui_scrollbar_zero( p ) n_memory_zero( p, sizeof( n_win64_ui_scrollbar ) )




#define n_win64_ui_scrollbar_hwndprintf(         p, f, ... ) n_win64_hwndprintf( n_win64_hwnd_toplevel( ( p )->hwnd ), f, ##__VA_ARGS__ )
#define n_win64_ui_scrollbar_hwndprintf_literal( p, f, ... ) n_win64_ui_scrollbar_hwndprintf( p, n_posix_literal( f ), ##__VA_ARGS__ )
#define n_win64_ui_scrollbar_debug_count(        p         ) n_win64_debug_count( n_win64_hwnd_toplevel( ( p )->hwnd ) )




void
n_win64_ui_scrollbar_ui_maker_shaft( n_win64_ui_scrollbar *p )
{

	n_type_gfx o_x = 0;
	n_type_gfx o_y = 0;
	n_type_gfx osx = p->csx;
	n_type_gfx osy = p->csy;

	n_bmp_new_fast( &p->bmp_sh, osx,osy );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR )
	{

		int mode = N_BMP_GRADIENT_CIRCLE;

		int type;
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			type = N_BMP_GRADIENT_HORIZONTAL;
		} else {
			type = N_BMP_GRADIENT_VERTICAL;
		}

		int lightness_fg = n_bmp_l( n_bmp_argb2ahsl( p->color_sh_fg ) );
		int lightness_bg = n_bmp_l( n_bmp_argb2ahsl( p->color_sh_bg ) );

		if ( lightness_fg < lightness_bg )
		{
			n_bmp_flush_gradient( &p->bmp_sh, p->color_sh_bg, p->color_sh_fg, mode | type );
		} else {
			n_bmp_flush_gradient( &p->bmp_sh, p->color_sh_fg, p->color_sh_bg, mode | type );
			n_bmp_flush_mirror( &p->bmp_sh, N_BMP_MIRROR_LEFTSIDE_RIGHT );
		}

		//n_bmp_cornermask( &p->bmp_gr, 4, 0, n_bmp_white_invisible );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC )
	{

		u32 color_hatch = n_bmp_white;
		if ( n_win64_darkmode_is_on() ) { color_hatch = n_win64_GetSysColor_nbmp( COLOR_BTNFACE ); }

//p->color_shaft = n_bmp_rgb( 0,200,255 );

		n_bmp_box                       ( &p->bmp_sh, o_x,o_y,osx,osy, p->color_shaft );
		n_win64_ui_scrollbar_bmp_checker( &p->bmp_sh, o_x,o_y,osx,osy,    color_hatch );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{

		u32 color_hatch = n_bmp_white;
		if ( n_win64_darkmode_is_on() ) { color_hatch = n_win64_GetSysColor_nbmp( COLOR_BTNFACE ); }

		n_bmp_box                       ( &p->bmp_sh, o_x,o_y,osx,osy, p->color_shaft );
		n_win64_ui_scrollbar_bmp_checker( &p->bmp_sh, o_x,o_y,osx,osy,    color_hatch );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{

		n_bmp_box( &p->bmp_sh, o_x+0,o_y+0,osx,osy, p->color_shaft );

	}


	// [!] : for collision/hittest

	p->rect_shaft = n_win64_ui_scrollbar_rect_set_range( o_x,o_y,osx,osy );


	return;
}

void
n_win64_ui_scrollbar_ui_maker_arrows( n_win64_ui_scrollbar *p )
{

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS ) { return; }


	// [!] : Shared Up/Left and Down/Right

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx            = (n_type_gfx) p->pixel_arrow_sx;
	gdi.sy            = (n_type_gfx) p->pixel_arrow_sy;
	gdi.style         = N_GDI_DEFAULT;
	gdi.layout        = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align         = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg = p->color_shaft;
	gdi.base_style    = N_GDI_BASE_SOLID;
	gdi.base_unit     = 0;

	gdi.text_font     = n_posix_literal( "Marlett" );
	gdi.text_size     = (n_type_gfx) ( p->pixel_minim / 3 * 2 );
	gdi.text_style    = N_GDI_TEXT_SMOOTH;


	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		gdi.text_font  = n_gdi_font_find( n_posix_literal( "MS UI Gothic" ), n_posix_literal( "Small Fonts" ) );
		gdi.text_style = gdi.text_style | N_GDI_TEXT_BOLD;

		//gdi.text_size  = p->pixel_minim;

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
		{
			n_type_gfx tmp_sx = gdi.sx;
			           gdi.sx = gdi.sy;
			           gdi.sy = tmp_sx;
		}
	}


	n_posix_char str[ 2 ];

	gdi.text = str;

	int frame_style_arrow = N_GDI_FRAME_NOFRAME;

	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC )
	{
		frame_style_arrow = N_GDI_FRAME_SCROLLARROW;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{
		frame_style_arrow = N_GDI_FRAME_FLAT;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		frame_style_arrow = N_GDI_FRAME_NOFRAME;
	}


	// Arrow : Up / Left

	gdi.frame_style = frame_style_arrow;

	if ( p->pressed_arrow_ul )
	{
		gdi.style |= N_GDI_PRESSED;
	}

	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			str[ 0 ] = n_posix_literal( '<' );
			str[ 1 ] = 0x00;
		} else {
			str[ 0 ] = n_posix_literal( '<' );
			str[ 1 ] = 0x00;
		}
	} else {
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			str[ 0 ] = 0x33;
			str[ 1 ] = 0x00;
		} else {
			str[ 0 ] = 0x35;
			str[ 1 ] = 0x00;
		}
	}

	if ( p->enabled_ul )
	{
		gdi.text_color_main = p->color_arrow;
	} else {
		gdi.text_color_main = n_bmp_blend_pixel( p->color_arrow, p->color_shaft, 0.75 );
	}

	n_gdi_bmp( &gdi, &p->bmp_ul );

	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
		{
			n_bmp_rotate( &p->bmp_ul, N_BMP_ROTATE_RIGHT );
		}
	}

	if ( p->pressed_arrow_ul )
	{
		gdi.style &= ~N_GDI_PRESSED;
	}


	// Arrow : Down / Right

	gdi.frame_style = frame_style_arrow;

	if ( p->pressed_arrow_dr )
	{
		gdi.style |= N_GDI_PRESSED;
	}

	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			str[ 0 ] = n_posix_literal( '>' );
			str[ 1 ] = 0x00;
		} else {
			str[ 0 ] = n_posix_literal( '>' );
			str[ 1 ] = 0x00;
		}
	} else {
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			str[ 0 ] = 0x34;
			str[ 1 ] = 0x00;
		} else {
			str[ 0 ] = 0x36;
			str[ 1 ] = 0x00;
		}
	}

	if ( p->enabled_dr )
	{
		gdi.text_color_main = p->color_arrow;
	} else {
		gdi.text_color_main = n_bmp_blend_pixel( p->color_arrow, p->color_shaft, 0.75 );
	}

	n_gdi_bmp( &gdi, &p->bmp_dr );

	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
		{
			n_bmp_rotate( &p->bmp_dr, N_BMP_ROTATE_RIGHT );
		}
	}


	return;
}

void
n_win64_ui_scrollbar_ui_maker_thumb( n_win64_ui_scrollbar *p )
{

	int frame_style_thumb = N_GDI_FRAME_NOFRAME;

	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC )
	{
		frame_style_thumb = N_GDI_FRAME_SCROLLARROW;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{
		frame_style_thumb = N_GDI_FRAME_FLAT;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		frame_style_thumb = N_GDI_FRAME_NOFRAME;
	}

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.frame_style   = frame_style_thumb;

	gdi.base_style    = N_GDI_BASE_SOLID;
	gdi.base_color_fg = p->color_thumb;
	gdi.base_color_bg = p->color_thumb;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		gdi.sx = (n_type_gfx) p->pixel_thumb;
		gdi.sy = (n_type_gfx) p->pixel_minim;
	} else {
		gdi.sx = (n_type_gfx) p->pixel_minim;
		gdi.sy = (n_type_gfx) p->pixel_thumb;
	}

	n_gdi_bmp( &gdi, &p->bmp_th );


	return;
}




n_type_real
n_win64_ui_scrollbar_position_unit2pixel( n_win64_ui_scrollbar *p )
{
	return ( p->unit_pos / p->unit_max ) * p->pixel_max;
}

n_type_real
n_win64_ui_scrollbar_position_pixel2unit( n_win64_ui_scrollbar *p )
{
	return ( p->pixel_pos / p->pixel_max ) * p->unit_max;
}

n_type_real
n_win64_ui_scrollbar_position_last_unit( n_win64_ui_scrollbar *p )
{
	return p->unit_max - p->unit_page;
}

n_type_real
n_win64_ui_scrollbar_position_last_pixel( n_win64_ui_scrollbar *p )
{
	return p->pixel_max - p->pixel_page;
}

void
n_win64_ui_scrollbar_position_cursor( n_win64_ui_scrollbar *p, n_type_gfx *x, n_type_gfx *y )
{

	n_type_gfx cur_x, cur_y; n_win64_cursor_position_relative( p->hwnd, &cur_x, &cur_y );

	if ( x != NULL ) { (*x) = cur_x; }
	if ( y != NULL ) { (*y) = cur_y; }


	return;
}

void
n_win64_ui_scrollbar_position_thumb( n_win64_ui_scrollbar *p, n_type_real *x, n_type_real *y )
{

	n_type_real dx = 0;
	n_type_real dy = 0;


	// [!] : thumb position

	if ( p->drag_onoff )
	{

		// [Needed] : prv only

		//n_win64_ui_scrollbar_position_cursor( p, &p->cur_cursor_x, &p->cur_cursor_y );

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			dx = p->prv_cursor_x - p->pixel_arrow_sx - p->pixel_offset;
		} else {
			dy = p->prv_cursor_y - p->pixel_arrow_sy - p->pixel_offset;
		}

	} else {

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			dx = p->pixel_pos;
		} else {
			dy = p->pixel_pos;
		}

	}


	// [!] : clamper

	n_type_real pixel_last = n_win64_ui_scrollbar_position_last_pixel( p );

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		dx = n_posix_minmax_n_type_real( 0, pixel_last, dx );
	} else {
		dy = n_posix_minmax_n_type_real( 0, pixel_last, dy );
	}


	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_pos = dx;
	} else {
		p->pixel_pos = dy;
	}


	// [!] : write back

	if ( x != NULL ) { (*x) = dx; }
	if ( y != NULL ) { (*y) = dy; }


	return;
}

void
n_win64_ui_scrollbar_arrowbutton_onoff( n_win64_ui_scrollbar *p )
{
//n_win64_hwndprintf_literal( GetParent( p->hwnd ), " %0.2f : %0.2f %0.2f ", p->unit_pos, 0, p->unit_max );

	if ( p->enabled )
	{
		if ( p->unit_pos <=                              0 ) { p->enabled_ul = FALSE; } else { p->enabled_ul = TRUE; }
		if ( p->unit_pos >= ( p->unit_max - p->unit_page ) ) { p->enabled_dr = FALSE; } else { p->enabled_dr = TRUE; }
	}


	return;
}

void
n_win64_ui_scrollbar_on_WM_SETTINGCHANGE( n_win64_ui_scrollbar *p, BOOL redraw )
{

	p->color_trans = n_bmp_white_invisible;
	p->color__back = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	p->color_arbtn = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	p->color_thumb = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );
	p->color_shaft = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
	p->color_press = n_win64_GetSysColor_nbmp( COLOR_BTNSHADOW );
	p->color_hvr_t = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
	p->color_hvr_s = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.25 );
	p->color_arrow = n_win64_GetSysColor_nbmp( COLOR_BTNTEXT );

	p->color_edge_ul = p->color__back;
	p->color_edge_ur = p->color__back;
	p->color_edge_dl = p->color__back;
	p->color_edge_dr = p->color__back;

	if ( n_win64_darkmode_is_on() )
	{
		p->color_arrow = n_bmp_white;
	}


	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{
		p->color_shaft = n_win64_GetSysColor_nbmp( COLOR_BTNFACE  );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		p->color_shaft = n_win64_GetSysColor_nbmp( COLOR_BTNFACE  );
		p->color_shaft = n_bmp_blend_pixel( p->color_shaft, n_bmp_black, 0.05 );
		p->color_hvr_t = n_win64_GetSysColor_nbmp( COLOR_3DSHADOW );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.25 );
		p->color_arbtn = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_thumb = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb,    n_bmp_black, 0.50 );
		p->color_arbtn = p->color_shaft;
	}

	if ( p->color_thumb == n_bmp_trans ) { p->color_thumb = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_shaft == n_bmp_trans ) { p->color_shaft = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_press == n_bmp_trans ) { p->color_press = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_hvr_t == n_bmp_trans ) { p->color_hvr_t = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_hvr_s == n_bmp_trans ) { p->color_hvr_s = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_arrow == n_bmp_trans ) { p->color_arrow = n_bmp_rgb( 1,1,1 ); }


	// [Needed] : for initial arrow button size

	extern void n_win64_ui_scrollbar_metrics( n_win64_ui_scrollbar* );
	n_win64_ui_scrollbar_metrics( p );


	extern void n_win64_ui_scrollbar_draw( n_win64_ui_scrollbar* );
	if ( redraw ) { n_win64_ui_scrollbar_draw( p ); }


	return;
}

n_type_gfx
n_win64_ui_scrollbar_stdsize( n_win64_ui_scrollbar *p )
{

	n_type_gfx ret;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		ret = GetSystemMetrics( SM_CYHSCROLL );
	} else {
		ret = GetSystemMetrics( SM_CXVSCROLL );
	}

	return ret;
}

void
n_win64_ui_scrollbar_enable( n_win64_ui_scrollbar *p, BOOL enable, BOOL redraw )
{

	if ( enable )
	{
		p->enabled    = TRUE;
		p->enabled_ul = TRUE;
		p->enabled_dr = TRUE;
	} else {
		p->enabled    = FALSE;
		p->enabled_ul = FALSE;
		p->enabled_dr = FALSE;
	}

	extern void n_win64_ui_scrollbar_draw( n_win64_ui_scrollbar* );
	if ( redraw ) { n_win64_ui_scrollbar_draw( p ); }


	return;
}

void
n_win64_ui_scrollbar_metrics( n_win64_ui_scrollbar *p )
{
//return;

	RECT client; GetClientRect( p->hwnd, &client );

	p->csx = client.right;
	p->csy = client.bottom;


	n_type_gfx ctl = n_win64_ui_scrollbar_stdsize( p );

	p->csx = n_posix_max_n_type_gfx( ctl, p->csx );
	p->csy = n_posix_max_n_type_gfx( ctl, p->csy );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			p->pixel_arrow_sx = p->pixel_arrow_sy = 0;
			p->pixel_minim = p->csy;
		} else {
			p->pixel_arrow_sx = p->pixel_arrow_sy = 0;
			p->pixel_minim = p->csx;
		}

	} else {

		n_type_real n = 1;
		if ( p->option & N_WIN_SCROLLBAR_OPTION_BIG_ARROWS )
		{
			n = 1.5;
		}

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			p->pixel_minim    = p->csy;
			p->pixel_arrow_sx = (n_type_real) p->csy * n;
			p->pixel_arrow_sy = p->csy;
		} else {
			p->pixel_minim    = p->csx;
			p->pixel_arrow_sx = p->csx;
			p->pixel_arrow_sy = (n_type_real) p->csx * n;
		}

	}


	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_shaft = p->csx - ( p->pixel_arrow_sx * 2 );
	} else {
		p->pixel_shaft = p->csy - ( p->pixel_arrow_sy * 2 );
	}

	p->pixel_shaft = n_posix_max_n_type_real( p->pixel_minim, p->pixel_shaft );


	// [!] : the second mode

	p->pixel_max  = n_posix_max_n_type_real( 1.0, p->pixel_shaft );
	p->pixel_step = ( p->unit_step / p->unit_max ) * p->pixel_max;
	p->pixel_page = ( p->unit_page / p->unit_max ) * p->pixel_max;
	p->pixel_pos  = ( p->unit_pos  / p->unit_max ) * p->pixel_max;
//n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g %g ", p->pixel_max, p->pixel_step, p->pixel_page );

	// [!] : minimum thumb size

	p->pixel_thumb_original = p->pixel_page;
	p->pixel_thumb          = n_posix_max_n_type_real( p->pixel_page, p->pixel_minim );

	// [Needed] : rounding is needed

	p->pixel_thumb_original = ceil( p->pixel_thumb_original );
	p->pixel_thumb          = ceil( p->pixel_thumb          );

//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g ", p->pixel_thumb_original, p->pixel_thumb ); }


	// [!] : the third mode

	if ( p->pixel_thumb_original < p->pixel_thumb )
	{
//n_win64_ui_scrollbar_debug_count( p );

//n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g ", (n_type_real) p->sy, (n_type_real) p->pixel_max );

		p->pixel_patch = ( p->pixel_max - p->pixel_page + p->pixel_thumb ) - p->pixel_max;

//n_win64_ui_scrollbar_hwndprintf_literal( p, " %g ", p->pixel_patch );

		p->pixel_max  = n_posix_max_n_type_real( 1.0, p->pixel_max - p->pixel_patch );
		p->pixel_step = ( p->unit_step / p->unit_max ) * p->pixel_max;
		p->pixel_page = ( p->unit_page / p->unit_max ) * p->pixel_max;
		p->pixel_pos  = ( p->unit_pos  / p->unit_max ) * p->pixel_max;

	} else {

		p->pixel_patch = 0;

	}


	return;
}

void
n_win64_ui_scrollbar_parameter( n_win64_ui_scrollbar *p, n_type_real step, n_type_real page, n_type_real max, n_type_real pos, BOOL redraw )
{

	// [!] : the first mode

	max += page;

	p->unit_step = step;
	p->unit_page = page;
	p->unit_max  = n_posix_max_n_type_real( 1.0, max ) ;
	p->unit_pos  = pos;
//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " parameter() :  %g %g %g ", p->unit_pos, p->unit_page, p->unit_max ); }

	if ( max >= page )
	{
		p->enabled    = TRUE;
		p->enabled_ul = TRUE;
		p->enabled_dr = TRUE;
	} else {
		p->enabled    = FALSE;
		p->enabled_ul = FALSE;
		p->enabled_dr = FALSE;
	}


	if ( redraw )
	{
		extern void n_win64_ui_scrollbar_draw( n_win64_ui_scrollbar* );
		n_win64_ui_scrollbar_draw( p );
	}


	return;
}




BOOL
n_win64_ui_scrollbar_scroll_pixel( n_win64_ui_scrollbar *p, n_type_real pixel_delta, int option )
{
//n_win64_ui_scrollbar_debug_count( p );

//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " n_win64_ui_scrollbar_scroll_pixel() " ); }


	if ( pixel_delta != 0 )
	{

		p->pixel_pos += pixel_delta;


		n_type_real pixel_min = 0;
		n_type_real pixel_max = n_win64_ui_scrollbar_position_last_pixel( p );

		p->pixel_pos = n_posix_minmax_n_type_real( pixel_min, pixel_max, p->pixel_pos );
//n_win64_ui_scrollbar_hwndprintf_literal( p, " %f %f %f ", pixel_delta, p->pixel_pos, pixel_max );


		p->unit_pos_prev = p->unit_pos;


		n_type_real unit_min = 0;
		n_type_real unit_max = n_win64_ui_scrollbar_position_last_unit( p );

		p->unit_pos = n_win64_ui_scrollbar_position_pixel2unit( p );


		// [Needed] : unit_max+1

		p->unit_pos = n_posix_minmax_n_type_real( unit_min, unit_max+1, p->unit_pos );

//if ( p->layout == 0 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g ", p->unit_pos, prv_unit_pos ); }
//if ( p->layout == 0 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g ", p->unit_pos,     unit_max ); }

	}


	BOOL ret = FALSE;
	if ( option == N_WIN_SCROLLBAR_SCROLL_NONE )
	{
		//
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_SEND )
	{
		n_win64_message_send( p->hwnd_parent, WM_COMMAND, p->unit_pos, p->hwnd );
		ret = TRUE;
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_AUTO )
	{
		ret = ( p->unit_pos_prev != p->unit_pos );
		if ( ret )
		{
			n_win64_message_send( p->hwnd_parent, WM_COMMAND, p->unit_pos, p->hwnd );
		}
	}


	return ret;
}

BOOL
n_win64_ui_scrollbar_scroll_unit( n_win64_ui_scrollbar *p, n_type_real unit_delta, int option )
{
//n_win64_ui_scrollbar_debug_count( p );

//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " n_win64_ui_scrollbar_scroll_unit() " ); }

	if ( unit_delta != 0 )
	{

		p->unit_pos_prev = p->unit_pos;


		p->unit_pos += unit_delta;


		n_type_real unit_min = 0;
		n_type_real unit_max = n_win64_ui_scrollbar_position_last_unit( p );

		p->unit_pos = n_posix_minmax_n_type_real( unit_min, unit_max, p->unit_pos );

//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g %g ", p->unit_pos, p->unit_page, unit_max ); }


		n_type_real pixel_min = 0;
		n_type_real pixel_max = n_win64_ui_scrollbar_position_last_pixel( p );

		p->pixel_pos = n_win64_ui_scrollbar_position_unit2pixel( p );
		p->pixel_pos = n_posix_minmax_n_type_real( pixel_min, pixel_max, p->pixel_pos );

//if ( p->layout == 1 ) { n_win64_ui_scrollbar_hwndprintf_literal( p, " %g %g ", p->pixel_pos, pixel_max ); }
	}


	BOOL ret = FALSE;
	if ( option == N_WIN_SCROLLBAR_SCROLL_NONE )
	{
		//
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_SEND )
	{
		ret = TRUE;
		n_win64_message_send( p->hwnd_parent, WM_COMMAND, (int) p->unit_pos, p->hwnd );
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_AUTO )
	{
		ret = ( 1 <= fabs( p->unit_pos_prev - p->unit_pos ) );
		if ( ret )
		{
			n_win64_message_send( p->hwnd_parent, WM_COMMAND, (int) p->unit_pos, p->hwnd );
		}
	}


	return ret;
}




void
n_win64_ui_scrollbar_reset( n_win64_ui_scrollbar *p )
{

	p->unit_pos = p->pixel_pos = 0;

	n_win64_ui_scrollbar_scroll_pixel( p, 0, N_WIN_SCROLLBAR_SCROLL_SEND );


	return;
}




void
n_win64_ui_scrollbar_thumb_rect_set( n_win64_ui_scrollbar *p, n_type_real *ret_x, n_type_real *ret_y )
{

	// [!] : position

	n_type_real dx,dy; n_win64_ui_scrollbar_position_thumb( p, &dx, &dy );


	// [!] : offset

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		dx += p->pixel_arrow_sx;
	} else {
		dy += p->pixel_arrow_sy;
	}


	if ( ret_x != NULL ) { (*ret_x) = dx; }
	if ( ret_y != NULL ) { (*ret_y) = dy; }


	// [!] : size

	n_type_gfx bmpsx = N_BMP_SX( &p->bmp_th );
	n_type_gfx bmpsy = N_BMP_SY( &p->bmp_th );


	// [!] : for collision/hittest

	p->rect_thumb = n_win64_ui_scrollbar_rect_set_range( dx,dy,bmpsx,bmpsy );


	return;
}




void
n_win64_ui_scrollbar_draw( n_win64_ui_scrollbar *p )
{

	if ( FALSE == IsWindow( p->hwnd ) ) { return; }


	RECT rect; GetClientRect( p->hwnd, &rect );

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_size( &rect, &x, &y, &sx, &sy );


	n_win64_doublebuffer_simple_init( p->hwnd, sx,sy );

	n_bmp *bmp_canvas = &n_win64_doublebuffer_instance.bmp;
//n_bmp_flush( bmp_canvas, n_bmp_rgb( 0,200,255 ) );


	// UI Maker

	n_win64_ui_scrollbar_metrics( p );

	n_win64_ui_scrollbar_arrowbutton_onoff( p );


	n_type_gfx ox_tl = 0;
	n_type_gfx oy_tl = 0;
	n_type_gfx ox_dr = 0;
	n_type_gfx oy_dr = 0;

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		n_type_real d = N_WIN_SCROLLBAR_RECT_NONE;

		p->rect_arrow_ul = n_win64_ui_scrollbar_rect_set_range( d,d,d,d );
		p->rect_arrow_dr = n_win64_ui_scrollbar_rect_set_range( d,d,d,d );

	} else {

		// [!] : Top / Left

		// [!] : for collision/hittest

		n_type_gfx hit_x_tl = ox_tl;
		n_type_gfx hit_y_tl = oy_tl;

		p->rect_arrow_ul = n_win64_ui_scrollbar_rect_set_range( hit_x_tl,hit_y_tl,p->pixel_arrow_sx,p->pixel_arrow_sy );


		// [!] : Bottom / Right

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			ox_dr = (n_type_gfx) ( sx - p->pixel_arrow_sx );
			oy_dr = 0;
		} else {
			ox_dr = 0;
			oy_dr = (n_type_gfx) ( sy - p->pixel_arrow_sy );
		}

		// [!] : for collision/hittest

		n_type_gfx hit_x_dr = ox_dr;
		n_type_gfx hit_y_dr = oy_dr;

		p->rect_arrow_dr = n_win64_ui_scrollbar_rect_set_range( hit_x_dr,hit_y_dr,p->pixel_arrow_sx,p->pixel_arrow_sy );

	}


	// Shaft

	n_win64_ui_scrollbar_ui_maker_shaft( p );

	n_bmp_fastcopy( &p->bmp_sh, bmp_canvas, x,y,N_BMP_SX( &p->bmp_sh ),N_BMP_SY( &p->bmp_sh ), x,y );


	// Arrows

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		//

	} else {

		n_win64_ui_scrollbar_ui_maker_arrows( p );

		// [!] : Top / Left

//n_bmp_box( bmp_canvas, ox_tl,oy_tl, p->pixel_arrow_sx,p->pixel_arrow_sy, n_bmp_rgb( 255,0,255 ) );

		n_bmp_fastcopy( &p->bmp_ul, bmp_canvas, 0,0,p->pixel_arrow_sx,p->pixel_arrow_sy, ox_tl,oy_tl );


		// [!] : Bottom / Right

//n_bmp_box( bmp_canvas, ox_dr,oy_dr, p->pixel_arrow_sx,p->pixel_arrow_sy, n_bmp_rgb( 255,255,0 ) );

		n_bmp_fastcopy( &p->bmp_dr, bmp_canvas, 0,0,p->pixel_arrow_sx,p->pixel_arrow_sy, ox_dr,oy_dr );

	}


	// Thumb

	{
		n_win64_ui_scrollbar_ui_maker_thumb( p );

		n_type_real dx,dy;
		n_win64_ui_scrollbar_thumb_rect_set( p, &dx, &dy );

		if ( p->enabled )
		{
			n_type_gfx int_x = (n_type_gfx) trunc( dx );
			n_type_gfx int_y = (n_type_gfx) trunc( dy );

			n_type_gfx bmpsx = N_BMP_SX( &p->bmp_th );
			n_type_gfx bmpsy = N_BMP_SY( &p->bmp_th );

			n_bmp_fastcopy( &p->bmp_th, bmp_canvas, 0,0,bmpsx,bmpsy, int_x,int_y );
		}
	}


	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		u32 check; n_bmp_ptr_get_fast( bmp_canvas, 0,0, &check );
		if ( check != p->color_edge_ul )
		{
			n_type_gfx round = n_win64_fluent_ui_round_param();

			n_bmp_cornermask_rich
			(
				bmp_canvas,
				round,
				0,
				p->color_edge_ul,
				p->color_edge_ur,
				p->color_edge_dl,
				p->color_edge_dr
			);
		}
	}

//n_bmp_save_literal( bmp_canvas, "ret.bmp" );


	// Done!

	n_win64_doublebuffer_simple_exit();


	return;
}




n_type_real
n_win64_ui_scrollbar_pager( n_win64_ui_scrollbar *p, n_type_gfx cursor_x, n_type_gfx cursor_y )
{

	// [!] : Nonnon Original Scrollpager

	n_type_real pos = 0;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		pos = cursor_x - p->pixel_arrow_sx - ( p->pixel_thumb / 2 );
	} else {
		pos = cursor_y - p->pixel_arrow_sy - ( p->pixel_thumb / 2 );
	}


	return pos;
}

void
n_win64_ui_scrollbar_event_shaft( n_win64_ui_scrollbar *p )
{

	n_type_gfx cursor_x, cursor_y; n_win64_ui_scrollbar_position_cursor( p, &cursor_x, &cursor_y );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_PAGER )
	{

		n_type_real pos = n_win64_ui_scrollbar_pager( p, cursor_x, cursor_y );
		p->pixel_pos = 0;

		n_win64_ui_scrollbar_scroll_pixel( p, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		n_win64_ui_scrollbar_draw( p );

	} else {

		n_type_real delta = 0;

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			if ( cursor_x < p->rect_thumb.x )
			{
				delta = -p->unit_page;
			} else
			if ( cursor_x > p->rect_thumb.x )
			{
				delta =  p->unit_page;
			}
		} else {
			if ( cursor_y < p->rect_thumb.y )
			{
				delta = -p->unit_page;
			} else
			if ( cursor_y > p->rect_thumb.y )
			{
				delta =  p->unit_page;
			}
		}
//n_posix_debug_literal( " %f ", delta );

		if ( n_win64_ui_scrollbar_scroll_unit( p, delta, N_WIN_SCROLLBAR_SCROLL_AUTO ) )
		{
			n_win64_ui_scrollbar_draw( p );
		}
	
	}


	return;
}

void
n_win64_ui_scrollbar_on_input( n_win64_ui_scrollbar *p )
{

	p->hovered_main     = n_win64_ui_scrollbar_rect_is_hovered( p->hwnd, p->rect_main );
	p->hovered_thumb    = n_win64_ui_scrollbar_rect_is_hovered( p->hwnd, p->rect_thumb );
	p->hovered_arrow_ul = n_win64_ui_scrollbar_rect_is_hovered( p->hwnd, p->rect_arrow_ul );
	p->hovered_arrow_dr = n_win64_ui_scrollbar_rect_is_hovered( p->hwnd, p->rect_arrow_dr );
	p->hovered_shaft    = n_win64_ui_scrollbar_rect_is_hovered( p->hwnd, p->rect_shaft );

	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_thumb    == FALSE );
	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_arrow_ul == FALSE );
	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_arrow_dr == FALSE );


	return;
}

void
n_win64_ui_scrollbar_thumb_dnd_offset( n_win64_ui_scrollbar *p )
{

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_offset = p->prv_cursor_x - p->rect_thumb.x;
	} else {
		p->pixel_offset = p->prv_cursor_y - p->rect_thumb.y;
	}


	return;
}

void
n_win64_ui_scrollbar_on_drag( n_win64_ui_scrollbar *p )
{
//return;

	n_win64_ui_scrollbar_position_cursor( p, &p->cur_cursor_x, &p->cur_cursor_y );


	n_type_real pixel_delta = 0;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		pixel_delta = p->cur_cursor_x - p->prv_cursor_x;
	} else
	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
	{
		pixel_delta = p->cur_cursor_y - p->prv_cursor_y;
	}

	if ( pixel_delta == 0.0 ) { return; }


	BOOL ret = n_win64_ui_scrollbar_scroll_pixel( p, pixel_delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
	if ( ret ) { n_win64_ui_scrollbar_draw( p ); }


	p->prv_cursor_x = p->cur_cursor_x;
	p->prv_cursor_y = p->cur_cursor_y;


	return;
}




void
n_win64_ui_scrollbar_proc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_win64_ui_scrollbar *p )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lParam;
		if ( di == NULL ) { break; }
//n_win64_ui_scrollbar_debug_count( p );

		if ( di->hwndItem == p->hwnd )
		{
			n_win64_ui_scrollbar_draw( p );
		}

	}
	break;


	} // switch


	return;
}




// internal
LRESULT CALLBACK
n_win64_ui_scrollbar_subclass( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
{

	n_win64_ui_scrollbar *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }


	switch( msg ) {


	case WM_MOUSEWHEEL :
	{
//n_win64_ui_scrollbar_debug_count( p );

		int delta = n_win64_scroll_wheeldelta( wParam, 1 ) * -1;
//n_win64_hwndprintf_literal( GetParent( p->hwnd ), " %d ", delta );

		n_win64_ui_scrollbar_scroll_unit( p, delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
		n_win64_ui_scrollbar_draw( p );
	}
	break;


	case WM_MOUSEMOVE :

		if ( p->drag_onoff )
		{
			n_win64_ui_scrollbar_on_drag( p );
		}

	break;


	case WM_LBUTTONDOWN :
	case WM_LBUTTONDBLCLK :

		SetCapture( hwnd );


		if ( p->enabled == FALSE ) { break; }


		n_win64_ui_scrollbar_on_input( p );

		n_win64_ui_scrollbar_position_cursor( p, &p->prv_cursor_x, &p->prv_cursor_y );

		if ( p->hovered_thumb )
		{
//n_win64_hwndprintf_literal( GetParent( p->hwnd ), " p->hovered_thumb " );

			p->pressed_thumb = TRUE;

			if ( p->drag_onoff == FALSE )
			{
				p->drag_onoff = TRUE;

				n_win64_ui_scrollbar_thumb_dnd_offset( p );

				n_win64_ui_scrollbar_draw( p );
			}

		} else
		if ( p->hovered_arrow_ul )
		{
//n_win64_hwndprintf_literal( GetParent( p->hwnd ), " p->hovered_arrow_ul " );

			if ( p->enabled_ul == FALSE ) { break; }

			p->pressed_arrow_ul = TRUE;

			n_win64_ui_scrollbar_draw( p );

		} else
		if ( p->hovered_arrow_dr )
		{

			if ( p->enabled_dr == FALSE ) { break; }

			p->pressed_arrow_dr = TRUE;

			n_win64_ui_scrollbar_draw( p );

		} else
		if ( p->hovered_shaft )
		{
//n_win64_ui_scrollbar_hwndprintf_literal( p, " p->hovered_shaft " );

			p->pressed_shaft= TRUE;

			n_win64_ui_scrollbar_event_shaft( p );

		}

	break;


	case WM_LBUTTONUP :
	{

		ReleaseCapture();


		if ( p->enabled == FALSE ) { goto cleanup; }


		n_win64_ui_scrollbar_on_input( p );


		if ( p->hovered_thumb )
		{

			if ( p->drag_onoff )
			{
				n_win64_ui_scrollbar_on_drag( p );
			}

			n_win64_ui_scrollbar_draw( p );

		} else
		if ( p->hovered_arrow_ul )
		{

			if ( p->enabled_ul == FALSE ) { goto cleanup; }

			n_win64_ui_scrollbar_scroll_unit( p, -p->unit_step, N_WIN_SCROLLBAR_SCROLL_AUTO );

			n_win64_ui_scrollbar_draw( p );

		} else
		if ( p->hovered_arrow_dr )
		{

			if ( p->enabled_dr == FALSE ) { goto cleanup; }

			n_win64_ui_scrollbar_scroll_unit( p, p->unit_step, N_WIN_SCROLLBAR_SCROLL_AUTO );

			n_win64_ui_scrollbar_draw( p );

		} else
		if ( p->hovered_shaft )
		{
			//
		}


		// [Needed] : prevent press'n'run

		cleanup:

		p->hovered_thumb = p->drag_onoff = FALSE;
		p->pressed_arrow_ul = FALSE;
		p->pressed_arrow_dr = FALSE;
		p->pressed_shaft = FALSE;

	}
	break;


	} // switch


	return DefSubclassProc( hwnd, msg, wParam, lParam );
}




void
n_win64_ui_scrollbar_init( n_win64_ui_scrollbar *p, HWND hwnd_parent, int layout, int style, int option )
{

	n_win64_ui_scrollbar_zero( p );


	p->hwnd_parent = hwnd_parent;

	const HINSTANCE hinst = GetModuleHandle( NULL );

	p->hwnd = CreateWindowEx
	(
		0,
		n_posix_literal( "BUTTON" ),
		N_STRING_EMPTY,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | BS_OWNERDRAW,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		hinst,
		NULL
	);

	SetWindowSubclass( p->hwnd, n_win64_ui_scrollbar_subclass, 0, (DWORD_PTR) p );


	p->enabled = TRUE;
	p->layout  = layout;
	p->style   = style;
	p->option  = option;


	n_win64_ui_scrollbar_on_WM_SETTINGCHANGE( p, FALSE );


	return;
}

void
n_win64_ui_scrollbar_exit( n_win64_ui_scrollbar *p )
{

	DestroyWindow( p->hwnd );


	n_bmp_free_fast( &p->bmp_sh );
	n_bmp_free_fast( &p->bmp_ul );
	n_bmp_free_fast( &p->bmp_dr );
	n_bmp_free_fast( &p->bmp_th );
	n_bmp_free_fast( &p->bmp_gr );


	n_win64_ui_scrollbar_zero( p );


	return;
}


#endif // _H_NONNON_WIN64_UI_SCROLLBAR


