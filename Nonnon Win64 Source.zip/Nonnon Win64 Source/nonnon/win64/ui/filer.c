// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_UI_FILER
#define _H_NONNON_WIN64_UI_FILER




#include "../../neutral/filer.c"


#include "./richdialog.c"




// internal
int
n_win_filer_text_style( void )
{
	return N_GDI_TEXT_BOLD;
}

// internal
n_type_gfx
n_win_filer_text_minsx( void )
{

	n_type_gfx sx,sy; n_win_desktop_size( &sx, &sy );

	return (n_type_gfx) ( (n_type_real) n_posix_min_n_type_gfx( sx, sy ) * 0.4 );
}

// internal
void
n_win_filer_text_precalc( n_gdi *gdi, n_type_gfx *sx, n_type_gfx *sy )
{

	n_gdi g = (*gdi);

	g.style |= N_GDI_CALCONLY; n_gdi_bmp( &g, NULL );

	if ( sx != NULL ) { (*sx) = g.sx; }
	if ( sy != NULL ) { (*sy) = g.sy; }


	return;
}

#define n_win_filer_text_space_add( s, c ) n_win_filer_text_space( s, c,  TRUE )
#define n_win_filer_text_space_del( s, c ) n_win_filer_text_space( s, c, FALSE )

// internal
void
n_win_filer_text_space( n_posix_char *str, int count, BOOL is_add )
{

	// [!] : unsafe module

	if ( str == NULL ) { return; }

	if ( count == 0 ) { return; }


	int cch = (int) n_posix_strlen( str );


	int i = 0;
	n_posix_loop
	{

		if ( is_add )
		{
			str[ cch + i + 0 ] = N_STRING_CHAR_SPACE;
			str[ cch + i + 1 ] = N_STRING_CHAR_NUL;
		} else {
			str[ cch - i + 0 ] = N_STRING_CHAR_NUL;

		}

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

// internal
void
n_win_filer_text_separator( n_gdi *gdi, n_type_gfx max_sx )
{

	n_type_gfx space_sx; n_win_stdsize_text( NULL, N_STRING_SPACE, &space_sx, NULL );

	n_win_filer_text_space_add( gdi->text, max_sx / space_sx );


	// [!] : don't use BOOL

	int move = 0;

	// [x] : buggy : doesn't reach break; in some cases

	n_type_int cch = n_posix_strlen( gdi->text );

	n_type_int i = 0;
	n_posix_loop
	{

		n_type_gfx sx; n_win_filer_text_precalc( gdi, &sx, NULL );
		if ( sx == max_sx )
		{
			break;
		} else
		if ( sx < max_sx )
		{
			if ( move == -1 ) { break; } else { i++; move =  1; }
			n_win_filer_text_space_add( gdi->text, 1 );
		} else
		if ( sx > max_sx )
		{
			n_win_filer_text_space_del( gdi->text, 1 );
			if ( move ==  1 ) { break; } else { i++; move = -1; }
		}

		if ( i >= cch ) { break; }
	}


	return;
}

// internal
void
n_win_filer_ui( const n_posix_char *title, const n_posix_char *f, const n_posix_char *t )
{


	n_win_richdialog_init( &n_win_richdialog_instance, 8, title );


	n_gdi *gdi = n_win_richdialog_instance.gdi;


	n_type_int o_f = 0;
	n_type_int o_t = 4;


	n_type_gfx max_sx;

	{

		gdi[ o_f + 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_f + 1 ].icon        = n_string_carboncopy( f );
		gdi[ o_f + 1 ].text        = n_string_carboncopy( f );
		gdi[ o_f + 1 ].text_style |= n_win_filer_text_style();

		gdi[ o_t + 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_t + 1 ].icon        = n_string_carboncopy( t );
		gdi[ o_t + 1 ].text        = n_string_carboncopy( t );
		gdi[ o_t + 1 ].text_style |= n_win_filer_text_style();


		n_type_gfx f_sx; n_win_filer_text_precalc( &gdi[ o_f + 1 ], &f_sx, NULL );
		n_type_gfx t_sx; n_win_filer_text_precalc( &gdi[ o_t + 1 ], &t_sx, NULL );

		max_sx = n_posix_max_n_type_gfx( n_win_filer_text_minsx(), n_posix_max_n_type_gfx( f_sx, t_sx ) );

	}


	{

		gdi[ o_f + 0 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_f + 0 ].text        = n_string_new( 4 + max_sx );
		gdi[ o_f + 0 ].text_style |= N_GDI_TEXT_UNDERLINE;

		gdi[ o_t + 0 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ o_t + 0 ].text        = n_string_new( 4 + max_sx );
		gdi[ o_t + 0 ].text_style |= N_GDI_TEXT_UNDERLINE;


		n_posix_snprintf_literal( gdi[ o_f + 0 ].text, 4 + max_sx + 1, "From" );
		n_posix_snprintf_literal( gdi[ o_t + 0 ].text, 4 + max_sx + 1, "To  " );

		n_win_filer_text_separator( &gdi[ o_f + 0 ], max_sx );
		n_win_filer_text_separator( &gdi[ o_t + 0 ], max_sx );

	}


	if ( n_posix_stat_is_dir( f ) )
	{

		gdi[ o_f + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 2 ].text        = n_string_new( 100 );

		gdi[ o_t + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 2 ].text        = n_string_new( 100 );

		n_posix_snprintf_literal( gdi[ o_f + 2 ].text, 100 + 1, "%s", n_posix_literal( "Folder" ) );
		n_posix_snprintf_literal( gdi[ o_t + 2 ].text, 100 + 1, "%s", n_posix_literal( "Folder" ) );

	} else {

		gdi[ o_f + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 2 ].text        = n_string_new( 100 );

		gdi[ o_t + 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 2 ].text        = n_string_new( 100 );


		n_type_int size_f = n_posix_stat_size( f );
		n_type_int size_t = n_posix_stat_size( t );

		n_posix_char str_size_f[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_size_f, size_f );
		n_posix_char str_size_t[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_size_t, size_t );

		n_posix_snprintf_literal( gdi[ o_f + 2 ].text, N_STRING_INT2STR_CCH_MAX, "%s Byte", str_size_f );
		n_posix_snprintf_literal( gdi[ o_t + 2 ].text, N_STRING_INT2STR_CCH_MAX, "%s Byte", str_size_t );


		if ( size_f > size_t )
		{
			gdi[ o_f + 2 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 2 ].text, n_posix_literal(" (Larger)" ) );
			n_posix_strcat( gdi[ o_t + 2 ].text, n_posix_literal(" (Smaller)") );
		} else
		if ( size_f < size_t )
		{
			gdi[ o_t + 2 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 2 ].text, n_posix_literal(" (Smaller)") );
			n_posix_strcat( gdi[ o_t + 2 ].text, n_posix_literal(" (Larger)" ) );
		}

	}


	if ( n_posix_stat_is_dir( f ) )
	{

		//

	} else {

		gdi[ o_f + 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_f + 3 ].text        = n_string_new( 100 );

		gdi[ o_t + 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ o_t + 3 ].text        = n_string_new( 100 );


		n_time_string_mtime( f, gdi[ o_f + 3 ].text );
		n_time_string_mtime( t, gdi[ o_t + 3 ].text );


		int ret = n_time_compare_mtime( f, t );
		if ( ret ==  1 )
		{
			gdi[ o_f + 3 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 3 ].text, n_posix_literal(" (Newer)") );
			n_posix_strcat( gdi[ o_t + 3 ].text, n_posix_literal(" (Older)") );
		}
		if ( ret == -1 )
		{
			gdi[ o_t + 3 ].text_style |= n_win_filer_text_style();
			n_posix_strcat( gdi[ o_f + 3 ].text, n_posix_literal(" (Older)") );
			n_posix_strcat( gdi[ o_t + 3 ].text, n_posix_literal(" (Newer)") );
		}

	}


	return;
}

BOOL
n_win_filer_replace( HWND hwnd, const n_posix_char *f, const n_posix_char *t, BOOL *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = FALSE; }


	if ( FALSE == n_posix_stat_is_exist( f ) ) { return TRUE; }
	if ( FALSE == n_posix_stat_is_exist( t ) )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		BOOL ret = n_filer_copy( f, t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}

	if ( n_string_is_same( f, t ) ) { return TRUE; }

	if ( n_filer_is_locked( t ) ) { return TRUE; }


	n_win_filer_ui( n_posix_literal( "Replace" ), f, t );

	n_win_richdialog_instance.label = n_posix_literal( "Replace" );


	BOOL is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_posix_char *dir = n_string_path_upperfolder_new( t );
		n_posix_char *tmp = n_string_path_tmpname_new( N_STRING_EMPTY );
		n_posix_char *nam = n_string_path_make_new( dir, tmp );


		BOOL ret = n_string_path_rename( t, nam );
		if ( ret )
		{

			// [!] : Error : nothing to do

		} else {

			ret = n_filer_copy( f, t );
			if ( ret )
			{

				// [!] : Failed : restore an old one

				ret = n_filer_remove( t );
				if ( ret == FALSE ) { ret = n_string_path_rename( nam, t ); }

			} else {

				// [!] : Succeeded : remove an old one

				ret = n_filer_remove( nam );

			}

		}


		n_string_path_free( dir );
		n_string_path_free( tmp );
		n_string_path_free( nam );


		n_win_cursor_add( NULL, IDC_ARROW );


		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = TRUE; }


	return FALSE;
}

BOOL
n_win_filer_merge( HWND hwnd, const n_posix_char *f, const n_posix_char *t, BOOL *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = FALSE; }


	if ( FALSE == n_posix_stat_is_exist( f ) ) { return TRUE; }
	if ( FALSE == n_posix_stat_is_exist( t ) )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		BOOL ret = n_filer_copy( f, t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}

	if ( n_string_is_same( f, t ) ) { return TRUE; }

	if ( n_filer_is_locked( t ) ) { return TRUE; }


	n_win_filer_ui( n_posix_literal( "Merge" ), f, t );

	n_win_richdialog_instance.label = n_posix_literal( "Merge" );


	BOOL is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_filer_merge( f, t );


		n_win_cursor_add( NULL, IDC_ARROW );


		return FALSE;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = TRUE; }


	return FALSE;
}

BOOL
n_win_filer_move( HWND hwnd, const n_posix_char *f, const n_posix_char *t, BOOL *is_cancelled )
{
//n_posix_debug_literal( "%s\n%s", f, t );

	if ( is_cancelled != NULL ) { (*is_cancelled) = FALSE; }


	if ( n_string_is_empty( f ) ) { return TRUE; }
	if ( n_string_is_empty( t ) ) { return TRUE; }

	if ( FALSE == n_posix_stat_is_exist( f ) ) { return TRUE; }
	if ( FALSE == n_posix_stat_is_exist( t ) )
	{
		// [!] : same drives => simply rename

		if ( f[ 0 ] == t[ 0 ] )
		{

			return ( -1 == n_posix_rename( f, t ) );

		} else {

			n_win_cursor_add( NULL, IDC_WAIT );

			BOOL ret = n_filer_is_locked( f );
			if ( ret == FALSE )
			{
				ret = n_filer_copy( f, t );
				if ( ret == FALSE )
				{
					ret = n_filer_remove( f );
				}

			}

			n_win_cursor_add( NULL, IDC_ARROW );

			return ret;
		}
	}

	if ( n_string_is_same( f, t ) ) { return TRUE; }

	if ( n_filer_is_locked( t ) ) { return TRUE; }


	n_win_filer_ui( n_posix_literal( "Move" ), f, t );

	n_win_richdialog_instance.label = n_posix_literal( "Move" );


	BOOL is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
//n_posix_debug_literal( " %d ", is_ok );

	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );


		n_posix_char *dir = n_string_path_upperfolder_new( t );
		n_posix_char *tmp = n_string_path_tmpname_new( N_STRING_EMPTY );
		n_posix_char *nam = n_string_path_make_new( dir, tmp );


		BOOL ret = n_string_path_rename( t, nam );
		if ( ret )
		{

			// [!] : Error : nothing to do

		} else
		if ( FALSE == n_filer_is_locked( f ) )
		{

			ret = n_filer_copy( f, t );
			if ( ret )
			{

				// [!] : Failed : restore an old one

				ret = n_filer_remove( t );
				if ( ret == FALSE ) { ret = n_string_path_rename( nam, t ); }

			} else {

				// [!] : Succeeded : remove an old one

				ret = n_filer_remove( nam );


				// [!] : integrity checker

				if ( n_filer_is_same( f, t ) )
				{

					// [!] : Succeeded

					ret = FALSE;
					n_filer_remove( f );

				} else {

					// [!] : Failed : cleanup is needed

					ret = TRUE;
					n_filer_remove( t );

				}

			}

		}


		n_string_path_free( dir );
		n_string_path_free( tmp );
		n_string_path_free( nam );


		n_win_cursor_add( NULL, IDC_ARROW );


		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = TRUE; }


	return FALSE;
}

BOOL
n_win_filer_delete( HWND hwnd, const n_posix_char *t, BOOL *is_cancelled )
{

	if ( is_cancelled != NULL ) { (*is_cancelled) = FALSE; }


	if ( FALSE == n_posix_stat_is_exist( t ) ) { return TRUE; }

	if ( n_filer_is_locked( t ) ) { return TRUE; }


	n_win_richdialog_init( &n_win_richdialog_instance, 5, n_posix_literal( "Delete" ) );

	n_win_richdialog_instance.label = n_posix_literal( "Delete" );


	n_gdi *gdi = n_win_richdialog_instance.gdi;


	n_type_gfx max_sx;

	{

		gdi[ 1 ].align       = N_GDI_ALIGN_LEFT;
		gdi[ 1 ].icon        = n_string_carboncopy( t );
		gdi[ 1 ].text        = n_string_carboncopy( t );
		gdi[ 1 ].text_style |= n_win_filer_text_style();

		n_type_gfx sx; n_win_filer_text_precalc( &gdi[ 1 ], &sx, NULL );
		max_sx = n_posix_max_n_type_gfx( n_win_filer_text_minsx(), sx );

	}


	{

		gdi[ 4 ] = gdi[ 0 ];

		gdi[ 0 ].text = n_string_new( max_sx );
		gdi[ 4 ].text = n_string_new( max_sx );

		n_win_filer_text_separator( &gdi[ 0 ], max_sx );
		n_win_filer_text_separator( &gdi[ 4 ], max_sx );

	}


	{

		gdi[ 2 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ 2 ].text        = n_string_new( 100 );

		n_type_int size = n_posix_stat_size( t );

		n_posix_char str_size[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_size, size );

		n_posix_snprintf_literal( gdi[ 2 ].text, N_STRING_INT2STR_CCH_MAX, "%s Byte", str_size );

	}


	{

		gdi[ 3 ].align       = N_GDI_ALIGN_RIGHT;
		gdi[ 3 ].text        = n_string_new( 100 );

		n_time_string_mtime( t, gdi[ 3 ].text );

	}


	BOOL is_ok = n_win_richdialog_go( &n_win_richdialog_instance, hwnd );
	if ( is_ok )
	{

		n_win_cursor_add( NULL, IDC_WAIT );

		BOOL ret = n_filer_remove( t );

		n_win_cursor_add( NULL, IDC_ARROW );

		return ret;
	}


	// [!] : Cancelled

	if ( is_cancelled != NULL ) { (*is_cancelled) = TRUE; }


	return FALSE;
}


#endif // _H_NONNON_WIN64_UI_FILER

