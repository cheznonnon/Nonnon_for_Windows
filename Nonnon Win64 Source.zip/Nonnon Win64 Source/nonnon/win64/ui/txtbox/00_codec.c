// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_TXTBOX_00_CODEC
#define _H_NONNON_MAC_TXTBOX_00_CODEC




void
n_txt_decoration_init( n_txt *txt, n_txt *txt_deco )
{

	if ( txt_deco == NULL ) { return; }

	n_txt_new( txt_deco );

	n_type_int i = 0;
	n_posix_loop
	{

		n_txt_set( txt_deco, i, N_STRING_SPACE );

		i++;
		if ( i >= txt->sy ) { break; }
	}


	return;
}




#endif // _H_NONNON_MAC_TXTBOX_00_CODEC

