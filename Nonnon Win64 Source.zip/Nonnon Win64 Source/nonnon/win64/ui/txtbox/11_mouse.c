// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
NonnonTxtboxMouseClamp( n_txtbox *txtbox )
{

//NSLog( @"NonnonTxtboxMouseClamp : %f %f", scroll, scroll_step );
//NSLog( @"NonnonTxtboxMouseClamp : %f %lld", scroll + scroll_page, txtbox->txt_data->sy );
//NSLog( @"NonnonTxtboxMouseClamp : %f %lld", scroll + scroll_page + scroll_step, txtbox->txt_data->sy );

	n_type_real line_sy = txtbox->txt_data->sy;

	if ( txtbox->scroll < 1.0 )
	{
		txtbox->scroll = 0;
	} else
	if ( ( txtbox->scroll + txtbox->scroll_page + txtbox->scroll_step ) > line_sy )
	{
//NSLog( @"overshoot" );
		txtbox->scroll = line_sy - txtbox->scroll_page;
	}

	return;
}




void
NonnonTxtboxClickEvent( n_txtbox *txtbox, UINT msg, int click_count, BOOL smart_selection_onoff )
{

	SetFocus( txtbox->hwnd );

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{

		if ( txtbox->txt_data->readonly ) { return; }

		POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

		txtbox->focus = n_txtbox_focus_calculate( txtbox, local_point );
		if ( txtbox->focus >= txtbox->txt_data->sy )
		{
			if ( txtbox->listbox_no_selection_onoff )
			{
				n_txtbox_caret_reset( txtbox );
				n_txtbox_redraw( txtbox );
				return;
			} else {
				txtbox->focus = txtbox->txt_data->sy - 1;
			}
		}
//NSLog( @"%f", txtbox->focus );

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		if ( ( txtbox->listbox_edit_onoff )&&( txtbox->listbox_edit_index == txtbox->focus ) )
		{
			if ( click_count == 3 )
			{
				NonnonTxtboxTripleClickDetect( txtbox );
			} else
			if ( click_count == 2 )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, TRUE );
			} else
			if ( click_count == 1 )
			{
				//prev = [theEvent buttonNumber];
				txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
			}

			n_txtbox_redraw( txtbox );
		} else {
			txtbox->listbox_edit_onoff = FALSE;

			txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );

			n_txtbox_redraw( txtbox );
		}

		n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT );

	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
//NSLog( @"!" );

		if ( n_txtbox_is_hovered( txtbox, &txtbox->find_icon_rect ) )
		{
			txtbox->find_icon_is_pressed = TRUE;
		} else
		if ( n_txtbox_is_hovered( txtbox, &txtbox->delete_circle_rect ) )
		{
			txtbox->delete_circle_onoff = FALSE;

			n_txt_del( txtbox->txt_data, 0 );
			n_txtbox_caret_reset( txtbox );

			n_txtbox_redraw( txtbox );
		} else {
			if ( click_count == 3 )
			{
				NonnonTxtboxTripleClickDetect( txtbox );
			} else
			if ( click_count == 2 )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, TRUE );
			} else
			if ( click_count == 1 )
			{
				txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
			}
		}

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->caret_blink_force_onoff = TRUE;

	} else {
		if ( click_count == 3 )
		{
			NonnonTxtboxTripleClickDetect( txtbox );
		} else
		if ( click_count == 2 )
		{
			NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, FALSE );
		} else
		if ( click_count == 1 )
		{
			txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
		}

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->caret_blink_force_onoff = TRUE;


		n_txtbox_redraw( txtbox );
	}


	return;
}




typedef BOOL (WINAPI* n_IsWindowArranged)(HWND);

BOOL
n_win64_txtbox_IsWindowArranged( HWND hwnd )
{

	// [x] : MinGW-w64 hasn't IsWindowArranged()

	HMODULE hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );

	n_IsWindowArranged func_IsWindowArranged = (n_IsWindowArranged) GetProcAddress( hmod, "IsWindowArranged" );

	BOOL ret = func_IsWindowArranged( hwnd );

	FreeLibrary( hmod );


	return ret;
}




void
n_win64_txtbox_proc_mouse( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_txtbox *txtbox )
{

	if ( FALSE == n_win64_is_hovered( txtbox->hwnd ) ) { return; }


	static UINT click_count_timer_id = 0;
	static int  click_count          = 0;
	static u32  click_count_timeout  = 0;
	static UINT click_count_prv_msg  = WM_NULL;

	static UINT mouse_lock_timer_id = 0;
	static BOOL mouse_lock_onoff    = FALSE;


	switch( msg ) {


	case WM_CREATE :

		click_count_timer_id = n_win64_timer_id_get();
		n_win64_timer_init( hwnd, click_count_timer_id, 100 );

	break;

	case WM_SIZE :

		if ( ( wParam == SIZE_MAXIMIZED )||( n_win64_txtbox_IsWindowArranged( hwnd ) ) )
		{
//n_posix_debug_literal( "" );
			mouse_lock_onoff = TRUE;

			mouse_lock_timer_id = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, mouse_lock_timer_id, 200 );
		}

	break;

	case WM_TIMER :
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d", wParam );

		if ( wParam == 0 ) { break; }

		if ( wParam == click_count_timer_id )
		{
			if ( click_count_timeout < n_posix_tickcount() )
			{
				click_count = 0;
			}
		} else
		if ( wParam == mouse_lock_timer_id )
		{
//n_posix_debug_literal( "" );
			mouse_lock_onoff = FALSE;
			n_win64_timer_exit( hwnd, mouse_lock_timer_id );
		}

	break;

	case WM_MOUSEMOVE :

		if ( mouse_lock_onoff ) { break; }

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			//
		} else
		if ( n_win64_is_input( VK_LBUTTON ) )
		{
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				//
			} else {
				if ( txtbox->scrollbar_thumb_is_hovered ) { return; }
				if ( txtbox->scrollbar_shaft_is_hovered ) { return; }

				if ( txtbox->find_icon_is_pressed ) { return; }

				txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
//n_caret_debug_cch( caret_fr, caret_to );

				if ( txtbox->caret_fr.cch.x < txtbox->caret_to.cch.x )
				{
					txtbox->shift_selection_is_tail = TRUE;
				} else {
					txtbox->shift_selection_is_tail = FALSE;
				}

				txtbox->drag_timer_queue = TRUE;

				n_txtbox_redraw( txtbox );
			}
		}

	break;


	case WM_LBUTTONUP :

		ReleaseCapture();


		txtbox->drag_timer_queue = FALSE;


		if ( txtbox->scrollbar_thumb_is_captured )
		{
			txtbox->scrollbar_thumb_is_captured = FALSE;

			txtbox->scrollbar_fade_captured_onoff = TRUE;
			n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
		}


		if ( txtbox->scrollbar_thumb_is_hovered ) { return; }
		if ( txtbox->scrollbar_shaft_is_hovered ) { return; }

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			//
		} else
		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			if ( txtbox->find_icon_is_pressed )
			{
				if ( n_txtbox_is_hovered( txtbox, &txtbox->find_icon_rect ) )
				{
					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT );
				}

				n_txtbox_redraw( txtbox );

				txtbox->find_icon_is_pressed = FALSE;
			}
		}

	break;


	case WM_LBUTTONDOWN :
	{
//n_win64_debug_count( hwnd );

		SetCapture( hwnd );


		SetFocus( txtbox->hwnd );

		if ( click_count_prv_msg != msg ) { click_count = 0; }
		click_count_prv_msg = msg;

		if ( click_count_timeout > n_posix_tickcount() )
		{
			click_count++;
		} else {
			click_count = 1;
		}

		click_count_timeout = n_posix_tickcount() + GetDoubleClickTime();

//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d", click_count );


		txtbox->pt                         = n_win64_cursor_position_relative_POINT( txtbox->hwnd );
		txtbox->scrollbar_thumb_is_hovered = n_txtbox_is_hovered( txtbox, &txtbox->scrollbar_thumb_rect );
		txtbox->scrollbar_shaft_is_hovered = n_txtbox_is_hovered( txtbox, &txtbox->scrollbar_shaft_rect );

//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d", txtbox->scrollbar_thumb_is_hovered );
//break;
		POINT pt_cur = txtbox->pt;

		txtbox->scrollbar_thumb_offset = txtbox->scrollbar_thumb_rect.top - pt_cur.y;

		if ( txtbox->scrollbar_thumb_is_hovered )
		{

			if ( txtbox->scrollbar_thumb_is_captured == FALSE )
			{
				txtbox->scrollbar_thumb_is_captured = TRUE;

				txtbox->scrollbar_fade_captured_onoff = TRUE;
				n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
			}

		} else
		if ( txtbox->scrollbar_shaft_is_hovered )
		{

			RECT client; GetClientRect( txtbox->hwnd, &client );

			n_type_real sy               = client.bottom;
			n_type_real csy              = sy - ( txtbox->offset_y * 2 );
			n_type_real items_per_canvas = csy / txtbox->font_size.cy;

			if ( pt_cur.y < txtbox->scrollbar_thumb_rect.top )
			{
//NSLog( @"upper" );
				txtbox->scroll -= items_per_canvas;
			} else {
//NSLog( @"lower" );
				txtbox->scroll += items_per_canvas;
			}

//NSLog( @"%f / %f", txtbox->scroll, scroll_step );
			txtbox->scroll = trunc( txtbox->scroll );

			n_txtbox_redraw( txtbox );

		} else {
			NonnonTxtboxClickEvent( txtbox, msg, click_count, FALSE );
		}

	}
	break;


	case WM_MOUSEWHEEL :
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "WM_MOUSEWHEEL" );

		int delta = n_win64_scroll_wheeldelta( wParam, 3 );

		txtbox->scroll += delta;

		n_txtbox_redraw( txtbox );

	break;


	case WM_RBUTTONDOWN :

		if ( click_count_prv_msg != msg ) { click_count = 0; }
		click_count_prv_msg = msg;

		if ( click_count_timeout > n_posix_tickcount() )
		{
			click_count++;
		} else {
			click_count = 1;
		}

		click_count_timeout = n_posix_tickcount() + GetDoubleClickTime();


		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			//
		} else {
			NonnonTxtboxClickEvent( txtbox, msg, click_count, TRUE );
		}

		n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT );

	break;

	case WM_RBUTTONUP :
//NSLog( @"rightMouseUp" );

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			if ( txtbox->find_icon_is_pressed )
			{
				if ( n_txtbox_is_hovered( txtbox, &txtbox->find_icon_rect ) )
				{
					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT );
				}

				n_txtbox_redraw( txtbox );

				txtbox->find_icon_is_pressed = FALSE;
			}
		} else {
			n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT );
		}

	break;


	} // switch


	return;
}


