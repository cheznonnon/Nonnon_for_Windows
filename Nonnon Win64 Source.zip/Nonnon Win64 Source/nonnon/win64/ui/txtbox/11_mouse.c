// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
NonnonTxtboxMouseClamp( n_txtbox *txtbox )
{

//NSLog( @"NonnonTxtboxMouseClamp : %f %f", scroll, scroll_step );
//NSLog( @"NonnonTxtboxMouseClamp : %f %lld", scroll + scroll_page, txtbox->txt_data->sy );
//NSLog( @"NonnonTxtboxMouseClamp : %f %lld", scroll + scroll_page + scroll_step, txtbox->txt_data->sy );

	n_type_real line_sy = txtbox->txt_data->sy;

	if ( txtbox->scroll < 1.0 )
	{
		txtbox->scroll = 0;
	} else
	if ( ( txtbox->scroll + txtbox->scroll_page + txtbox->scroll_step ) > line_sy )
	{
//NSLog( @"overshoot" );
		txtbox->scroll = line_sy - txtbox->scroll_page;
	}

	return;
}




void
NonnonTxtboxClickEvent( n_txtbox *txtbox, UINT msg, int click_count, BOOL smart_selection_onoff )
{

	SetFocus( txtbox->hwnd );

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{

		if ( txtbox->txt_data->readonly ) { return; }

		POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

		txtbox->focus = n_txtbox_focus_calculate( txtbox, local_point );
		if ( txtbox->focus >= txtbox->txt_data->sy )
		{
			if ( txtbox->listbox_no_selection_onoff )
			{
				n_txtbox_caret_reset( txtbox );
				n_txtbox_redraw( txtbox );
				return;
			} else {
				txtbox->focus = txtbox->txt_data->sy - 1;
			}
		}
//NSLog( @"%f", txtbox->focus );

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		if ( ( txtbox->listbox_edit_onoff )&&( txtbox->listbox_edit_index == txtbox->focus ) )
		{
			if ( click_count == 3 )
			{
				NonnonTxtboxTripleClickDetect( txtbox );
			} else
			if ( click_count == 2 )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, TRUE );
			} else
			if ( click_count == 1 )
			{
				//prev = [theEvent buttonNumber];
				txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
			}

			n_txtbox_redraw( txtbox );
		} else {
			txtbox->listbox_edit_onoff = FALSE;

			txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );

			n_txtbox_redraw( txtbox );
		}

		n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT );

	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
//NSLog( @"!" );

		POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

		if ( n_txtbox_PtInRect( &txtbox->find_icon_rect, local_point ) )
		{
			txtbox->find_icon_is_pressed = TRUE;
		} else
		if ( n_txtbox_PtInRect( &txtbox->delete_circle_rect, local_point ) )
		{
			txtbox->delete_circle_onoff = FALSE;

			n_txt_del( txtbox->txt_data, 0 );
			n_txtbox_caret_reset( txtbox );

			n_txtbox_redraw( txtbox );
		} else {
			if ( click_count == 3 )
			{
				NonnonTxtboxTripleClickDetect( txtbox );
			} else
			if ( click_count == 2 )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, TRUE );
			} else
			if ( click_count == 1 )
			{
				txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
			}
		}

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->caret_blink_force_onoff = TRUE;

	} else {
		if ( click_count == 3 )
		{
			NonnonTxtboxTripleClickDetect( txtbox );
		} else
		if ( click_count == 2 )
		{
			NonnonTxtboxDoubleClickDetect( txtbox, smart_selection_onoff, FALSE );
		} else
		if ( click_count == 1 )
		{
			txtbox->caret_fr = txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
		}

		txtbox->scrollbar_thumb_is_hovered = FALSE;

		txtbox->caret_blink_force_onoff = TRUE;


		n_txtbox_redraw( txtbox );
	}


	return;
}




void
n_win64_txtbox_proc_mouse( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_txtbox *txtbox )
{

	if ( FALSE == n_win64_is_hovered( txtbox->hwnd ) ) { return; }


	static UINT click_count_timer_id = 0;
	static int  click_count          = 0;
	static u32  click_count_timeout  = 0;


	static UINT mouse_lock_timer_id = 0;
	static BOOL mouse_lock_onoff    = FALSE;


	switch( msg ) {


	case WM_CREATE :

		click_count_timer_id = n_win64_timer_id_get();
		n_win64_timer_init( hwnd, click_count_timer_id, 100 );

	break;

	case WM_SIZE :

		if ( wParam == SIZE_MAXIMIZED )
		{
//n_posix_debug_literal( "" );
			mouse_lock_onoff = TRUE;

			mouse_lock_timer_id = n_win64_timer_id_get();
			n_win64_timer_init( hwnd, mouse_lock_timer_id, 200 );
		}

	break;

	case WM_TIMER :

		if ( wParam == 0 ) { break; }

		if ( wParam == click_count_timer_id )
		{
			if ( click_count_timeout < n_posix_tickcount() )
			{
				click_count = 0;
			}
		} else
		if ( wParam == mouse_lock_timer_id )
		{
//n_posix_debug_literal( "" );
			mouse_lock_onoff = FALSE;
			n_win64_timer_exit( hwnd, mouse_lock_timer_id );
		}

	break;

	case WM_MOUSEMOVE :

		if ( mouse_lock_onoff ) { break; }

		n_win64_on_WM_MOUSEMOVE( hwnd );

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			//
		} else
		if ( n_win64_is_input( VK_LBUTTON ) )
		{
			POINT pt_cur = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

			n_type_real dy = pt_cur.y - txtbox->pt.y;

			txtbox->pt = pt_cur;

			if ( txtbox->scrollbar_thumb_is_captured )
			{
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%f", dy );

				RECT client; GetClientRect( txtbox->hwnd, &client );

				n_type_real scroll_csy = (n_type_real) client.bottom - ( txtbox->offset_y * 2 );

				n_type_real max_c = (n_type_real) txtbox->txt_data->sy;
				n_type_real step  = scroll_csy / ( max_c * txtbox->font_size.cy );


				txtbox->scroll += dy / ( txtbox->font_size.cy * step );

				n_txtbox_redraw( txtbox );

			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{

				if ( txtbox->scrollbar_thumb_is_hovered ) { return; }
				if ( txtbox->scrollbar_shaft_is_hovered ) { return; }

				n_txtbox_redraw( txtbox );

			} else {

				if ( txtbox->scrollbar_thumb_is_hovered ) { return; }
				if ( txtbox->scrollbar_shaft_is_hovered ) { return; }

				if ( txtbox->find_icon_is_pressed ) { return; }


				txtbox->caret_to = n_txtbox_mouse_cursor_detect( txtbox );
//n_caret_debug_cch( caret_fr, caret_to );

				if ( txtbox->caret_fr.cch.x < txtbox->caret_to.cch.x )
				{
					txtbox->shift_selection_is_tail = TRUE;
				} else {
					txtbox->shift_selection_is_tail = FALSE;
				}


				txtbox->drag_timer_queue = TRUE;


				n_txtbox_redraw( txtbox );

			}

		} else
		if ( txtbox->grab_n_drag_onoff )
		{
			POINT pt_cur = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

			n_type_real dy = txtbox->pt.y - pt_cur.y;

			txtbox->pt = pt_cur;


			txtbox->scroll += dy / txtbox->font_size.cy;

			n_txtbox_redraw( txtbox );
		}

	break;


	case WM_MOUSELEAVE :

	break;


	case WM_LBUTTONUP :

		ReleaseCapture();


		txtbox->drag_timer_queue = FALSE;


		if ( txtbox->scrollbar_thumb_is_captured )
		{
			txtbox->scrollbar_thumb_is_captured = FALSE;

			txtbox->scrollbar_fade_captured_onoff = TRUE;
			n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
		}


		if ( txtbox->scrollbar_thumb_is_hovered ) { return; }
		if ( txtbox->scrollbar_shaft_is_hovered ) { return; }

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			//
		} else
		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			if ( txtbox->find_icon_is_pressed )
			{
				POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );
				if ( n_txtbox_PtInRect( &txtbox->find_icon_rect, local_point ) )
				{
					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT );
				}

				n_txtbox_redraw( txtbox );

				txtbox->find_icon_is_pressed = FALSE;
			}
		}

	break;


	case WM_LBUTTONDOWN :
	{
//n_win64_debug_count( hwnd );

		SetFocus( txtbox->hwnd );

		if ( click_count_timeout > n_posix_tickcount() )
		{
			click_count++;
		} else {
			click_count = 1;
		}

		click_count_timeout = n_posix_tickcount() + GetDoubleClickTime();

//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d", click_count );


		SetCapture( hwnd );

//n_hwnd = GetParent( txtbox->hwnd );

		txtbox->pt                         = n_win64_cursor_position_relative_POINT( txtbox->hwnd );
		txtbox->scrollbar_thumb_is_hovered = n_txtbox_PtInRect( &txtbox->scrollbar_thumb_rect, txtbox->pt );
		txtbox->scrollbar_shaft_is_hovered = n_txtbox_PtInRect( &txtbox->scrollbar_shaft_rect, txtbox->pt );

//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d", txtbox->scrollbar_thumb_is_hovered );
//break;
		POINT pt_cur = txtbox->pt;

		txtbox->scrollbar_thumb_offset = txtbox->scrollbar_thumb_rect.top - pt_cur.y;

		if ( txtbox->scrollbar_thumb_is_hovered )
		{

			if ( txtbox->scrollbar_thumb_is_captured == FALSE )
			{
				txtbox->scrollbar_thumb_is_captured = TRUE;

				txtbox->scrollbar_fade_captured_onoff = TRUE;
				n_bmp_fade_always_on( &txtbox->scrollbar_fade, n_bmp_black, n_bmp_white );
			}

		} else
		if ( txtbox->scrollbar_shaft_is_hovered )
		{

			RECT client; GetClientRect( txtbox->hwnd, &client );

			n_type_real sy               = client.bottom;
			n_type_real csy              = sy - ( txtbox->offset_y * 2 );
			n_type_real items_per_canvas = csy / txtbox->font_size.cy;

			if ( pt_cur.y < txtbox->scrollbar_thumb_rect.top )
			{
//NSLog( @"upper" );
				txtbox->scroll -= items_per_canvas;
			} else {
//NSLog( @"lower" );
				txtbox->scroll += items_per_canvas;
			}

//NSLog( @"%f / %f", txtbox->scroll, scroll_step );
			txtbox->scroll = trunc( txtbox->scroll );

			n_txtbox_redraw( txtbox );

		} else {
			NonnonTxtboxClickEvent( txtbox, msg, click_count, FALSE );
		}

	}
	break;


	case WM_MOUSEWHEEL :
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "WM_MOUSEWHEEL" );

		int delta = n_win64_scroll_wheeldelta( wParam, 3 );

		txtbox->scroll += delta;

		n_txtbox_redraw( txtbox );

	break;


	case WM_RBUTTONDOWN :

		if ( click_count_timeout > n_posix_tickcount() )
		{
			click_count++;
		} else {
			click_count = 1;
		}

		click_count_timeout = n_posix_tickcount() + GetDoubleClickTime();


		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			//
		} else {
			NonnonTxtboxClickEvent( txtbox, msg, click_count, TRUE );
		}

		n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT );

	break;

	case WM_RBUTTONUP :
//NSLog( @"rightMouseUp" );

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			if ( txtbox->find_icon_is_pressed )
			{
				POINT local_point = n_win64_cursor_position_relative_POINT( txtbox->hwnd );
				if ( n_txtbox_PtInRect( &txtbox->find_icon_rect, local_point ) )
				{
					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT );
				}

				n_txtbox_redraw( txtbox );

				txtbox->find_icon_is_pressed = FALSE;
			}
		} else {
			n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT );
		}

	break;


	case WM_MBUTTONUP :

		// [!] : middle button

		txtbox->grab_n_drag_onoff = FALSE;

	break;

	case WM_MBUTTONDOWN :

		// [!] : Grab N Drag

		txtbox->grab_n_drag_onoff = TRUE;

		txtbox->pt = n_win64_cursor_position_relative_POINT( txtbox->hwnd );

	break;


	} // switch


	return;
}


