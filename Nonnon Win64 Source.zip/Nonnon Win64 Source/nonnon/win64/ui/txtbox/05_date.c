// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_txtbox_date( n_posix_char *str, n_type_int cch )
{

	// [Mechanism]
	//
	//	this like format is used in some locales
	//	big-to-small order is simply sortable


	int year, month, day, hour, minute, second;


	n_time_today( &year, &month, &day, &hour, &minute, &second );


	n_posix_snprintf_literal
	(
		str,
		cch + 1,
		"%04d/%02d/%02d %02d:%02d:%02d",
		year, month, day,
		hour, minute, second
	);


	return;
}

void
n_txtbox_day_of_week( n_posix_char *str, n_type_int cch )
{

	// [Needed] : an explicit name like "ja-JP" will not work

	setlocale( LC_ALL, "" );


	time_t     rawtime; time( &rawtime );
	struct tm *timeinfo = localtime( &rawtime );

	n_posix_strftime_literal( str, cch, "%A", timeinfo );


	return;
}

