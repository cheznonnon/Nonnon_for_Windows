﻿// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_TXTBOX_INDICATOR_SEARCH n_bmp_argb( 255,255,  0,128 )
#define N_TXTBOX_INDICATOR_CARET  n_bmp_argb( 255,  0,200,255 )




COLORREF
n_txtbox_argb2colorref( u32 color )
{

	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	return RGB( r,g,b );
}

void
n_mac_draw_circle( n_bmp *bmp, u32 color, RECT rect )
{

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x,&y,&sx,&sy );

	n_bmp_circle( bmp, x,y,sx,sy, color );
	n_bmp_circle( bmp, x,y,sx,sy, color ); // [!] : thicken

	return;
}

void
n_mac_draw_frame( n_bmp *bmp, u32 color, RECT rect )
{

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x,&y,&sx,&sy );

	n_bmp_frame( bmp, x,y,sx,sy, 1, color );

	return;
}

void
n_mac_draw_roundrect( n_bmp *bmp, u32 color, RECT rect, n_type_gfx round )
{

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x,&y,&sx,&sy );


	n_bmp b; n_bmp_zero( &b ); n_bmp_new_fast( &b, sx,sy ); n_bmp_flush( &b, n_bmp_white_invisible );

	n_bmp_roundrect_pixel( &b, 0,0,sx,sy, color, round );

	n_bmp_transcopy( &b, bmp, 0,0,sx,sy, x,y );

	n_bmp_free_fast( &b );


	return;
}

void
n_mac_draw_roundframe( n_bmp *bmp, u32 color, RECT rect, n_type_gfx round, n_type_gfx frame_size )
{

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x,&y,&sx,&sy );


	u32 color_nc = n_win64_GetSysColor_nbmp( COLOR_BTNFACE );

	n_bmp b; n_bmp_zero( &b ); n_bmp_new_fast( &b, sx,sy );
	n_bmp_flush( &b, color_nc );

	n_bmp_roundrect_pixel( &b, 0,0,sx,sy, color, round );

	n_type_gfx o = frame_size * 2;
	n_type_gfx oo = o * 2;

	n_bmp_roundrect_pixel( &b, o,o,sx-oo,sy-oo, n_bmp_black_invisible, round );

	n_bmp_transcopy( &b, bmp, 0,0,sx,sy, x,y );

	n_bmp_free_fast( &b );


	n_bmp_cornermask( bmp, round, frame_size, color_nc );


	return;
}

u32
n_txtbox_thin_highlight( n_txt *txt, n_txt *txt_deco, n_type_int i, u32 f, u32 t )
{

	u32 ret = f;

	if ( ( txt_deco != NULL )&&( txt->sy == txt_deco->sy ) )
	{
		n_posix_char *deco = n_txt_get( txt_deco, i );
		if ( ( 2 <= n_posix_strlen( deco ) )&&( deco[ 1 ] == '!' ) )
		{
			ret = n_bmp_blend_pixel( f, t, 0.2 );
		}
	}


	return ret;
}

void
n_txtbox_crop( n_bmp *bmp, u32 color_trans )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx bmpsx = N_BMP_SX( bmp );
	n_type_gfx bmpsy = N_BMP_SY( bmp );


	n_type_gfx fx = 0;
	n_type_gfx tx = 0;
	n_type_gfx fy = bmpsx;
	n_type_gfx ty = bmpsy;


	n_type_gfx x,y;


	// [!] : Left
	
	x = y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );
		if ( color != color_trans ) { fx = x; break; }

		y++;
		if ( y >= bmpsy )
		{
			y = 0;

			x++;
			if ( x >= bmpsx ) { break; }
		}
	}

	// [!] : Top
	
	x = y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );
		if ( color != color_trans ) { fy = y; break; }

		x++;
		if ( x >= bmpsx )
		{
			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}

	// [!] : Right
	
	x = bmpsx - 1;
	y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );
		if ( color != color_trans ) { tx = x; break; }

		y++;
		if ( y >= bmpsy )
		{
			y = 0;

			x--;
			if ( x < 0 ) { break; }
		}
	}

	// [!] : Bottom
	
	x = 0;
	y = bmpsy - 1;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );
		if ( color != color_trans ) { ty = y; break; }

		x++;
		if ( x >= bmpsx )
		{
			x = 0;

			y--;
			if ( y < 0 ) { break; }
		}
	}

	if ( fx >     0 ) { fx--; }
	if ( fy >     0 ) { fy--; }
	if ( tx < bmpsx ) { tx++; }
	if ( ty < bmpsx ) { ty++; }

	n_type_gfx fsx = tx - fx; if ( fsx < 0 ) { return; }
	n_type_gfx fsy = ty - fy; if ( fsy < 0 ) { return; }

	fsx += ( 0 == ( fsx % 2 ) );
	fsy += ( 0 == ( fsy % 2 ) );

	n_bmp ret; n_bmp_zero( &ret ); n_bmp_new( &ret, fsx, fsy );

	n_bmp_fastcopy( bmp, &ret, fx,fy,fsx,fsy, 0,0 );

	n_bmp_free( bmp );
	n_bmp_alias( &ret, bmp );


	return;
}




// internal
n_posix_char*
n_mac_txtbox_path_ellipsis( n_txtbox *txtbox, n_posix_char *path, HFONT font, n_type_real width_limit )
{

	// [!] : internal :  security : omitted


	if ( path[ 0 ] != '/' )
	{
//NSLog( @"1 : %c", path[ 0 ] );
		return n_string_path_carboncopy( path );
	}


	n_type_int c = n_string_path_split_count( path );
	if ( c <= 1 )
	{
//NSLog( @"2 : %lld", c );
		return n_string_path_carboncopy( path );
	}


	n_posix_char **line = n_memory_new( sizeof(n_posix_char*) * c );


	n_type_int i = 0;
	n_posix_loop
	{
		line[ i ] = n_string_path_split_new( path, i );

		i++;
		if ( i >= c ) { break; }
	}

/*
	i = 0;
	n_posix_loop
	{break;
		NSLog( @"%s", line[ i ] );

		i++;
		if ( i >= c ) { break; }
	}
*/

	n_posix_char *ret = NULL;


	i = 0;
	n_posix_loop
	{

		n_type_int   j = 0;
		n_type_int cch = 0;
		n_posix_loop
		{
			cch += n_posix_strlen( line[ j ] );

			j++;
			if ( j >= c ) { break; }

			cch += 1;
		}

		n_string_free( ret );
		ret = n_string_path_new( cch );

		n_type_int start_cch = cch;

		j = cch = 0;
		n_posix_loop
		{
			cch += n_posix_snprintf_literal( &ret[ cch ], start_cch - cch + 1, "%s", line[ j ] );

			j++;
			if ( j >= c ) { break; }

			cch += n_posix_snprintf_literal( &ret[ cch ], start_cch - cch + 1, "/" );
		}
//NSLog( @"%s", s ); //break;


		SIZE size = n_win64_text_pixelsize( txtbox->hdc, ret, font );
		if ( size.cx < width_limit ) { break; }
//NSLog( @"%f %f", size.cx, width_limit );

		n_memory_free( line[ 1 + i ] );
		line[ 1 + i ] = n_string_path_new( 3 ); n_posix_snprintf_literal( line[ 1 + i ], 3 + 1, "..." );


		i++;
		if ( i >= ( c - 1 ) ) { break; } // [!] : the last component will always be visible
	}


	// [!] : clean-up

	i = 0;
	n_posix_loop
	{
		n_string_path_free( line[ i ] );

		i++;
		if ( i >= c ) { break; }
	}

	n_string_path_free( line );


	return ret;
}




void
NonnonTxtboxDrawBox( n_txtbox *txtbox, u32 color, RECT rect )
{

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x, &y, &sx, &sy );
	n_bmp_box( txtbox->canvas, x,y,sx,sy, color );

	return;
}

void
NonnonTxtboxDrawText( n_txtbox *txtbox, n_posix_char *character, u32 color_fg, RECT rect, int align, HFONT hfont )
{

	int p_bkmode = GetBkMode( txtbox->hdc );
	SetBkMode( txtbox->hdc, TRANSPARENT );

	SetTextColor( txtbox->hdc, n_txtbox_argb2colorref( color_fg ) );

/*
	// [x] : buggy
	int dt = DT_NOPREFIX | DT_NOCLIP | ( DT_SINGLELINE | DT_VCENTER );
	DrawText( txtbox->hdc, character, -1, &rect, dt );
*/

	HFONT hf_prv = SelectObject( txtbox->hdc, hfont );

	n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect, &x, &y, &sx, &sy );

	SIZE size = n_win64_text_pixelsize( txtbox->hdc, character, hfont );

	if ( align == 1 )
	{
		x  = sx - size.cx;
		y += ( sy - size.cy ) / 2;
	} else {
		x += ( sx - size.cx ) / 2;
		y += ( sy - size.cy ) / 2;
	}

	TextOut( txtbox->hdc, x, y, character, n_posix_strlen( character ) );

	SelectObject( txtbox->hdc, hf_prv );


	SetBkMode( txtbox->hdc, p_bkmode );


	return;
}




void
NonnonTxtboxDrawScrollClamp( n_txtbox *txtbox )
{

	// [!] : this code is same as drawRect

	RECT client; GetClientRect( txtbox->hwnd, &client );

	n_type_gfx scroll_csy = (n_type_gfx) client.bottom - ( txtbox->offset_y * 2 );

	const n_type_gfx scroll_pixel_sx = 12;

	if ( txtbox->corner_size == -1 ) { txtbox->corner_size = scroll_pixel_sx; }
//NSLog( @"%f", txtbox->corner_size );

	n_type_real shaft_sy         = scroll_csy - txtbox->corner_size;
	n_type_real items_per_canvas = shaft_sy / txtbox->font_size.cy;
	//n_type_real max_count        = (n_type_real) txtbox->txt_data->sy;
	n_type_real rest             = txtbox->font_size.cy - fmod( shaft_sy, txtbox->font_size.cy );


	n_type_real txt_sy = txtbox->txt_data->sy;

	if ( txt_sy <= 1 )
	{
		txtbox->scroll = 0;
	} else
	if ( items_per_canvas < txt_sy )
	{
		if ( rest ) { items_per_canvas -= 1.0; }

		n_type_real max_sy = txt_sy - items_per_canvas;

		if ( txtbox->scroll <       0 ) { txtbox->scroll =      0; } else
		if ( txtbox->scroll >= max_sy ) { txtbox->scroll = max_sy; }
	} else {
		txtbox->scroll = 0;
	}

//NSLog( @"%lld : %lld %lld", txtbox->focus, caret_fr.cch.y, caret_to.cch.y );


	return;
}




void
NonnonTxtboxCaretDraw( n_txtbox *txtbox, RECT rect, n_type_int focus )
{
//return;

	txtbox->ime_pt.x = rect.left + 1;
	txtbox->ime_pt.y = rect.top  - 2;

	if ( txtbox->ime_composition_onoff ) { return; }


	double d;

	if ( txtbox->hwnd != GetFocus() )
	{
		d = 0.1;
	} else
	if ( txtbox->caret_blink_force_onoff )
	{
		d = 1.0;
	} else {
		if ( txtbox->caret_blink_onoff )
		{
//NSLog( @"On %d", caret_blink_fade.percent );
			d = txtbox->caret_blink_fade.percent * 0.01;
		} else {
//NSLog( @"Off %d", caret_blink_fade.percent );
			d = txtbox->caret_blink_fade.percent * 0.01;
			d = 1.0 - d;
		}
	}

//NSLog( @"Percent %f", d );


	u32 color_bg;

	if ( focus & 1 )
	{
		color_bg = txtbox->nscolor_stripe;
	} else {
		color_bg = txtbox->nscolor_back;
	}


	u32 color_caret;

	if ( n_win64_darkmode_is_on() )
	{
		color_caret = n_bmp_white;
	} else {
		color_caret = n_bmp_black;
	}


	u32 color = n_bmp_blend_pixel( color_bg, color_caret, d );

	NonnonTxtboxDrawBox( txtbox, color, rect );


	return;
}




void
NonnonTxtboxDrawLine_Phase0( n_txtbox *txtbox, n_type_int i, RECT rect )
{
//return;

	u32 nscolor;
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		nscolor = txtbox->nscolor_back;
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		nscolor = txtbox->nscolor_back;
	} else
	if ( i & 1 )
	{
		nscolor = txtbox->nscolor_stripe;
	} else {
		nscolor = txtbox->nscolor_back;
	}

	nscolor = n_txtbox_thin_highlight( txtbox->txt_data, txtbox->txt_deco, i, nscolor, txtbox->nscolor_accent );

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		RECT client; GetClientRect( txtbox->hwnd, &client );
		NonnonTxtboxDrawBox( txtbox, nscolor, client );
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		RECT client; GetClientRect( txtbox->hwnd, &client );
		NonnonTxtboxDrawBox( txtbox, nscolor, client );
	} else {
		NonnonTxtboxDrawBox( txtbox, nscolor, rect   );
	}


	return;
}

void
NonnonTxtboxDrawLine_Phase1( n_txtbox *txtbox, n_type_int i, RECT rect )
{
//return;

	n_posix_char *line = n_txt_get( txtbox->txt_data, i );

	n_type_int  index = 0;
	n_type_real sx    = 0;
	n_type_int  tab   = 0;
	SIZE        char_size;
	n_type_int  char_index;
	n_posix_loop
	{//break;
		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		n_mac_txtbox_character( txtbox->hdc, txtbox->font, txtbox->font_size, line, index, txtbox->is_monospace, &char_size, &char_index, &tab );

		index += char_index;
		sx    += char_size.cx;
	}


	// [!] : End-of-Line Marker

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		//
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		//
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		//
	} else {
		RECT char_rect = n_win64_rect_set( rect.left + sx, rect.top, 12, rect.bottom );

		n_posix_char crlf[ 2 ] = { 8617, 0 };
		NonnonTxtboxDrawText( txtbox, crlf, txtbox->nscolor_crlf, char_rect, 0, txtbox->font_crlf );
	}


	return;
}

void
NonnonTxtboxDrawLine_Phase2( n_txtbox *txtbox, n_type_int i, RECT rect, n_type_gfx csx, n_type_gfx csy )
{
//return;

	n_posix_char *line = n_txt_get( txtbox->txt_data, i );


	// [!] : don't use edit : currently not supported

	n_posix_char *line_ellipsis = NULL;
	if ( txtbox->path_ellipsis_onoff )
	{
		n_type_int cch = n_posix_strlen( line );
		if ( ( cch >= txtbox->path_ellipsis_offset )&&( line[ txtbox->path_ellipsis_offset ] == '/' ) )
		{
			line_ellipsis = n_mac_txtbox_path_ellipsis( txtbox, &line[ txtbox->path_ellipsis_offset ], txtbox->font, (n_type_real) csx * 0.8 );
//NSLog( @"%s", line_ellipsis );
			if ( txtbox->path_ellipsis_offset != 0 )
			{
				n_type_int    c = cch * 10;
				n_posix_char *l = n_string_alloccopy( c, line );
				n_posix_snprintf_literal( &l[ txtbox->path_ellipsis_offset ], c + 1, "%s", line_ellipsis );
				n_string_path_free( line_ellipsis );
				line_ellipsis = l;
			}

			line = line_ellipsis;
		}
	}


	if ( ( txtbox->txt_deco != NULL )&&( txtbox->txt_data->sy == txtbox->txt_deco->sy ) )
	{
		//n_posix_char *deco = n_txt_get( txtbox->txt_deco, i );

		// [x] : italic : no better way
/*
		if ( ( self.txtbox->listbox_edit_onoff )&&( i == txtbox->focus ) )
		{
			NSNumber *n = [NSNumber numberWithDouble:0.0];
			[txtbox->attr setObject:n forKey:NSObliquenessAttributeName ];

			NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
			[txtbox->attr setObject:u forKey:NSUnderlineStyleAttributeName ];
		} else
		if ( deco[ 0 ] == ' ' )
		{
			NSNumber *n = [NSNumber numberWithDouble:0.2];
			[txtbox->attr setObject:n forKey:NSObliquenessAttributeName ];

			NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
			[txtbox->attr setObject:u forKey:NSUnderlineStyleAttributeName ];
		} else
		if ( deco[ 0 ] == 'B' )
		{
			NSNumber *n = [NSNumber numberWithDouble:0.0];
			[txtbox->attr setObject:n forKey:NSObliquenessAttributeName ];

			NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
			[txtbox->attr setObject:u forKey:NSUnderlineStyleAttributeName ];
		} else
		if ( deco[ 0 ] == 'u' )
		{
			NSNumber *n = [NSNumber numberWithDouble:0.2];
			[txtbox->attr setObject:n forKey:NSObliquenessAttributeName ];

			NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
			[txtbox->attr setObject:u forKey:NSUnderlineStyleAttributeName ];
		} else
		if ( deco[ 0 ] == 'U' )
		{
			NSNumber *n = [NSNumber numberWithDouble:0.0];
			[txtbox->attr setObject:n forKey:NSObliquenessAttributeName ];

			NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
			[txtbox->attr setObject:u forKey:NSUnderlineStyleAttributeName ];
		}
*/
	}

/*
	BOOL        gradient_onoff  = FALSE;
	RECT        gradient_rect   = n_win64_rect_set( 0,0,0,0 );
	n_type_real gradient_cut    = (n_type_real) csx - csy - csy;
	BOOL        gradient_go     = FALSE;

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		n_type_int  index = 0;
		n_type_real sx    = 0;
		n_type_int  tab   = 0;
		SIZE        char_size;
		n_type_int  char_index;
		n_posix_loop
		{//break;
			if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

			RECT char_rect = rect;

			n_mac_txtbox_character( txtbox->hdc, txtbox->font, txtbox->font_size, line, index, txtbox->is_monospace, &char_size, &char_index, &tab );

			char_rect.left  += sx;
			char_rect.left  -= 1;
			char_rect.right  = char_size.cx + 1;


			index += char_index;
			sx    += char_size.cx;

//NSLog( @"%f %f", ceil( sx ), (n_type_real) csx - csy - csy );
			if ( ceil( sx ) > gradient_cut )
			{
				gradient_onoff = TRUE;

				gradient_rect       = char_rect;
				gradient_rect.left  = gradient_cut - csy;
				gradient_rect.right = csx - gradient_rect.left;

				break;
			}
		}
	}
*/

	//int round_mode = N_MAC_DRAW_ROUNDRECT_LEFT;

	{
		n_type_int  index = 0;
		n_type_real sx    = 0;
		n_type_int  tab   = 0;
		SIZE        char_size;
		n_type_int  char_index;
		n_posix_loop
		{//break;
			if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

			RECT char_rect = rect;

			n_mac_txtbox_character( txtbox->hdc, txtbox->font, txtbox->font_size, line, index, txtbox->is_monospace, &char_size, &char_index, &tab );

			char_rect.left  += sx;
			char_rect.left  -= 1;
			char_rect.right  = char_size.cx + 1;

			POINT pt = { sx, i };

			sx += char_size.cx;

			BOOL selected = n_mac_txtbox_is_selected( pt, txtbox->caret_fr.pxl.x, txtbox->caret_fr.cch.y, txtbox->caret_to.pxl.x, txtbox->caret_to.cch.y );
			if ( selected )
			{
				u32 nscolor = txtbox->nscolor_accent;
				NonnonTxtboxDrawBox( txtbox, nscolor, char_rect );
			}
/*
			if ( ( ( gradient_onoff ) )&&( ceil( sx ) > gradient_rect.origin.x ) )
			{
				gradient_go = TRUE;
			}
*/
			index += char_index;

		}
	}


	n_type_int  index = 0;
	n_type_real sx    = 0;
	n_type_int  tab   = 0;
	SIZE        char_size;
	n_type_int  char_index;
	n_posix_loop
	{//break;
		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		RECT char_rect = rect;

		n_posix_char *character;
		character = n_mac_txtbox_character( txtbox->hdc, txtbox->font, txtbox->font_size, line, index, txtbox->is_monospace, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );
//n_posix_debug_literal( "%s : %s", line, character );

		char_rect.left  += sx;
		char_rect.left  -= 1;
		char_rect.right  = char_size.cx + 1;


		POINT pt = { sx, i };

		BOOL selected = n_mac_txtbox_is_selected( pt, txtbox->caret_fr.pxl.x, txtbox->caret_fr.cch.y, txtbox->caret_to.pxl.x, txtbox->caret_to.cch.y );
		if ( ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )&&( txtbox->listbox_edit_onoff == FALSE ) )
		{
			if ( i == txtbox->focus )
			{
				selected = TRUE;
			}
		}


		if ( line[ index ] == N_STRING_CHAR_TAB )
		{

			RECT rect_local = char_rect; rect_local.right = 1;

			NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_crlf, rect_local );

		} else
		//
		{

			u32 nscolor;
			if ( selected )
			{
				nscolor = txtbox->nscolor_text_highlight;
			} else {
				nscolor = txtbox->nscolor_text_normal;
			}

			// [x] : M$KK have to work hard
			//
			//	bitmap font(maybe "MS UI Gothic") is used when "Consolas"


			HFONT hfont_cur = NULL;
			if ( n_mac_txtbox_is_fullwidth_detect( character[ 0 ] ) )
			{
				hfont_cur = txtbox->font_cjk;
			} else {
				hfont_cur = txtbox->font;
			}

			NonnonTxtboxDrawText( txtbox, character, nscolor, char_rect, 0, hfont_cur );
		}

//NSLog( @"%lld", char_index );
		index += char_index;
		sx    += char_size.cx;
	}

	n_string_free( line_ellipsis );

/*
	if ( gradient_go )
	{
		n_mac_draw_gradient( n_bmp_argb( 0,0,0,0 ), txtbox->nscolor_back, gradient_rect );
	}
*/

	return;
}

void
NonnonTxtboxDrawLineNumber( n_txtbox *txtbox, n_type_int index, RECT rect, BOOL semi_indicator )
{
//return;
//RECT _rect = rect;

	if ( txtbox->option_linenumber == N_MAC_TXTBOX_DRAW_LINENUMBER_NONE ) { return; }


	n_type_int offset = txtbox->scroll;

	n_type_int focus_f = (n_type_int) n_posix_min_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );
	n_type_int focus_t = (n_type_int) n_posix_max_n_type_real( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );


	n_type_int cch_y = index + offset;

	if ( txtbox->option_linenumber & N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX )
	{
		//
	} else {
		cch_y++;
	}


	u32 nscolor_main = n_txtbox_thin_highlight( txtbox->txt_data, txtbox->txt_deco, index + txtbox->scroll, txtbox->nscolor_back, txtbox->nscolor_accent );
	u32 nscolor_stripe;
	if ( ( index + offset ) & 1 )
	{
		nscolor_stripe = n_bmp_blend_pixel( txtbox->nscolor_text, nscolor_main, 0.90 );
	} else {
		nscolor_stripe = n_bmp_blend_pixel( txtbox->nscolor_text, nscolor_main, 0.95 );
	}

	NonnonTxtboxDrawBox( txtbox, nscolor_stripe, rect );


	if ( ( index + offset ) < txtbox->txt_data->sy )
	{

		u32 nscolor_txt;
		if ( ( ( index + offset ) >= focus_f )&&( ( index + offset ) <= focus_t ) )
		{
			// [!] : indicator

			n_type_gfx size = 2;

			RECT r = rect; r.right = size;

			NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_accent, r );

			nscolor_txt = n_bmp_blend_pixel( txtbox->nscolor_text, txtbox->nscolor_back, 0.33 );
		} else {
			nscolor_txt = n_bmp_blend_pixel( txtbox->nscolor_text, txtbox->nscolor_back, 0.66 );
		}


		if ( semi_indicator )
		{
			n_type_gfx size = 2;

			RECT r = rect;
			r.left  += r.right - size;
			r.right  = size;

			u32 color = n_bmp_blend_pixel( txtbox->nscolor_text, txtbox->nscolor_back, 0.66 );

			NonnonTxtboxDrawBox( txtbox, color, r );
		}


		BOOL over_ten_thousand = FALSE;
		if ( cch_y >= 10000 ) { over_ten_thousand = TRUE; }

		if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

		n_posix_char nsstr[ 100 ];

		// [Patch] : not working accurately

		if ( cch_y < 1000 )
		{
			if ( over_ten_thousand )
			{
				n_posix_snprintf_literal( nsstr, 100, " %04d ", (int) cch_y );
			} else {
				n_posix_snprintf_literal( nsstr, 100, " % 4d ", (int) cch_y );
			}
		} else {
			n_posix_snprintf_literal( nsstr, 100, " %d ", (int) cch_y );
		}


		NonnonTxtboxDrawText( txtbox, nsstr, nscolor_txt, rect, 1, txtbox->linenumber_font );
	}



	return;
}

void
NonnonTxtboxDraw( n_txtbox *txtbox )
{
//NSLog( @"NonnonTxtboxDraw" );


	BOOL is_partial_redraw = FALSE;

	if ( ( txtbox->redraw_fy == -1 )||( txtbox->redraw_ty == -1 ) )
	{//return;
		txtbox->redraw_fy = 0;
		txtbox->redraw_ty = txtbox->txt_data->sy;
	} else {
		is_partial_redraw = TRUE;
	}
/*
if ( txtbox->mode == N_MAC_TXTBOX_MODE_EDITBOX )
{
NSLog( @"%lld %lld", redraw_fy, redraw_ty );
}
*/

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		if ( 0 != n_posix_strlen( n_txt_get( txtbox->txt_data, 0 ) ) )
		{
			txtbox->delete_circle_onoff = TRUE;
		}
	}


	// [!] : Metrics

	RECT client; GetClientRect( txtbox->hwnd, &client );

	n_type_gfx csx = (n_type_gfx) client.right;
	n_type_gfx csy = (n_type_gfx) client.bottom;
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%d %d", csx, csy );


	if ( ( csx != txtbox->doublebuffer_psx )||( csy != txtbox->doublebuffer_psy ) )
	{
		n_win64_doublebuffer_cleanup( &txtbox->doublebuffer );
	}

	txtbox->hdc    = n_win64_doublebuffer_init( &txtbox->doublebuffer, txtbox->hwnd, NULL, csx,csy );
	txtbox->canvas = &txtbox->doublebuffer.bmp;

	//txtbox->hdc    = n_win64_doublebuffer_simple_init( txtbox->hwnd, csx,csy );
	//txtbox->canvas = &n_win64_doublebuffer_instance.bmp;

	txtbox->doublebuffer_psx = csx;
	txtbox->doublebuffer_psy = csy;


	NonnonTxtboxDrawScrollClamp( txtbox );


	n_bmp_flush( txtbox->canvas, n_win64_GetSysColor_nbmp( COLOR_BTNFACE ) );


	HFONT hfont_prev = SelectObject( txtbox->hdc, txtbox->font );


	txtbox->caret_centered_offset = 0;

	if (
		( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		||
		( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )

	)
	{
		txtbox->caret_centered_offset = ( ( txtbox->font_size.cy + ( txtbox->offset_y * 2 ) ) - csy ) / 2;
	} else {
		n_type_real minim = txtbox->font_size.cy + ( txtbox->offset_y * 2 );
		if ( ( csx < minim )||( csy < minim ) ) { return; }
	}

	if ( txtbox->caret_fr.cch.y >= txtbox->txt_data->sy ) { txtbox->caret_fr.cch.y = txtbox->txt_data->sy - 1; }


	n_type_int i = txtbox->scroll;

	RECT _rect_main = n_win64_rect_set( txtbox->padding, txtbox->offset_y - txtbox->caret_centered_offset, csx - ( txtbox->offset_x * 2 ), txtbox->font_size.cy );
	if ( is_partial_redraw )
	{
		_rect_main.left -= txtbox->font_size.cy * i;
		_rect_main.top  += txtbox->font_size.cy * txtbox->redraw_fy;
	}

	// [!] : max_sy : plus one line

	const RECT        rect_main = _rect_main;
	const n_type_real max_sy    = csy - ( txtbox->offset_y * 2 ) + txtbox->font_size.cy;


	// [!] : Metrics 2 : Colors


	// [x] : don't move : old color is used when darkmode state is changed

	if ( n_win64_darkmode_is_on() )
	{
		txtbox->nscolor_stripe = n_bmp_blend_pixel( txtbox->nscolor_back, txtbox->nscolor_text, 0.10 );
	} else {
		txtbox->nscolor_stripe = n_bmp_blend_pixel( txtbox->nscolor_back, txtbox->nscolor_text, 0.05 );
	}

	txtbox->nscolor_frame = n_bmp_blend_pixel( txtbox->nscolor_back, txtbox->nscolor_text, 0.25 );
	txtbox->nscolor_crlf  = txtbox->nscolor_frame;


	// [!] : n_txt rendering engine

//NSLog( @"%f %f", caret_fr.pxl.x, caret_to.pxl.x );

	RECT listbox_rect = n_win64_rect_set( 0,0,0,0 );

	{ // [!] : Phase #0 : Background : before text rendering : for some fonts like "g"

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
		{
			//
		} else
		if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			//
		} else {
			u32 nscolor = txtbox->nscolor_back;

			RECT rect_1 = n_win64_rect_set( 0,0,csx,txtbox->offset_y );
			RECT rect_2 = n_win64_rect_set( 0,0,txtbox->offset_x,csy );

			NonnonTxtboxDrawBox( txtbox, nscolor, rect_1 );
			NonnonTxtboxDrawBox( txtbox, nscolor, rect_2 );

			RECT rect_g = n_win64_rect_set( txtbox->offset_x + txtbox->linenumber_size.cx, txtbox->offset_y, txtbox->margin, csy );
			NonnonTxtboxDrawBox( txtbox, nscolor, rect_g );
		}


		RECT rect_local = rect_main;

		if ( is_partial_redraw )
		{
			i = txtbox->redraw_fy;
			n_posix_loop
			{//break;

				if ( ( txtbox->redraw_fy <= i )&&( i < txtbox->redraw_ty ) )
				{
					NonnonTxtboxDrawLine_Phase0( txtbox, i, rect_local );
				}

				rect_local.top += txtbox->font_size.cy;
				if ( rect_local.top > max_sy ) { break; }

				i++;
				if ( i >= txtbox->redraw_ty ) { break; }
			}
		} else {
			i = txtbox->scroll;
			n_posix_loop
			{//break;

				NonnonTxtboxDrawLine_Phase0( txtbox, i, rect_local );

				rect_local.top += txtbox->font_size.cy;
				if ( rect_local.top > max_sy ) { break; }

				i++;
			}
		}

	} // [!] : Background


	{ // [!] : Phase #1 : EOL marker : and calculation for caret

		RECT rect_local = rect_main;

		i = txtbox->scroll; if ( is_partial_redraw ) { i = txtbox->redraw_fy; }
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
		n_posix_loop
		{//break;

			if ( ( txtbox->redraw_fy <= i )&&( i < txtbox->redraw_ty )&&( i < txtbox->txt_data->sy ) )
			{
				NonnonTxtboxDrawLine_Phase1( txtbox, i, rect_local );
			}

			rect_local.top += txtbox->font_size.cy;
			if ( rect_local.top > max_sy ) { break; }

			i++;
			if ( i >= txtbox->redraw_ty ) { break; }
		}

	} // [!] : Phase #1


	// [!] : Fake Caret #1

	if ( NonnonTxtboxCaretIsOnScreen( txtbox ) )
	{
		if ( ( txtbox->delete_circle_onoff )&&( txtbox->caret_pt.x > ( csx - csy + txtbox->offset_x ) ) )
		{
			//
		} else {
			RECT rect_local = n_win64_rect_set( txtbox->caret_pt.x, txtbox->caret_pt.y - txtbox->caret_centered_offset, N_MAC_TXTBOX_CARET_SIZE, txtbox->font_size.cy );
			NonnonTxtboxCaretDraw( txtbox, rect_local, txtbox->focus );
		}
	}


	{ // [!] : Phase #2 : Main

		RECT rect_local = rect_main;

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{

			i = txtbox->scroll; if ( is_partial_redraw ) { i = txtbox->redraw_fy; }
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
			n_posix_loop
			{//break;

				if ( i == txtbox->focus )
				{
					if ( txtbox->listbox_edit_onoff )
					{
						listbox_rect = rect_local;
						listbox_rect.right = csx - txtbox->padding - txtbox->offset_x;
					} else {
						if ( txtbox->txt_data->readonly )
						{
							NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_gray  , rect_local );
						} else {
							NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_accent, rect_local );
						}
					}
				}

				if ( ( txtbox->redraw_fy <= i )&&( i < txtbox->redraw_ty )&&( i < txtbox->txt_data->sy ) )
				{
					NonnonTxtboxDrawLine_Phase2( txtbox, i, rect_local, csx, csy );
				}

				if ( i == txtbox->focus )
				{
					if ( txtbox->listbox_edit_onoff )
					{
						RECT rect_local = listbox_rect;

						rect_local.left--;
						rect_local.top--;
						//rect_local.right += 2;
						rect_local.bottom += 2;

						n_mac_draw_frame( txtbox->canvas, txtbox->nscolor_accent, rect_local );
					}
				}

				rect_local.top += txtbox->font_size.cy;
				if ( rect_local.top > max_sy ) { break; }


				i++;
				if ( i >= txtbox->redraw_ty ) { break; }
			}

		} else {

			i = txtbox->scroll; if ( is_partial_redraw ) { i = txtbox->redraw_fy; }
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
			n_posix_loop
			{//break;

				if ( ( txtbox->redraw_fy <= i )&&( i < txtbox->redraw_ty )&&( i < txtbox->txt_data->sy ) )
				{
					NonnonTxtboxDrawLine_Phase2( txtbox, i, rect_local, csx, csy );
				}

				rect_local.top += txtbox->font_size.cy;
				if ( rect_local.top > max_sy ) { break; }

				i++;
				if ( i >= txtbox->redraw_ty ) { break; }
			}

		}

	} // [!] : Phase #2


	// [!] : Line Number

	if (
		( txtbox->mode == N_MAC_TXTBOX_MODE_EDITBOX )
		||
		( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	)
	{
//{static int i = 0;NSLog( @"%d", i );i++;}

		n_type_int     i = 0;
		n_type_gfx pxl_y = 0;
		n_posix_loop
		{

			BOOL semi_indicator = FALSE;

			if ( ( txtbox->txt_deco != NULL )&&( txtbox->txt_data->sy == txtbox->txt_deco->sy ) )
			{
				semi_indicator = TRUE;

				n_posix_char *deco = n_txt_get( txtbox->txt_deco, txtbox->scroll + i );

				if ( ( txtbox->listbox_edit_onoff )&&( i == txtbox->focus ) )
				{
					//
				} else
				if ( deco[ 0 ] == ' ' )
				{
					semi_indicator = FALSE;
				} else
				if ( deco[ 0 ] == 'B' )
				{
					//
				} else
				if ( deco[ 0 ] == 'u' )
				{
					semi_indicator = FALSE;
				} else
				if ( deco[ 0 ] == 'U' )
				{
					//
				}
			}

			RECT rect = n_win64_rect_set
			(
				txtbox->offset_x,
				txtbox->offset_y + pxl_y,
				txtbox->linenumber_size.cx,
				txtbox->linenumber_size.cy
			);

			NonnonTxtboxDrawLineNumber( txtbox, i, rect, semi_indicator );

			i++;


			pxl_y += txtbox->linenumber_size.cy;
			if ( pxl_y > max_sy ) { break; }

		}

	}


	// [!] : Find Icon

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &txtbox->find_icon_rect, &x, &y, &sx, &sy );

		RECT r = txtbox->find_icon_rect;
		if ( txtbox->find_icon_is_pressed ) { r.left++; r.top++; x++; y++; }

		RECT rr = r;

		rr.left   -= 1;
		rr.top    -= 1;
		rr.right  += 2;
		rr.bottom += 2;

		if ( txtbox->hwnd == GetFocus() )
		{
			n_mac_draw_circle( txtbox->canvas, txtbox->nscolor_accent, rr );

			u32 color = n_bmp_white;
			n_bmp_rasterizer( &txtbox->find_icon, txtbox->canvas, x,y, color, FALSE );
		} else {
			u32 color = txtbox->nscolor_gray;
			n_bmp_rasterizer( &txtbox->find_icon, txtbox->canvas, x,y, color, FALSE );
		}

	}


	// [!] : Delete Circle

	if ( txtbox->delete_circle_onoff )
	{

		txtbox->delete_circle_rect.left = csx - txtbox->ui_stdsize + 4; 
		n_mac_draw_circle( txtbox->canvas, n_bmp_rgb( 255,0,128 ), txtbox->delete_circle_rect );


		RECT rect_local = txtbox->delete_circle_rect;
		n_type_gfx x,y,sx,sy; n_win64_rect_expand_simple( &rect_local, &x,&y,&sx,&sy );


		n_gdi gdi; n_gdi_zero( &gdi );

		//gdi.base_style          = N_GDI_BASE_CIRCLE;
		gdi.base_color_bg       = n_bmp_white_invisible;//n_bmp_rgb( 255,0,128 );
		gdi.base_color_fg       = n_bmp_white;
		gdi.text                = n_posix_literal( "×" );
		gdi.text_color_main     = n_bmp_white;
		gdi.text_size           = 11; // [Needed] : odd number
		gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_BOLD;

		n_bmp bmp; n_bmp_zero( &bmp );
		n_gdi_bmp( &gdi, &bmp );

		n_txtbox_crop( &bmp, gdi.base_color_bg );
//n_bmp_save_literal( &bmp, "ret.bmp" );

		x += ( sx - N_BMP_SX( &bmp ) ) / 2;
		y += ( sy - N_BMP_SY( &bmp ) ) / 2;

		n_bmp_transcopy( &bmp, txtbox->canvas, 0,0,N_BMP_SX( &bmp ),N_BMP_SY( &bmp ), x,y );

		n_bmp_free_fast( &bmp );
	}


	// [!] : Margin : before scrollbar

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		//
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		//
	} else {
		// [!] : right-side margin

		RECT rect_padding = n_win64_rect_set( csx - txtbox->offset_x, 0, txtbox->offset_x, csy );
		NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_back, rect_padding );


		// [!] : bottom-side margin

		{
			n_type_real o = txtbox->offset_y;
			if ( txtbox->border_separator_only ) { o -= 2; }

			rect_padding = n_win64_rect_set( 0, csy - o, csx, o );
			NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_back, rect_padding );
		}
	}


	// [!] : Scrollbar

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		//
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		//
	} else {

		// [!] : Fake Scroller

//NSLog( @"%f %f", page, txt_sy );


		// [!] : this code needs to be the same as NonnonTxtboxDrawScrollClamp

		n_type_gfx scroll_csy = (n_type_gfx) client.bottom - ( txtbox->offset_y * 2 );

		const n_type_gfx scroll_pixel_sx = 12;

		if ( txtbox->corner_size == -1 ) { txtbox->corner_size = scroll_pixel_sx; }
//NSLog( @"%f", txtbox->corner_size );

		n_type_real shaft_sy         = scroll_csy - txtbox->corner_size;
		n_type_real items_per_canvas = shaft_sy / txtbox->font_size.cy;
		n_type_real max_count        = (n_type_real) txtbox->txt_data->sy;
		n_type_real rest             = txtbox->font_size.cy - fmod( shaft_sy, txtbox->font_size.cy );


		BOOL onoff = FALSE; if ( onoff ) {}

//NSLog( @"%f %f", items_per_canvas, max_count );
		if ( trunc( items_per_canvas ) < max_count )
		{
			onoff = TRUE;

			if ( rest ) { items_per_canvas -= 1.0; }
//NSLog( @"Rest %f", rest );

			n_type_gfx scrsx = scroll_pixel_sx;
			n_type_gfx scr_x = csx - txtbox->offset_x - scrsx;


			n_type_real step = txtbox->font_size.cy * ( shaft_sy / ( max_count * txtbox->font_size.cy ) );
			n_type_real page = max_count / items_per_canvas;

			n_type_gfx scr_y = txtbox->offset_y + ( txtbox->scroll * step );
			n_type_gfx scrsy = n_posix_max_n_type_gfx( 12, scroll_csy / page );

			txtbox->scroll_step = shaft_sy / ( max_count * txtbox->font_size.cy );
			txtbox->scroll_page = items_per_canvas;


			// [!] : for hit test
//scroller_rect = n_win64_rect_set( 0, 0, 0, 0 );
			txtbox->scrollbar_shaft_rect = n_win64_rect_set( scr_x, txtbox->offset_y, scrsx, shaft_sy );
			txtbox->scrollbar_thumb_rect = n_win64_rect_set( scr_x,            scr_y, scrsx,    scrsy );


			u32 color = txtbox->nscolor_text;

			u32 color_shaft = n_bmp_alpha_replace_pixel( color, 16 );

			{
				u32  clr = color_shaft;
				RECT rct = n_win64_rect_set( scr_x, txtbox->offset_y, scrsx, shaft_sy );
				n_mac_draw_roundrect( txtbox->canvas, clr, rct, scrsx / 2 );
			}

			if ( txtbox->search_marker != NULL )
			{
				if ( txtbox->search_marker_count != txtbox->txt_data->sy )
				{
					NonnonTxtboxSearchMarkerReset( txtbox, FALSE );
				} else {
					n_type_int i = 0;
					n_posix_loop
					{
						if ( txtbox->search_marker[ i ] )
						{
							RECT rect_local = n_win64_rect_set( scr_x, i * step, scrsx, 1 );
							NonnonTxtboxDrawBox( txtbox, N_TXTBOX_INDICATOR_SEARCH, rect_local );
						}

						i++;
						if ( i >= txtbox->txt_data->sy ) { break; }
					}
				}
			}


			int hot    =  64;
			int normal =  96;
			int press  = 128;

			u32 color_thumb;
			if ( txtbox->scrollbar_fade_captured_onoff )
			{
//NSLog( @"scrollbar_fade_captured_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, press  );
				u32 t = n_bmp_alpha_replace_pixel( color, hot    );
				if ( txtbox->scrollbar_thumb_is_captured )
				{
//NSLog( @"thumb_is_captured" );
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) txtbox->scrollbar_fade.percent * 0.01 );
				} else {
//NSLog( @"else" );
					if ( txtbox->scrollbar_thumb_is_hovered )
					{
						t = n_bmp_alpha_replace_pixel( color, hot    );
					} else {
						t = n_bmp_alpha_replace_pixel( color, normal );
					}
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) txtbox->scrollbar_fade.percent * 0.01 );
				}
//NSLog( @"%d", scrollbar_fade.percent );
			} else
			if ( txtbox->scrollbar_fade_hovered_onoff )
			{
//NSLog( @"scrollbar_fade_hovered_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, hot    );
				u32 t = n_bmp_alpha_replace_pixel( color, normal );
				if ( txtbox->scrollbar_thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press );
				} else
				if ( txtbox->scrollbar_thumb_is_hovered )
				{
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) txtbox->scrollbar_fade.percent * 0.01 );
				} else {
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) txtbox->scrollbar_fade.percent * 0.01 );
				}
			} else {
//NSLog( @"else" );

				if ( txtbox->scrollbar_thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press  );
				} else
				if ( txtbox->scrollbar_thumb_is_hovered )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, hot    );
				} else {
					color_thumb = n_bmp_alpha_replace_pixel( color, normal );
				}
			}

			{
				u32  clr = color_thumb;
				RECT rct = n_win64_rect_set( scr_x,scr_y, scrsx,scrsy );
				n_mac_draw_roundrect( txtbox->canvas, clr, rct, scrsx / 2 );
			}


			// [!] : caret indicator on a shaft

			RECT rect_local = n_win64_rect_set( scr_x, txtbox->offset_y + ( step * txtbox->focus ), scrsx, 1 );
			NonnonTxtboxDrawBox( txtbox, N_TXTBOX_INDICATOR_CARET, rect_local );

		}

	}


	// [!] : Frame

	if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		RECT rect_canvas = n_win64_rect_set( 0, 0, csx, csy );
		n_mac_draw_roundframe( txtbox->canvas, txtbox->nscolor_frame, rect_canvas, 8, 1 );
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_EDITBOX )
	{
		if ( txtbox->border_separator_only )
		{
			RECT rect_separator = n_win64_rect_set( 0, 0, csx, 1 );
			NonnonTxtboxDrawBox( txtbox, txtbox->nscolor_frame, rect_separator );
		} else {
			RECT rect_canvas = n_win64_rect_set( 0, 0, csx, csy );
			n_mac_draw_roundframe( txtbox->canvas, txtbox->nscolor_frame, rect_canvas, 8, 1 );
		}
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		RECT rect_canvas = n_win64_rect_set( 0, 0, csx, csy );
		n_mac_draw_roundframe( txtbox->canvas, txtbox->nscolor_frame, rect_canvas, 4, 1 );
	} else
	if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		RECT rect_canvas = n_win64_rect_set( 0, 0, csx, csy );

		u32 color;
		if ( txtbox->hwnd == GetFocus() )
		{
			color = txtbox->nscolor_accent;
		} else {
			color = txtbox->nscolor_frame;
		}

		n_mac_draw_roundframe( txtbox->canvas, color, rect_canvas, csy/2, 2 );
	}

//n_mac_draw_frame( txtbox->canvas, n_bmp_rgb(0,200,255), txtbox->debug_rect );


	// [!] : Clean-up
//if ( self.txtbox->mode == N_MAC_TXTBOX_MODE_EDITBOX ) { NSLog( @"%lld %lld", redraw_fy, redraw_ty ); }

	SelectObject( txtbox->hdc, hfont_prev );

	n_win64_doublebuffer_postsync( &txtbox->doublebuffer );
	n_win64_doublebuffer_cleanup( &txtbox->doublebuffer );

	//n_win64_doublebuffer_simple_exit();

	txtbox->redraw_fy = -1;
	txtbox->redraw_ty = -1;


	return;
}


