﻿// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_txtbox_edit_insert( n_txtbox *txtbox, n_posix_char *text )
{

	n_posix_char *line_f = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );
	n_posix_char *line_m = n_string_carboncopy( text );
	n_posix_char *line_t = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );
	
	line_f[ txtbox->caret_fr.cch.x ] = N_STRING_CHAR_NUL;

	n_posix_snprintf_literal( line_t, n_posix_strlen( line_t ) + 1, "%s", &line_t[ txtbox->caret_fr.cch.x ] );
//NSLog( @"%s", line_f );
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%s", line_t );

	n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
	n_posix_char *str = n_string_new( cch );
	n_posix_snprintf_literal( str, cch + 1, "%s%s%s", line_f, line_m, line_t );
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%s : %s : %s", line_f, line_m, line_t );

	n_txt_mod( txtbox->txt_data, txtbox->focus, str );

	n_string_free( str );


	txtbox->caret_fr.cch.x = txtbox->caret_to.cch.x = txtbox->caret_fr.cch.x + n_posix_strlen( line_m );

	txtbox->hdc = GetDC( txtbox->hwnd );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->caret_fr.cch.x,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	n_string_free( line_f );
	n_string_free( line_m );
	n_string_free( line_t );


	return;
}




n_posix_bool
n_txtbox_input( n_txtbox *txtbox, int vk )
{

	if ( txtbox == NULL ) { return FALSE; }


	BYTE         key[ 256 ]; GetKeyboardState( key );
	n_posix_char str[ 100 ];

#ifdef UNICODE

	ToUnicode( vk,0,key, str,100, 0 );

#else // #ifdef UNICODE

	WORD w;
	ToAscii  ( vk,0,key, &w, 0 );
	str[ 0 ] = w;
	str[ 1 ] = N_STRING_CHAR_NUL;

	// [x] : Buggy : ANSI version on NT : invalid character will be returned

	//if ( txtbox->is_nt )
	{
		wchar_t wstr[ 100 ];
		ToUnicode( vk,0,key, wstr,100, 0 );
		if ( wstr[ 0 ] == L'\0' ) { return n_posix_false; }
	}

#endif // #ifdef UNICODE

//n_posix_debug_literal( " %d ", str[ 0 ] );

//n_posix_debug_literal( "%d : %d : %d : %x", vk, ImmGetVirtualKey( p->hwnd ), n_win_is_input( VK_CONVERT ), (int) str[ 0 ] );

	if ( n_string_is_empty( str ) ) { return FALSE; }


	if ( 0x08 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x08 : BS

	} else
/*
	if ( 0x09 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x09 : TAB

	} else
*/
	if ( 0x0d == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x0d CR

	} else
	if ( 0x1b == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x1b ESC

		return FALSE;

	} else
	if ( 0x03 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x03 End of Text

		return FALSE;

	} else
	if ( 0x16 == str[ 0 ] )
	{

		// [!] : ASCII Control Code : 0x16 Synchronous Idle

		return FALSE;

	} else
	//
	{
//n_win_txtbox_hwndprintf_literal( p, " %s ", str );

		NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );

		NonnonTxtboxKeyboardInputMethod( txtbox, str );

	}


	return TRUE;
}




BOOL
NonnonTxtboxKeyboardIsFullStop( n_txtbox *txtbox )
{

	BOOL ret = FALSE;

	if (
		( txtbox->caret_fr.cch.x == 0 )&&( txtbox->caret_fr.cch.y == 0 )
		&&
		( txtbox->caret_to.cch.x == 0 )&&( txtbox->caret_to.cch.y == 0 )

	)
	{
		ret = TRUE;
	}

	return ret;
}

void
NonnonTxtboxKeyboardMoveDetect( n_txtbox *txtbox, n_type_int ud, n_type_int lr, BOOL oneline_override )
{
//NSLog( @"NonnonTxtboxKeyboardMoveDetect %f", txtbox->focus );


	// [!] : unselect
/*
	if ( ( caret_fr.pxl.x != caret_to.pxl.x )&&( caret_fr.cch.y != caret_to.cch.y ) )
	{
//NSLog( @"!" );
		caret_fr = caret_to;
	}
*/

//NSLog( @"%d", shift_selection_is_tail );


	txtbox->focus += ud;
	if ( txtbox->focus < 0 )
	{
		if ( txtbox->focus <= -1 ) { txtbox->caret_to.cch.x = 0; }
		txtbox->focus = 0;
	}
	if ( txtbox->focus >= txtbox->txt_data->sy ) { txtbox->focus = txtbox->txt_data->sy - 1; }


	if ( ud )
	{
		RECT client; GetClientRect( txtbox->hwnd, &client );

		RECT r = n_win64_rect_set( txtbox->padding, txtbox->offset_y, client.right - ( txtbox->offset_x * 2 ), txtbox->font_size.cy );

		POINT pt = { txtbox->padding + txtbox->caret_to.pxl.x, txtbox->caret_to.cch.y + txtbox->font_size.cy };

		txtbox->hdc = GetDC( txtbox->hwnd );

		txtbox->caret_to = n_txtbox_caret_detect_pixel2caret
		(
			txtbox->hdc,
			txtbox->txt_data,
			txtbox->focus,
			r,
			txtbox->font,
			txtbox->font_size,
			pt,
			txtbox->is_monospace
		);
//NSLog( @"%0.2f", caret_to.pxl.x );

		ReleaseDC( txtbox->hwnd, txtbox->hdc );

		// [!] : Win32 compatible behavior 
		if ( txtbox->caret_to.pxl.x == 0 ) { txtbox->caret_to.cch.x = 0; }
	}


	if ( lr != 0 )
	{

		if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			if ( txtbox->listbox_edit_onoff ) { oneline_override = TRUE; } else { return; }
		}

		n_posix_char *s = n_txt_get( txtbox->txt_data, txtbox->focus );
		if ( lr < 0 )
		{
			if ( txtbox->caret_to.cch.x == 0 )
			{
				if ( oneline_override )
				{
					//
				} else
				if ( txtbox->focus != 0 )
				{
					txtbox->focus--;
					txtbox->caret_fr.cch.x = txtbox->caret_to.cch.x = n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->focus ) );
				}
			} else {
				txtbox->caret_to.cch.x = n_mac_txtbox_caret_move( s, txtbox->caret_to.cch.x, TRUE, N_MAC_TXTBOX_CARET_MOVE_L );
			}
		} else {
			if ( txtbox->caret_to.cch.x == n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->focus ) ) )
			{
				n_type_int max_sy = txtbox->txt_data->sy - 1;
				if ( oneline_override )
				{
					//
				} else
				if ( txtbox->focus < max_sy )
				{
					txtbox->focus++;
					txtbox->caret_to.cch.x = 0;
				}
			} else {
				txtbox->caret_to.cch.x = n_mac_txtbox_caret_move( s, txtbox->caret_to.cch.x, TRUE, N_MAC_TXTBOX_CARET_MOVE_R );	
			}
		}
	}


	txtbox->hdc = GetDC( txtbox->hwnd );

	txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		txtbox->caret_to.cch.x,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	return;
}

n_caret
NonnonTxtboxKeyboardShiftSelectionDetect( n_txtbox *txtbox, n_type_int lr, n_type_int cch )
{
//NSLog( @"NonnonTxtboxKeyboardShiftSelectionDetect %f", txtbox->focus );

	n_posix_char *s = n_txt_get( txtbox->txt_data, txtbox->focus );
	if ( lr < 0 )
	{
		cch = n_mac_txtbox_caret_move( s, cch, TRUE, N_MAC_TXTBOX_CARET_MOVE_L );
	} else {
		cch = n_mac_txtbox_caret_move( s, cch, TRUE, N_MAC_TXTBOX_CARET_MOVE_R );
	}
//NSLog( @"%lld", (*cch) );

	txtbox->hdc = GetDC( txtbox->hwnd );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		txtbox->hdc,
		txtbox->txt_data,
		txtbox->focus,
		txtbox->font,
		txtbox->font_size,
		cch,
		txtbox->is_monospace
	);

	ReleaseDC( txtbox->hwnd, txtbox->hdc );


	return caret;
}

void
NonnonTxtboxTabPatch( n_txtbox *txtbox, n_type_int index_f, n_type_int index_t )
{

	txtbox->caret_fr = NonnonMakeCaret
	(
		0, index_f * txtbox->font_size.cy,
		0, index_f
	);


	{
		n_posix_char *line = n_txt_get( txtbox->txt_data, index_t );
		n_type_int    cch  = n_posix_strlen( line );

		txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
		(
			txtbox->hdc,
			txtbox->txt_data,
			index_t,
			txtbox->font,
			txtbox->font_size,
			cch,
			txtbox->is_monospace
		);


		txtbox->caret_to = NonnonMakeCaret
		(
			txtbox->caret_to.pxl.x, index_t * txtbox->font_size.cy,
			txtbox->caret_to.cch.x, index_t
		);
	}

	txtbox->shift_selection_is_tail = TRUE;


	return;
}




void
n_win64_txtbox_proc_keyboard( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, n_txtbox *txtbox )
{
//return;

	// [Needed] : put in subclass


	if ( txtbox->hwnd != GetFocus() ) { return; }

	if ( FALSE == IsWindowVisible( txtbox->hwnd ) ) { return; }

	if ( txtbox->focus < 0 ) { return; }


	switch( msg ) {

	case WM_KEYUP :

		txtbox->is_key_input = FALSE;

	break;

	case WM_KEYDOWN :

		txtbox->is_key_input = TRUE;


		txtbox->caret_blink_force_onoff = TRUE;


		if ( wParam == VK_PRIOR ) // Page Up
		{

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				break;
			}

			RECT client; GetClientRect( hwnd, &client );

			n_type_real csy              = client.bottom - ( txtbox->offset_y * 2 );
			n_type_real items_per_canvas = csy / txtbox->font_size.cy;

			txtbox->scroll -= items_per_canvas;

			n_txtbox_redraw( txtbox );

		} else
		if ( wParam == VK_NEXT ) // Page DOWN
		{

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				break;
			}

			RECT client; GetClientRect( hwnd, &client );

			n_type_real csy              = client.bottom - ( txtbox->offset_y * 2 );
			n_type_real items_per_canvas = csy / txtbox->font_size.cy;

			txtbox->scroll += items_per_canvas;

			n_txtbox_redraw( txtbox );

		} else

		if ( wParam == VK_UP )
		{
//NSLog( @"Up" );

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				if ( txtbox->listbox_edit_onoff )
				{
					//
				} else
				if ( txtbox->focus >= 1 )
				{

					if ( n_win64_is_input( VK_SHIFT ) )
					{
						n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_SWAP );
					} else {
						txtbox->focus--;
						txtbox->listbox_edit_onoff = FALSE;
					}

					NonnonTxtboxCaretOutOfCanvasUpDownListbox( txtbox );
					n_txtbox_redraw( txtbox );

					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_LISTBOX_MOVED );
				}

				break;
			}


			if ( n_win64_is_input( VK_SHIFT ) )
			{

				n_caret caret = txtbox->caret_fr;

				NonnonTxtboxKeyboardMoveDetect( txtbox, -1, 0, FALSE );

				txtbox->caret_fr = caret;

			} else {

				NonnonTxtboxKeyboardMoveDetect( txtbox, -1, 0, FALSE );

			}

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );
		} else
		if ( wParam == VK_DOWN )
		{
//NSLog( @"Down" );

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				break;
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				if ( txtbox->listbox_edit_onoff )
				{
					//
				} else
				if ( txtbox->focus <= ( txtbox->txt_data->sy - 1 - 1 ) )
				{
				
					if ( n_win64_is_input( VK_SHIFT ) )
					{
						n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_SWAP );
					} else {
						txtbox->focus++;
						txtbox->listbox_edit_onoff = FALSE;
					}

					NonnonTxtboxCaretOutOfCanvasUpDownListbox( txtbox );
					n_txtbox_redraw( txtbox );

					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_LISTBOX_MOVED );
				}

				break;
			}


			if ( n_win64_is_input( VK_SHIFT ) )
			{

				n_caret caret = txtbox->caret_fr;

				NonnonTxtboxKeyboardMoveDetect( txtbox, 1, 0, FALSE );

				txtbox->caret_fr = caret;

			} else {

				NonnonTxtboxKeyboardMoveDetect( txtbox, 1, 0, FALSE );

			}

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );
		} else
		if ( wParam == VK_LEFT )
		{
//NSLog( @"Left" );
			if ( n_win64_is_input( VK_SHIFT ) )
			{
				n_caret caret = txtbox->caret_fr;

				NonnonTxtboxKeyboardMoveDetect( txtbox, 0, -1, TRUE );

				txtbox->caret_fr = caret;

				txtbox->shift_selection_is_tail = TRUE;
			} else
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, FALSE, FALSE );
				txtbox->caret_to = txtbox->caret_fr;

				if ( txtbox->caret_to.cch.x > 0 ) { txtbox->caret_to.cch.x--; }
				txtbox->caret_fr.cch.x = txtbox->caret_to.cch.x;
			} else {
				NonnonTxtboxKeyboardMoveDetect( txtbox, 0, -1, FALSE );
			}

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );
		} else
		if ( wParam == VK_RIGHT )
		{
//NSLog( @"Right" );
			if ( n_win64_is_input( VK_SHIFT ) )
			{
				n_caret caret = txtbox->caret_fr;

				NonnonTxtboxKeyboardMoveDetect( txtbox, 0, 1, TRUE );

				txtbox->caret_fr = caret;

				txtbox->shift_selection_is_tail = FALSE;
			} else
			if ( n_win64_is_input( VK_CONTROL ) )
			{
				NonnonTxtboxDoubleClickDetect( txtbox, FALSE, FALSE );
				txtbox->caret_fr = txtbox->caret_to;
			} else {
				NonnonTxtboxKeyboardMoveDetect( txtbox, 0, 1, FALSE );
			}

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );
		} else
		if ( wParam == VK_RETURN )
		{

			if ( txtbox->txt_data->readonly ) { break; }


			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				//
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				//
			} else
			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				if ( txtbox->listbox_no_edit ) { break; }

				n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_LISTBOX_EDITED );

				if ( txtbox->listbox_edit_onoff )
				{
					txtbox->listbox_edit_onoff = FALSE;
					n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_EDITED );
				} else {
					txtbox->listbox_edit_onoff = TRUE;

					txtbox->listbox_edit_index = txtbox->focus;

					txtbox->hdc = GetDC( txtbox->hwnd );

					txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
					(
						txtbox->hdc,
						txtbox->txt_data,
						txtbox->focus,
						txtbox->font,
						txtbox->font_size,
						n_posix_strlen( n_txt_get( txtbox->txt_data, txtbox->focus ) ),
						txtbox->is_monospace
					);

					ReleaseDC( txtbox->hwnd, txtbox->hdc );
				}

				NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
				n_txtbox_redraw( txtbox );

				break;

			} else
			if ( n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to ) )
			{

				txtbox->hdc = GetDC( txtbox->hwnd );

				txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
				(
					txtbox->hdc,
					txtbox->txt_data,
					txtbox->focus,
					txtbox->font,
					txtbox->font_size,
					txtbox->caret_fr.cch.x,
					txtbox->is_monospace
				);

				ReleaseDC( txtbox->hwnd, txtbox->hdc );

//n_caret_debug_cch( caret_fr ,caret_to );

			} else {
//NSLog( @"divide" );

				n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
				n_posix_char *s    = n_string_carboncopy( line );

				n_txt_add( txtbox->txt_data, txtbox->focus + 1, &s[ txtbox->caret_fr.cch.x ] );
				line[ txtbox->caret_fr.cch.x ] = N_STRING_CHAR_NUL;

				n_string_free( s );


				txtbox->focus++;
				txtbox->caret_fr = txtbox->caret_to = NonnonMakeCaret( 0, txtbox->focus * txtbox->font_size.cy, 0, txtbox->focus );

			}

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				txtbox->is_enter_pressed = TRUE;
				n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_F3 );
				txtbox->is_enter_pressed = FALSE;
			} else {
				n_txtbox_edited_notify( txtbox );
			}

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );

		} else
		if ( wParam == VK_BACK )
		{

			if ( txtbox->txt_data->readonly ) { break; }


			if ( NonnonTxtboxKeyboardIsFullStop( txtbox ) )
			{
				NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
				break;
			}


			NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );


//n_caret_debug_cch( caret_fr ,caret_to );// break;

			BOOL grow = ( txtbox->caret_fr.cch.y < txtbox->caret_to.cch.y );

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{

				if ( txtbox->listbox_edit_onoff )
				{
					n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
					n_type_int     cch = txtbox->caret_fr.cch.x - 1;

					n_posix_snprintf_literal( &line[ cch ], n_posix_strlen( line ) - cch + 1, "%s", &line[ txtbox->caret_fr.cch.x ] );

					if ( grow ) { txtbox->focus = txtbox->caret_fr.cch.y; }

					txtbox->hdc = GetDC( txtbox->hwnd );

					txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
					(
						txtbox->hdc,
						txtbox->txt_data,
						txtbox->focus,
						txtbox->font,
						txtbox->font_size,
						cch,
						txtbox->is_monospace
					);

					ReleaseDC( txtbox->hwnd, txtbox->hdc );

					NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
					n_txtbox_redraw( txtbox );
				}

				break;
			}

			if ( n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to ) )
			{
//NSLog( @"Backspace : deleted : %0.2f %lld %lld", txtbox->focus, caret_fr.cch.y, caret_to.cch.y );

				txtbox->hdc = GetDC( txtbox->hwnd );

				txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
				(
					txtbox->hdc,
					txtbox->txt_data,
					txtbox->focus,
					txtbox->font,
					txtbox->font_size,
					txtbox->caret_fr.cch.x,
					txtbox->is_monospace
				);

				ReleaseDC( txtbox->hwnd, txtbox->hdc );

				n_txtbox_edited_notify( txtbox );

				NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
				n_txtbox_redraw( txtbox );

				break;
			}

			if (
				( txtbox->mode == N_MAC_TXTBOX_MODE_EDITBOX )
				&&
				( txtbox->caret_fr.cch.x == 0 )
			)
			{
//NSLog( @"Backspace : zero" );

				if ( txtbox->focus == 0 )
				{
					// [!] : for select all
					txtbox->caret_fr = txtbox->caret_to = NonnonMakeCaret( 0,0,0,0 );
					n_txtbox_redraw( txtbox );
					break;
				}

				n_posix_char *line_1 = n_txt_get( txtbox->txt_data, txtbox->focus - 1 );
				n_posix_char *line_2 = n_txt_get( txtbox->txt_data, txtbox->focus     );
				n_type_int     cch_1 = n_posix_strlen( line_1 );
				n_type_int     cch_2 = n_posix_strlen( line_2 );

				n_posix_char  *s     = n_string_new( cch_1 + cch_2 );
				n_posix_snprintf_literal( s, cch_1 + cch_2 + 1, "%s%s", line_1, line_2 );

				n_txt_del( txtbox->txt_data, txtbox->focus );
				n_txt_mod( txtbox->txt_data, txtbox->focus - 1, s );

				txtbox->focus--;

				txtbox->caret_fr.cch.x = txtbox->caret_to.cch.x = cch_1;

				txtbox->hdc = GetDC( txtbox->hwnd );

				txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
				(
					txtbox->hdc,
					txtbox->txt_data,
					txtbox->focus,
					txtbox->font,
					txtbox->font_size,
					txtbox->caret_fr.cch.x,
					txtbox->is_monospace
				);

				ReleaseDC( txtbox->hwnd, txtbox->hdc );

				n_string_free( s );

			} else {
//NSLog( @"Backspace : normal" );

				n_posix_char *line = n_txt_get( txtbox->txt_data, txtbox->focus );
				n_type_int     cch = txtbox->caret_fr.cch.x - 1;

				n_posix_snprintf_literal( &line[ cch ], n_posix_strlen( line ) - cch + 1, "%s", &line[ txtbox->caret_fr.cch.x ] );

				if ( grow ) { txtbox->focus = txtbox->caret_fr.cch.y; }

				txtbox->hdc = GetDC( txtbox->hwnd );

				txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
				(
					txtbox->hdc,
					txtbox->txt_data,
					txtbox->focus,
					txtbox->font,
					txtbox->font_size,
					cch,
					txtbox->is_monospace
				);

				ReleaseDC( txtbox->hwnd, txtbox->hdc );

			}

			n_txtbox_edited_notify( txtbox );

			NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
			n_txtbox_redraw( txtbox );

		} else

		if ( wParam == VK_TAB )
		{

			if ( txtbox->txt_data->readonly ) { break; }


			// [!] : same as Xcode

			BOOL selected = ( 1 <= llabs( txtbox->caret_fr.cch.y - txtbox->caret_to.cch.y ) );

			NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );

			if ( n_win64_is_input( VK_SHIFT ) )
			{
				// [!] : multi-line tab remover

				if ( selected == FALSE )
				{
					goto n_txtbox_input_default;
					break;
				}

				n_type_int count = llabs( txtbox->caret_fr.cch.y - txtbox->caret_to.cch.y ) + 1;
				n_type_int min_y = n_posix_min_n_type_int( txtbox->caret_fr.cch.y, txtbox->caret_to.cch.y );

				n_type_int y = 0;
				n_posix_loop
				{
					if ( y >= count ) { break; }

					n_posix_char *line = n_txt_get( txtbox->txt_data, min_y + y );

					if ( line[ 0 ] == N_STRING_CHAR_TAB )
					{
						n_type_int    cch = n_posix_strlen( line ) + 1;
						n_posix_char *str = n_string_new( cch );
						n_posix_snprintf_literal( str, cch + 1, "%s", &line[ 1 ] );

						n_txt_mod_fast( txtbox->txt_data, min_y + y, str );
					}

					y++;
				}

				NonnonTxtboxTabPatch( txtbox, min_y, min_y + count - 1 );

				n_txtbox_edited_notify( txtbox );

				n_txtbox_redraw( txtbox );
			} else {
				// [!] : multi-line tab adder

				if ( selected == FALSE )
				{
					goto n_txtbox_input_default;
					break;
				}

				n_type_int count = llabs( txtbox->caret_fr.cch.y - txtbox->caret_to.cch.y ) + 1;
				n_type_int min_y = n_posix_min_n_type_int( txtbox->caret_fr.cch.y,  txtbox->caret_to.cch.y );

				n_type_int y = 0;
				n_posix_loop
				{
					if ( y >= count ) { break; }

					n_posix_char *line = n_txt_get( txtbox->txt_data, min_y + y );

					if ( FALSE == n_string_is_empty( line ) )
					{
						n_type_int    cch = n_posix_strlen( line ) + 1;
						n_posix_char *str = n_string_new( cch );
						n_posix_snprintf_literal( str, cch + 1, "%s%s", N_STRING_TAB, line );

						n_txt_mod_fast( txtbox->txt_data, min_y + y, str );
					}

					y++;
				}

//n_posix_debug_literal( "Min : %s", n_txt_get( txtbox->txt_data, min_y ) );
//n_posix_debug_literal( "Max : %s", n_txt_get( txtbox->txt_data, min_y + count - 1 ) );

				NonnonTxtboxTabPatch( txtbox, min_y, min_y + count - 1 );

				n_txtbox_edited_notify( txtbox );

				//NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
				n_txtbox_redraw( txtbox );
			}

		} else
		if ( wParam == 'X' ) // [!] : Cut
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );

				n_txtbox_edited_notify( txtbox );


				n_posix_char *s = n_mac_txtbox_copy( txtbox->txt_data, txtbox->caret_fr.cch.x, txtbox->caret_fr.cch.y, txtbox->caret_to.cch.x, txtbox->caret_to.cch.y );
				n_clipboard_text_set( txtbox->hwnd, s );

				n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );

				txtbox->hdc = GetDC( txtbox->hwnd );

				txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
				(
					txtbox->hdc,
					txtbox->txt_data,
					txtbox->focus,
					txtbox->font,
					txtbox->font_size,
					txtbox->caret_fr.cch.x,
					txtbox->is_monospace
				);

				ReleaseDC( txtbox->hwnd, txtbox->hdc );

				NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );
				n_txtbox_redraw( txtbox );

			} else {

				NonnonTxtboxCaretOutOfCanvasUpDown( txtbox );

				goto n_txtbox_input_default;

			}
		} else
		if ( wParam == 'C' ) // [!] : Copy
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				n_posix_char *s = n_mac_txtbox_copy( txtbox->txt_data, txtbox->caret_fr.cch.x, txtbox->caret_fr.cch.y, txtbox->caret_to.cch.x, txtbox->caret_to.cch.y );
				n_clipboard_text_set( txtbox->hwnd, s );
			} else {
				goto n_txtbox_input_default;
			}

		} else
		if ( wParam == 'V' ) // [!] : Paste
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_REGISTER );

				n_txtbox_edited_notify( txtbox );

				n_type_int cch = n_clipboard_text_get( txtbox->hwnd, NULL );
				n_posix_char *c = n_string_new( cch );
				n_clipboard_text_get( txtbox->hwnd, c );
//n_win64_hwndprintf_literal( GetParent( txtbox->hwnd ), "%s", c );

				// [Patch] : vector_load() may have a bug
				BOOL patch = FALSE;
				if ( ( cch > 0 )&&( c[ cch - 1 ] == N_STRING_CHAR_LF ) )
				{
//NSLog( @"patched" );
					patch = TRUE;
				}

				n_txt t; n_txt_zero( &t ); n_txt_load_onmemory( &t, c, cch * sizeof( n_posix_char ) );
//NSLog( @"%lld", t.sy );

				if (
					( txtbox->mode == N_MAC_TXTBOX_MODE_FINDBOX )
					||
					( txtbox->mode == N_MAC_TXTBOX_MODE_ONELINE )
				)
				{
					if ( t.sy != 1 ) { n_txt_free( &t ); break; }

					n_posix_char *s = n_txt_get( &t, 0 );
					n_string_replace( s, s, N_STRING_LF, N_STRING_NUL );
				} else {
					if ( patch )
					{
						n_txt_add( &t, t.sy, N_STRING_EMPTY );
					}
				}


				n_mac_txtbox_del( txtbox->txt_data, &txtbox->focus, &txtbox->caret_fr, &txtbox->caret_to );

				if ( t.sy == 1 )
				{

					n_txtbox_edit_insert( txtbox, n_txt_get( &t, 0 ) );

					n_txtbox_edited_notify( txtbox );

				} else {
//break;
					if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX ) { break; }


					n_posix_char *line_f = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );
					n_posix_char *line_t = n_string_carboncopy( n_txt_get( txtbox->txt_data, txtbox->focus ) );

					line_f[ txtbox->caret_fr.cch.x ] = N_STRING_CHAR_NUL;
					n_posix_snprintf_literal( line_t, n_posix_strlen( line_t ) + 1, "%s", &line_t[ txtbox->caret_fr.cch.x ] );
//NSLog( @"F:%s", line_f );
//NSLog( @"T:%s", line_t );

					{
						n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( n_txt_get( &t, 0 ) );
						n_posix_char *str = n_string_new( cch );

						n_posix_snprintf_literal( str, cch + 1, "%s%s", line_f, n_txt_get( &t, 0 ) );
						n_txt_mod_fast( txtbox->txt_data, txtbox->focus, str );
					}

					n_type_int i = 1;
					n_posix_loop
					{//break;
						if ( i >= t.sy ) { break; }

						n_txt_add( txtbox->txt_data, txtbox->focus + i, n_txt_get( &t, i ) );

						i++;
					}

					{
						i--;

						n_type_int    cch = n_posix_strlen( n_txt_get( &t, i ) ) + n_posix_strlen( line_t );
						n_posix_char *str = n_string_new( cch );

						n_posix_snprintf_literal( str, cch + 1, "%s%s", n_txt_get( &t, i ), line_t );
						n_txt_mod_fast( txtbox->txt_data, txtbox->focus + i, str );
					}


					n_type_int p_focus = txtbox->caret_fr.cch.y;

					txtbox->focus = txtbox->focus + i;

					txtbox->hdc = GetDC( txtbox->hwnd );

					txtbox->caret_fr = txtbox->caret_to = n_txtbox_caret_detect_cch2pixel
					(
						txtbox->hdc,
						txtbox->txt_data,
						txtbox->focus,
						txtbox->font,
						txtbox->font_size,
						n_posix_strlen( n_txt_get( &t, i ) ),
						txtbox->is_monospace
					);

					ReleaseDC( txtbox->hwnd, txtbox->hdc );


					RECT client; GetClientRect( txtbox->hwnd, &client );

					n_type_real csy              = client.bottom - ( txtbox->offset_y * 2 );
					n_type_real items_per_canvas = csy / txtbox->font_size.cy;
					n_type_real edge             = trunc( txtbox->scroll + items_per_canvas );
//NSLog( @"Focus %lld : Edge %0.2f : Scroll %0.2f", txtbox->focus, edge, scroll );

					if ( p_focus < txtbox->scroll )
					{
						txtbox->scroll = p_focus;
						//NonnonTxtboxDrawScrollClamp( txtbox );
						edge = trunc( txtbox->scroll + items_per_canvas );
					}

					if ( txtbox->focus >= edge )
					{
						txtbox->scroll = txtbox->scroll + ( txtbox->focus - edge );
						txtbox->scroll = ceil( txtbox->scroll ) + 1;
					}


					n_string_free( line_f );
					n_string_free( line_t );

				}

				n_txt_free( &t );


				n_txtbox_redraw( txtbox );

			} else {

				goto n_txtbox_input_default;

			}

		} else
		if ( wParam == 'A' ) // [!] : Select All
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX ) { break; }

				NonnonTxtboxSelectAll( txtbox, TRUE );
			} else {
				goto n_txtbox_input_default;
			}

		} else
		if ( wParam == 'Z' ) // [!] : Undo
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				if ( txtbox->txt_data->readonly ) { break; }

				NonnonTxtboxUndo( txtbox, N_TXTBOX_UNDO_RESTORE );

				n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_UNDO );

				n_txtbox_redraw( txtbox );
			} else {
				goto n_txtbox_input_default;
			}

		} else
		if ( wParam == 'F' )
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_FIND_FOCUS );
			} else {
				goto n_txtbox_input_default;
			}

		} else
		if ( wParam == 'S' )
		{

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				//if ( n_txt_save_utf8( txtbox->txt_data, n_mac_nsstring2str( txtbox->path ) ) )
				{
//NSLog( @"n_txt_save_utf8() failed : %s", n_mac_nsstring2str( path ) );
				}
			} else {
				goto n_txtbox_input_default;
			}

		} else
		if ( wParam == VK_F3 )
		{
			n_txtbox_delegate_message( txtbox, N_MAC_TXTBOX_DELEGATE_F3 );
		} else
		if ( wParam == VK_F5 )
		{

			if ( txtbox->txt_data->readonly ) { break; }

			n_posix_char str[ 100 ];

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				n_txtbox_day_of_week( str, 100 );
			} else {
				n_txtbox_date( str, 100 );
			}

			n_txtbox_edit_insert( txtbox, str );

			n_txtbox_edited_notify( txtbox );

			n_txtbox_redraw( txtbox );

		} else
		//
		{
//NSLog( @"pressed" );

			n_txtbox_input_default:

			if ( txtbox->txt_data->readonly ) { break; }

			if ( txtbox->mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				if ( txtbox->listbox_edit_onoff == FALSE ) { break; }
			}

			if ( n_win64_is_input( VK_CONTROL ) )
			{
				//
			} else {
				n_txtbox_input( txtbox, wParam );
			}

		}

	break;

	} // switch


	return;
}


