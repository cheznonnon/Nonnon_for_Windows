// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_type_int
n_mac_txtbox_utf8_cb( char *str )
{

	n_type_int cb;
	if ( (u8) str[ 0 ] >= 0xf0 )
	{
		cb = 4;
	} else
	if ( (u8) str[ 0 ] >= 0xe0 )
	{
		cb = 3;
	} else
	if ( (u8) str[ 0 ] >= 0xc0 )
	{
		cb = 2;
	} else {
		cb = 1;
	}


	return cb;
}

// internal
BOOL
n_mac_txtbox_is_fullwidth_detect( u16 c )
{

	if ( c <= 127 )
	{

		// [!] : ASCII compatible code

		return FALSE;

	} else
	if (
		(						//  8448 -  8703
			( c == 8470 )
			||
			( ( c >=  8544 )&&( c <=  8578 ) )
		)
		||
		(						//  8704 -  8959
			( ( c >=  8704 )&&( c <=  8748 ) )
			||
			( c == 8750 )
		)
		||
		( ( c >=  8960 )&&( c <=  9215 ) )		//  8960 -  9215 
		||
		( ( c >=  9312 )&&( c <=  9471 ) )		//  9216 -  9471
		||
		( ( c >= 0x25A0 )&&( c <= 0x25ff ) )		//  9472 -  9727
		||
		( ( c >= 0x2600 )&&( c <= 0x26ff ) )		//  9728 -  9983
		||
		( ( c >= 0x2700 )&&( c <= 0x27ff ) )		//  9984 - 10239
		||
		( ( c >= 0x2e00 )&&( c <= 0x2eff ) )		// 11766 - 12031
		||
		( ( c >= 0x2f00 )&&( c <= 0x2fff ) )		// 12032 - 12287
		||
		( ( c >= 0x3000 )&&( c <= 0xd7ff ) )		// 12288 - 55295
		||
		( ( c >= 0xff00 )&&( c <= 0xff60 ) )		// 65280 - 65376 : 0xff61 or above : includes "half-width kana"
	)
	{
		return TRUE;
	}


	return FALSE;
}

// internal
BOOL
n_mac_txtbox_is_accentmark_detect( u16 c )
{
//NSLog( @"%04x", c );


	BOOL ret = FALSE;


	if ( ( c >= 0x0300 )&&( c <= 0x036f ) )
	{
		ret = TRUE;
	} else
	if ( ( c >= 0x1ab0 )&&( c <= 0x1ac0 ) )
	{
		ret = TRUE;
	} else
	if ( ( c >= 0x1dc0 )&&( c <= 0x1dff ) )
	{
		ret = TRUE;
	} else
	if ( ( c >= 0x20d0 )&&( c <= 0x20f0 ) )
	{
		ret = TRUE;
	} else
	if ( ( c >= 0xfe20 )&&( c <= 0xfeff ) )
	{
		ret = TRUE;
	} else
	if ( ( c == 0x3099 )||( c == 0x309a ) )
	{
		// [!] : for japanese combining characters : dakuten(0x3099) and handakuten(0x309a)
		//
		//	dakuten    : "ha" will be "ba"
		//	handakuten : "ha" will be "pa"
		//
		//	Finder : a default name of a new folder uses this

		ret = TRUE;
	}


	return ret;
}

BOOL
n_mac_txtbox_is_digit_fullwidth( n_posix_char *str, n_type_int index )
{

	BOOL ret = FALSE;


	if ( n_string_is_empty( str ) ) { return ret; }

	if ( index < 0 ) { return ret; } 


	char *fullwidth_digit[ 10 ] = {
		"０", "１", "２", "３", "４", "５", "６", "７", "８", "９"
	};

	int utf8 = 0;
	n_posix_loop
	{
		char *cmp = fullwidth_digit[ utf8 ];

		if (
			(
				( str[ index + 0 ] != N_STRING_CHAR_NUL )
				&&
				( str[ index + 0 ] == cmp[ 0 ] )
			)
			&&
			(
				( str[ index + 1 ] != N_STRING_CHAR_NUL )
				&&
				( str[ index + 1 ] == cmp[ 1 ] )
			)
			&&
			(
				( str[ index + 2 ] != N_STRING_CHAR_NUL )
				&&
				( str[ index + 2 ] == cmp[ 2 ] )
			)
		)
		{
			ret = TRUE;
			break; 
		}

		utf8++;
		if ( utf8 >= 10 ) { break; }
	}


	return ret;
}

BOOL
n_mac_txtbox_digit_detect( n_posix_char *starting_char, n_posix_char *str, n_type_int index )
{

	// [!] : is_digit : set starting char status


	BOOL ret = FALSE;


	if (
		(
			( n_string_is_digit( starting_char, 0 ) )
			&&
			( FALSE == n_string_is_digit( str, index ) )
		)
		||
		(
			( FALSE == n_string_is_digit( starting_char, 0 ) )
			&&
			( n_string_is_digit( str, index ) )
		)
	)
	{
		ret = TRUE;
	}


	if (
		(
			( n_mac_txtbox_is_digit_fullwidth( starting_char, 0 ) )
			&&
			( FALSE == n_mac_txtbox_is_digit_fullwidth( str, index ) )
		)
		||
		(
			( FALSE == n_mac_txtbox_is_digit_fullwidth( starting_char, 0 ) )
			&&
			( n_mac_txtbox_is_digit_fullwidth( str, index ) )
		)
	)
	{
		ret = TRUE;
	}


	return ret;
}

// internal
n_posix_char*
n_mac_txtbox_character
(
	      HDC           hdc,
	      HFONT         hfont,
	      SIZE          font_size,
	const n_posix_char *str,
	      n_type_int    index,
	      BOOL          is_monospace,
	      SIZE         *ret_size,
	      n_type_int   *ret_cch,
	      n_type_int   *ret_tab
)
{

	// [ Mechanism ]
	//
	//	call this module from begining of a string
	//
	//	index    : element counter
	//	ret_size : pixel metrics of returned string
	//	ret_cch  : character count
	//	ret_tab  : tabbed character count


	static n_posix_char character[ 20 ];

	if ( ret_size == NULL ) { n_string_truncate( character ); }


	BOOL is_ascii = FALSE;


	n_type_int _index = 0;
	n_type_int _tab   = 0;
	n_type_int _width = 1;

	if ( str[ index ] == N_STRING_CHAR_NUL )
	{

		n_string_truncate( character );

	} else
	if ( ( str[ index ] == N_STRING_CHAR_TAB )&&( ret_tab != NULL ) )
	{

		n_type_int tabstop = 8;
		if ( tabstop <= 0 ) { tabstop = 8; }

		const n_type_int tab = tabstop - ( (*ret_tab) % tabstop );

		if ( ret_size != NULL )
		{
			n_string_padding  ( character, N_STRING_CHAR_SPACE, tab );
			n_string_terminate( character, tab );
		}

		_index = 1;
		_tab   = tab;

	} else {

		if ( ret_size != NULL )
		{
			character[ 0 ] = str[ index ];
			character[ 1 ] = N_STRING_CHAR_NUL;
		}

		if ( n_mac_txtbox_is_fullwidth_detect( str[ index ] ) )
		{
			_width = 2;
		}

		if ( n_mac_txtbox_is_accentmark_detect( str[ index + 1 ] ) )
		{
			if ( ret_size != NULL )
			{
				character[ 1 ] = str[ index + 1 ];
				character[ 2 ] = N_STRING_CHAR_NUL;
			}
			_index++;
		} else
		if ( n_unicode_surrogatepair_is_hi( str[ index ] ) )
		{
			if ( ret_size != NULL )
			{
				character[ 1 ] = str[ index + 1 ];
				character[ 2 ] = N_STRING_CHAR_NUL;
			}
			_index++;
		} else
		if ( character[ 0 ] <= 127 )
		{
			is_ascii = TRUE;
		}

		_index++;
		_tab   = 1;

	}

	if ( ret_size != NULL )
	{
		if ( is_monospace )
		{
			if ( _width == 2 )
			{
				n_type_real kaku = font_size.cx * _width;
				n_type_real tabs = font_size.cx * _tab  ;

				SIZE sz = { n_posix_max_n_type_real( kaku, tabs ), font_size.cy };
				(*ret_size) = sz;
			} else
			if ( is_ascii )
			{
				n_type_real kaku = font_size.cx *    1;
				n_type_real tabs = font_size.cx * _tab;

				SIZE sz = { n_posix_max_n_type_real( kaku, tabs ), font_size.cy };
				(*ret_size) = sz;
			} else
			//
			{
				(*ret_size) = n_win64_text_pixelsize( hdc, character, hfont );
			}
		} else
		//
		{
			(*ret_size) = n_win64_text_pixelsize( hdc, character, hfont );
		}
	}
	if ( ret_cch  != NULL ) { (*ret_cch)  = _index; }
	if ( ret_tab  != NULL ) { (*ret_tab) += _tab  ; }


	return character;
}



