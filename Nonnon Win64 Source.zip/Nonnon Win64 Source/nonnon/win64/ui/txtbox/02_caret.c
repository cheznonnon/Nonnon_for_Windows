// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	n_type_int x;
	n_type_int y;

} n_point_cch;

typedef struct {

	POINT       pxl;
	n_point_cch cch;

} n_caret;

n_caret
NonnonMakeCaret( n_type_real pxl_x, n_type_real pxl_y, n_type_int cch_x, n_type_int cch_y )
{

	n_caret caret = { { pxl_x, pxl_y }, { cch_x, cch_y } };

	return caret;
}

void
n_caret_debug_cch( n_caret fr, n_caret to )
{
//NSLog( @"CCH : Fr %lld %lld : To %lld %lld", fr.cch.x, fr.cch.y, to.cch.x, to.cch.y );

	return;
}

n_caret
n_txtbox_caret_detect_pixel2caret
(
	HDC         hdc,
	n_txt      *txt,
	n_type_int  focus,
	RECT        rect,
	HFONT       font,
	SIZE        font_size,
	POINT       local_point,
	BOOL        is_monospace
)
{

	n_posix_char *line = n_txt_get( txt, focus );
//n_posix_debug_literal( "%s", line );

	n_type_int index = 0;
	n_type_gfx sx    = 0;
	n_type_int tab   = 0;
	n_type_int cch   = 0;
	n_posix_loop
	{//break;

		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		SIZE       char_size;
		n_type_int char_index;
		RECT       char_rect = rect;

		n_mac_txtbox_character( hdc, font, font_size, line, index, is_monospace, &char_size, &char_index, &tab );

		// [!] : macOS to Win32 : this is not "CGFloat" : modulo error happens

		n_type_gfx half_sx = char_size.cx / 2;

		sx += half_sx;
		char_rect.left = rect.left + sx;
		if ( char_rect.left > local_point.x ) { sx -= half_sx; break; }

		index += char_index;
		cch    = index;

		sx += half_sx + ( char_size.cx % 2 );
		char_rect.left = rect.left + sx;
		if ( char_rect.left > local_point.x ) { break; }
	}


	return NonnonMakeCaret( sx, focus * font_size.cy, cch, focus );
}

n_caret
n_txtbox_caret_detect_cch2pixel
(
	HDC         hdc,
	n_txt      *txt,
	n_type_int  focus,
	HFONT       font,
	SIZE        font_size,
	n_type_int  caret_cch,
	BOOL        is_monospace
)
{
//NSLog( @"%lld", caret_cch );

	n_posix_char *line = n_txt_get( txt, focus );


	n_type_int  index = 0;
	n_type_real sx    = 0;
	n_type_int  tab   = 0;
	n_posix_loop
	{//break;
		if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

		SIZE       char_size;
		n_type_int char_index;

		n_mac_txtbox_character( hdc, font, font_size, line, index, is_monospace, &char_size, &char_index, &tab );

		if ( index >= caret_cch ) { break; }

		sx    += char_size.cx;
		index += char_index;

	}

//NSLog( @"%f", sx );
	return NonnonMakeCaret( sx, focus * font_size.cy, caret_cch, focus );
}

n_caret
n_txtbox_caret_tail
(
	HDC         hdc,
	n_txt      *txt,
	n_type_int  focus,
	HFONT       font,
	SIZE        font_size,
	BOOL       *is_tail,
	BOOL        is_monospace
)
{
//NSLog( @"%f", txtbox->focus );


	n_posix_char *line = n_txt_get( txt, focus );
	n_type_int    cch  = n_posix_strlen( line );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		hdc,
		txt,
		focus,
		font,
		font_size,
		cch,
		is_monospace
	);

	if ( is_tail != NULL ) { (*is_tail) = TRUE; }


	return caret;
}

