// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_ISHELLLINK
#define _H_NONNON_WIN64_ISHELLLINK




#include "../neutral/string_path.c"


#include <shlobj.h>




const GUID n_GUID_CLSID_ShellLink = { 0x00021401,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };

const GUID n_GUID_IID_IPersistFile = { 0x0000010B,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };


#ifdef UNICODE


const GUID n_GUID_IID_IShellLink = { 0x000214F9,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };


#define IShellLink_GetPath         IShellLinkW_GetPath
#define IShellLink_SetPath         IShellLinkW_SetPath
#define IShellLink_GetIconLocation IShellLinkW_GetIconLocation
#define IShellLink_SetIconLocation IShellLinkW_SetIconLocation
#define IShellLink_GetArguments    IShellLinkW_GetArguments
#define IShellLink_SetArguments    IShellLinkW_SetArguments


#else  // #ifdef UNICODE


const GUID n_GUID_IID_IShellLink = { 0x000214EE,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };


#define IShellLink_GetPath         IShellLinkA_GetPath
#define IShellLink_SetPath         IShellLinkA_SetPath
#define IShellLink_GetIconLocation IShellLinkA_GetIconLocation
#define IShellLink_SetIconLocation IShellLinkA_SetIconLocation
#define IShellLink_GetArguments    IShellLinkA_GetArguments
#define IShellLink_SetArguments    IShellLinkA_SetArguments


#endif // #ifdef UNICODE




#define N_WIN64_ISHELLLINK_EXT n_posix_literal( ".lnk\0\0" )




#define n_win64_IShellLink_bstr_init_literal( s ) n_win64_IShellLink_bstr_init( n_posix_literal( s ) )

#define n_win64_IShellLink_bstr_exit( bstr ) SysFreeString( bstr )

BSTR
n_win64_IShellLink_bstr_init( const n_posix_char *str )
{

	// [!] : you need to do n_com_bstr_exit() with returned BSTR


	if ( str == NULL ) { return NULL; }


#ifdef UNICODE

	wchar_t *wstr = n_string_carboncopy( str );

#else // #ifdef UNICODE

	wchar_t *wstr = n_posix_ansi2unicode( str );

#endif // #ifdef UNICODE


	// [!] : IE4 hasn't SysAllocStringLen();

//n_com_debug_w( wstr );

	BSTR bstr = SysAllocString( wstr );


	n_memory_free( wstr );


	return bstr;
}




BOOL
n_win64_IShellLink_is_shortcut( const n_posix_char *name )
{

	BOOL ret = FALSE;


	if (
		( n_posix_stat_is_file( name ) )
		&&
		( n_string_path_ext_is_same( N_WIN64_ISHELLLINK_EXT, name ) )
	)
	{
		ret = TRUE;
	}


	return ret;
}

void
n_win64_IShellLink_path2lnk
(
	n_posix_char *name,
	n_posix_char *path,
	n_posix_char *args,
	n_posix_char *icon,
	n_type_gfx    icon_number
)
{
//n_posix_debug_literal( "%s\n%s\n%s", name, path, args ); return;

	// [Mechanism]
	//
	//	each parameters are semi-const
	//	real data are read-only, but pointer variables are overwritten
	//
	//	name        : [ Needed ] : .LNK name : absolute path
	//	path        : [ Needed ] : a target path
	//	args        : [Optional] : commandline option
	//	icon        : [Optional] : icon name
	//	icon_number : [Optional] : icon number


	if ( n_string_is_empty( path ) ) { return; }
	if ( n_string_is_empty( name ) ) { return; }


	if ( icon_number > INT_MAX ) { return; }


	if ( n_string_is_empty( args ) ) { args = N_STRING_EMPTY; }
	if ( n_string_is_empty( icon ) ) { icon = path; }


	CoInitialize( NULL );


	IShellLink *sl;

	CoCreateInstance( &n_GUID_CLSID_ShellLink, NULL, CLSCTX_ALL, &n_GUID_IID_IShellLink, (void**) &sl );
	if ( sl == NULL )
	{
		CoUninitialize();

		return;
	}


	IPersistFile *pf;

	sl->lpVtbl->QueryInterface( sl, &n_GUID_IID_IPersistFile, (void**) &pf );
	if ( pf == NULL )
	{
		sl->lpVtbl->Release( sl );

		CoUninitialize();

		return;
	}


	// [!] : Win95 : backslash only
	//
	//	before : "C:/nonnon_win/catpad.exe"
	//	after  : "C:\\nonnon_win/catpad.exe" => handled as not exist

	// [!] : Not Needed : SetArguments( sl, "%1" );

	IShellLink_SetPath        ( sl, path );
	IShellLink_SetArguments   ( sl, args );
	IShellLink_SetIconLocation( sl, icon, (int) icon_number );


	{

		n_posix_char *lnk = n_string_path_cat( name, N_WIN64_ISHELLLINK_EXT, NULL );
//n_posix_debug_literal( "%s", lnk );

		{
			BSTR bstr = n_win64_IShellLink_bstr_init( lnk );
//n_com_debug_w( bstr );
			IPersistFile_Save( pf, bstr, n_posix_true );

			n_win64_IShellLink_bstr_exit( bstr );
		}

		n_string_free( lnk );

	}


	sl->lpVtbl->Release( sl );
	pf->lpVtbl->Release( pf );


	CoUninitialize();


	return;
}

#define N_WIN64_ISHELLLINK_LNK2PATH_CCH_PATH ( MAX_PATH )
#define N_WIN64_ISHELLLINK_LNK2PATH_CCH_ARGS (   1024   )

void
n_win64_IShellLink_lnk2path
(
	const n_posix_char *lnk,
	      n_posix_char *path,
	      n_posix_char *args,
	      n_posix_char *icon,
	      n_type_gfx   *icon_number
)
{

	if ( FALSE == n_win64_IShellLink_is_shortcut( lnk ) )
	{

		if ( path != NULL ) { n_string_copy( lnk, path ); }

		return;
	}


	CoInitialize( NULL );


	IShellLink *sl;

	CoCreateInstance( &n_GUID_CLSID_ShellLink, NULL, CLSCTX_ALL, &n_GUID_IID_IShellLink, (void**) &sl );
	if ( sl == NULL )
	{
		CoUninitialize();

		return;
	}


	IPersistFile *pf;

	sl->lpVtbl->QueryInterface( sl, &n_GUID_IID_IPersistFile, (void**) &pf );
	if ( pf == NULL )
	{
		sl->lpVtbl->Release( sl );

		CoUninitialize();

		return;
	}


	{
		BSTR bstr = n_win64_IShellLink_bstr_init( lnk );

		IPersistFile_Load( pf, bstr, STGM_READ );

		n_win64_IShellLink_bstr_exit( bstr );
	}


	// [!] : GetArguments() : maximum length
	//
	//	MAX_PATH : 260

	if ( path != NULL ) { IShellLink_GetPath( sl, path, N_WIN64_ISHELLLINK_LNK2PATH_CCH_PATH, NULL, 0 ); }


	// [!] : GetArguments() : maximum length
	//
	//	before Win2000    : MAX_PATH    :  260
	//	Win2000 and later : INFOTIPSIZE : 1024

	if ( args != NULL ) { IShellLink_GetArguments( sl, args, N_WIN64_ISHELLLINK_LNK2PATH_CCH_ARGS ); }


	if ( ( icon != NULL )&&( icon_number != NULL ) )
	{
		int number = 0;
		IShellLink_GetIconLocation( sl, icon, N_WIN64_ISHELLLINK_LNK2PATH_CCH_PATH, &number );
		(*icon_number) = (n_type_gfx) number;
	}


	sl->lpVtbl->Release( sl );
	pf->lpVtbl->Release( pf );


	CoUninitialize();


	return;
}

void
n_win64_IShellLink_iotest( n_posix_char *cmdline )
{

	if ( n_string_path_ext_is_same( N_WIN64_ISHELLLINK_EXT, cmdline ) )
	{

		n_posix_char path[ N_WIN64_ISHELLLINK_LNK2PATH_CCH_PATH ];
		n_posix_char args[ N_WIN64_ISHELLLINK_LNK2PATH_CCH_ARGS ];


		n_win64_IShellLink_lnk2path( cmdline, path, args, NULL, NULL );

		n_posix_debug_literal( "%s : %s", path, args );

	} else {

		n_win64_IShellLink_path2lnk( NULL, cmdline, NULL, NULL, 0 );

	}


	return;
}


#endif // _H_NONNON_WIN64_ISHELLLINK

