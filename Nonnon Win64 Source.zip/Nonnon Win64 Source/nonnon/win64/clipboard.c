// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_CLIPBOARD
#define _H_NONNON_WIN64_CLIPBOARD




#include "../neutral/string.c"
#include "../neutral/string_path.c"

#include "../neutral/bmp.c"


#include <shlobj.h>




BOOL
n_clipboard_nbmp_get( n_bmp *b )
{

	// [Needed] : n_bmp_zero( &b );


	if ( b == NULL ) { return TRUE; }


	OpenClipboard( GetDesktopWindow() );


	if (
		( n_posix_false == IsClipboardFormatAvailable( CF_DIB    ) )
		||
		( n_posix_false == IsClipboardFormatAvailable( CF_BITMAP ) )
	)
	{

		CloseClipboard();

		return TRUE;
	}


	BITMAPINFO bi;

	{

		HGLOBAL h = GetClipboardData( CF_DIB );
		if ( h == NULL )
		{

			CloseClipboard();

			return n_posix_true;
		}


		n_memory_copy( (void*) GlobalLock( h ), &bi, sizeof(BITMAPINFO) );

		GlobalUnlock( h );

	}

/*
n_posix_debug
(
	"Size      \t\t %d-%d \n"
	"Depth       \t %d \n"
	"Compression \t %d \n"
	"SizeImage   \t %d \n",
	(int) bi.bmiHeader.biWidth,
	(int) bi.bmiHeader.biHeight,
	(int) bi.bmiHeader.biBitCount,
	(int) bi.bmiHeader.biCompression,
	(int) bi.bmiHeader.biSizeImage
);
*/


	HGLOBAL h = GetClipboardData( CF_BITMAP );
	if ( h == NULL )
	{

		CloseClipboard();

		return n_posix_true;
	}


	// [!] : auto-conversion

	bi.bmiHeader.biCompression =  0;
	bi.bmiHeader.biSizeImage   =  0;
	bi.bmiHeader.biBitCount    = 32;

	n_type_int byte = n_bmp_size
	(
		bi.bmiHeader.biWidth,
		bi.bmiHeader.biHeight,
		bi.bmiHeader.biBitCount
	);


	n_bmp_free( b );


	BITMAPFILEHEADER fileh = { N_BMP_TYPE_BM, 0, 0,0, N_BMP_SIZE_HEADER };

	fileh.bfSize = fileh.bfOffBits + (u32) byte;

	n_memory_copy( &fileh,        &N_BMP_FILEH( b ), N_BMP_SIZE_FILEH );
	n_memory_copy( &bi.bmiHeader, &N_BMP_INFOH( b ), N_BMP_SIZE_INFOH );

	{

		HDC hdc = GetDC( NULL );

		N_BMP_PTR( b ) = n_memory_new( byte );

		GetDIBits( hdc, h, 0,bi.bmiHeader.biHeight, N_BMP_PTR( b ), &bi, DIB_RGB_COLORS );

		ReleaseDC( NULL, hdc );

	}

	n_bmp_precalc( b );


	CloseClipboard();


	return FALSE;
}

n_posix_bool
n_clipboard_nbmp_set( const n_bmp *bmp )
{

	if ( bmp == NULL ) { return n_posix_true; }


	OpenClipboard( GetDesktopWindow() );


	EmptyClipboard();


	const n_bmp *bmp_target = bmp;


	BITMAPINFO bi = { N_BMP_INFOH( bmp_target ), { { 0,0,0,0 } } };


	{
		HDC hdc = GetDC( NULL );

		HBITMAP hbmp = CreateDIBitmap( hdc, &N_BMP_INFOH( bmp_target ), CBM_INIT, N_BMP_PTR( bmp_target ), &bi, DIB_RGB_COLORS );

		SetClipboardData( CF_BITMAP, hbmp );

		ReleaseDC( NULL, hdc );
	}


	CloseClipboard();


	return n_posix_false;
}




n_type_int
n_clipboard_text_get( HWND hwnd, n_posix_char *text )
{

	OpenClipboard( hwnd );


#ifdef UNICODE

	HANDLE handle = GetClipboardData( CF_UNICODETEXT );

#else // #ifdef UNICODE

	HANDLE handle = GetClipboardData( CF_TEXT );

#endif // #ifdef UNICODE


	n_type_int length = GlobalSize( handle ) / sizeof( n_posix_char );

	if ( text != NULL )
	{

		n_posix_char *str = (n_posix_char*) GlobalLock( handle );

		if ( str != NULL )
		{
			n_posix_snprintf_literal( text, length + 1, "%s", str );
		}

		GlobalUnlock( handle );

	}


	CloseClipboard();


	return length;
}

void
n_clipboard_text_set( HWND hwnd, const n_posix_char *text )
{

	if ( text == NULL ) { return; }


	OpenClipboard( hwnd );

	EmptyClipboard();


	n_type_int length = n_posix_strlen( text ) + 1;
	HANDLE     handle = GlobalAlloc( GHND, length * sizeof( n_posix_char ) );

	n_string_copy( text, (void*) GlobalLock( handle ) );

	GlobalUnlock( handle );


#ifdef UNICODE

	SetClipboardData( CF_UNICODETEXT, handle );

#else // #ifdef UNICODE

	SetClipboardData( CF_TEXT, handle );

#endif // #ifdef UNICODE


	CloseClipboard();


	return;
}




#endif // _H_NONNON_WIN32_CLIPBOARD

