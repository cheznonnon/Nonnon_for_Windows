// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_FONT
#define _H_NONNON_WIN64_FONT




#include "_windows.c"




#define n_win64_font_exit( hfont ) DeleteObject( hfont )


#define n_win64_font_logfont2hfont( ptr_lf ) CreateFontIndirect( ptr_lf )

LOGFONT
n_win64_font_hfont2logfont( HFONT hfont )
{

	LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

	GetObject( hfont, sizeof( LOGFONT ), &lf );

	return lf;
}

HFONT
n_win64_font_decoration( HFONT hfont, int aa, int bold, int pitch, BOOL italic, BOOL underline )
{

	LOGFONT lf = n_win64_font_hfont2logfont( hfont );

	lf.lfQuality        = aa;	// ANTIALIASED_QUALITY, CLEARTYPE_QUALITY
	lf.lfWeight         = bold;	// FW_BOLD
	lf.lfPitchAndFamily = pitch;	// FIXED_PITCH
	lf.lfItalic         = italic;
	lf.lfUnderline      = underline;


	n_win64_font_exit( hfont );

	return n_win64_font_logfont2hfont( &lf );
}




HFONT
n_win64_font_ui( void )
{

	// [Needed] : n_win64_font_exit( hfont );

	int cb = sizeof( NONCLIENTMETRICS );

	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;

	BOOL ret = SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );
	if ( ret == FALSE ) { return GetStockObject( DEFAULT_GUI_FONT ); }

	// [x] : Win11 : too small
	ncm.lfMessageFont.lfHeight = -15;

	return n_win64_font_logfont2hfont( &ncm.lfMessageFont );
}




// internal
int CALLBACK
n_win64_font_enumfontsproc( const LOGFONT *lf, const TEXTMETRIC *tm, DWORD type, LPARAM lparam )
{

	// [Mechanism] : type
	//
	//	DEVICE_FONTTYPE
	//	RASTER_FONTTYPE
	//	TRUETYPE_FONTTYPE

	// [!] : lfPitchAndFamily : FIXED_PITCH : bitmap fonts are only returned


	LOGFONT *query = (LOGFONT*) lparam;


	if ( n_string_is_same( lf->lfFaceName, query->lfFaceName ) )
	{
//n_posix_debug_literal( "%s : %s", lf->lfFaceName, query->lfFaceName );

		n_memory_copy( lf, query, sizeof( LOGFONT ) );


		return FALSE;
	}


	return TRUE;
}

#define n_win64_font_is_exist_literal( name ) n_win64_font_is_exist( n_posix_literal( name ) )

BOOL
n_win64_font_is_exist( const n_posix_char *name )
{

	HWND hwnd = NULL;
	HDC  hdc  = GetDC( hwnd );


	LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

	if ( LF_FACESIZE > n_posix_strlen( name ) ) { n_string_copy( name, lf.lfFaceName ); }


	BOOL ret = EnumFonts( hdc, NULL, n_win64_font_enumfontsproc, (LPARAM) &lf );


	ReleaseDC( hwnd, hdc );


	return ( ret == FALSE );
}

n_posix_char*
n_win64_font_find( n_posix_char *first, ... )
{

	n_posix_char *ret = NULL;


	va_list vl; va_start( vl, first );

	n_posix_loop
	{

		if ( ret == NULL )
		{
			ret = first;
		} else {
			ret = va_arg( vl, n_posix_char* );
		}
		if ( ret == NULL ) { break; }

		if ( n_win64_font_is_exist( ret ) ) { break; }

	}

	va_end( vl );


	return ret;
}

#define n_win64_font_name2hfont_literal( name, size ) n_win64_font_name2hfont( n_posix_literal( name ), size )

HFONT
n_win64_font_name2hfont( const n_posix_char *name, n_type_gfx size )
{

	LOGFONT lf; ZeroMemory( &lf, sizeof( LOGFONT ) );

	n_string_copy( name, lf.lfFaceName );


	HDC hdc = GetDC( NULL );

	EnumFonts( hdc, NULL, n_win64_font_enumfontsproc, (LPARAM) &lf );

	ReleaseDC( NULL, hdc );


	lf.lfWidth  = 0;
	lf.lfHeight = size;


	return n_win64_font_logfont2hfont( &lf );
}

n_type_gfx
n_win64_font_hfont2size( HFONT hfont )
{

	LOGFONT lf = n_win64_font_hfont2logfont( hfont );

	return lf.lfHeight;
}

void
n_win64_font_hfont2name( HFONT hfont, n_posix_char *ret )
{

	LOGFONT lf = n_win64_font_hfont2logfont( hfont );

	if ( ret != NULL )
	{
		n_posix_snprintf_literal( ret, LF_FACESIZE, "%s", lf.lfFaceName );
	}


	return;
}




#endif // _H_NONNON_WIN64_FONT

