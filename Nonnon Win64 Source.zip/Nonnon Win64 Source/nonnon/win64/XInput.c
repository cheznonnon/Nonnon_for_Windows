// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN64_XINPUT
#define _H_NONNON_WIN64_XINPUT




#include <xinput.h>




#define N_XINPUT_BUTTON_MAX 16




typedef DWORD (*n_XInputGetCapabilities_type)( int, int, XINPUT_CAPABILITIES* );
typedef DWORD (*n_XInputGetState_type)       ( int, XINPUT_STATE* );
typedef DWORD (*n_XInputSetState_type)       ( int, XINPUT_VIBRATION* );


typedef struct {

	int number;
	int udlr   [ 4 ];
	int buttons[ N_XINPUT_BUTTON_MAX ];

	// [!] : internal cache

	HMODULE                      XInput_hmodule;
	n_XInputGetCapabilities_type XInputGetCapabilities;
	n_XInputGetState_type        XInputGetState;
	n_XInputSetState_type        XInputSetState;

} n_XInput;




#define n_XInput_zero( p ) n_memory_zero( p, sizeof( n_XInput ) )

void
n_XInput_exit( n_XInput *p )
{

	if ( p == NULL ) { return; }


	FreeLibrary( p->XInput_hmodule );

	n_XInput_zero( p );


	return;
}

void
n_XInput_init( n_XInput *p, int number )
{

	if ( p == NULL ) { return; }


	n_XInput_exit( p );


	p->number = number;


	p->XInput_hmodule = LoadLibrary( n_posix_literal( "Xinput9_1_0.dll" ) );
	if ( p->XInput_hmodule == NULL )
	{
		p->XInput_hmodule = LoadLibrary( n_posix_literal( "Xinput1_4.dll" ) );
	}
	if ( p->XInput_hmodule == NULL )
	{
//n_log( " LoadLibrary() : Xinput.dll " );
	}

	p->XInputGetCapabilities = (n_XInputGetCapabilities_type) GetProcAddress( p->XInput_hmodule, "XInputGetCapabilities" );
	p->XInputGetState        = (n_XInputGetState_type)        GetProcAddress( p->XInput_hmodule, "XInputGetState"        );
	p->XInputSetState        = (n_XInputSetState_type)        GetProcAddress( p->XInput_hmodule, "XInputSetState"        );

	if (
		( p->XInputGetCapabilities == NULL )
		||
		( p->XInputGetState        == NULL )
		||
		( p->XInputSetState        == NULL )
	)
	{
//n_log( " GetProcAddress() " );

		FreeLibrary( p->XInput_hmodule );

		p->XInput_hmodule        = NULL;
		p->XInputGetCapabilities = NULL;
		p->XInputGetState        = NULL;
		p->XInputSetState        = NULL;

	}

//n_log( " OK " );
	return;
}

#define n_XInput_vk2udlr_default( p ) n_XInput_vk2udlr( p, VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT )

void
n_XInput_vk2udlr( n_XInput *p, int vk_u, int vk_d, int vk_l, int vk_r )
{

	if ( p == NULL ) { return; }


	p->udlr[ 0 ] = vk_u;
	p->udlr[ 1 ] = vk_d;
	p->udlr[ 2 ] = vk_l;
	p->udlr[ 3 ] = vk_r;


	return;
}

void
n_XInput_vk2button( n_XInput *p, int vk, int button )
{

	if ( p == NULL ) { return; }


	if ( button <                    0 ) { return; }
	if ( button >= N_XINPUT_BUTTON_MAX ) { return; }


	p->buttons[ button ] = vk;


	return;
}

#define N_XINPUT_THUMB_MIN    -32768
#define N_XINPUT_THUMB_MAX     32767

#define N_XINPUT_TRIGGER_MAX   255

BOOL
n_XInput_is_enabled( n_XInput *p )
{

	XINPUT_CAPABILITIES caps; ZeroMemory( &caps, sizeof( XINPUT_CAPABILITIES ) );
	DWORD dw = (DWORD) p->XInputGetCapabilities( p->number, XINPUT_FLAG_GAMEPAD, &caps );
	if ( dw == ERROR_DEVICE_NOT_CONNECTED )
	{
//n_log( " ERROR_DEVICE_NOT_CONNECTED " );

		return FALSE;
	}


	return TRUE;
}

BOOL
n_XInput_is_input( n_XInput *p, int vk )
{

	XINPUT_STATE state; ZeroMemory( &state, sizeof( XINPUT_STATE ) );
	p->XInputGetState( p->number, &state );

	WORD button = state.Gamepad.wButtons;
//if ( button ) { n_log( " %d : %d ", state.dwPacketNumber, button ); }

	if ( ( vk == p->udlr   [  0 ] )&&( button & XINPUT_GAMEPAD_DPAD_UP        ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  1 ] )&&( button & XINPUT_GAMEPAD_DPAD_DOWN      ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  2 ] )&&( button & XINPUT_GAMEPAD_DPAD_LEFT      ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  3 ] )&&( button & XINPUT_GAMEPAD_DPAD_RIGHT     ) ) { return TRUE; }
	if ( ( vk == p->buttons[  0 ] )&&( button & XINPUT_GAMEPAD_Y              ) ) { return TRUE; }
	if ( ( vk == p->buttons[  1 ] )&&( button & XINPUT_GAMEPAD_B              ) ) { return TRUE; }
	if ( ( vk == p->buttons[  2 ] )&&( button & XINPUT_GAMEPAD_A              ) ) { return TRUE; }
	if ( ( vk == p->buttons[  3 ] )&&( button & XINPUT_GAMEPAD_X              ) ) { return TRUE; }
	if ( ( vk == p->buttons[  6 ] )&&( button & XINPUT_GAMEPAD_LEFT_SHOULDER  ) ) { return TRUE; }
	if ( ( vk == p->buttons[  7 ] )&&( button & XINPUT_GAMEPAD_RIGHT_SHOULDER ) ) { return TRUE; }
	if ( ( vk == p->buttons[  8 ] )&&( button & XINPUT_GAMEPAD_LEFT_THUMB     ) ) { return TRUE; }
	if ( ( vk == p->buttons[  9 ] )&&( button & XINPUT_GAMEPAD_RIGHT_THUMB    ) ) { return TRUE; }
	if ( ( vk == p->buttons[ 10 ] )&&( button & XINPUT_GAMEPAD_BACK           ) ) { return TRUE; }
	if ( ( vk == p->buttons[ 11 ] )&&( button & XINPUT_GAMEPAD_START          ) ) { return TRUE; }

	BYTE l2 = state.Gamepad.bLeftTrigger;
	BYTE r2 = state.Gamepad.bRightTrigger;

	if ( ( vk == p->buttons[  4 ] )&&( l2 == N_XINPUT_TRIGGER_MAX  ) ) { return TRUE; }
	if ( ( vk == p->buttons[  5 ] )&&( r2 == N_XINPUT_TRIGGER_MAX  ) ) { return TRUE; }

	SHORT updown = state.Gamepad.sThumbLY;
	SHORT lr     = state.Gamepad.sThumbLX;
//n_log( " %d : %d : %d : %d ", updown, lr, state.Gamepad.sThumbRX, state.Gamepad.sThumbRY );

	if ( ( vk == p->udlr   [  0 ] )&&( updown == N_XINPUT_THUMB_MAX ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  1 ] )&&( updown == N_XINPUT_THUMB_MIN ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  2 ] )&&( lr     == N_XINPUT_THUMB_MIN ) ) { return TRUE; }
	if ( ( vk == p->udlr   [  3 ] )&&( lr     == N_XINPUT_THUMB_MAX ) ) { return TRUE; }


	return FALSE;
}

#define N_XINPUT_VIBRATE_MAX 65535

void
n_XInput_vibrate( n_XInput *p, int vibrate_l, int vibrate_r )
{

	if ( p == NULL ) { return; }

	if ( p->XInput_hmodule == NULL ) { return; }


	XINPUT_VIBRATION v = { vibrate_l, vibrate_r };
	p->XInputSetState( p->number, &v );


	return;
}


#endif // _H_NONNON_WIN64_XINPUT

