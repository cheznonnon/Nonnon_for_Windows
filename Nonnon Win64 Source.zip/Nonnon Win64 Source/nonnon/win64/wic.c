// Windows Imaging Component Support
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Limitaiton ]
//
//	+ WinXP SP2 or later only
//	+ decoder only
//	+ webp plugin : Win10 or later only




#ifndef _H_NONNON_WIN64_WIC
#define _H_NONNON_WIN64_WIC




#include "../neutral/bmp.c"




#include <wincodec.h>

#ifdef _MSC_VER

#pragma comment( lib, "Windowscodecs.lib" )

#endif // #ifdef _MSC_VER




const GUID CLSID_WICImagingFactory       = { 0xcacaf262,0x9370,0x4615,{ 0xa1,0x3b, 0x9f,0x55,0x39,0xda,0x4c,0x0a } };
const GUID  IID_IWICImagingFactory       = { 0xec5ec8a9,0xc395,0x4314,{ 0x9c,0x77, 0x54,0xd7,0xa9,0x35,0xff,0x70 } };
const GUID GUID_WICPixelFormat32bppPBGRA = { 0x6fddc324,0x4e03,0x4bfe,{ 0xb1,0x85, 0x3d,0x77,0x76,0x8d,0xc9,0x10 } };




BOOL
n_win64_wic_load( const n_posix_char *name, n_bmp *bmp )
{

	n_posix_bool ret = TRUE;


	if ( FALSE == n_posix_stat_is_file( name ) ) { return ret; }


	CoInitialize( NULL );


	IWICImagingFactory    *n_IWICImagingFactory    = NULL;
	IWICBitmapDecoder     *n_IWICBitmapDecoder     = NULL;
	IWICFormatConverter   *n_IWICFormatConverter   = NULL;
	IWICBitmapFrameDecode *n_IWICBitmapFrameDecode = NULL;

	HRESULT hr = CoCreateInstance
	(
		        &CLSID_WICImagingFactory,
		          NULL,
		         CLSCTX_INPROC_SERVER,
		        &IID_IWICImagingFactory,
		(void*) &n_IWICImagingFactory
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "WICImagingFactory" );

		goto cleanup;
	}


#ifdef UNICODE
	const wchar_t *str = name;
#else  // #ifdef UNICODE
	wchar_t *str = n_posix_ansi2unicode( name );
#endif // #ifdef UNICODE

	hr = n_IWICImagingFactory->lpVtbl->CreateDecoderFromFilename
	(
		         n_IWICImagingFactory,
		         str,
		         NULL,
		         GENERIC_READ,
		         WICDecodeMetadataCacheOnDemand,
		(void*) &n_IWICBitmapDecoder
	);

#ifdef UNICODE
	//
#else  // #ifdef UNICODE
	n_memory_free( str );
#endif // #ifdef UNICODE

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "CreateDecoderFromFilename" );

		goto cleanup;
	}


	hr = n_IWICImagingFactory->lpVtbl->CreateFormatConverter
	(
		         n_IWICImagingFactory,
		(void*) &n_IWICFormatConverter
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "CreateFormatConverter" );
		goto cleanup;
	}


	hr = n_IWICBitmapDecoder->lpVtbl->GetFrame
	(
		         n_IWICBitmapDecoder,
		         0,
		(void*) &n_IWICBitmapFrameDecode
	);

	if ( FAILED( hr ) )
	{
//n_posix_debug_literal( "GetFrame" );
		goto cleanup;
	}


	UINT sx = 0;
	UINT sy = 0;
	n_IWICBitmapFrameDecode->lpVtbl->GetSize
	(
		 n_IWICBitmapFrameDecode,
		&sx, &sy
	);

	WICPixelFormatGUID n_WICPixelFormatGUID;
	n_IWICBitmapFrameDecode->lpVtbl->GetPixelFormat
	(
		 n_IWICBitmapFrameDecode,
		&n_WICPixelFormatGUID
	);


	n_IWICFormatConverter->lpVtbl->Initialize
	(
		         n_IWICFormatConverter,
		(void*)  n_IWICBitmapFrameDecode,
		        &GUID_WICPixelFormat32bppPBGRA,
		         WICBitmapDitherTypeNone,
		         NULL,
		         0.0,
		         WICBitmapPaletteTypeCustom
	);


	UINT bytesPerPixel = 4;
	UINT stride        = sx * bytesPerPixel;
	UINT size          = stride * sy;

	n_bmp_free( bmp );
	n_bmp_new( bmp, sx,sy );

	n_IWICFormatConverter->lpVtbl->CopyPixels
	(
		        n_IWICFormatConverter,
		        NULL,
		        stride,
		        size,
		(void*) N_BMP_PTR( bmp )
	);

	n_bmp_flush_mirror( bmp, N_BMP_MIRROR_UPSIDE_DOWN );

	ret = FALSE;


	cleanup:

	if ( n_IWICBitmapFrameDecode != NULL ) { n_IWICBitmapFrameDecode->lpVtbl->Release( n_IWICBitmapFrameDecode ); }
	if ( n_IWICFormatConverter   != NULL ) { n_IWICFormatConverter  ->lpVtbl->Release( n_IWICFormatConverter   ); }
	if ( n_IWICBitmapDecoder     != NULL ) { n_IWICBitmapDecoder    ->lpVtbl->Release( n_IWICBitmapDecoder     ); }
	if ( n_IWICImagingFactory    != NULL ) { n_IWICImagingFactory   ->lpVtbl->Release( n_IWICImagingFactory    ); }


	CoUninitialize();


	return ret;
}




#endif // _H_NONNON_WIN64_WIC

