
:Init

@echo off

REM     MinGW64 : -Wno-maybe-uninitialized : stupid errors happen (never resolvable)
REM     MinGW64 : -march=x86-64-v3 : fulfill Windows11 spec

set     warn=-Wall -Werror -Wno-maybe-uninitialized
set      opt=-O3
set     tune=-march=x86-64-v3

set lib_w32=-lcomctl32 -limm32 -lversion -lvfw32 -lwinmm -ldwmapi -luxtheme
set lib_ole=-lole32 -loleaut32 -ld3d9
set lib_net=-lwininet
set lib_oss=-ljpeg -lz
set lib_all=%lib_w32% %lib_ole% %lib_net% %lib_oss%


:Main

@echo on

windres -i %name%.rc -o rc.o
gcc %debug% %warn% %opt% %tune% -c %name%.c -o obj.o
gcc -mwindows -s -mthreads obj.o rc.o -o %name%.tmp %lib_all%


:ErrorChecker

@echo off

if errorlevel 1 goto :Error


:Patch

@echo off

if exist %name%.exe del %name%.exe
if errorlevel 1 goto :Error

ren %name%.tmp %name%.exe
if errorlevel 1 goto :Error

goto :Exit


:Error

if exist %name%.tmp del %name%.tmp

@echo off

pause


:Exit

@echo off

if exist *.o del *.o


